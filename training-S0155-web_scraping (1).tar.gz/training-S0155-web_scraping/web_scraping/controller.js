var CP=require('./middleware/sql')
var config = require("./initConf").get();
var constants=require('./util/constants.js');
var queries=constants.queries;
var errors=constants.errors;
constants=constants.constants;
function convertLocalDateToUTC(date) {
    const timestamp = Date.UTC(
        date.getFullYear(),
        date.getMonth(),
        date.getDate(),
        date.getHours(),
        date.getMinutes(),
        date.getSeconds(),
        date.getMilliseconds(),
    );
    return new Date(timestamp);
}
var storeRegistration=function(data,response,res){
    var token=Math.random().toString(36).split('.')[1];
    if(token){
        CP.query(queries.DELETE_OLD_REGIDS,[data.regid],function(err,res1){
            CP.query(queries.INSERT_TOKEN,[data.username,token,data.regid],function(err,res){
                sendResponse(response,codes.SUCCESS,{token:token})
            })
        })
    }
    else
        sendResponse(response,codes.AUTH_ERROR,{success:false});
}

var login = function(data, response) {
    CP.query(queries.LOGIN, [data.username, data.password], function(err, res) {
        if (!err && res && res.length > 0) {
            storeRegistration(data, response, res);
        } else
            sendResponse(response, codes.AUTH_ERROR, {success: false })
    })
}
var forgotpassword=function(data,response){
    var password=Math.random().toString(16).substring(2,10);
    CP.query(queries.RESET_PASS,[password,data.emailID],function(err,res){
        if(err)       
            return sendResponse(response,codes.DATABASE_ERROR,{success:false});
        else if(res.affectedRows==0)
            return   sendResponse(response,codes.SUCCESS,{success:false,Reason:errors[2],ReasonCode:2});
        email.sendEmail(password,data.emailID,function(err,res){
            if(err)
                sendResponse(response,codes.DATABASE_ERROR,{success:false});
            sendResponse(response,codes.SUCCESS,{success:true});
        })
    })
}
var logout=function(data,response){
    CP.query(queries.LOGOUT,[data.loginId,data.regid],function(err,res){
        sendResponse(response,codes.SUCCESS,{success:true})
    })
}
var updateRegID=function(data,response){
    CP.query(queries.UPDATE_REG_ID,[data.newID,data.token],function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        if(res.affectedRows==0)
            return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:7,Reason:errors[7]});
        sendResponse(response,codes.SUCCESS,{success:true});
    })
}
var signup=function(data,response){
    CP.query(queries.SIGN_UP_EMAIL_CHECK,[data.emailID],function(err,res){
        if(err)
            sendResponse(response,codes.DATABASE_ERROR,{success:false});
        else if(res.length>0)
            sendResponse(response,codes.SUCCESS,{success:false,Reason:errors[1],ReasonCode:1});
        else{
            CP.query(queries.NEW_USER,[data.username,data.emailID,data.password,new Date(0)],function(err,res){
                if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false});   
                sendResponse(response,codes.SUCCESS,{success:true});
            })
        }
    })
}
var weatherData=function(data,response){
	var startDate=new Date(data.startDate)
    var endDate=new Date(data.endDate)
    startDate=convertLocalDateToUTC(startDate)
    endDate=convertLocalDateToUTC(endDate)
    var params=[startDate,endDate]
    var query=queries.WEATHERSELECT
    if(data.source){
    	params.push(constants.source_names[data.source])
    	query=query+'and source = ?'
    }
    CP.query(query,params, function(err, res) {
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        else if(!res)
            return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
        return sendResponse(response,codes.SUCCESS,{success:true,result:res});
    })
}
var mapping={
	'/login': {
        model:login,
        fields:['username','password','regid']
    },
    '/logout':{
        model:logout,
        fields:['regid'],
        authCheck:true,
    },
    '/signUP':{
        model:signup,
        fields:['emailID','username','password']
    },
    '/forgotPswd':{
        model:forgotpassword,
        fields:['emailID']
    },
    '/updateRegID':{
        model:updateRegID,
        authCheck:true,
        fields:['newID']
    },
    '/weatherData':{
        model:weatherData,
        fields:['startDate','endDate'],
        authCheck:true,
    },
}
function sendResponse(res, code,result) {
    res.status(code).send(JSON.stringify(result));
}
const codes = {
    AUTH_ERROR: 401,
    INVALID_DATA: 400,
    SUCCESS: 200,
    NOT_FOUND:404,
    DATABASE_ERROR:503
}
var contoroller={};
contoroller.authCheck=function (req,res,next) {
    if(!mapping[req.path].authCheck)
        return next();
    if(!req || !req.headers || !req.headers.token )
        return sendResponse(res,codes.AUTH_ERROR,{success:false})
    CP.query(queries.TOKEN_CHECK,[req.headers.token],function(err,result){
        if(!err&&result&&result.length>0){
            if(req.body){
                req.body.loginId=result[0].loginId
            }
            req.body.token=req.headers.token;
            next()
        }
        else 
            sendResponse(res,codes.AUTH_ERROR,{success:false})
    })
}
var validate=function(data,fields){
    var valid=true;
    for(var i in fields)
        if(!data.hasOwnProperty(fields[i])){
            valid=false;
            break;
        }
    return valid;
}
contoroller.do=function(req,res){
	console.log('---->',req.body)
    var mapper=mapping[req.path]
    var body=req.body
    if(!validate(body,mapper.fields))
        return sendResponse(res,codes.INVALID_DATA,{success:false})
    mapper.model(body,res,req.path)
}
module.exports=contoroller;