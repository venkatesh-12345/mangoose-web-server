var cheerio = require("cheerio")
var CP = require('./middleware/sql')
var fs = require("fs")
var json2csv = require("json2csv").Parser
var constants = require('./util/constants.js');
var queries = constants.queries;
var errors = constants.errors;
constants = constants.constants;
var params = []
const puppeteer = require('puppeteer');
var urls = constants.urls
var degreeText = constants.degreeText
var BeafortScale = constants.BeafortScale

function convertLocalDateToUTC(date) {
    const timestamp = Date.UTC(
        date.getFullYear(),
        date.getMonth(),
        date.getDate(),
        date.getHours(),
        date.getMinutes(),
        date.getSeconds(),
        date.getMilliseconds(),
    );
    return new Date(timestamp);
}

function url_data($, url, name, callback) {
    try {
        var timeex = null,
            speed = null,
            angle = null,
            gust = null,
            windspeedError = null,
            windangleError = null,
            nintyspeed = null,
            nintyangle = null
        if (name == 'Zhunan_Windmill') {
            timeex = $('div[id="UpdatePanel2"] > p > span[id="Label3"]').text().split(' ')
            var meridien = timeex[1]
            timeex = new Date(timeex[0] + ' ' + timeex[2])
            if (meridien == '下午'){
                timeex = new Date(timeex.setHours( timeex.getHours() + 12 ))
            }
            timeex = convertLocalDateToUTC(timeex)
            timeex = new Date(timeex - 8 * 60 * 60 * 1000)
            nintyspeed=$('div[id="UpdatePanel2"] > p > span[id="Label2"]').text().replace(/[^0-9\.]+/g, "")
            nintyspeed=nintyspeed?parseFloat(nintyspeed)* 1.94384 : null
            speed=$('div[id="UpdatePanel2"] > p > span[id="Label8"]').text().replace(/[^0-9\.]+/g, "")
            speed=speed?parseFloat(speed)* 1.94384 : null         
            nintyangle = $('div[id="UpdatePanel2"] > p > span[id="Label6"]').text().replace(/[^0-9\.]+/g, "")
            nintyangle=nintyangle?parseFloat(nintyangle) : null
            angle = $('div[id="UpdatePanel2"] > p > span[id="Label10"]').text().replace(/[^0-9\.]+/g, "")
            angle=angle?parseFloat(angle) : null  
        } else if (name == 'Bali_Station') {
            var d = new Date();
            var n = d.getFullYear();
            var test_time = $('tr[data-cstname="八里"] > th[headers="time"]').text().split(' ')
            timeex = new Date(test_time[0] + '/' + n + ' ' + test_time[1])
            timeex = convertLocalDateToUTC(timeex)
            timeex = new Date(timeex - 8 * 60 * 60 * 1000)
            angle = degreeText[$('tr[data-cstname="八里"] > td[headers="w-1"]').text()]['degreeAngle']
            windangleError = degreeText[$('tr[data-cstname="八里"] > td[headers="w-1"]').text()]['windAngleError']
            gust = $('tr[data-cstname="八里"] > td[headers="w-3"] > span[class="wind_1 is-active"]').text() == '-' ? null : BeafortScale[parseFloat($('tr[data-cstname="八里"] > td[headers="w-3"] > span[class="wind_1 is-active"]').text())]['knots']
            speed = BeafortScale[parseFloat($('tr[data-cstname="八里"] > td[headers="w-2"] > span[class="wind_1 is-active"]').text())]['knots']
            windspeedError = BeafortScale[parseFloat($('tr[data-cstname="八里"] > td[headers="w-2"] > span[class="wind_1 is-active"]').text())]['windSpeedError']
        } else if (name == 'Bali_Port') {
            timeex = new Date($('span[id="ContentPlaceHolder1_SDate"]').text() + ' ' + $('span[id="ContentPlaceHolder1_W_Time1"]').text())
            timeex = convertLocalDateToUTC(timeex)
            timeex = new Date(timeex - 8 * 60 * 60 * 1000)
            speed =$('span[id="ContentPlaceHolder1_WS_value"]').text().replace(/[^0-9\.]+/g, "")
            speed = speed?parseFloat(speed) * 1.94384 : null
            angle = $(' span[id="ContentPlaceHolder1_WD_value"]').text().replace(/[^0-9\.]+/g, "")
            angle=angle?parseFloat(angle):null
        } else if (name == 'Taoyuan_Airport') {
            var values = $('pre').text().split('\n')
            var data1 = values[1].split(' ')
            var data2 = values[4].split(' ')
            timeex = new Date(values[0])
            data1 = data1[3]
            data2 = data2[3]
            var Gindex = data1.indexOf('G')
            if (Gindex >= 0){
                gust = parseInt(data1[Gindex + 1] + data1[Gindex + 2])
            }
            if (data1.indexOf('VRB') < 0)
                angle = parseInt(data1[0] + data1[1] + data1[2])
            speed = parseInt(data1[3] + data1[4])

            var Gindex2 = data2.indexOf('G')
            if (Gindex2 > -1)
                var gust2 = parseInt(data2[Gindex + 1] + data2[Gindex + 2])
            if (data2.indexOf('VRB') < 0)
                var angle2 = parseInt(data2[0] + data2[1] + data2[2])
            var speed2 = parseInt(data2[3] + data2[4])
            var timeex2=new Date(values[3])
            params.push([timeex2, speed2?speed2:null, angle2?angle2:null, name, gust2?gust2:null, windspeedError, windangleError, nintyspeed, nintyangle])
        } else if (name == 'Hsinchu_Buoy') {
            var d1=$('table[class="table table-striped version_5 two-th en-table"]')[0].children[3].children[1].children[1].children[0].data.replace(/[^0-9\/]+/g, "")
            var d2=$('table[class="table table-striped version_5 two-th en-table"]')[0].children[3].children[1].children[1].children[2].data.replace(/[^0-9\:]+/g, "")
            var d = new Date();
            var n = d.getFullYear();
            timeex = new Date(d1 + '/' + n + ' ' + d2)
            timeex = convertLocalDateToUTC(timeex)
            timeex = new Date(timeex - 8 * 60 * 60 * 1000)
            speed=$('table[class="table table-striped version_5 two-th en-table"]')[0].children[3].children[1].children[11].children[1].children[0].data
            speed=speed?parseFloat(speed) * 1.94384 : null
            gust=$('table[class="table table-striped version_5 two-th en-table"]')[0].children[3].children[1].children[15].children[1].children[0].data
            gust=gust?parseFloat(gust) * 1.94384 : null
            var direction=$('table[class="table table-striped version_5 two-th en-table"]')[0].children[3].children[1].children[13].children[2].children[0].data
            angle = degreeText[direction]['degreeAngle']
            windangleError = degreeText[direction]['windAngleError']
        } /*else if (name == 'Custom') {
            var d1=$('.windTable')[0].children[1].children[0].children[2].children[0].data.split(' ')
            var d2=$('.windTable')[0].children[1].children[0].children[3].children[0].data.split(' ')
            var d = new Date();
            var n = d.getFullYear();
            timeex = new Date(d1[0] + '/' + n + ' ' + d1[1])
            timeex = convertLocalDateToUTC(timeex)
            timeex = new Date(timeex - 8 * 60 * 60 * 1000)
            var timeex2 = new Date(d2[0] + '/' + n + ' ' + d2[1])
            timeex2 = convertLocalDateToUTC(timeex2)
            timeex2 = new Date(timeex2 - 8 * 60 * 60 * 1000)
            console.log(timeex,timeex2)
            var direction=$('tbody[id="StationData"]')[0].children[1].children[2].children[0]['attribs'].title
            speed=$('tbody[id="StationData"]')[0].children[1].children[3].children[2].data
            speed=speed?parseFloat(speed) * 1.94384 : null
            gust=$('tbody[id="StationData"]')[0].children[1].children[4].children[2].data
            gust=gust?parseFloat(gust) * 1.94384 : null
            var direction2=$('tbody[id="StationData"]')[0].children[1].children[5].children[0]['attribs'].title
            var speed2=$('tbody[id="StationData"]')[0].children[1].children[6].children[2].data
            speed2=speed2?parseFloat(speed2) * 1.94384 : null
            var gust2=$('tbody[id="StationData"]')[0].children[1].children[7].children[2].data
            gust2=gust2?parseFloat(gust2) * 1.94384 : null
        }*/
        if(timeex)
            params.push([timeex, speed, angle, name, gust, windspeedError, windangleError, nintyspeed, nintyangle])
        callback()
    } catch (e) {
        console.log(e);
    }

}

async function datascrap(url, i, callback) {
    try {
        const browser = await puppeteer.launch();
        const page = await browser.newPage();
        await page.goto(url, {
            waitUntil: 'load',
            timeout: 0
        });
        await page.waitForTimeout(5000);
        callback(await page.content(), i, url)
        await browser.close();
    } catch (e) {
        console.log(e);
    }
}
var url_fetch = function() {
    params = []
    var urlparams = Object.keys(urls)
    var i = 0
    scrapTime(urlparams[i], i)
    function scrapTime(prop, i) {
        console.log(i)
        datascrap(urls[prop], prop, function(html, name, url) {
            i++
            if (html) {
                let $ = cheerio.load(html)
                url_data($, url, name, function() {
                    if (i < urlparams.length)
                        scrapTime(urlparams[i], i)
                    else {
                        CP.query(queries.WEATHERINSERT,[params],function(err,res){
                            if(err)
                                console.log('mysql error',err)
                        })
                    }
                })
            } 
        })
    }
}
setTimeout(url_fetch,10*1000)
setInterval(url_fetch, 10 * 60 * 1000)
module.exports = url_fetch