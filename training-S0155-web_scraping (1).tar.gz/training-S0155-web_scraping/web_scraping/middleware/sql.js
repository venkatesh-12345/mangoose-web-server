var mysql = require("mysql");
var config = require("../initConf").get().Connections.Sql;
var sqlConnection = {};

var pool = mysql.createPool({
    connectionLimit: 3,
    host: config.Host,
    user: config.User,
    password: config.Password,
    database: config.Database,
    multipleStatements: true,
    charset : 'utf8mb4'
});

sqlConnection.query = function(query, params, callback, recCount) {
    console.log(" Am i come here ***********888")
    recCount = recCount ? recCount : 0;
    pool.getConnection(function(err, conn) {
        console.log(" did i get conn", err)
        if (err)
            sqlConnection.query(query, params, callback, ++recCount);
        else
            conn.query(query, params, function(err, result) {
                console.log(" query", err)
                conn.release();
                if (!err)
                    return callback(null, result);
                if (err.fatal)
                    return sqlConnection.query(query, params, callback, ++recCount);
                callback(err, null);
            });
    });
};
console.log("Reached at the end of sql.js")
module.exports = sqlConnection;
