var http = require('http');
var express = require('express');
var eSession = require('express-session'),
    bodyParser = require('body-parser');
var controller=require('./controller.js')
var scrapData=require('./scrapingData.js')
var config=require('./initConf').get()
var app = express()
    .use(bodyParser.urlencoded({
        extended: true
    }))
    .use(eSession({
        secret: 'WeB$cR@pInG',
        resave: true,
        saveUninitialized: true
    }));
var server = require('http').Server(app);

server.listen(config.Port);
var session = {};
app.get('/', function(req, res) {
    res.send('hello world')
});
var controllerReqs=['/login','/signUP','/logout','/weatherData']
app.post(controllerReqs,controller.authCheck, function(req,res){
    controller.do(req,res);
})
app.post('/', function(req,res){
    var data=req.body;
     if (data &&data.token) {
        res.status(200).send('ok');
    } else {
        res.status(400).send('error');
    }
    //needs to be implemented
})
app.get('*', function(req, res) {
    return res.redirect('/');
    res.end();
})