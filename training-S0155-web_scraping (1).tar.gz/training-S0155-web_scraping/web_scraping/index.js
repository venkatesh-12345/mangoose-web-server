var cheerio = require("cheerio")
var fs = require("fs")
var json2csv = require("json2csv").Parser
const puppeteer = require('puppeteer');

var default_mobile = 'http://140.96.175.47/ds/Default_mobile.aspx'
var OBS = 'https://www.cwb.gov.tw/V8/E/W/OBS_Station.html?ID=C0AD1'
var urls = ['http://140.96.175.47/ds/Default_mobile.aspx',
    'https://www.cwb.gov.tw/V8/E/W/OBS_Station.html?ID=C0AD1',
    'https://isohe.ihmt.gov.tw/Station/mobile/port/Taipei.aspx'
]

function url_data($, url) {
    var params = []
    if (url == 'http://140.96.175.47/ds/Default_mobile.aspx') {
        var timeex = new Date($('div[id="UpdatePanel2"] > p > span[id="Label3"]').text().replace('下午', ''))
        params.push(timeex)
        params.push($('div[id="UpdatePanel2"] > p > span[id="Label2"]').text().replace(/[^0-9\.]+/g, ""))
        params.push($('div[id="UpdatePanel2"] > p > span[id="Label8"]').text().replace(/[^0-9\.]+/g, ""))
        params.push($('div[id="UpdatePanel2"] > p > span[id="Label6"]').text().replace(/[^0-9\.]+/g, ""))
        params.push($('div[id="UpdatePanel2"] > p > span[id="Label10"]').text().replace(/[^0-9\.]+/g, ""))
    } else if (url == 'https://www.cwb.gov.tw/V8/E/W/OBS_Station.html?ID=C0AD1') {
        var d = new Date();
        var n = d.getFullYear();
        var test_time = $('tr[data-cstname="八里"] > th[headers="time"]').text().split(' ')
        params.push(new Date(test_time[0] + '/' + n + ' ' + test_time[1]))
        params.push($('tr[data-cstname="八里"] > td[headers="w-1"]').text())
        params.push($('tr[data-cstname="八里"] > td[headers="w-2"] > span[class="wind_1 is-active"]').text())
        params.push($('tr[data-cstname="八里"] > td[headers="w-3"] > span[class="wind_1 is-active"]').text())
    } else if (url == 'https://isohe.ihmt.gov.tw/Station/mobile/port/Taipei.aspx') {
        params.push($('span[id="ContentPlaceHolder1_WS_value"]').text().replace(/[^0-9\.]+/g, ""))
        params.push($(' span[id="ContentPlaceHolder1_WD_value"]').text().replace(/[^0-9\.]+/g, ""))
        params.push($('span[id="ContentPlaceHolder1_W_Time1"]').text())
    }
    for (var i in params)
        console.log(url, "------>", params[i])
}

async function datascrap(url, callback) {
    try {
        const browser = await puppeteer.launch();
        const page = await browser.newPage();
        await page.goto(url, {
            waitUntil: 'load',
            timeout: 0
        });
        await page.waitForTimeout(5000);
        callback(await page.content(), url)
        await browser.close();
    } catch (e) {
        console.log(e);
    }
}
setInterval(function() {
    for (var i in urls) {
        datascrap(urls[i], function(html, url) {
            if (html) {
                let $ = cheerio.load(html)
                url_data($, url)
            }
        })
    }
}, 30 * 1000)