/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var testInput = nconf.get('updateDevice');
var CLEAR_DB = nconf.get('CLEAR_DB');
var responseMaker = require('./extraFiles/responseMaker');
require('./extraFiles/almondConsumer');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

describe('Device Update Tests : ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                console.log('==================== ---------- : ', AUTH);
                done();
            }
        });
    });
    it('case where device value gets successfully updated', function (done) {
        this.timeout(20000);
        var options = {
            method: 'POST',
            url: URL + '/UpdateDeviceIndex',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'Update': [{
                        'AlmondMAC': testEnv.almondMAC,
                        'ID': testInput.validDevice.devID,
                        'Index': testInput.validDevice.devIndex,
                        'Value': testInput.validDevice.Value
                    }]
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true, dynamic:true});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            expect(response.statusCode).to.equal(200);
            console.log(JSON.stringify(body));
            expect(body.success).to.equal(true);
            expect(body.Result[0].success).to.equal(true);
            expect(body.Result[0].AlmondMAC).to.equal(testEnv.almondMAC);
            expect(body.Result[0].ID + '').to.equal(testInput.validDevice.devID);
            expect(body.Result[0].Index + '').to.equal(testInput.validDevice.devIndex);
            expect(body.Result[0].Value).to.equal(testInput.validDevice.Value);
            expect(body.Result[0].success + '').to.equal('true');
            done();
        });
    });
    if (testEnviron === 'standaloneEnv') {
        it('case where device value gets successfully updated no dynamic', function (done) {
            this.timeout(20000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateDeviceIndex',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'Update': [{
                            'AlmondMAC': testEnv.almondMAC,
                            'ID': testInput.validDevice.devID,
                            'Index': testInput.validDevice.devIndex,
                            'Value': testInput.validDevice.Value
                        }]
                },
                json: true
            };
            if (testEnviron === 'standaloneEnv')
                responseMaker.setProperties({success: true, dynamic: false});

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body));
                expect(body.success).to.equal(true);
                expect(body.Result[0].success).to.equal(true);
                expect(body.Result[0].AlmondMAC).to.equal(testEnv.almondMAC);
                expect(body.Result[0].ID + '').to.equal(testInput.validDevice.devID);
                expect(body.Result[0].Index + '').to.equal(testInput.validDevice.devIndex);
                expect(body.Result[0].Value).to.equal(testInput.validDevice.Value);
                expect(body.Result[0].success + '').to.equal('true');
                done();
            });
        });
        it('case where device value gets successfully, different dynamic', function (done) {
            this.timeout(20000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateDeviceIndex',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'Update': [{
                            'AlmondMAC': testEnv.almondMAC,
                            'ID': testInput.validDevice.devID,
                            'Index': testInput.validDevice.devIndex,
                            'Value': testInput.validDevice.Value
                        }]
                },
                json: true
            };
            if (testEnviron === 'standaloneEnv')
                responseMaker.setProperties({success: true, dynamic: true, sameDynamic: false});

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                // Result is not dependent on the dynamic.
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body));
                expect(body.success).to.equal(true);
                expect(body.Result[0].success).to.equal(true);
                expect(body.Result[0].AlmondMAC).to.equal(testEnv.almondMAC);
                expect(body.Result[0].ID + '').to.equal(testInput.validDevice.devID);
                expect(body.Result[0].Index + '').to.equal(testInput.validDevice.devIndex);
                expect(body.Result[0].Value).to.equal(testInput.validDevice.Value);
                expect(body.Result[0].success + '').to.equal('true');
                done();
            });
        });
    }
    it('case where we try to update device value with its actual value', function (done) {
        this.timeout(15000);
        var options = {
            method: 'POST',
            url: URL + '/UpdateDeviceIndex',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'Update': [{
                        'AlmondMAC': testEnv.almondMAC,
                        'ID': testInput.validDevice.devID,
                        'Index': testInput.validDevice.devIndex,
                        'Value': testInput.validDevice.Value
                    }]
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:false, reason:"Same Value Received"});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            expect(response.statusCode).to.equal(200);
            console.log(JSON.stringify(body));
            expect(body.success + '').to.equal('true');
            expect(body.Result[0].AlmondMAC + '').to.equal(testEnv.almondMAC);
            expect(body.Result[0].ID + '').to.equal(testInput.validDevice.devID);
            expect(body.Result[0].Index + '').to.equal(testInput.validDevice.devIndex);
            expect(body.Result[0].Value).to.equal(testInput.validDevice.Value);
            expect(body.Result[0].success + '').to.equal('false');
            expect(body.Result[0].reason).to.equal('Same Value Received');
            done();
        });
    });
    it('case where the almond has no access to the device anymore', function (done) {// NEW
        this.timeout(15000);
        var options = {
            method: 'POST',
            url: URL + '/UpdateDeviceIndex',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {'Update': [
                    {
                        'AlmondMAC': testInput.invalidDevice.almondMAC,
                        'ID': testInput.invalidDevice.devID,
                        'Index': testInput.invalidDevice.devIndex,
                        'Value': testInput.invalidDevice.Value
                    }
                ]},
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:false,reason:"Invalid ID"});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log('####### ', body);
            expect(response.statusCode).to.equal(200);
            expect(body.Result[0].success).to.equal(false);
            done();
        });
    });
    it('Wrong almondMAC case', function (done) {
        this.timeout(15000);
        var options = {
            method: 'POST',
            url: URL + '/UpdateDeviceIndex',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'Update': [{
                        'AlmondMAC': 12345,
                        'ID': testInput.validDevice.devID,
                        'Index': testInput.validDevice.devIndex,
                        'Value': testInput.validDevice.Value
                    }]
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:false, reason:"Same Value Received"});

        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
