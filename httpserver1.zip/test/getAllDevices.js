/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var CLEAR_DB = nconf.get('CLEAR_DB');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

var sortByKey = function (array, key) {
    return array.sort(function (a, b) {
        var x = a[key];
        var y = b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
};

describe('GetAllDevices tests: ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function (err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                done();
            }
        });
    });
    it('Success testcase', function (done) {
        this.timeout(5000);
        var options = {
            method: 'GET',
            url: URL + '/GetAllDevices',
            headers: {
                'content-type': TYPE_X,
                'cache-control': 'no-cache',
                authorization: AUTH
            }
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.success + '').to.equal('true');
            expect(body.hasOwnProperty('Result')).to.equal(true);
            expect(body.Result.hasOwnProperty(testEnv.almondMAC)).to.equal(true);
            expect(body.Result[testEnv.almondMAC].status).to.equal('1');
            expect(body.Result[testEnv.almondMAC].name).to.equal(testEnv.almondName);
            expect(body.Result[testEnv.almondMAC].version).to.equal(testEnv.almondVersion);
            expect(body.Result[testEnv.almondMAC].hasOwnProperty('Devices')).to.equal(true);
            // change the asserts
            if (testEnviron !== 'productionEnv') {
                body.Result[testEnv.almondMAC].Devices = sortByKey(body.Result[testEnv.almondMAC].Devices, 'DeviceID');
                expect(body.Result[testEnv.almondMAC].Devices[0].DeviceID + '').to.equal('1');
                expect(body.Result[testEnv.almondMAC].Devices[0].DeviceName + '').to.equal('first thermostat');
                expect(body.Result[testEnv.almondMAC].Devices[0].DeviceType + '').to.equal('7');
                expect(body.Result[testEnv.almondMAC].Devices[0].AssociationTimeStamp + '').to.equal('null');
                expect(body.Result[testEnv.almondMAC].Devices[1].DeviceID + '').to.equal('2');
                expect(body.Result[testEnv.almondMAC].Devices[1].DeviceName + '').to.equal('main table light');
                expect(body.Result[testEnv.almondMAC].Devices[1].DeviceType + '').to.equal('4');
                expect(body.Result[testEnv.almondMAC].Devices[1].AssociationTimeStamp + '').to.equal('null');
                
            }
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
