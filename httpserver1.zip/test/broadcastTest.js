var assert  = require("assert");
var testConfig = require('./TestConfigs/testConfig');
var redisConn = require('../database/redis/redisConnector');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var URL = nconf.get('httpUrl');
const ALMOND_MAC = testEnv.almondMAC;
const KEY = 'MDECAQACBgC+tzKxhQIDAQABAgYAh8eMiSECAw4taQIDDXO9AgMFOukCAwnJrQIDCxf0';

function sendToHttp(body,callback){
	var request = require("request");
	var options = { 
	  method: 'POST',
	  url: URL + '/Broadcast',
	  headers: 
	   { //'postman-token':  '737139df916988a9f1c75cd90c8a2e69c19f3d96' ,
	     'cache-control': 'no-cache',
	     'content-type': 'application/json',
	     },
	  body: 
	   {
			AlmondMAC: testEnv.almondMAC,
			Payload	 : '{"CommandType":"AddScene","AlmondMAC":"' + testEnv.almondMAC + '","MobileInternalIndex":286930897,"Scenes":{"Name":"1","VoiceCompatible":false,"SceneEntryList":[{"ID":0,"Index":1,"Value":"home"}]}}',
			Command  : 1062,
			To 		 : '[Mobile]',
			Key      : KEY
	   },
	  json: true 
	};

	if(body)
	{
		options.body = body;
	}

	request(options, function (error, response, body) {
		callback(error,response,body)
		});
}

describe('Broadcaster Test',function(){
    before(function (done) {
        this.timeout(5000);
        if (testEnviron !== 'productionEnv') {
            redisConn.query('set', KEY, '1', function(err) {
                if(err) return done(err);
                redisConn.query('hmset', 'AL_'+ALMOND_MAC, ['server', "S12"], function(err) {
                    if(err) return done(err);
                    done();
                });
            });
        } else
            done();
    });
	it('Broadcast To Almond',function(done){
		
		var body = {
			AlmondMAC: ALMOND_MAC,
			Payload	 : '{"CommandType":"AddScene","AlmondMAC":"' + ALMOND_MAC + '","MobileInternalIndex":286930897,"Scenes":{"Name":"1","VoiceCompatible":false,"SceneEntryList":[{"ID":0,"Index":1,"Value":"home"}]}}',
			Command  : 1062,
			To 		 : ['Almond'],
			Key      : KEY
		}
		sendToHttp(body,function(err,response,body){
			if(!err && response &&  body)
			{
				console.log(body);
				assert.equal(body,'{"Success: true"}')
				done();
			}
			else{
				assert.equal(1,-1)
				done();
			}
		})
	})

	it('Broadcast To Mobile',function(done){
		var body = {
			AlmondMAC: ALMOND_MAC,
			Payload	 : '{"CommandType":"AddScene","AlmondMAC":"' + ALMOND_MAC + '","MobileInternalIndex":286930897,"Scenes":{"Name":"1","VoiceCompatible":false,"SceneEntryList":[{"ID":0,"Index":1,"Value":"home"}]}}',
			Command  : 1062,
			To 		 : ['Mobile'],
			Key      : KEY
		}
		sendToHttp(body,function(err,response,body){
			if(!err && response &&  body)
			{
				console.log(body);
				assert.equal(body,'{"Success: true"}')
				done();
			}
			else{
				assert.equal(1,-1)
				done();
			}
		})
	})

	it('Broadcast To Notification',function(done){
		var body = {
			AlmondMAC: ALMOND_MAC,
			Payload	 : '{"CommandType":"AddScene","AlmondMAC":"' + ALMOND_MAC + '","MobileInternalIndex":286930897,"Scenes":{"Name":"1","VoiceCompatible":false,"SceneEntryList":[{"ID":0,"Index":1,"Value":"home"}]}}',
			Command  : 1062,
			To 		 : ['Notification'],
			Key      : KEY
		}
		sendToHttp(body,function(err,response,body){
			if(!err && response &&  body)
			{
				console.log( body);
				assert.equal(body,'{"Success: true"}')
				done();
			}
			else{
				assert.equal(1,-1)
				done();
			}
		})
	})

	// it('Broadcast To Mobile,Notification',function(done){
	// 	var body = {
	// 		AlmondMAC: ALMOND_MAC,
	// 		Payload	 : '{"CommandType":"AddScene","AlmondMAC":"' + ALMOND_MAC + '","MobileInternalIndex":286930897,"Scenes":{"Name":"1","VoiceCompatible":false,"SceneEntryList":[{"ID":0,"Index":1,"Value":"home"}]}}',
	// 		Command  : 1062,
	// 		To 		 : ['Mobile','Notification'],
	// 		Key      : KEY
	// 	}
	// 	sendToHttp(body,function(err,response,body){
	// 		if(!err && response &&  body)
	// 		{
	// 			console.log(body);
	// 			assert.equal(body,'{"Success: true"}')
	// 			done();
	// 		}
	// 		else{
	// 			assert.equal(1,-1)
	// 			done();
	// 		}
	// 	})
	// })
})