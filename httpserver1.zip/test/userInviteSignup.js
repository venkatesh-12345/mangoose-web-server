var request = require("request");
var bcrypt = require("bcrypt");
var redis = require("redis");
var assert = require("assert");
var rediClient = redis.createClient(6379, "127.0.0.1");
var nconf = require("nconf");
require('./TestConfigs/configTestEnviron');
var URL = nconf.get('httpUrl');
var CP = require("../database/sql/sqlQuery");
var UserID = "987654";
var sUserID = "9872563";
var sEmailID = "newUser@securifi.com";
var testConsumer = require("./Subscriptions/testConsumer");
var AlmondMAC = 2839174152;
var assertFunction;
testConsumer.on("data", function(data) {
    assertFunction(data);
});

function addRedis(mac, callback) {
    rediClient.hmset("AL_" + mac, ["server", "R@", "status", 1], callback);
}
function insertUser(data, callback) {
    bcrypt.genSalt(10, function(err, salt) {
        bcrypt.hash(data.Password, salt, function(err, hash) {
            data.Password = hash;
            var query =
                "INSERT into ?? (UserID, EmailID, Password, EmailValidated, ValidationToken) Values(?, ?, ?, ?, ?) on duplicate key update EmailID=values(EmailID),UserID=values(UserID),Password=values(Password)";
            var params = ["Users", data.UserID, data.EmailID, data.Password, 0, data.ValidationToken];
            CP.queryFunction(query, params, callback);
        });
    });
}
function deleteUser(data, callback) {
    CP.queryFunction("delete from Users where UserID  IN(?)", [data.UserID], callback);
}
function deleteAUser(data, callback) {
    CP.queryFunction("delete from AlmondUsers where AlmondMAC=?", [data.AlmondMAC], callback);
}
function insertAlmondUser(data, callback) {
    CP.queryFunction(
        "insert into AllAlmondPlus (AlmondMAC,AlmondID,ProductType) values(?,?,?) on duplicate key update AlmondMAC=values(AlmondMAC)",
        [data.AlmondMAC, 1, "Testing"],
        function(e, res) {
            if (e) return console.log("er in insert", e);
            CP.queryFunction(
                "insert into AlmondUsers (AlmondMAC,userID, ownership, LongSecret, StaticDeviceListHash) Values(?, ?, ?, ?, ?) on duplicate key update AlmondMAC=values(AlmondMAC),userID=values(userID)",
                [data.AlmondMAC, data.UserID, "P", "ss", "ssss"],
                function(e, res) {
                    console.log("in add aUser*****", e, res);
                    callback(null, null);
                }
            );
        }
    );
}
function insertInvite(data, callback) {
    CP.queryFunction("select * from InvitedEmails where EmailID=? and UserID=? and AlmondMAC=?",[data.EmailID, UserID, AlmondMAC],function(err,res){
        if(res.length==0){
            CP.queryFunction("insert into InvitedEmails (EmailID,UserID,AlmondMAC) values(?,?,?)", [data.EmailID, UserID, AlmondMAC], callback);
        }
        else 
            callback(null,true);
    })
}
function deletesUser(callback) {
    CP.queryFunction("delete from AlmondSecondaryUsers where AlmondMAC=?", AlmondMAC, callback);
}
describe("SignUp with UserInvite tests", function() {
    this.timeout(200000);
    before(function(done) {
        insertUser({ UserID: UserID, EmailID: "abcd@securifi.com", Password: "000000" }, function(e, res) {
            console.log("in insertUserr", e, res);
            insertAlmondUser({ AlmondMAC: AlmondMAC, UserID: UserID }, function(e, res) {
                insertInvite({ EmailID: sEmailID }, function(e, invite) {
                    console.log("e,res in invite", e, invite);
                    addRedis(AlmondMAC, function(e, res) {
                        console.log("in redis", e, res);
                        done();
                    });
                });
            });
        });
    });
    it("SignUp is successful", function(done) {
        var options = {
            method: "POST",
            url: URL + "/SignUp",
            body: {
                emailID: sEmailID,
                password: "000000"
            },
            json: true
        };
        console.log("options", options);
        request(options, function(error, response, body) {
            console.log("err", error, body);
            var query = "select * from Users where EmailID= ? ;";
            var params = [sEmailID];
            CP.queryFunction(query, params, function(err, rows) {
                if (err || !rows) console.log("err inselete", err, rows);
                sUserID = rows[0].UserID;
                CP.queryFunction("select * from AlmondSecondaryUsers where AlmondMAC=?", [AlmondMAC], function(e, sU) {
                    console.log("sU", sU);
                    assert.equal(sU.length, 1);
                    CP.queryFunction("select * from InvitedEmails where AlmondMAC=?", [AlmondMAC], function(e, invite) {
                        console.log("Invite", e, invite);
                        assert.equal(invite.length, 0);
                        rediClient.hgetall("AL_" + AlmondMAC, function(e, res) {
                            console.log("res in AL_", res);
                            assert.equal(res["SUSER_" + sUserID], 1);
                            rediClient.hgetall("UID_" + sUserID, function(e, res) {
                                console.log("res UID_", res);
                                assert.equal(res["SMAC_" + AlmondMAC], 1);
                                done();
                            });
                        });
                    });
                });
            });
        });
        assertFunction = function(data) {
            console.log("data", data);
            assert.equal(data.command, 2222);
            assert.equal(JSON.parse(data.payload).CommandType, "UserInviteRequest");
            assert.equal(JSON.parse(data.payload).AlmondMAC, AlmondMAC);
        };
    });
    it("Invite  again after delete", function(done) {
        insertInvite({ EmailID: sEmailID }, function(er, res) {
            var options = {
                method: "POST",
                url: URL + "/SignUp",
                body: {
                    emailID: sEmailID,
                    password: "000000"
                },
                json: true
            };
            console.log("options", options);
            request(options, function(error, response, body) {
                console.log("err", error, body);
                var query = "select * from Users where EmailID= ? ;";
                var params = [sEmailID];
                CP.queryFunction(query, params, function(err, rows) {
                    if (err || !rows) console.log("err inselete", err, rows);
                    sUserID = rows[0].UserID;
                    CP.queryFunction("select * from AlmondSecondaryUsers where AlmondMAC=?", [AlmondMAC], function(e, sU) {
                        console.log("sU", sU);
                        assert.equal(sU.length, 1);
                        CP.queryFunction("select * from InvitedEmails where AlmondMAC=?", [AlmondMAC], function(e, invite) {
                            console.log("Invite", e, invite);
                            assert.equal(invite.length, 0);
                            rediClient.hgetall("AL_" + AlmondMAC, function(e, res) {
                                console.log("res in AL_", res);
                                assert.equal(res["SUSER_" + sUserID], 1);
                                rediClient.hgetall("UID_" + sUserID, function(e, res) {
                                    console.log("res UID_", res);
                                    assert.equal(res["SMAC_" + AlmondMAC], 1);
                                    done();
                                });
                            });
                        });
                    });
                });
            });
            assertFunction = function(data) {
                console.log("data", data);
                assert.equal(data.command,2222);
                assert.equal(JSON.parse(data.payload).CommandType,'UserInviteRequest');
                assert.equal(JSON.parse(data.payload).AlmondMAC,AlmondMAC)
            };
        });
    });

    afterEach(function(done) {
        deleteUser({ UserID: [sUserID] }, function(e, res) {
            done();
        });
    });

    after(function(done) {
        deleteAUser({ AlmondMAC: AlmondMAC }, function(e, res) {
            deleteUser({ UserID: [UserID, sUserID] }, function(e, res) {
                deletesUser(function(e, re) {
                    rediClient.del("AL_" + AlmondMAC, function(e, res) {
                        console.log("res", res);
                        done();
                    });
                });
            });
        });
    });
});
