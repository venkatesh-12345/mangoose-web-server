var data_driven = require('data-driven');
var chai = require('chai');
var assert = chai.assert
var alexa = require("../../controllers/alexa.js");
var redisStore = require("../../database/redis/redisStore.js");

// //Non supported Alexa device
// //Non supported Action in Lights
// //Value 0,
// //Value max when increase
// //Value min when decrease
// //Value greater than when increment
// //Value less than max when decrement.

// 3 lights
// //Success for both increment and decrement for all 3 devices.

// 3 thermostats
// //Thermostat SetTemperature
// //Less than maximum
// //More than maximum
// //Thermostat off
// //Nest thermostat offline, emergency heat, away mode
// //Thermostat Auto mode
// //Thermostat heat mode
// //Thermostat cool mode

// 3 thermostats
// //Thermostat AdjustTemperature
// //Adjust less than minimum
// //Adjust more than maximum
// //Thermostat off
// //Thermostat Auto mode
// //Thermostat heat mode
// //Thermostat cool mode
// //Value not found.

// other error Messages.

// Alexa:
// check correct request formats in AlexaRequest



describe('Alexa', function() {
    describe('TurnOn', function() {
        data_driven(require("./util/turnOn").input, function() {
            it('should  {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                        result=JSON.parse(result); 
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual( result, ctx.expected,"Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log("  and result here", result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('TurnOff', function() {
        data_driven(require("./util/turnOff").input, function() {
            it('should  {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('AdjustBrightness', function() {
        data_driven(require("./util/adjustBrightness").input, function() {
            it('should  {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    
    describe('SetBrightness', function() {
        data_driven(require("./util/setBrightness").input, function() {
            it('should {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                   var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
     describe('AdjustTemperature', function() {
        data_driven(require("./util/adjustTemp").input, function() {
            it('should {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('SetTemperature', function() {
        data_driven(require("./util/setTemp").input, function() {
            it('should {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('Lock', function() {
        data_driven(require("./util/lock").input, function() {
            it('should  {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('UnLock', function() {
        data_driven(require("./util/unlock").input, function() {
            it('should  {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('SetMode', function() {
        data_driven(require("./util/setMode").input, function() {
            it('should {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('SetColor', function() {
        data_driven(require("./util/setColor").input, function() {
            it('should {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('SetColorTemperature', function() {
        data_driven(require("./util/setColorTemperature").input, function() {
            it('should {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    describe('ReportState', function() {
        data_driven(require("./util/reportState").input, function() {
            it('should {description} {deviceName}', function(ctx, done) {
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
     describe('validate Error', function() {
        data_driven(require("./util/validate").input, function() {
            it('should {description} {deviceName}', function(ctx, done) {
                //console.log(ctx.device.INDEXES)
                redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                    var res={}
                    res.status=function(code){
                        console.log(code);
                        return this;
                    }
                    res.send=function(result){
                         result=JSON.parse(result);
                        console.log(ctx.expectedError,ctx.expected,result);
                        if (ctx.expectedError)
                            assert.deepEqual(ctx.expectedError, result, "Error for unsupported Devices")
                        else if (ctx.expected){
                            for(var i in result.commandList)
                                delete result.commandList[i].MobileInternalIndex
                            delete result.toAlmond
                            assert.deepEqual(ctx.expected, result, "Index and Values are correct")
                        }
                        //assert.equal(ctx.expected, result)
                        console.log(" e, and result here",  result)
                        done()
                    }
                    alexa.do({body:ctx.input},res);
                });
            })
        })
    })
    
});

