var multiline = require('multiline'),
COLOR_DIMMABLE = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "132":{ 
          "DeviceValues":{  
             "1":{  
               "Name":"SWITCH MULTILEVEL",
               "Value":"150"
             },
              "2":{  
               "Name":"SWITCH BINARY",
               "Value":"false"
             },
             "3":{  
               "Name":"HUE",
               "Value":"170"
             },
             "4":{  
               "Name":"SATURATION",
               "Value":"176"
             },
             "5":{  
               "Name":"COLOR_TEMPERATURE",
               "Value":"4000"
             }
          }
       }
   }
 }
 	*/
});
exports.INDEXES=COLOR_DIMMABLE;