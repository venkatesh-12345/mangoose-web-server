var multiline = require('multiline'),
BINARY_SWITCH = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "15":{ 
          "DeviceValues":{  
             "1":{  
               "Name":"LOCK_STATE",
               "Value":"0"
             }
          }
       }
   }
 }
 	*/
});
exports.INDEXES=BINARY_SWITCH;