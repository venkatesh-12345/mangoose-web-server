var multiline = require('multiline'),
thermostat = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "17":{ 
          "DeviceValues":{  
             "0":{"Name":"SECURITYDEVICE","Value":"0","Type":"118","EndPoint":"0","CommandClassID":"-1","CommandIndex":"-1"},
                "1":{"Name":"SENSOR MULTILEVEL","Value":"84.4","Type":"25","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"},
                "2":{"Name":"THERMOSTAT MODE","Value":"Cool","Type":"35","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"},
                "3":{"Name":"THERMOSTAT OPERATING STATE","Value":"","Type":"36","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"},
                "4":{"Name":"THERMOSTAT SETPOINT HEATING","Value":"79","Type":"37","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"},
                "5":{"Name":"THERMOSTAT SETPOINT COOLING","Value":"59","Type":"38","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"},
                "6":{"Name":"THERMOSTAT FAN MODE","Value":"On Low","Type":"39","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"},
                "7":{"Name":"THERMOSTAT FAN STATE","Value":"","Type":"40","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"},
                "8":{"Name":"BATTERY","Value":"","Type":"50","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"},
                "9":{"Name":"UNITS","Value":"","Type":"0","EndPoint":"1","CommandClassID":"-1","CommandIndex":"-1"}
          }
       }
   }
 }
 	*/
});
exports.INDEXES=thermostat;