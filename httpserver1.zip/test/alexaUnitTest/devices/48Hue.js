var multiline = require('multiline'),
HUE = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "148":{ 
          "DeviceValues":{  
             "1":{  
               "Name":"HUE_BRIDGE_ID",
               "Value":"001788FFFE1A712D"
             },
              "2":{  
               "Name":"SWITCH BINARY",
               "Value":"false"
             },
             "3":{  
               "Name":"HUE",
               "Value":"25535"
             },
             "4":{  
               "Name":"SATURATION",
               "Value":"170"
             },
             "5":{  
               "Name":"SWITCH MULTILEVEL",
               "Value":"194"
             },
             "6":{  
               "Name":"EFFECT",
               "Value":"none"
             },
             "7":{  
               "Name":"COLOUR_MODE",
               "Value":"hs"
             },
             "8":{  
               "Name":"HUE_BULB_ID",
               "Value":"1"
             },
             "9":{  
               "Name":"USER_NAME",
               "Value":"d8a3a12eaefbf262a35e023607b9f"
             },
             "10":{  
               "Name":"REACHABLE",
               "Value":"true"
             }
          }
       }
   }
 }
 	*/
});
exports.INDEXES=HUE;