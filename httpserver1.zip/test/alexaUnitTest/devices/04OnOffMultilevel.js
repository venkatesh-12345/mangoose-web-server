var multiline = require('multiline'),
ONOFFMULTILEVEL = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "14":{ 
          "DeviceValues":{  
             "1":{  
               "Name":"Dimmer",
               "Value":"79"
             },
              "2":{  
               "Name":"Binary",
               "Value":"true"
             }
        
          }
       }
   }
 }
 	*/
});
exports.INDEXES=ONOFFMULTILEVEL;