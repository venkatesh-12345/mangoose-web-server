var multiline = require('multiline'),
BINARY_SENSOR = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "13":{ 
          "DeviceValues":{  
             "1":{  
               "Name":"Binary",
               "Value":"true"
             },
              "2":{  
               "Name":"Battery",
               "Value":"45"
             },
             "3":{  
               "Name":"Tampered",
               "Value":"true"
             }
          }
       }
   }
 }
 	*/
});
exports.INDEXES=BINARY_SENSOR;