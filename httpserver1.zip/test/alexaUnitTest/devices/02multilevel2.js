var multiline = require('multiline'),
MULTILEVEL = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "12":{ 
          "DeviceValues":{  
             "1":{  
               "Name":"Multilevel",
               "Value":"45"
             }
          }
       }
   }
 }
 	*/
});
exports.INDEXES=MULTILEVEL;