var multiline = require('multiline'),
BINARY_SWITCH = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "129":{ 
          "DeviceValues":{  
             "1":{  
               "Name":"TEMPERATURE",
               "Value":"87"
             }
          }
       }
   }
 }
 	*/
});
exports.INDEXES=BINARY_SWITCH;