var multiline = require('multiline'),
thermostat = multiline(function() {
 /*
 	{  
   "CommandType":"DynamicDeviceAdded",
   "AlmondMAC": "2020201",
   "HashNow":"1",
   "Action":"add",
   "Devices":{  
       "162":{ 
           "DeviceValues":{  
              "0":{  
                 "Name":"SECURITYDEVICE",
                 "Value":"0",
                 "Type":"118",
                 "EndPoint":"0",
                 "CommandClassID":"-1",
                 "CommandIndex":"-1"
              },
              "1":{  
                 "Name":"SENSOR MULTILEVEL",
                 "Value":"85.8",
                 "Type":"25",
                 "EndPoint":"1",
                 "CommandClassID":"-1",
                 "CommandIndex":"-1"
              },
              "2":{  
                 "Name":"THERMOSTAT MODE",
                 "Value":"Auto",
                 "Type":"35",
                 "EndPoint":"1",
                 "CommandClassID":"-1",
                 "CommandIndex":"-1"
              },
              "3":{  
                 "Name":"THERMOSTAT OPERATING STATE",
                 "Value":"",
                 "Type":"36",
                 "EndPoint":"1",
                 "CommandClassID":"-1",
                 "CommandIndex":"-1"
              },
              "4":{  
                 "Name":"THERMOSTAT SETPOINT HEATING",
                 "Value":"84",
                 "Type":"37",
                 "EndPoint":"1",
                 "CommandClassID":"-1",
                 "CommandIndex":"-1"
              },
              "5":{  
                 "Name":"THERMOSTAT SETPOINT COOLING",
                 "Value":"77",
                 "Type":"38",
                 "EndPoint":"1",
                 "CommandClassID":"-1",
                 "CommandIndex":"-1"
              }
            }
        }
    }
  }
 	*/
});
exports.INDEXES=thermostat;