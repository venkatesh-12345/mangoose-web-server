/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 var data_driven = require('data-driven');

var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('../dbForTest/accountManager');
var dbmodifier = require('../dbForTest/dbmodifier');
var nconf = require('nconf');
require('../TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var testInputs = nconf.get('activateScene');
var CLEAR_DB = nconf.get('CLEAR_DB');
var responseMaker = require('../extraFiles/responseMaker');
require('../extraFiles/almondConsumer');
var redisStore = require("../../database/redis/redisStore.js");
console.log(testEnv);
var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

describe('AlexaMultiRequest tests : ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                done();
            }
        });
    });
    data_driven(require("./util/multiRequest").input, function() {
        it('should  {description} {deviceName}', function(ctx, done) {
            this.timeout(10000);
            console.log(ctx.device.INDEXES)
            redisStore.add(JSON.parse(ctx.device.INDEXES), function(error, out) {
                var options = {
                    method: 'POST',
                    url: URL + '/alexa',
                    headers: {
                        'content-type': TYPE_JSON,
                        'cache-control': 'no-cache',
                        authorization: AUTH
                    },
                    body: ctx.body,
                    json: true
                };
                if (testEnviron === 'standaloneEnv')
                            responseMaker.setProperties({success:true, dynamic:true, sameDynamic:false});

                request(options, function (error, response, body) {
                    if (error)
                        done(error);
                    expect(response.statusCode).to.equal(200);
                    console.log(JSON.stringify(body));
                    delete body.MobileInternalIndex;
                    assert.deepEqual(body,ctx.expected,'true');
                    done();
                });
            });
        });
    });
});
