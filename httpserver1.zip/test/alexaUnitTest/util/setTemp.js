exports.input= [{
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetTargetTemperature", deviceType: 4, almondMAC: 2020201, deviceId: 14,targetValue: 2}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32ColorDimmableLight'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetTargetTemperature", deviceType: 32, almondMAC: 2020201, deviceId: 132,targetValue: 75 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch(type-1)',
        device: require('../devices/01BinarySwitch'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetTargetTemperature", deviceType: 1, almondMAC: 2020201, deviceId: 11 ,targetValue: 75}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch(type-3)',
        device: require('../devices/03BinarySensor'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetTargetTemperature", deviceType: 3, almondMAC: 2020201, deviceId: 13 ,targetValue: 75}
    },
    {
        description: 'return success for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expected: {success:true,value:75,mode:'COOL',previousValue:"59",commandList:  [{Index:5,Value:75,AlmondMAC:2020201,ID:17,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetTargetTemperature", deviceType: 7, almondMAC: 2020201, deviceId: 17,targetValue: 75}
    },
    {
        description: 'return error with message, "thermostat is off" for',
        deviceName: 'NestThermostat',
        device: require('../devices/57NestThermostat'),
        expectedError: { mode: 'off','success': false,'reasonCode': 11},
        input: { action: "SetTargetTemperature", deviceType: 57, almondMAC: 2020201, deviceId: 157,targetValue: 75}
    },
    {
        description: 'return success for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expected: {success:true,value:75,mode:'AUTO',previousValue:80,commandList:[{Index:4,Value:77,AlmondMAC:2020201,ID:162,CommandType:"UpdateDeviceIndex"},{Index:5,Value:74,AlmondMAC:2020201,ID:162,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: 75}
    },
    {
        description: 'return error Value Out of Range',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:  {"success":false,"reasonCode":8,"Value":2,"min":39,"max":95},
        input: { action: "SetTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 152,targetValue: 2}
    },
    {
        description: 'return Error Same Value  for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError: {'success': false,'reasonCode': 17,"Value":80,"mode":"AUTO","previousValue":80},
        input: { action: "SetTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: 80}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'DoorLock(type-5)',
        device: require('../devices/05DoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetTargetTemperature", deviceType: 5, almondMAC: 2020201, deviceId: 15,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetTargetTemperature", deviceType: 28, almondMAC: 2020201, deviceId: 128,  }
    },
];