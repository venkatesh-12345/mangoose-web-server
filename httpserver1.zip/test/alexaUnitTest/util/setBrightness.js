exports.input= [{
        description: 'return success for ',
        deviceName: 'MultiLevel Switch(type-2)',
        device: require('../devices/02multilevel2.js'),
        expected: {success:true,value:2,commandList:[{ Index: 1, Value: 2 ,AlmondMAC:2020201,ID:12,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetBrightness", deviceType: 2, almondMAC: 2020201, deviceId: 12, targetValue: 2 }
    }, {
        description: 'return success for',
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expected:  {success:true,value:2,commandList:[{ Index: 1, Value: 5 ,AlmondMAC:2020201,ID:14,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetBrightness", deviceType: 4, almondMAC: 2020201, deviceId: 14, targetValue: 2 }
    },
    {
        description: 'return Error light is off for',
        deviceName: 'ColorDimmableLight(type-4)',
        device: require('../devices/32ColorDimmableLight'),
        expected: {success:true,value:2,commandList:[{ Index: 1, Value: 5 ,AlmondMAC:2020201,ID:132,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetBrightness", deviceType: 32, almondMAC: 2020201, deviceId: 132, targetValue: 2 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch',
        device: require('../devices/01BinarySwitch'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetBrightness", deviceType: 1, almondMAC: 2020201, deviceId: 11, targetValue: 2 }
    },
    {
        description: 'return Error light is off for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expected:{success:true,value:2,commandList:[{ Index: 2,Value: 'true',AlmondMAC: 2020201,ID: 148,CommandType: 'UpdateDeviceIndex'},{ Index: 5, Value: 5 ,AlmondMAC:2020201,ID:148,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetBrightness", deviceType: 48, almondMAC: 2020201, deviceId: 148, targetValue: 2 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetBrightness", deviceType: 7, almondMAC: 2020201, deviceId: 17, targetValue: 2 }
    },
    {
        description: 'return error same value for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:  {'success': false,'reasonCode': 17, 'Value': 76 },
        input: { action: "SetBrightness", deviceType: 48, almondMAC: 2020201, deviceId: 148, targetValue: 76 }
    },
    {
        description: 'return error EndPoint UnReachable for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:  {'success': false,'reasonCode': 4},
        input: { action: "SetBrightness", deviceType: 48, almondMAC: 2020201, deviceId: 138, targetValue: 2 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'DoorLock(type-5)',
        device: require('../devices/05DoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetBrightness", deviceType: 5, almondMAC: 2020201, deviceId: 15,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetBrightness", deviceType: 28, almondMAC: 2020201, deviceId: 128,  }
    },
   
];