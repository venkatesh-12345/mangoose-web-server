exports.input= [{
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetThermostatMode", deviceType: 4, almondMAC: 2020201, deviceId: 14,targetValue: 'HEAT'}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32ColorDimmableLight'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetThermostatMode", deviceType: 32, almondMAC: 2020201, deviceId: 132,targetValue: 'HEAT' }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch(type-1)',
        device: require('../devices/01BinarySwitch'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetThermostatMode", deviceType: 1, almondMAC: 2020201, deviceId: 11 ,targetValue: 'HEAT'}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch(type-3)',
        device: require('../devices/03BinarySensor'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "SetThermostatMode", deviceType: 3, almondMAC: 2020201, deviceId: 13 ,targetValue: 'HEAT'}
    },
    {
        description: 'return success for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expected: [{Index:2,Value:'Heat'}],
        expected: {success:true,value:79,mode:"HEAT",commandList:[{ Index: 2, Value: 'Heat' ,AlmondMAC:2020201,ID:17,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetThermostatMode", deviceType: 7, almondMAC: 2020201, deviceId: 17,targetValue: 'HEAT'}
    },
    {
        description: 'return success for',
        deviceName: 'NestThermostat',
        device: require('../devices/57NestThermostat'),
        expected: {success:true,value:78,mode:"HEAT",commandList:[{ Index: 2, Value: 'heat' ,AlmondMAC:2020201,ID:157,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetThermostatMode", deviceType: 57, almondMAC: 2020201, deviceId: 157,targetValue: 'HEAT'}
    },
    {
        description: 'return success for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expected: [{Index:2,Value:'Heat'}],
        expected: {success:true,value:84,mode:"HEAT",commandList:[{ Index: 2, Value: 'Heat' ,AlmondMAC:2020201,ID:162,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetThermostatMode", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: 'HEAT'}
    },
    {
        description: 'return error EndPoint UnReachable for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:  {'success': false,'reasonCode': 4},
        input: { action: "SetThermostatMode", deviceType: 62, almondMAC: 2020201, deviceId: 152,targetValue: "HEAT"}
    },
    {
        description: 'return Error Same Value for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:{'success': false,'reasonCode': 17, 'Value': 80, 'mode': 'AUTO'},
        input: { action: "SetThermostatMode", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: 'AUTO'}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'DoorLock(type-5)',
        device: require('../devices/05DoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetThermostatMode", deviceType: 5, almondMAC: 2020201, deviceId: 15,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetThermostatMode", deviceType: 28, almondMAC: 2020201, deviceId: 128,  }
    },
];