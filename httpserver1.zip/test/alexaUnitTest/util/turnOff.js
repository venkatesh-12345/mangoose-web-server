exports.input= [{
        description: 'return success for ',
        deviceName: 'MultiLevel Switch(type-2)',
        device: require('../devices/02multilevel2.js'),
        expected: {success:true,value:"OFF",commandList:[{Index:1,Value:'0',AlmondMAC:2020201,ID:12,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "TurnOff", deviceType: 2, almondMAC: 2020201, deviceId: 12 }
    }, {
        description: 'return success for ',
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expected: {success:true,value:"OFF",commandList:[{Index:2,Value:'false',AlmondMAC:2020201,ID:14,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "TurnOff", deviceType: 4, almondMAC: 2020201, deviceId: 14}
    },
    {
        description: 'return error with message, "same value" for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32ColorDimmableLight'),
        expectedError: {'success': false,'reasonCode': 17, 'Value': 'OFF'},
        input: { action: "TurnOff", deviceType: 32, almondMAC: 2020201, deviceId: 132 }
    },
    {
        description: 'return error with message, "same value" for',
        deviceName: 'BinarySwitch(type-1)',
        device: require('../devices/01BinarySwitch'),
        expectedError:{'success': false,'reasonCode': 17,'Value': 'OFF'},
        input: { action: "TurnOff", deviceType: 1, almondMAC: 2020201, deviceId: 11 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch(type-3)',
        device: require('../devices/03BinarySensor'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "TurnOff", deviceType: 3, almondMAC: 2020201, deviceId: 13 }
    },
    {
        description: 'return error with message, "same value" for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:{'success': false,'reasonCode': 17,'Value': 'OFF'},
        input: { action: "TurnOff", deviceType: 48, almondMAC: 2020201, deviceId: 148}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "TurnOff", deviceType: 7, almondMAC: 2020201, deviceId: 17}
    },
    {
        description: 'return error EndPoint UnReachable for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:  {'success': false,'reasonCode': 4},
        input: { action: "TurnOff", deviceType: 48, almondMAC: 2020201, deviceId: 138 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'DoorLock(type-5)',
        device: require('../devices/05DoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "TurnOff", deviceType: 5, almondMAC: 2020201, deviceId: 15,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "TurnOff", deviceType: 28, almondMAC: 2020201, deviceId: 128,  }
    },
];