exports.input = [{
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-2)',
        device: require('../devices/02multilevel2.js'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "Lock", deviceType: 2, almondMAC: 2020201, deviceId: 12,  }
     }, {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "Lock", deviceType: 4, almondMAC: 2020201, deviceId: 14,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ColorDimmableLight(type-4)',
        device: require('../devices/32ColorDimmableLight'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "Lock", deviceType: 32, almondMAC: 2020201, deviceId: 132,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch',
        device: require('../devices/01BinarySwitch'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "Lock", deviceType: 1, almondMAC: 2020201, deviceId: 11,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "Lock", deviceType: 48, almondMAC: 2020201, deviceId: 148,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "Lock", deviceType: 7, almondMAC: 2020201, deviceId: 17,  }
    },
    {
        description: 'return error with message, "same value received" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expectedError: {'success': false,'reasonCode': 17,'Value': 'LOCKED'},
        input: { action: "Lock", deviceType: 28, almondMAC: 2020201, deviceId: 128,  }
    },
];