exports.input = [{
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-2)',
        device: require('../devices/02multilevel2.js'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColor", deviceType: 2, almondMAC: 2020201, deviceId: 12, targetValue: {"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524} }
     }, {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColor", deviceType: 4, almondMAC: 2020201, deviceId: 14, targetValue: {"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524} }
    },
    {
        description: 'return suceess for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32ColorDimmableLight'),
        expected: {success:true,value:{"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524},commandList:[{ Index: 1, Value: 166 ,AlmondMAC:2020201,ID:132,CommandType:"UpdateDeviceIndex"},{"AlmondMAC": 2020201, "CommandType": "UpdateDeviceIndex","ID": 132,"Index": 4,"Value": 182}, {"AlmondMAC": 2020201,"CommandType": "UpdateDeviceIndex", "ID": 132,"Index": 3,"Value": 248}]},
        input: { action: "SetColor", deviceType: 32, almondMAC: 2020201, deviceId: 132, targetValue: {"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524} }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch',
        device: require('../devices/01BinarySwitch'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColor", deviceType: 1, almondMAC: 2020201, deviceId: 11, targetValue: {"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524} }
    },
    {
        description: 'return suceess for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expected: {success:true,value:{"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524},commandList:[{ Index: 2,Value: 'true',AlmondMAC: 2020201,ID: 148,CommandType: 'UpdateDeviceIndex'},{ Index: 5, Value: 166 ,AlmondMAC:2020201,ID:148,CommandType:"UpdateDeviceIndex"},{"AlmondMAC": 2020201, "CommandType": "UpdateDeviceIndex","ID": 148,"Index": 4,"Value": 182}, {"AlmondMAC": 2020201,"CommandType": "UpdateDeviceIndex", "ID": 148,"Index": 3,"Value": 63806}]},
        input: { action: "SetColor", deviceType: 48, almondMAC: 2020201, deviceId: 148, targetValue: {"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524} }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColor", deviceType: 7, almondMAC: 2020201, deviceId: 17, targetValue: {"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524} }
    },
    {
        description: 'return error EndPoint UnReachable for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:  {'success': false,'reasonCode': 4},
        input: { action: "SetColor", deviceType: 48, almondMAC: 2020201, deviceId: 138, targetValue: {"hue": 350.5,"saturation": 0.7138,"brightness": 0.6524} }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'DoorLock(type-5)',
        device: require('../devices/05DoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColor", deviceType: 5, almondMAC: 2020201, deviceId: 15,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColor", deviceType: 28, almondMAC: 2020201, deviceId: 128,  }
    },
];