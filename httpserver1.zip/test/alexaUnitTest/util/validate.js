exports.input= [
    {
        description: 'return error Invalid Value for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:{'success': false,'reasonCode': 19},
        input: { action: "SetThermostatMode", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: 2}
    },
    {
        description: 'return error Invalid Value for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:  {'success': false,'reasonCode': 14},
        input: { action: "SetBrightness", deviceType: 48, almondMAC: 2020201, deviceId: 148, targetValue: "HEAT" }
    },
    {
        description: 'return error Invalid Value for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:{'success': false,'reasonCode': 14},
        input: { action: "AdjustTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: "HEAT"}
    },
    {
        description: 'return error Invalid Value for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:{'success': false,'reasonCode': 14},
        input: { action: "SetTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: "HEAT"}
    },
    {
        description: 'return error Value out of Range for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError: {'success': false,'reasonCode':8, Value:100,"min":39,"max":95},
        input: { action: "SetTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: 100}
    },
     {
        description: 'return error Invalid Value for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:  {'success': false,'reasonCode': 14},
        input: { action: "AdjustBrightness", deviceType: 48, almondMAC: 2020201, deviceId: 148, targetValue: "HEAT" }
    },
    {
        description: 'return error Value Out Of Range for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:   {'success': false,'reasonCode':16, Value:319},
        input: { action: "SetBrightness", deviceType: 48, almondMAC: 2020201, deviceId: 148, targetValue: 125 }
    },
];