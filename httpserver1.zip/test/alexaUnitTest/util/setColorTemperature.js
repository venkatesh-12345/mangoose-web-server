exports.input = [{
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-2)',
        device: require('../devices/02multilevel2.js'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColorTemperature", deviceType: 2, almondMAC: 2020201, deviceId: 12, targetValue: 5000 }
     }, {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColorTemperature", deviceType: 4, almondMAC: 2020201, deviceId: 14, targetValue: 5000 }
    },
    {
        description: 'return suceess for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32ColorDimmableLight'),
        expected: {success:true,value:5000,commandList:[{ Index: 5, Value: "5000" ,AlmondMAC:2020201,ID:132,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetColorTemperature", deviceType: 32, almondMAC: 2020201, deviceId: 132, targetValue: 5000 }
    },
    {
        description: 'return suceess for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32ColorDimmableLight'),
        expected: {success:true,value:5524,commandList:[{ Index: 1,Value: 255,AlmondMAC: 2020201,ID: 132,CommandType: 'UpdateDeviceIndex'},{ Index: 4, Value: 33, AlmondMAC: 2020201, ID: 132,CommandType: 'UpdateDeviceIndex'},{ Index: 3,Value: 21,AlmondMAC: 2020201,ID: 132,CommandType: 'UpdateDeviceIndex' },{ Index: 5, Value: "5524" ,AlmondMAC:2020201,ID:132,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "SetColorTemperature", deviceType: 32, almondMAC: 2020201, deviceId: 132, targetValue: 5500 }
    },
    {
        description: 'return suceess for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32light'),
        expected: {success:true,value:7042,commandList:[{ Index: 1,Value: 255,AlmondMAC: 2020201,ID: 132,CommandType: 'UpdateDeviceIndex'},{ Index: 4,Value: 13,AlmondMAC: 2020201,ID: 132,CommandType: 'UpdateDeviceIndex' },{ Index: 3,Value: 177,AlmondMAC: 2020201,ID: 132,CommandType: 'UpdateDeviceIndex'}]},
        input: { action: "SetColorTemperature", deviceType: 32, almondMAC: 2020201, deviceId: 132, targetValue: 7000 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch',
        device: require('../devices/01BinarySwitch'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColorTemperature", deviceType: 1, almondMAC: 2020201, deviceId: 11, targetValue: 5000 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColorTemperature", deviceType: 48, almondMAC: 2020201, deviceId: 148, targetValue: 5000 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColorTemperature", deviceType: 7, almondMAC: 2020201, deviceId: 17, targetValue: 5000 }
    },
    {
        description: 'return error EndPoint UnReachable for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expectedError:  {'success': false,'reasonCode': 5},
        input: { action: "SetColorTemperature", deviceType: 48, almondMAC: 2020201, deviceId: 138, targetValue: 5000 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'DoorLock(type-5)',
        device: require('../devices/05DoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColorTemperature", deviceType: 5, almondMAC: 2020201, deviceId: 15, targetValue: 5000 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "SetColorTemperature", deviceType: 28, almondMAC: 2020201, deviceId: 128, targetValue: 5000 }
    },
];