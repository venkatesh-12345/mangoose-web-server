exports.input= [{
        description: 'return success for',
        deviceName: 'MultiLevel Switch(type-2)',
        device: require('../devices/02multilevel2.js'),
        expected:{ success: true,power: 'ON',brightness: 45 },
        input: { action: "ReportState", deviceType: 2, almondMAC: 2020201, deviceId: 12 }
    }, 
    {
        description: 'return success for',        
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expected:{ success: true,power: 'ON',brightness: 31 },
        input: { action: "ReportState", deviceType: 4, almondMAC: 2020201, deviceId: 14}
    },
    {
        description: 'return success for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32ColorDimmableLight'),
        expected:{ success: true,power: 'OFF', brightness: 59, color: { hue: 240, saturation: 0.69, brightness: 0.59 }},
        input: { action: "ReportState", deviceType: 32, almondMAC: 2020201, deviceId: 132 }
    },
    {
        description: 'return success for',
        deviceName: 'ColorDimmableLight',
        device: require('../devices/32colorlight'),
        expected:{ success: true,power: 'OFF', brightness: 100,colorTemperatureInKelvin: 7042},
        input: { action: "ReportState", deviceType: 32, almondMAC: 2020201, deviceId: 132 }
    },
    {
        description: 'return success for',
        deviceName: 'BinarySwitch(type-1)',
        device: require('../devices/01BinarySwitch'),
        expected:{ success: true,power: 'OFF' },
        input: { action: "ReportState", deviceType: 1, almondMAC: 2020201, deviceId: 11 }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch(type-3)',
        device: require('../devices/03BinarySensor'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "ReportState", deviceType: 3, almondMAC: 2020201, deviceId: 13 }
    },
    {
        description: 'return success for',
        deviceName: 'Hue',
        device: require('../devices/48Hue'),
        expected:{ success: true,power: 'OFF',brightness: 76,color: { hue: 140, saturation: 0.67, brightness: 0.76 } },
        input: { action: "ReportState", deviceType: 48, almondMAC: 2020201, deviceId: 148}
    },
    {
        description: 'return success for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expected:{ success: true,mode: 'COOL',temp: { value: 59, scale: 'FAHRENHEIT' } },
        input: { action: "ReportState", deviceType: 7, almondMAC: 2020201, deviceId: 17}
    },
    {
        description: 'return thermostat is off error  for',
        deviceName: 'NestThermostat',
        device: require('../devices/57NestThermostat'),
        expected: { mode: 'off', reasonCode: 11, success: false },
        input: { action: "ReportState", deviceType: 57, almondMAC: 2020201, deviceId: 157}
    },
    {
        description: 'return success for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expected: { success: true,mode: 'AUTO',temp: { value: 80, scale: 'FAHRENHEIT' } },
        input: { action: "ReportState", deviceType: 62, almondMAC: 2020201, deviceId: 162}
    },
    {
        description: 'return error EndPoint UnReachable for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:  {'success': false,'reasonCode': 4},
        input: { action: "ReportState", deviceType: 62, almondMAC: 2020201, deviceId: 152}
    },
    {
        description: 'return success for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expected: { success: true, lockState: 'LOCKED' },
        input: { action: "ReportState", deviceType: 28, almondMAC: 2020201, deviceId: 128,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/27TemperatureSensor'),
        expected: { success: true, temperature: { value: 87, scale: 'FAHRENHEIT' } },
        input: { action: "ReportState", deviceType: 27, almondMAC: 2020201, deviceId: 127,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/29ZigbeeTemperatureSensor'),
        expected: { success: true, temperature: { value: 87, scale: 'FAHRENHEIT' } },
        input: { action: "ReportState", deviceType: 29, almondMAC: 2020201, deviceId: 129,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/49MultiSensor'),
        expected: { success: true, temperature: { value: 87, scale: 'FAHRENHEIT' } },
        input: { action: "ReportState", deviceType: 49, almondMAC: 2020201, deviceId: 149,  }
    },
];