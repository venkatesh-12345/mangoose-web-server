exports.input= [
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'MultiLevel Switch(type-4)',
        device: require('../devices/04OnOffMultilevel.js'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "AdjustTargetTemperature", deviceType: 4, almondMAC: 2020201, deviceId: 14,targetValue: 2}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch(type-1)',
        device: require('../devices/01BinarySwitch'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "AdjustTargetTemperature", deviceType: 1, almondMAC: 2020201, deviceId: 11 ,targetValue: 2}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'BinarySwitch(type-3)',
        device: require('../devices/03BinarySensor'),
        expectedError:{'success': false,'reasonCode': 5},
        input: { action: "AdjustTargetTemperature", deviceType: 3, almondMAC: 2020201, deviceId: 13 ,targetValue: 2}
    },
    {
        description: 'return success for',
        deviceName: 'Thermostat',
        device: require('../devices/07Thermostat'),
        expected:{success:true,value:61,mode:'COOL',previousValue:59,commandList: [{Index:5,Value:61 ,AlmondMAC:2020201,ID:17,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "AdjustTargetTemperature", deviceType: 7, almondMAC: 2020201, deviceId: 17,targetValue: 2}
    },
    {
        description: 'return error with message, "thermostat is off" for',
        deviceName: 'NestThermostat',
        device: require('../devices/57NestThermostat'),
        expectedError: { mode: 'off','success': false,'reasonCode': 11},
        input: { action: "AdjustTargetTemperature", deviceType: 57, almondMAC: 2020201, deviceId: 157,targetValue: 2}
    },
    {
        description: 'return success for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expected: {success:true,value:82,mode:'AUTO',previousValue:80,commandList:[{Index:4,Value:86,AlmondMAC:2020201,ID:162,CommandType:"UpdateDeviceIndex"},{Index:5,Value:79 ,AlmondMAC:2020201,ID:162,CommandType:"UpdateDeviceIndex"}]},
        input: { action: "AdjustTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: 2}
    },
    {
        description: 'return error EndPoint UnReachable for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:  {'success': false,'reasonCode': 4},
        input: { action: "AdjustTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 152,targetValue: 2}
    },
    {
        description: 'return error Value out of Range for',
        deviceName: 'ZenThermostat',
        device: require('../devices/62ZenThermostat'),
        expectedError:{'success': false,'reasonCode':8, Value:100,"max":95,"min":39},
        input: { action: "AdjustTargetTemperature", deviceType: 62, almondMAC: 2020201, deviceId: 162,targetValue: 20}
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'DoorLock(type-5)',
        device: require('../devices/05DoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "AdjustTargetTemperature", deviceType: 5, almondMAC: 2020201, deviceId: 15,  }
    },
    {
        description: 'return error with message, "Action Not Supported" for',
        deviceName: 'ZigbeeDoorLock',
        device: require('../devices/28ZigbeeDoorLock'),
        expectedError: {'success': false,'reasonCode': 5},
        input: { action: "AdjustTargetTemperature", deviceType: 28, almondMAC: 2020201, deviceId: 128,  }
    },
];