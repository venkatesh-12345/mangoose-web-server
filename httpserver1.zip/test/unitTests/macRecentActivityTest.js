var macActivity = require('../../database/model/macRecentActivity');
var assert = require('chai').assert;
var expect = require('chai').expect;
var moment = require('moment');
var loggerPoint = require('../../database/cassandra/cqlConnection');

// insert data into the cassandra database
var temp = {};
var fetchSize = 50;
const ALMOND_MAC = 123456789;
const DEV_ID = 12;
const CLI_ID = 875421;
const TIME = Date.now();
var date = moment.utc().utcOffset(0);
const CURR_DATE = date.format('YYYY-MM-DD');

var insert = function (data, table, callback) {
    var day = 0;//Math.floor(Math.random() * 3) + 0;
    var dateyear = data.dateyear;//moment(data.time).subtract(day,"days").format('YYYY-MM-DD');
    var error = null;
    var ip = '127.0.0.1';
    var query;
    var params = [];
    if (table === "dynamic_update_wifi_client")
        query = "insert into " + table + " (mac, client_mac, time , client_id , client_name , client_type , dateyear , mac_date , userid , value ) values " +
                "(" + data.mac + "," + data.client_mac + "," + data.time + "," + data.client_id + ",'" + data.client_name + "','" + data.client_type + "','" + dateyear + "','" + data.mac + ':' + dateyear + "','" + data.userid + "','" + data.value + "')";
    else if (table === "dynamic_update_log")
        query = "insert into " + table + " (mac, device_id , time , index_id , dateyear , device_name , type , index_name , mac_date , userid , value ) values " +
                "(" + data.mac + "," + data.device_id + "," + data.time + "," + data.index_id + ",'" + dateyear + "','" + data.device_name + "','" + data.device_type + "', '" + data.index_name + "','" + data.mac + ':' + dateyear + "','" + data.userid + "','" + data.value + "')";
    else if (table === 'dynamic_log') {
        query = "INSERT INTO " + table + " (mac, id, time, index_id, dateyear, name, type, index_name, client_id, mac_date, userid, value) VALUES (?,?,?,?,'" + data.dateyear + "',?,?,?,?,?,?,?);";
        params = [data.mac, data.id, data.time, data.index_id, data.name, data.type.toString(), data.index_name, data.client_id, data.mac + ":" + data.dateyear, data.userid, data.value]
    }
    //console.log(query);
    //console.log(JSON.stringify(params));
    loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
        if (error)
            console.log(error);
        else
            callback();
    });
};

function clearDB(mac, callback) {
    var query = "DELETE FROM dynamic_log WHERE mac = ? AND id IN (?,?);";
    var params = [mac, DEV_ID, CLI_ID];
    loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
        callback(error);
    });
}

function insertOneRecord(i, callback) {
    var devData = {
        mac: ALMOND_MAC,
        id: DEV_ID,
        time: TIME + i,
        index_id: 1,
        index_name: 'indexName#1',
        type: "20",
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: "device value"
    };
    //console.log(TIME+j);
    devData.name = 'name#' + devData.id;
    insert(devData, "dynamic_log", function () {
        //console.log("Insert Done");
        //callback();
    });
    var cliData = {
        mac: ALMOND_MAC,
        id: CLI_ID,
        time: TIME + i,
        index_id: 123456,
        client_id: 12,
        type: "30",
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: "client value"
    };
    cliData.name = 'name#' + cliData.id;
    insert(cliData, "dynamic_log", function () {
        //console.log("Insert Done");
        callback();
    });
}

var createDB = function (callback) {
    var nextItemIndex = 0;
    function iterator(err) {
        nextItemIndex++;
        if (nextItemIndex === 100) {
            callback(err);
        }
        else {
            if(nextItemIndex % 10 ===0)
                date.subtract(1,'day');
            insertOneRecord(nextItemIndex, function () {
                iterator();
            });
        }
    }
    insertOneRecord(nextItemIndex, function () {
        iterator();
    });
};

describe('MAC recent activity tests', function () {
    before(function (done) {
        this.timeout(15000);
        //require('./insertlogs');
        clearDB(ALMOND_MAC, function (err) {
            if(err)
                return done(err);
            createDB(done);
        });
    });

    it('case no data for MAC ', function (done) {
        this.timeout(5000);
        var noDataMAC = 54215421;
        clearDB(noDataMAC, function (err) {
            if (err)
                done(err);
            else
                macActivity.getRecentActivity(noDataMAC, fetchSize, {dateyear: CURR_DATE, pageState: null, type: "all"}, function (err, res) {
                    if (err || !res)
                        done(err);
                    else {
                        console.log('RESULT :: ', JSON.stringify(res));
                        var resDate = moment.utc().utcOffset(0).subtract(6, 'day').format('YYYY-MM-DD');
                        assert.deepEqual(res.dateyear, resDate, 'dateyear not equal');
                        assert.deepEqual(res.pageState, null, 'pageState failed');
                        assert.deepEqual(res.logs.length, 0, 'Failed at record count');
                        done();
                    }
                });
        });
    });
    
    it('case where data available for mac first query', function (done) {
        this.timeout(5000);
        macActivity.getRecentActivity(ALMOND_MAC, fetchSize, {type: "all"}, function (err, res) {
            if (err || !res)
                done(err);
            else {
                //console.log('RESULT :: ', JSON.stringify(res));
                assert.isBelow(res.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(res.pageState, null, 'pageState failed');
                assert.deepEqual(res.logs.length, fetchSize, 'Failed at record count');
                assert.equal(res.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.include([DEV_ID, CLI_ID], parseInt(res.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(res.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], res.logs[0].type, 'type mismatch');
                assert.include(["755624541"], res.logs[0].userid, 'userid mismatch');
                assert.include(["client value", "device value"], res.logs[0].value, 'value mismatch');
                done();
            }
        });
    });

    it('case where data available for mac', function (done) {
        this.timeout(5000);
        macActivity.getRecentActivity(ALMOND_MAC, fetchSize, {dateyear: CURR_DATE, pageState: null, type: "all"}, function (err, res) {
            if (err || !res)
                done(err);
            else {
                //console.log('RESULT :: ', JSON.stringify(res));
                assert.isBelow(res.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(res.pageState, null, 'pageState failed');
                assert.deepEqual(res.logs.length, fetchSize, 'Failed at record count');
                assert.equal(res.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.include([DEV_ID, CLI_ID], parseInt(res.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(res.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], res.logs[0].type, 'type mismatch');
                assert.include(["755624541"], res.logs[0].userid, 'userid mismatch');
                assert.include(["client value", "device value"], res.logs[0].value, 'value mismatch');
                done();
            }
        });
    });

    it('case where less data available for mac', function (done) {
        this.timeout(5000);
        var reqDate = moment.utc().utcOffset(0).subtract(9, 'day').format('YYYY-MM-DD');
        macActivity.getRecentActivity(ALMOND_MAC, fetchSize, {dateyear: reqDate, pageState: null, type: "all"}, function (err, res) {
            if (!err && res) {
                //console.log('RESULT :: ', JSON.stringify(res));
                assert.isBelow(res.dateyear, reqDate, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.deepEqual(res.pageState, null, 'pageState failed');
                assert.isBelow(res.logs.length, fetchSize, 'Failed at record count');
                assert.include([DEV_ID, CLI_ID], parseInt(res.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(res.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], res.logs[0].type, 'type mismatch');
                assert.include(["755624541"], res.logs[0].userid, 'userid mismatch');
                assert.include(["client value", "device value"], res.logs[0].value, 'value mismatch');
                done();
            } else
                console.log(' in else part');
        });
    });
    
    it('case query with the response dateyear and pageState ', function (done) {
        this.timeout(5000);
        macActivity.getRecentActivity(ALMOND_MAC, fetchSize, {type: "all"}, function (err, res) {
            if (err || !res)
                done(err);
            else {
                assert.isBelow(res.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(res.pageState, null, 'pageState failed');
                assert.deepEqual(res.logs.length, fetchSize, 'Failed at record count');
                assert.equal(res.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.include([DEV_ID, CLI_ID], parseInt(res.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(res.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], res.logs[0].type, 'type mismatch');
                assert.include(["755624541"], res.logs[0].userid, 'userid mismatch');
                assert.include(["client value", "device value"], res.logs[0].value, 'value mismatch');
                console.log('-------- proceeding with the second query -----------');
                macActivity.getRecentActivity(ALMOND_MAC, fetchSize, {dateyear: res.dateyear, pageState: res.pageState, type: "all"}, function (err, res) {
                    assert.isBelow(res.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                    assert.notDeepEqual(res.pageState, null, 'pageState failed');
                    assert.deepEqual(res.logs.length, fetchSize, 'Failed at record count');
                    assert.equal(res.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                    assert.include([DEV_ID, CLI_ID], parseInt(res.logs[0].id), 'ID mismatch');
                    assert.include([1, 123456], parseInt(res.logs[0].index_id), 'index_id mismatch');
                    assert.include(["20", "30"], res.logs[0].type, 'type mismatch');
                    assert.include(["755624541"], res.logs[0].userid, 'userid mismatch');
                    assert.include(["client value", "device value"], res.logs[0].value, 'value mismatch');
                    done();
                });
            }
        });
    });
    
    after(function (done) {
        clearDB(ALMOND_MAC, function (err) {
            done();
        });
    });
});
