var auth = require('../../database/model/authorization');
var assert = require('chai').assert;

describe('', function () {
    it('case 1', function (done) {
        auth.isValidUserForAlmond([4563219881], 10101123008, function(err, valid) {
            assert.deepEqual(valid, true, 'Falied primary user');
            done();
        });
    });
    it('case 2', function (done) {
        auth.isValidUserForAlmond([987654321], 10101123008, function(err, valid) {
            assert.deepEqual(valid, true, 'Falied secondary user');
            done();
        });
    });
    it('case 3', function (done) {
        auth.isValidUserForAlmond([4563219881,987654321], 10101123008, function(err, valid) {
            assert.deepEqual(valid, true, 'Falied secondary user');
            done();
        });
    });
});

