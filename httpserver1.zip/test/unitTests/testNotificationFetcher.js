var cassandra = require('cassandra-driver');
var moment = require('moment');
var assert = require('chai').assert;
var notificationFetcher = require('../database/model/notificationFetcher');
var loggerPoint = require('../../database/cassandra/cqlConnection');


describe('Testing getLogs for devices', function () {
    before(function (done) {
        this.timeout(5000);
        var query = 'DELETE from dynamic_update_log WHERE mac=1234567 AND device_id =9876543;';
        var date = '2017-05-30';
        loggerPoint.execute(query, function(err, res) {
            if(!err && res) {
                var queries = [{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , device_type , index_id, index_name, pk , mac_date , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","23","12","gBkSF","65","49","Temperature", null,"251176221163205:"+date,"755624541","99"]
                    },{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , device_type , index_id, index_name, pk , mac_date , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","23","3","NhKKs","38","39","Temperature",null,"251176221163205:"+date,"755624541","98"]
                    },{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , device_type , index_id, index_name, pk , mac_date , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","23","2","fWlrJ","84","87","Temperature",null,"251176221163205:"+date,"755624541","80"]
                    },{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , device_type , index_id, index_name, pk , mac_date , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","23","7","iDdKt","64","58","Temperature",null,"251176221163202:"+date,"755624541","23"]
                    },{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , device_type , index_id, index_name, pk , mac_date , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","23","15","ggEkx","52","62","Temperature",null,"251176221163200:"+date,"755624541","82"]
                    }
                ];
                loggerPoint.batch(queries, {prepare:true}, function(err, res) {
                    if(!err && res) {
                        done();
                    } else {
                        console.log(err);
                    }
                });
            } else {
                console.log(err);
            }
        });
    });
    it('undefined mac', function (done) {
        var req = {mac:undefined};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {error:'true'};
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for undefined mac');
            done();
        });
    });
    it('undefined device_id', function (done) {
        var req = {mac:undefined, device_id:undefined};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {error:'true'};
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for undefined device_id');
            done();
        });
    });
    it('invalid mac and device_id', function (done) {
        var req = {mac:'mac', device_id:'devId', requestId:8765};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {error:'true'};
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for invalid mac and device_id');
            done();
        });
    });
    it('with empty records', function (done) {
        var req = {mac:147258, device_id:852741, requestId:654321};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {logs:[], requestId:654321};
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for empty records');
            done();
        });
    });
    it('valid device case', function (done) {
        var req = {mac:1234567, device_id:23, requestId:654321};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {
                "logs":[
                    {"mac":"1234567","device_id":"23","device_name":"ggEkx","device_type":52,"index_id":62,"index_name":"Temperature","time":"15","value":"82"},
                    {"mac":"1234567","device_id":"23","device_name":"gBkSF","device_type":65,"index_id":49,"index_name":"Temperature","time":"12","value":"99"},
                    {"mac":"1234567","device_id":"23","device_name":"iDdKt","device_type":64,"index_id":58,"index_name":"Temperature","time":"7","value":"23"},
                    {"mac":"1234567","device_id":"23","device_name":"NhKKs","device_type":38,"index_id":39,"index_name":"Temperature","time":"3","value":"98"},
                    {"mac":"1234567","device_id":"23","device_name":"fWlrJ","device_type":84,"index_id":87,"index_name":"Temperature","time":"2","value":"80"}
                ],
                "requestId":654321
            };
            console.log('Result ==: ', res);
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for empty records');
            done();
        });
    });
});

describe('Testing getLogs for clients', function () {
    before(function (done) {
        this.timeout(5000);
        var query = 'DELETE from dynamic_update_log WHERE mac=1234567 AND device_id =9876543;';
        var date = '2017-05-30';
        loggerPoint.execute(query, function(err, res) {
            if(!err && res) {
                var queries = [{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , client_type , client_id, pk , mac_date , userid , value, index_id) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, 123)",
                        "params":["1234567","9876543","12","gBkSF","65","49",null,"251176221163205:"+date,"755624541","99"]
                    },{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , client_type , client_id, pk , mac_date , userid , value, index_id) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, 123)",
                        "params":["1234567","9876543","3","NhKKs","38","39",null,"251176221163205:"+date,"755624541","98"]
                    },{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , client_type , client_id, pk , mac_date , userid , value, index_id) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, 123)",
                        "params":["1234567","9876543","2","fWlrJ","84","87",null,"251176221163205:"+date,"755624541","80"]
                    },{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , client_type , client_id, pk , mac_date , userid , value, index_id) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, 123)",
                        "params":["1234567","9876543","7","iDdKt","64","58",null,"251176221163202:"+date,"755624541","23"]
                    },{
                        "query":"insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , client_type , client_id, pk , mac_date , userid , value, index_id) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?, ?, 123)",
                        "params":["1234567","9876543","15","ggEkx","52","62",null,"251176221163200:"+date,"755624541","82"]
                    }
                ];
                loggerPoint.batch(queries, {prepare:true}, function(err, res) {
                    if(!err && res) {
                        done();
                    } else {
                        console.log(err);
                    }
                });
            } else {
                console.log(err);
            }
        });
    });
    it('undefined client_mac', function (done) {
        var req = {type:'wifi_client', mac:1234567, client_mac:undefined};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {error:'true'};
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for undefined client_mac');
            req = {type:'wifi_client', mac:1234567, client_mac:'undefined'};
            notificationFetcher.getLogs(req, function(err, res) {
                exp = {error:'true'};
                assert.deepEqual(res, JSON.stringify(exp), 'Failed for undefined client_mac');
                done();
            });
        });
    });
    it('null client_mac', function (done) {
        var req = {type:'wifi_client', mac:1234567, client_mac:null};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {error:'true'};
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for null client_mac');
            req = {type:'wifi_client', mac:1234567, client_mac:'null'};
            notificationFetcher.getLogs(req, function(err, res) {
                exp = {error:'true'};
                assert.deepEqual(res, JSON.stringify(exp), 'Failed for null client_mac');
                done();
            });
        });
    });
    it('invalid mac and device_id', function (done) {
        var req = {type:'wifi_client', mac:'mac', client_mac:'cmac', requestId:8765};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {error:'true'};
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for invalid mac and device_id');
            req = {type:'wifi_client', mac:1234567, client_mac:654321};
            notificationFetcher.getLogs(req, function(err, res) {
                exp = {error:'true'};
                assert.deepEqual(res, JSON.stringify(exp), 'Failed for null client_mac');
                done();
            });
        });
    });
    it('with empty records', function (done) {
        var req = {type:'wifi_client', mac:147258, client_mac:'852741', requestId:654321};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {logs:[], requestId:654321};
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for empty records');
            done();
        });
    });
    it('valid client case', function (done) {
        var req = {mac:1234567, device_id:9876543, requestId:654321};
        notificationFetcher.getLogs(req, function(err, res) {
            var exp = {
                "logs":[{"mac":"1234567","device_id":"9876543","device_name":"ggEkx","device_type":null,"index_id":123,"index_name":null,"time":"15","value":"82"},
                    {"mac":"1234567","device_id":"9876543","device_name":"gBkSF","device_type":null,"index_id":123,"index_name":null,"time":"12","value":"99"},
                    {"mac":"1234567","device_id":"9876543","device_name":"iDdKt","device_type":null,"index_id":123,"index_name":null,"time":"7","value":"23"},
                    {"mac":"1234567","device_id":"9876543","device_name":"NhKKs","device_type":null,"index_id":123,"index_name":null,"time":"3","value":"98"},
                    {"mac":"1234567","device_id":"9876543","device_name":"fWlrJ","device_type":null,"index_id":123,"index_name":null,"time":"2","value":"80"}
                ],"requestId":654321
            };
            console.log('Result ==: ', res);
            assert.deepEqual(res, JSON.stringify(exp), 'Failed for empty records');
            done();
        });
    });
});