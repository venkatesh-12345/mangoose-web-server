var cassandra = require('cassandra-driver');
var moment = require('moment');
var assert = require('chai').assert;
var copydb = require('../scripts/copyClient2Device.js');
var loggerPoint = require('../database/cassandra/cqlConnection');
const CURR_DATE = moment.utc().utcOffset(0).format('YYYY-MM-DD');

describe('Testing copy client to device Database', function () {
    before(function (done) {
        this.timeout(5000);
        var query = 'DELETE from dynamic_update_wifi_client WHERE mac=1234567 AND client_mac =9876543;';
        var date = CURR_DATE;
        loggerPoint.execute(query, function(err, res) {
            if(!err && res) {
                var queries = [{
                        "query":"insert into dynamic_update_wifi_client (mac, client_mac , time , dateyear , client_name , client_type , client_id, pk , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","9876543","1496239130364","gBkSF","65","49",null,"755624541","99"]
                    },{
                        "query":"insert into dynamic_update_wifi_client (mac, client_mac , time , dateyear , client_name , client_type , client_id, pk , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","9876543","1496239129257","NhKKs","38","39",null,"755624541","98"]
                    },{
                        "query":"insert into dynamic_update_wifi_client (mac, client_mac , time , dateyear , client_name , client_type , client_id, pk , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","9876543","1496239125922","fWlrJ","84","87",null,"755624541","80"]
                    },{
                        "query":"insert into dynamic_update_wifi_client (mac, client_mac , time , dateyear , client_name , client_type , client_id, pk , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","9876543","1496239129860","iDdKt","64","58",null,"755624541","23"]
                    },{
                        "query":"insert into dynamic_update_wifi_client (mac, client_mac , time , dateyear , client_name , client_type , client_id, pk , userid , value) values (?, ?, ?, '"+date+ "', ?, ?, ?, ?, ?, ?)",
                        "params":["1234567","9876543","1496239130967","ggEkx","52","62",null,"755624541","82"]
                    }
                ];
                loggerPoint.batch(queries, {prepare:true}, function(err, res) {
                    if(!err && res) {
//                        query = "SELECT * FROM device_log where mac=;"
//                        loggerPoint.execute()
                        done();
                    } else {
                        console.log(err);
                    }
                });
            } else {
                console.log(err);
            }
        });
        
    });
    
    it('date with empty records', function (done) {
        var query = 'DELETE from dynamic_update_log WHERE mac=1234567 AND device_id =9876543;';
        var date = CURR_DATE;
        loggerPoint.execute(query, function(err, res) {
            if(!err && res) {
                copydb.totalUpdateTable('copyClient', function() {
                    var query = "select * from dynamic_update_log where mac=1234567 AND device_id =9876543 AND dateyear='"+ date + "';";
                    var exp = [];
                    loggerPoint.execute(query, {prepare:true}, function(err, res) {
                        if(!err && res) {
                            console.log(JSON.stringify(res.rows));
                            assert.deepEqual(JSON.stringify(res.rows), JSON.stringify(exp), 'Failed for valid case');
                            done();
                        }
                    });
                });
            }
        });
    });
    
    it('Valid case', function (done) {
        var date = CURR_DATE;
        copydb.totalUpdateTable('copyClient', function() {
            var query = "select * from dynamic_update_log where mac=1234567 and device_id=9876543";
            var exp = [{"mac":"1234567","device_id":"9876543","time":"1496239130967","index_id":123456,"client_id":"62","dateyear":"2017-05-29T18:30:00.000Z","device_name":"ggEkx","device_type":null,"index_name":null,"mac_date":"251176221163200:2017-05-30","pk":null,"type":"52","userid":"755624541","value":"82"},
                {"mac":"1234567","device_id":"9876543","time":"1496239130364","index_id":123456,"client_id":"49","dateyear":"2017-05-29T18:30:00.000Z","device_name":"gBkSF","device_type":null,"index_name":null,"mac_date":"251176221163205:2017-05-30","pk":null,"type":"65","userid":"755624541","value":"99"},
                {"mac":"1234567","device_id":"9876543","time":"1496239129860","index_id":123456,"client_id":"58","dateyear":"2017-05-29T18:30:00.000Z","device_name":"iDdKt","device_type":null,"index_name":null,"mac_date":"251176221163202:2017-05-30","pk":null,"type":"64","userid":"755624541","value":"23"},
                {"mac":"1234567","device_id":"9876543","time":"1496239129257","index_id":123456,"client_id":"39","dateyear":"2017-05-29T18:30:00.000Z","device_name":"NhKKs","device_type":null,"index_name":null,"mac_date":"251176221163205:2017-05-30","pk":null,"type":"38","userid":"755624541","value":"98"},
                {"mac":"1234567","device_id":"9876543","time":"1496239125922","index_id":123456,"client_id":"87","dateyear":"2017-05-29T18:30:00.000Z","device_name":"fWlrJ","device_type":null,"index_name":null,"mac_date":"251176221163205:2017-05-30","pk":null,"type":"84","userid":"755624541","value":"80"}
            ];
            loggerPoint.execute(query, {prepare:true}, function(err, res) {
                
                if(!err && res) {
                    console.log(JSON.stringify(res.rows));
                    assert.deepEqual(JSON.stringify(res.rows), JSON.stringify(exp), 'Failed for valid case');
                    done();
                }
            });
        });
    });
    
    
});
