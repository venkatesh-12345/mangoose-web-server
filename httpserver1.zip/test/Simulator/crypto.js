var crypto = require('crypto')
  ,  key =  new  Buffer([110, 204, 148, 237, 106, 144, 1, 61, 48, 175, 82, 13, 24, 119, 68, 47]);



function getIV (AlmondMAC, Uptime){
	var macArray = AlmondMAC.split('');
	var upTimeArray = Uptime.split('');
	var intArrayOfIV = [];
	for (var i =macArray.length; i < 16;i++){
		macArray.push('\0');
	}
	for (var i =upTimeArray.length; i < 16;i++){
		upTimeArray.push('\0');
	}



	for (var i =0; i < 16;i++){
		var macChar = 	macArray[i].charCodeAt(0);
		//console.log(macChar);
		var upTimeChar = 	upTimeArray[i].charCodeAt(0);
		// console.log(upTimeChar);
		// console.log(macChar+upTimeChar)
		// console.log(((macChar+upTimeChar) % 94) + 33);
		intArrayOfIV.push(((macChar+upTimeChar) % 94) + 33);
	}
	//console.log(intArrayOfIV);
	var IV = new Buffer (intArrayOfIV);
	return IV;
}
function Encrypt (pass,almond,uptime ){
	var iv = getIV(almond+'',uptime+'');
	cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
	
	var len = pass.length;
	var padSize = 16 - ((len + 16 - 1) % 16 + 1);
	for(var i = 0; i<padSize;i++){
		pass+='\0';
	}
	 var crypted = cipher.update(pass, 'utf-8', 'base64');
	crypted += cipher.final('base64');
	//var buf = new Buffer(crypted, 'base64');
	// console.log("This is the base 64 thing");
	 //console.log("crypted geetha: ", crypted);
	return crypted.toString();
}

function Decrypt (encrypted, almond , uptime){
	var realPass = ""
	try{
	var iv = getIV(almond+'',uptime+'');
	cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
	var decipher = crypto.createDecipheriv('aes-128-cbc', key, iv)
	decipher.setAutoPadding(false);
  	var buf = new Buffer(encrypted,'base64');
 	dCrypt = decipher.update(buf,'ascii');
	dCrypt+=decipher.final('ascii')
  	realPass = dCrypt;
  	for (var i =0; i < dCrypt.length ; i++){
  		 if(dCrypt.charCodeAt(i)== 0){
 		 	realPass = dCrypt.substring(0,i);
 			break;
  		 }
  	}
  	}catch(error){

		console.error(error);
		return "";
	}
	
    return realPass
}
//Encrypt('99999',251176217114456,90131);

// function EncryptDecrypt(){
// 		var iv = getIV('251176217032936','1100086');
	
// 	cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
// 	var text = '123'; // original password // if u dont 
// 	var len = text.length;
// 	var padSize = 16 - ((len + 16 - 1) % 16 + 1);
// 	for(var i = 0; i<padSize;i++){
// 		text+='\0';
// 	}
// 	console.log(text.length);

//  var crypted = cipher.update(text, 'utf-8', 'base64');

// crypted += cipher.final('base64');
// console.log("This is the base 64 thing");
// console.log(crypted);
// console.log( new Buffer(crypted,'base64').toString('ascii'));
// 	var decipher = crypto.createDecipheriv('aes-128-cbc', key, iv)
//   	var buf = new Buffer('judKKeMXCMOdHqvIsTA+YxLf27nEIuug5HttJvDyBkYO','base64');
//   	console.log(buf);

// 	var hexBuf = buf.toString('hex')
//   , decrypted = decipher.update(hexBuf, 'hex', 'utf-8');


// console.log("<<<<<<<<<<>>>>>>>>>>>>>>>>");
// console.log(decrypted);
// }




	//Decrypt('sB/GKRfZLgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=', 251176217114456, 90131);
// var encrypted = Encrypt('123', '251176217032936', '1100086');
// console.log("Encrypted value is",encrypted);
// console.log("realpass: ", Decrypt(encrypted,'251176217032936', '1100086'));
//console.log("this should work atleast: ", Decrypt("DbLZ1IuaWFtduvENVb2tlQQZMPmfJybEpo9+A4MZfCReN2NI0gyaXeWtIIEIbA0N80OyhdLrLMf9AZxtuyqtfQ==","251176217032936", "1100086"));


module.exports = Encrypt;
