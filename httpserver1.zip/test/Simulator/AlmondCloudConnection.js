var AlmondProtocol = require('@securificloud/cloud-protocols').Almond;
var Client = require('@securificloud/cloud-servers-clients').clients.ProtocoledClient;
var parseString = require('xml2js').parseString;
var util = require('util');

cloudConfigs = require('../TestConfigs/testConfig').almondConfig;

var EventEmitter = require('events').EventEmitter; 

function AlmondCloudConnection (modelF, almondMAC, longSecret, firmwareVersion, almondPlusID){
  this.model = modelF;
	this.mac = almondMAC;
	this.longSecret = longSecret;
	this.firmwareVersion =firmwareVersion;
	this.almondPlusID = almondPlusID;
	this.cloudAccepted = false;
  this._almondCloudConnection = undefined;
	this.createConnection();
}

util.inherits(AlmondCloudConnection, EventEmitter);

AlmondCloudConnection.prototype.send = function (commandType, command, CID) {
	if(this.cloudAccepted){
        if(CID==undefined){
	        this._almondCloudConnection.send({'Command':commandType,'Payload':JSON.stringify(command)});
        }
        else{
            this._almondCloudConnection.send({'Command':commandType, 'ICID':CID, 'Payload':JSON.stringify(command)})
        }
	}
}

AlmondCloudConnection.prototype.getLoginPayload = function (){
	return '<root><AlmondHello><AlmondplusMAC>'+this.mac+'</AlmondplusMAC><AlmondplusID>'+this.almondPlusID+'</AlmondplusID><LongSecret>'+this.longSecret+'</LongSecret><FirmwareVersion>'+this.firmwareVersion+'</FirmwareVersion></AlmondHello></root>'
}

AlmondCloudConnection.prototype.generateCommandForDeviceListHashCheck = function (){
    var hash = this.model.getHashNow('DEVICE');
    return JSON.stringify({"CommandType":"DeviceListHash","Action":"hash", "HashNow":"1234"});
}

AlmondCloudConnection.prototype.generateCommandForSceneListHashCheck = function(){
    var hash = this.model.getHashNow('SCENES');
    return JSON.stringify({"CommandType":"SceneListHash","Action":"hash", "HashNow":"1234"});
}

AlmondCloudConnection.prototype.generateCommandForClientListHashCheck = function(){
    var hash = this.model.getHashNow('CLIENTS');
    return JSON.stringify({"CommandType":"ClientListHash","Action":"hash","HashNow":"1234","RouterMode":"router"});
} 

AlmondCloudConnection.prototype.createConnection = function() {
  this._almondCloudConnection = new Client(cloudConfigs, AlmondProtocol);
  this._almondCloudConnection.connect();
  var self = this;
  this._almondCloudConnection.on('error', function(err) {
    console.log('CONNECTING CLOUD FAILED');
    console.log(err);
    self._almondCloudConnection.destroy();
     self.emit('error',err);
  });

  this._almondCloudConnection.on('packet', function(packet) {
    console.log('received packet..', self.mac, packet.Payload.toString(), packet.Command);
    if(packet.Command != 32 )
	    self.emit('packet',packet);
	else
	{
		// check if this is successfull or not
    
        var interval = setInterval(function() {
                  self._almondCloudConnection.send({
                    'Command':104,
                    'Payload':'<root><KeepAlive>KEEP_ALIVE</KeepAlive></root>'
                 });
                }, 1000*3*60);
        //devices
        var command = self.generateCommandForDeviceListHashCheck();
        console.log('sending this',self.mac, command);
        self._almondCloudConnection.send({
                'Command':1200,
                'Payload':command
             });
        //scenes
        command = self.generateCommandForSceneListHashCheck();
        console.log('sending this',self.mac,command);
        self._almondCloudConnection.send({
                'Command':1300,
                'Payload':command
             });
        //clients
        command = self.generateCommandForClientListHashCheck();
        console.log('sending this',self.mac,command);
        self._almondCloudConnection.send({
                'Command':1500,
                'Payload':command
             });
        var jsonDoc=undefined;
        parseString(packet.Payload.toString(), function (err, result) {
            jsonDoc = result;
        });
        if(jsonDoc['root']['AlmondHelloResponse'][0]['$']['success'] == 'true'){
            console.log("logged into almond successfully");
            self.cloudAccepted = true;
            self.emit('cloudconnected',true);

        }else{
            if(jsonDoc['root']['AlmondHelloResponse'][0]['Reason'] == 'No Affiliation'){
              console.log("Almond not Affiliated");
              console.log("EXITING ALMOND SIMULATOR");
            }
        }
	}
  });

   this._almondCloudConnection.on('connect', function() {
    console.log("connection to cloud established sending this: ", self.getLoginPayload());
     self._almondCloudConnection.send({
      Command: 31,
      Payload: self.getLoginPayload()
    });
  });

  this._almondCloudConnection.on('close', function() {
	self.createConnection();
    console.log('***********closed');
  });

};

module.exports = AlmondCloudConnection;
