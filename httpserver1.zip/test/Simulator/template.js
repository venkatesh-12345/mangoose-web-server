var template = {};


// gives the order of response to be written 
template['MobileCommandResponse'] = ["CommandType","MobileInternalIndex","Success","Reason","ReasonCode"]

//scenes
template['AddScene'] = {
	"Action":"add",
	"Table":"SCENES",
	"ActionEntity":"Scenes", 
	"Emit":"DynamicSceneAdded",
	"DynamicCommandNumber":1300,
	"ResponseType":template['MobileCommandResponse'],
	"DBFunction":"add"
}
template['ActivateScene'] = {
	"Action":"update",
	"Table":"SCENES",
	"ActionEntity":"Scenes",
	"Emit":"DynamicSceneActivated",
	"DynamicCommandNumber":1300,
	"ResponseType":template['MobileCommandResponse'],
	"DBFunction":"activate"
}
template['RemoveScene'] = {
	"Action":"remove",
	"Table":"SCENES",
	"ActionEntity":"Scenes",
	"Emit":"DynamicSceneRemoved",
	"DynamicCommandNumber":1300,
	"ResponseType":template['MobileCommandResponse'],
	"DBFunction":"remove"
}
template['UpdateScene'] = {
	"Action":"update",
	"Table":"SCENES",
	"ActionEntity":"Scenes",
	"Emit":"DynamicSceneUpdated",
	"DynamicCommandNumber":1300,
	"ResponseType":template['MobileCommandResponse'],
	"DBFunction":"update"
}

//clients
template['UpdateClient'] = {
	"Action":"update",
	"Table":"CLIENTS",
	"ActionEntity":"Clients",
	"Emit":"DynamicClientUpdated",
	"DynamicCommandNumber":1500,
	"ResponseType":template['MobileCommandResponse'],
	"DBFunction":"update"
}
template['RemoveClient'] = {
	"Action":"remove",
	"Table":"CLIENTS",
	"ActionEntity":"Clients",
	"Emit":"DynamicClientRemoved",
	"DynamicCommandNumber":1500,
	"ResponseType":template['MobileCommandResponse'],
	"DBFunction":"remove"
}


//devices
template['UpdateDeviceIndex'] = {
	"Action":"update",
	"Table":"DEVICE",
	"ActionEntity":"Devices",
	"Emit":"DynamicIndexUpdated",
	"DynamicCommandNumber":1200,
	"ResponseType":template['MobileCommandResponse'],
	"DBFunction":"updateDevice"
}
template['UpdateDeviceName'] = {
	"Action":"update",
	"Table":"DEVICE",
	"ActionEntity":"Devices",
	"Emit":"DynamicDeviceUpdated",
	"DynamicCommandNumber":1200,
	"ResponseType":template['MobileCommandResponse'],
	"DBFunction":"updateDeviceName"
}

template['Dynamic'] = {}
//scenes
template['Dynamic']['DynamicSceneAdded'] = {
	"Fields":{
		"CommandType":"DynamicSceneAdded",
		"Action":"add"
	},
	"DBFields":{
		"Scenes":{"Action":"get"},
		"HashNow":{"Action":"getHashNow"}		
	},
	"Table":"SCENES"
}
template['Dynamic']['DynamicSceneActivated'] = {
	"Fields":{
		"CommandType":"DynamicSceneActivated",
		"Action":"update"
	},
	"DBFields":{
		"Scenes":{"Action":"get"},
		"HashNow":{"Action":"getHashNow"}
	},
	"Table":"SCENES"
}
template['Dynamic']['DynamicSceneRemoved'] = {
	"Fields":{
		"CommandType":"DynamicSceneRemoved",
		"Action":"remove"
	},
	"DBFields":{
		"Scenes":{"Action":"get"},
		"HashNow":{"Action":"getHashNow"}		
	},
	"Table":"SCENES"
} 
template['Dynamic']['DynamicSceneUpdated'] = {
	"Fields":{
		"CommandType":"DynamicSceneUpdated",
		"Action":"update"
	},
	"DBFields":{
		"Scenes":{"Action":"get"},
		"HashNow":{"Action":"getHashNow"}		
	},
	"Table":"SCENES"
}

//devices
template['Dynamic']['DynamicIndexUpdated'] = {
	"Fields":{
		"CommandType":"DynamicIndexUpdated",
		"Action":"UpdateIndex"
	},
	"DBFields":{
		"Devices":{"Action":"get1"},
		"HashNow":{"Action":"getHashNow"}		
	},
	"Table":"DEVICE"
}
template['Dynamic']['DynamicDeviceUpdated'] = {
	"Fields":{
		"CommandType":"DynamicDeviceUpdated",
		"Action":"update"
	},
	"DBFields":{
		"Devices":{"Action":"get"},
		"HashNow":{"Action":"getHashNow"}		
	},
	"Table":"DEVICE"
}

//clients
template['Dynamic']['DynamicClientUpdated'] = {
	"Fields":{
		"CommandType":"DynamicClientUpdated",
		"Action":"update"
	},
	"DBFields":{
		"Clients":{"Action":"get"},
		"HashNow":{"Action":"getHashNow"}		
	},
	"Table":"CLIENTS"
}
template['Dynamic']['DynamicClientRemoved'] = {
	"Fields":{
		"CommandType":"DynamicClientRemoved",
		"Action":"remove"
	},
	"DBFields":{
		"Clients":{"Action":"get"},
		"HashNow":{"Action":"getHashNow"}		
	},
	"Table":"CLIENTS"
}

template.generateResponse = function (keys, values){
	var response = {};
	for (var key in keys){
		response[keys[key]] = values[keys[key]]+'';
	}
	return response;
}

module.exports = template;