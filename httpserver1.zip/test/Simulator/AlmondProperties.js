AlmondProperties={
	"Mode":"home",
	"Router":"router",
	"TemperatureScale":"F",
	"Name": "Something"
}
module.exports=AlmondProperties;