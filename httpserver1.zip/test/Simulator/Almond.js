var AlmondCloudConnection = require('./AlmondCloudConnection.js');
var util = require('util');
var model = require('./model.js');
var parseString = require('xml2js').parseString;
var template = require('./template.js');
var Encrypt = require('./crypto.js');
var nconf = require('nconf').argv();
var AlmondMAC = undefined;
var emailId = undefined;
var EventEmitter = require('events').EventEmitter;

function Almond (configs){
	this.model = new model(configs.devices, configs.wifiClients, configs.rules, configs.scenes);
	console.log('Starting the almond -> ', configs.almondMAC);
	AlmondMAC = configs.almondMAC;
	emailID = configs.EmailID;
	this.connection = new AlmondCloudConnection(this.model, configs.almondMAC, configs.longSecret, configs.firmwareVersion, configs.almondPlusID);
	var self = this;
	this.connection.on('packet', function (packet){
		self.packetHanlder(packet);
	});
	this.connection.on('cloudconnected', function(isconnected){
		 self.emit('cloudconnected', isconnected);
	});
	this.connection.on('error', function (error){
		console.log(error);
	});
}
util.inherits(Almond, EventEmitter);
function clone(a) {
   return JSON.parse(JSON.stringify(a));
}

Almond.prototype.activate = function(jsonPacket){
	console.log("inside new activate");
	var response = {};
	response['break'] = true;
	var id = jsonPacket['Scenes']['ID'];
	var scene = this.model.getTable('SCENES')[id];
	if(scene==undefined){
		response['ID'] = id;
		response['Success'] = "false";
		response['ReasonCode'] = "9";
		return response;
	}
	if(scene.Active == "true"){
		response['ID'] = id;
		response['Success'] = "false";
		response['ReasonCode'] = "33";
		return response;
	}
	var sceneEntryList = scene.SceneEntryList;
	var s_id, s_index, s_value;
	for(var i in sceneEntryList){
		s_id = sceneEntryList[i]['ID'];
		s_index = sceneEntryList[i]['Index'];
		s_value = sceneEntryList[i]['Value'];
		if(s_id == '0'){
			response['break'] = false;
			this.model.updateMode(s_value);
			this.checkAnySceneActivated(id);
		}else{
			if(this.model.updateDeviceIndex(s_id, s_index, s_value)){
				response['break'] = false;
				var dynamicResponse = this.responseObject('DynamicIndexUpdated', s_id, s_index);
				this.connection.send(1200, dynamicResponse);
				this.checkAnySceneActivated(id);
			}
		}
	}
	response['ID'] = id;
	response['Success'] = true;
	response['ResponseCode'] = '0';
	return response;
}

Almond.prototype.checkAnySceneActivated = function(id){
	sceneList = this.model.getTable('SCENES');
	for(var sceneid in sceneList){
		var active = sceneList[sceneid]["Active"];
		if(sceneList.hasOwnProperty(sceneid)){
			if(active != this.model.checkIfActiveAndUpdate(sceneList[sceneid], sceneid)){
				if(id!=sceneid){
					var dynamicResponse = this.responseObject('DynamicSceneActivated', sceneid);
					this.connection.send(1300,dynamicResponse);
				}
			}
		}
	}
}

Almond.prototype.responseObject = function(CommandType, id, index){
	var dynamicTemplate = template['Dynamic'][CommandType];
	var response = clone(dynamicTemplate["Fields"]);
	var dbFields = dynamicTemplate["DBFields"];
	var tableName = dynamicTemplate["Table"];
	for (var dbField in dbFields) {
		if (dbFields.hasOwnProperty(dbField)) {
			response[dbField] = this.model[dbFields[dbField]['Action']](tableName,id, index);	
		}
	}
	console.log("Sending this to cloud");
	console.log(JSON.stringify(response));
	return response;
}

Almond.prototype.packetHanlder = function(packet) {
	switch (packet.Command) {
		case 62:
			var jsonDoc=undefined;
			var CID = packet.ICID;
			parseString(packet.Payload.toString(), function (err, result) {
				jsonDoc = result;
			});
			if(jsonDoc['root']['AlmondModeChange']){
				var mode = jsonDoc['root']['AlmondModeChange'][0]['AlmondMode'];
				if(mode == '3') this.model.updateMode('away');
				else this.model.updateMode('home');
				var mobileresponse = '<root><AlmondModeChangeResponse success="true"><Reason>Almond Mode Set Successfully</Reason><ReasonCode>1</ReasonCode></AlmondModeChangeResponse></root>';
				this.connection._almondCloudConnection.send({'Command':63,'ICID':CID, 'Payload':mobileresponse});
				var dynamicResponse = '<root><AlmondplusMAC>' + AlmondMAC + '</AlmondplusMAC><DynamicAlmondMode success="true"><AlmondMode>' + mode + '</AlmondMode><ModeSetBy>' + emailID + '</ModeSetBy></DynamicAlmondMode></root>';
				this.connection._almondCloudConnection.send({'Command':154,'Payload':dynamicResponse});
				this.checkAnySceneActivated();
			}else if(jsonDoc['root']['AlmondNameChange']){
				var name = jsonDoc['root']['AlmondNameChange'][0]['NewName'];
				var mii = jsonDoc['root']['AlmondNameChange'][0]['MobileInternalIndex'];
				console.log(name[0], mii[0], AlmondMAC);
				this.model.updateName(name);
				var mobileresponse = '<root><AlmondNameChangeResponse success="true"><MobileInternalIndex>'+mii+'</MobileInternalIndex></AlmondNameChangeResponse></root>';
				console.log("Sending mobile: ", mobileresponse)
				this.connection._almondCloudConnection.send({'Command':63,'ICID':CID, 'Payload':mobileresponse});
				var dynamicResponse = '<root><DynamicAlmondNameChange><AlmondplusMAC>'+AlmondMAC+'</AlmondplusMAC><AlmondplusName>'+name+'</AlmondplusName></DynamicAlmondNameChange></root>';
				console.log("Sending dynamic: ", dynamicResponse)
				this.connection._almondCloudConnection.send({'Command':49,'Payload':dynamicResponse});
			}
		break;
		case 1100:
			var jsonPacket = JSON.parse(packet.Payload.toString());
			var CID = packet.ICID;
			var wirelessSetting = this.model.wirelessSetting();
			var routerSummary = this.model.routerSummary();
			switch(jsonPacket['CommandType']){
				case 'RouterSummary':
					routerSummary.TempPass = Encrypt('securifi', AlmondMAC , '1100086');
					this.connection.send(1100, routerSummary, CID);
				break;
				case 'GetWirelessSettings':
					this.connection.send(1100, wirelessSetting, CID);
				break;
				case 'SetWirelessSettings':
					var type = jsonPacket["WirelessSetting"]["Type"];
					var res = {};
					res.WirelessSetting = [];
					res.CommandType = jsonPacket.CommandType;
					res.AppID = jsonPacket.AppID;
					res.Uptime = wirelessSetting.Uptime;
					if(type == "Guest2G&Guest5G"){
						var g2g = undefined;
						var g5g = undefined;
						for(var i in wirelessSetting.WirelessSetting){
							var net = wirelessSetting.WirelessSetting[i];
							if(net['Type'] == "Guest5G") g5g = clone(net);
							if(net['Type'] == "Guest2G") g2g = clone(net);
						}
						if(g2g['Enabled'] == jsonPacket["WirelessSetting"]["Enabled"]){
							g2g["Password"] = Encrypt('securifi',AlmondMAC, '1100086');
         					g2g["Success"] = "false";
         					g2g["Reason"] = "enable is same";
						}else{
							g2g["Password"] = Encrypt('securifi', AlmondMAC, '1100086');
         					g2g["Success"] = "true";
         					g2g['Enabled'] = jsonPacket["WirelessSetting"]["Enabled"]
						}
						if(g5g['Enabled'] == jsonPacket["WirelessSetting"]["Enabled"]){
							g5g["Password"] = Encrypt('securifi', AlmondMAC, '1100086');
         					g5g["Success"] = "false";
         					g5g["Reason"] = "enable is same";
						}else{
							g5g["Password"] = Encrypt('securifi', AlmondMAC, '1100086');
         					g5g["Success"] = "true";
         					g5g['Enabled'] = jsonPacket["WirelessSetting"]["Enabled"]
						}
						for(var i in wirelessSetting.WirelessSetting){
							var net = wirelessSetting.WirelessSetting[i];
							if(net['Type'] == "Guest5G") net.Enabled = jsonPacket["WirelessSetting"]["Enabled"];
							if(net['Type'] == "Guest2G") net.Enabled = jsonPacket["WirelessSetting"]["Enabled"];
						}
						for(var i in routerSummary.WirelessSetting){
							var net = routerSummary.WirelessSetting[i];
							if(net['Type'] == "Guest5G") net.Enabled = jsonPacket["WirelessSetting"]["Enabled"];
							if(net['Type'] == "Guest2G") net.Enabled = jsonPacket["WirelessSetting"]["Enabled"];
						}
						res.WirelessSetting.push(g2g);
						res.WirelessSetting.push(g5g);
						console.log("res: ", res);
						this.connection.send(1100, res, CID);
						break;
					}
					if(type == 'Guest2G'){
						console.log("inside al2 command for guest network");
						var g2g = undefined;
						for(var i in wirelessSetting.WirelessSetting){
							var net = wirelessSetting.WirelessSetting[i];
							if(net['Type'] == "Guest2G") g2g = clone(net);
						}
						if(g2g['Enabled'] == jsonPacket["WirelessSetting"]["Enabled"]+''){
							g2g.Enabled = jsonPacket["WirelessSetting"]["Enabled"]+'';
                            g2g.Password = Encrypt('securifi', AlmondMAC, '1100086');
							res.Success = 'false';
							res.Reason = "Enable is same";
                            res.WirelessSetting.push(g2g);
						}else{
							g2g["Password"] = Encrypt('securifi', AlmondMAC, '1100086');
							g2g['Enabled'] = jsonPacket["WirelessSetting"]["Enabled"]+''
							res['Success'] = 'true';
							res.WirelessSetting.push(g2g);
						}
						for(var i in wirelessSetting.WirelessSetting){
							var net = wirelessSetting.WirelessSetting[i];
							if(net['Type'] == "Guest2G") net.Enabled = jsonPacket["WirelessSetting"]["Enabled"]+'';
						}
						for(var i in routerSummary.WirelessSetting){
							var net = routerSummary.WirelessSetting[i];
							if(net['Type'] == "Guest2G") net.Enabled = jsonPacket["WirelessSetting"]["Enabled"]+'';
						}
						console.log("res: ", res);
						this.connection.send(1100, res, CID);
						break;
					}
					for(var i in wirelessSetting.WirelessSetting){
						if(wirelessSetting["WirelessSetting"][i]['Type'] == type){
							if(jsonPacket["WirelessSetting"]["SSID"]!=undefined)
								wirelessSetting["WirelessSetting"][i]['SSID'] = jsonPacket["WirelessSetting"]["SSID"];
							res.WirelessSetting.push({
								"Type":type,
								"Enabled":wirelessSetting["WirelessSetting"][i]['Enabled']+'',
								"SSID":wirelessSetting["WirelessSetting"][i]['SSID'],
								"Password":Encrypt('securifi', AlmondMAC, '1100086')
							});
							if(jsonPacket["WirelessSetting"]["Enabled"]!=undefined){
								res.WirelessSetting[0]['Enabled'] = jsonPacket["WirelessSetting"]["Enabled"]+'';
								if(wirelessSetting["WirelessSetting"][i]['Enabled'] == jsonPacket["WirelessSetting"]["Enabled"]+''){
									res.Success = "false";
									res.Reason = "enable is same";
								}else{
									wirelessSetting["WirelessSetting"][i]['Enabled'] = jsonPacket["WirelessSetting"]["Enabled"]+'';
									res.Success = "true";
								}
							}
							routerSummary["WirelessSetting"][i]["SSID"] = wirelessSetting["WirelessSetting"][i]['SSID'];
							routerSummary["WirelessSetting"][i]["Enabled"] = wirelessSetting["WirelessSetting"][i]['Enabled']+'';
							break;
						}
					}
					console.log("res: ", res);
					this.connection.send(1100, res, CID);
				break;
                case 'RebootRouter':
                    this.connection.send(1100, {"CommandType":"RebootRouter","Success":"true"}, CID);
                    break;
			}
		break;
		case 1062:
			console.log("got 1062");
			var jsonPacket = JSON.parse(packet.Payload.toString());
			var MII = jsonPacket.MobileInternalIndex;
			var CID = packet.ICID;
			var BID = packet.BID;
			var commandTemplate = template[jsonPacket['CommandType']];
			switch(jsonPacket['CommandType']){
				case 'UpdateDeviceIndex':
				case 'UpdateDeviceName':
				case 'AddScene':
				case 'ActivateScene':
				case 'RemoveScene':
				case 'UpdateScene':
				case 'UpdateClient':
				case 'RemoveClient':
					var dbFunction = commandTemplate['DBFunction']
					var successObject = undefined;
					if(jsonPacket['CommandType']=='ActivateScene'){
						successObject = this.activate(jsonPacket);
						if(successObject.Success == "false"){
							this.connection.send(1063, {'Success':successObject['Success'], 'ReasonCode':successObject['ReasonCode'], "MobileInternalIndex": MII+''}, CID);
							break;
						}
						if(successObject['break']) {
							this.connection.send(1063, {'Success':successObject['Success'], "MobileInternalIndex": MII+'', "Reason": "0"}, CID);
							break;
						}
					}
					else
						successObject = this.model[dbFunction](commandTemplate['Table'], jsonPacket,commandTemplate['ActionEntity']);
					var responseKeys = commandTemplate['ResponseType'];
					var responseForCloud=undefined;
					if(jsonPacket['CommandType']=='UpdateDeviceIndex' && successObject.Success=='false')
						responseForCloud = {"CommandType":"UpdateDeviceIndex","Success":"false","MobileInternalIndex":MII,"Reason":"Same Value Received"};
					else
						responseForCloud = template.generateResponse(responseKeys, {'Success':successObject['Success']+'','ReasonCode':successObject['ReasonCode'],"MobileInternalIndex":MII+'',"CommandType":jsonPacket['CommandType']});
					this.connection.send(1063, responseForCloud, CID);
					var dynamicResponse = this.responseObject(commandTemplate['Emit'], successObject.ID, successObject.Index);
					if(successObject.Index!=undefined){
						if(successObject.DynamicUpdate){
							this.checkAnySceneActivated();
							this.connection.send(commandTemplate['DynamicCommandNumber'], dynamicResponse);
						}
					}else{
						this.connection.send(commandTemplate['DynamicCommandNumber'], dynamicResponse);
					}
					if(successObject['Active']!=undefined && successObject['Active']=="true"){
						dynamicResponse = this.responseObject('DynamicSceneActivated', successObject.ID);
						this.connection.send(1300, dynamicResponse);
					}
				break;
				case 'RemoveAllScenes':
					var successObject = this.model.removeAll('SCENES', jsonPacket);
					var responseForCloud = {'Success':successObject['Success']+'', 'ResponseCode':successObject['ResponseCode']+'', 'MobileInternalIndex':MII+''};
					this.connection.send(1063, responseForCloud, CID);
					var dynamicResponse = {"CommandType":"DynamicAllScenesRemoved","Action":"removeAll"};
					console.log("Sendind this to cloud: ", dynamicResponse);
					this.connection.send(1300, dynamicResponse);
				break;
				case 'RemoveAllClients':
					var successObject = this.model.removeAll('CLIENTS', jsonPacket);
					var responseForCloud = {'Success':successObject['Success']+'', 'ResponseCode':successObject['ResponseCode'], 'MobileInternalIndex':MII+''};
					this.connection.send(1063, responseForCloud, CID);
					var dynamicResponse = {"CommandType":"DynamicAllClientsRemoved","Action":"removeAll"};
					console.log("Sendind this to cloud: ", dynamicResponse);
					this.connection.send(1500, dynamicResponse);
				break;
			}
		break;
		case 1200:
			var jsonPacket = JSON.parse(packet.Payload.toString());
			switch (jsonPacket['CommandType']){
				case 'DeviceListHashResponse':
					if(jsonPacket['Success'] == false){
						var devices = this.model.getTable('DEVICE');
						var payload = {'CommandType':"DynamicDeviceList", "Action":"addAll", "Devices":devices, "HashNow":this.model.getHashNow('DEVICE')};
						this.connection.send(1200, payload);
					}
				break;
			}
		break;
		case 1300:
			var jsonPacket = JSON.parse(packet.Payload.toString());
			switch(jsonPacket['CommandType']){
				case 'SceneListHashResponse':
					if(jsonPacket['Success'] == false){
						var scenes = this.model.getTable('SCENES');
						var payload = {'CommandType':"DynamicSceneList", "Action":"addAll", "Scenes":scenes, "HashNow":this.model.getHashNow('SCENES')};
						this.connection.send(1300, payload);
					}
				break;
			}
		break;
		case 1500:
			var jsonPacket = JSON.parse(packet.Payload.toString());
			switch(jsonPacket['CommandType']){
				case 'ClientListHashResponse':
					if(jsonPacket['Success'] == false){
						var clients = this.model.getTable('CLIENTS');
						var payload = {'CommandType':"DynamicClientList", "Action":"addAll", "Clients":clients, "HashNow":this.model.getHashNow('CLIENTS')};
						this.connection.send(1500, payload);
					}
				break;
			}
		break;
	}
};

Almond.prototype.killConnection = function() {
	this.connection._almondCloudConnection.destroy();
};

//new Almond();

module.exports = Almond;
