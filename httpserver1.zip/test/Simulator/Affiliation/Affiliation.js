var CloudEndPoint = require('./ClientServerOwn.js');
var assert = require("assert");
var AlmondProtocol = require('@securificloud/cloud-protocols').Almond;
var Client = require('@securificloud/cloud-servers-clients').clients.ProtocoledClient;
var parseString = require('xml2js').parseString;

var cloudConfigs = require('../../TestConfigs/testConfig').almondConfig;

var getAlmondCommand = function(AlmondPlusID, AlmondMAC){
	return '<root><AffiliationAlmondRequest><AlmondplusID>' + AlmondPlusID + '</AlmondplusID><AlmondplusMAC>' + AlmondMAC + '</AlmondplusMAC></AffiliationAlmondRequest></root>'
}

var getMobileCommand = function(code){
	return '<root><AffiliationUserRequest><Code>' + code + '</Code></AffiliationUserRequest></root>'
}

var getAlmondHello = function(mobileConfigs){
	return '<root><AlmondHello><AlmondplusMAC>'+mobileConfigs.almondMAC+'</AlmondplusMAC><AlmondplusID>'+mobileConfigs.almondPlusID+'</AlmondplusID><LongSecret>'+mobileConfigs.longSecret+'</LongSecret><FirmwareVersion>'+mobileConfigs.firmwareVersion+'</FirmwareVersion></AlmondHello></root>'
}

var getUnlinkCommand = function(mobileConfigs){
    return '{"CommandType":"UnlinkAlmondRequest","AlmondMAC":"' + mobileConfigs.almondMAC + '","EmailID":"' + mobileConfigs.EmailID + '","Password":"' + mobileConfigs.password + '"}';
};
//maintains mobile-cloud connection
var sendMobileCommand = function(code, mobileConfigs){
	var mobileCommand = getMobileCommand(code);
	CloudEndPoint.login(mobileConfigs.EmailID, mobileConfigs.password, false, function(data){
	},function(err, socket, response){
		if(err){
			console.log("error");
			return console.error(err);
		}
		socket.send({
			"Command":23,
			"Payload":mobileCommand
		})
		socket.destroy();
	});
}

//maintains Almond-cloud connection
function Affiliation(mobileConfigs, callback){
	//if link is true, affiliation gets started...; if link is false unlinking gets started
	if(!mobileConfigs.link){
		var Socket = undefined;
		var unlinkCommand = getUnlinkCommand(mobileConfigs);
		CloudEndPoint.login(mobileConfigs.EmailID, mobileConfigs.password, false, function(data){
			if(data.Command == 1110){
				Socket.destroy();
				if(data.Payload['CommandType'] == 'UnlinkAlmondResponse' && data.Payload['success'] == "true"){
					console.log("UNLINKING DONE SUCCESSFULLY");
					callback(true);
				}else{
					console.log("ERROR UNLINKING");
					callback(false);
				}
			}
		},function(err, socket, response){
			if(err){
				console.log("error");
				return console.error(err);
			}
			Socket = socket;
			socket.send({
				"Command": 1110,
				"Payload": unlinkCommand
			})
		});
		return;
	}
	this.cloudConnection = new Client(cloudConfigs, AlmondProtocol);
	this.cloudConnection.connect();
	var self = this;
	var command = getAlmondCommand(mobileConfigs.almondPlusID, mobileConfigs.almondMAC);
	var code;
	var affiliated = false;
	var killConnection = false;

	this.cloudConnection.on('error', function(err){
		console.log("error connecting to cloud");
		console.error(err);
		killConnection = true;
		this.cloudConnection.destroy();
		callback(false);
	});

	this.cloudConnection.on('connect', function(){
		console.log("clous connection established")
		if(!affiliated){
			self.cloudConnection.send({
				"Command" : 21,
				"Payload" : command
			})
		}else{
			var hello = getAlmondHello(mobileConfigs);
			self.cloudConnection.send({
				"Command":31,
				"Payload":hello
			})
		}
	})

	this.cloudConnection.on('packet', function(packet){
		if(packet.Command == 22){
			var jsonPacket;
			parseString(packet.Payload.toString(), function(err, result){
				jsonPacket = result;
			});
			if(jsonPacket['root']['AffiliationAlmondResponse'][0]['$']['success'] == "true"){
				code = jsonPacket['root']['AffiliationAlmondResponse'][0]['Code'];
				sendMobileCommand(code, mobileConfigs);
			}else{
				console.log("ALMOND ALREADY AFFILIATED");
				killConnection = true;
				self.cloudConnection.destroy();
				callback(true);
			}
		}
		else if(packet.Command == 24){
			var jsonPacket;
			parseString(packet.Payload.toString(), function(err, result){
				jsonPacket = result;
			});
			if(jsonPacket['root']['AffiliationAlmondComplete'][0]['$']['success'] == "true"){
				var infoCommand = '<root>'+
				   '<AffiliationAlmondCompleteResponse>'+
				      '<AlmondplusMAC>'+mobileConfigs.almondMAC+'</AlmondplusMAC>'+
				      '<AlmondplusID>'+mobileConfigs.almondplusID+'</AlmondplusID>'+
				      '<LongSecret>'+mobileConfigs.longSecret+'</LongSecret>'+
				      '<AlmondplusName>'+mobileConfigs.AlmondName+'</AlmondplusName>'+
				      '<FirmwareVersion>'+mobileConfigs.firmwareVersion+'</FirmwareVersion>'+
				      '<Code>' + code + '</Code>'+
				      '<WifiSSID>Almond+ 5GHz-S5pWi5,SECURIFI HELLO</WifiSSID>'+
				      '<WifiPassword />'+
				   '</AffiliationAlmondCompleteResponse>'+
				'</root>'
				affiliated = true;
				self.cloudConnection.send({
					"Command":25,
					"Payload":infoCommand
				});
			}
		}
		else if(packet.Command == 32){
			var jsonPacket;
			parseString(packet.Payload.toString(), function(err, result){
				jsonPacket = result;
			});
			if(jsonPacket['root']['AlmondHelloResponse'][0]['$']['success'] == "true"){
				console.log("AFFILIATION DONE SUCCESSFULLY");
				killConnection = true;
				self.cloudConnection.destroy();
				callback(true);
			}
		}
	});

	this.cloudConnection.on('close', function(){
		console.log("cloud connection terminated");
		if(!killConnection)
			self.cloudConnection.connect();
	})
}

module.exports = Affiliation;