var parseString = require('xml2js').parseString;
var MobileProtocol = require('@securificloud/cloud-protocols').Mobile;
var Client = require('@securificloud/cloud-servers-clients').clients.ProtocoledClient;
var xmlEscape = require('xml-escape');
var cloudConfigs = require('../../TestConfigs/testConfig').mobileConfig;

	 //console.log(ca);

//})
console.log("clous configs", cloudConfigs);
var cloudService = {}

// will be adding the session id 
cloudService.login = function(email, tempPass, temp,responseHandler, callback) {
  var emailID = 'EmailID'
  var password = 'Password'
  if (temp) {
    emailID = 'UserID';
    password = 'TempPass';
  }
  console.log("This is inside of login 1",email);
  var login = '<root><Login><' + emailID + '>' + xmlEscape(email) + '</' + emailID + '>' +
    '<' + password + '>' + xmlEscape(tempPass) + '</' + password + '></Login></root>';
  console.log("This is the login generated" + login);
  cloudService.createNewClient(1, login, function(err, client, packet) {
    //console.log("received packet valur: ", packet.Payload.toString());
    if (err) {
      console.log("Error durin connection?" + err)
      callback(err);
    } else {
      //got this client
      // store the client
      var error = new Error('Couldn\'t authenticate with given information');
      error.code = 1;
      if (packet.Command !== 2) {
        console.log('received command as response: ' + packet.Command);
        console.log('Recived this from payload' + packet.Payload.toString());
        responseHandler(packet);
     //   CloudResponseHandler.handleResponse(packet,sessionId);
      } else {
		    console.log("outside !==2");
        parseString(packet.Payload.toString(), function (err, result) {
      
		  var success = result.root.LoginResponse[0]['$'].success;
          if (success === 'false') {
            console.log("Invalid login");
            var reason = result.root.LoginResponse[0]['Reason'];
            var reasonCode = 105;
            if(reason === 'UserID or TempPass not found'){
              reasonCode = 101;
            }
            else if(reason === 'Email Not Validated'){
                          reasonCode = 102;
            }
            else if(reason === 'Username not found'){
                          reasonCode = 103;
            }
            else if(reason === 'Wrong Password'){
                          reasonCode = 104;
            }
            console.log("one** *********")
            client.destroy();
            callback(undefined, client, {
              success: false,
              reasonCode: reasonCode,
              reason: reason
            });
          } else {
            console.log("********\n\n******* WE LOGGED IN********\n\n***************");
            console.log(result.root.LoginResponse[0]['UserID']);
            return callback(undefined, client, {
              success: true,
              UserID: result.root.LoginResponse[0]['UserID'],
              IsActivated: 1,
              TempPass: result.root.LoginResponse[0]['TempPass']
            });
          }  
          });    
     
      }

    }

  });

}
cloudService.createNewClient = function(command, payload, callback) {
    console.log("Creating a New Client with  ====> \n");
    console.log(cloudConfigs);
	var client = new Client(cloudConfigs, MobileProtocol);
    //console.log(client);
    client.on('error', function(err) {
      console.log('CONNECTING CLOUD FAILED');
      console.log(err);
      client.destroy();
      callback(err);
    });

    client.on('packet', function(packet) {
      console.log('received packet..', packet.Payload.toString());
      callback(undefined, client, packet);
    });

    client.on('connect', function() {
      console.log('******=================================*****connected');
      client.send({
        Command: command,
        Payload: payload
      });
    });

    client.on('close', function() {
      console.log('***********closed');
    });

    client.connect();
  }
  //cloudService.createNewClient(1,'<root></root>', function (err,x , y){
  //	console.log('\n\n\n Finished');
  //})

module.exports = cloudService;
