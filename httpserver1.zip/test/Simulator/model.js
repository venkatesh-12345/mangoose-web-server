var debug = require('debug')('model');
var EventEmitter = require('events').EventEmitter; 
var crypto = require('crypto');
var template = require('./template.js');
var reasonCode = require('./ReasonCodes.js');
var fs = require('fs');

function db (devices, wifiClients, rules, scenes){
		this.GetWirelessSetting = require('./GetWirelessSetting.json');
		this.RouterSummary = require('./RouterSummary.json');
		this.TABLE = {};
		this.AlmondProperties = require('./AlmondProperties.js');
	    this.DEVICE = devices;
	    this.TABLE["DEVICE"] = devices;
	    this.TABLE["SCENES"] = scenes;
	    this.TABLE["CLIENTS"] = wifiClients;
	    this.TABLE["RULES"] = rules;
}


db.prototype.initTable = function(tableName, fileName){
	this.TABLE[tableName] = require(fileName);
	console.log("table of scenes: ", this.TABLE[tableName])
}

//handles AddScene
db.prototype.add = function (tableName, jsonPacket, addEntity){
	console.log("inside add");
	var id = undefined;
	var response = {};
	var validitity = this.checkValidity(tableName,jsonPacket);
	if(validitity['Success']){
		response['Success'] = "true";
		response['ReasonCode'] = '0';
	}else{
		return validitity;
	}
	if(tableName=="SCENES"){
		var active = undefined;
		var id = 1;
		while(true){
			if(this.TABLE[tableName].hasOwnProperty(id+'')){
				id++;
			}else{
				this.TABLE[tableName][id+''] = jsonPacket[addEntity];
				break;
			}
		}
		active = this.checkIfActiveAndUpdate(jsonPacket[addEntity],id);	
		response['Active'] = active;
		response['ID'] = id;
		this.TABLE[tableName][id]['VoiceCompatible'] = this.TABLE[tableName][id]['VoiceCompatible'] + '';
		var sceneEntryList = this.TABLE[tableName][id].SceneEntryList;
		for(var i in sceneEntryList){
			for (var key in sceneEntryList[i]){
  				if (sceneEntryList[i].hasOwnProperty(key)){
    				sceneEntryList[i][key] = sceneEntryList[i][key]+'';
  				}
			}
		}
		console.log("sceneEntryList: ", this.TABLE[tableName][id].SceneEntryList);
	}
	fs.writeFileSync("initSceneList.json", JSON.stringify(this.TABLE['SCENES']), "utf8");
	return response;
}

//handles RemoveScene,RemoveClient
db.prototype.remove = function(tableName, jsonPacket, removeEntity){
	console.log("inside remove");
	var response = {};
	var id = jsonPacket[removeEntity]['ID'];
	delete this.TABLE[tableName][id];
	response['ID'] = id;
	response['Success'] = true;
	response['ResponseCode'] = '0';
	return response;
}

//handles RemoveAllScenes, RemoveAllClients
db.prototype.removeAll = function(tableName, jsonPacket){
	this.TABLE[tableName] = {};
	var response = {};
	response['Success'] = true;
	response['ResponseCode'] = "0";
	return response;
}

//handles UpdateScene, UpdateClient
db.prototype.update = function(tableName, jsonPacket, updateEntity){
	console.log("inside update");
	var response = {};
	var id = jsonPacket[updateEntity]['ID'];
	var entity = this.TABLE[tableName][id];
	var UpdatedEntity = jsonPacket[updateEntity];
	for (var key in UpdatedEntity){
  		if (entity.hasOwnProperty(key) && UpdatedEntity.hasOwnProperty(key)){
    		entity[key] = UpdatedEntity[key];
  		}
	}
	if(tableName == 'CLIENTS'){
		this.TABLE[tableName][id]['Active'] = this.TABLE[tableName][id]['Active'] + '';
		this.TABLE[tableName][id]['UseAsPresence'] = this.TABLE[tableName][id]['UseAsPresence'] + '';
		this.TABLE[tableName][id]['CanBlock'] = this.TABLE[tableName][id]['CanBlock'] + '';
	}
	if(tableName == 'SCENES'){
		this.TABLE[tableName][id]['VoiceCompatible'] = this.TABLE[tableName][id]['VoiceCompatible'] + '';
		for(var i in entity.SceneEntryList){
			entity.SceneEntryList[i]['Valid'] = "true";
			for (var key in entity.SceneEntryList[i]){
  				if (entity.SceneEntryList[i].hasOwnProperty(key)){
    				entity.SceneEntryList[i][key] = entity.SceneEntryList[i][key]+'';
  				}
			}
		}
		response['Active'] = this.checkIfActiveAndUpdate(entity, id);
	}
	response['ID'] = id;
	response['Success'] = "true";
	response['ResponseCode'] = '0';
	return response;
}

db.prototype.updateDevice = function(tableName, jsonPacket, updateEntity){
	var deviceId = jsonPacket.ID;
	var index = jsonPacket.Index;
	var value = jsonPacket.Value;
	var res = {};
	res['Index'] = index;
	res['ID'] = deviceId;
	res['DynamicUpdate'] = this.updateDeviceIndex(deviceId, index, value);
	res['Success'] = res['DynamicUpdate']+'';
	return res;
}

db.prototype.updateDeviceName = function(tableName, jsonPacket, updateEntity){
	var deviceId = jsonPacket.ID;
	var name = jsonPacket.Name;
	var location = jsonPacket.Location;
	this.updateDeviceNameLocation(deviceId, name, location);
	var res = {};
	res['Success'] = true;
	res['ID'] = deviceId;
	console.log("**********res: ", res);
 	return res;
}

db.prototype.updateMode = function(value){
	if(this.AlmondProperties['Mode'] != value){
		this.AlmondProperties['Mode'] = value;
	}
}

db.prototype.updateName = function(name){
	this.AlmondProperties['Name'] = name;
}

//checks if passed scene is active and updates db for Active and lastActiveEpoch keys
db.prototype.checkIfActiveAndUpdate = function(scene,id){
	sceneEntryList = scene.SceneEntryList;
	var active = "true";
	for(var i in sceneEntryList)
		sceneEntryList[i]['Valid'] = "true";
	for(var i in sceneEntryList){
		if(sceneEntryList[i]['ID']=="0"){
			if(sceneEntryList[i]['Value'] !== this.AlmondProperties['Mode']){
				active = "false";
				break;
			}
		}
		else{
			if(this.TABLE['DEVICE'][sceneEntryList[i]['ID']] && this.TABLE['DEVICE'][sceneEntryList[i]['ID']]['DeviceValues'][sceneEntryList[i]['Index']]['Value'] !== sceneEntryList[i]['Value']){
				active = "false";
				break;
			}
		}
	}
	this.TABLE['SCENES'][id]["Active"] = active;
	if(this.TABLE['SCENES'][id]["Active"] == "true"){
		this.TABLE['SCENES'][id]["LastActiveEpoch"]=Date.now()+'';
	}
	else if(this.TABLE['SCENES'][id]["LastActiveEpoch"] == undefined){
		this.this.TABLE['SCENES'][id]["LastActiveEpoch"]="0";
	}
	return this.TABLE['SCENES'][id]["Active"];
}

db.prototype.getTable = function(tableName){
	return this.TABLE[tableName];
}
db.prototype.wirelessSetting = function(){
	return this.GetWirelessSetting;
}
db.prototype.routerSummary = function(){
	return this.RouterSummary;
}
db.prototype.resumeDevice = function (){
	// need to create A Mobile Device and get Everything 
	// DEVICE = //TODO
}
db.prototype.get = function(tableName,id){
	response = {};
	if(this.TABLE[tableName][id]==undefined){
		response[id] = {};
	}else{
		response[id] = this.TABLE[tableName][id];
	}
	return response;
}
db.prototype.get1 = function(tableName, deviceId, index){
	var DeviceJSON = {};
	var IndexJSON = {};
	IndexJSON[index+''] = this.getThisDeviceIndex(deviceId, index);
	DeviceJSON[deviceId+''] = {"DeviceValues":IndexJSON};
	var command = DeviceJSON;
	return command;
}
db.prototype.getWholeDevice = function (){
	return this.TABLE['DEVICE'];
};
db.prototype.getDeviceLength = function (){
	return Object.keys(this.DEVICE).length;
}
db.prototype.getThisDevice = function (deviceId){
	return this.DEVICE[deviceId];
}
db.prototype.getThisDeviceIndex = function (deviceId,index){
	return this.DEVICE[deviceId+'']['DeviceValues'][index+''];
}
db.prototype.updateDeviceIndex = function  (deviceId, index, value) {
	if(this.TABLE['DEVICE'][deviceId+'']==undefined)
		return false;
	if(this.TABLE['DEVICE'][deviceId+'']['DeviceValues'][index+'']['Value'] == value){
		return false;
	}else{
		this.TABLE['DEVICE'][deviceId+'']['DeviceValues'][index+'']['Value'] = value;
		return true;		
	}
}
db.prototype.updateDeviceNameLocation = function  (deviceId, name, location) {
	this.TABLE['DEVICE'][deviceId+'']['Data']['Name'] = name;
	this.TABLE['DEVICE'][deviceId+'']['Data']['Location'] = location;
}
db.prototype.getHashNow = function (tableName){
	return crypto.createHash('sha1').update(JSON.stringify(this.TABLE[tableName])).digest('hex');
}

db.prototype.clone = function(a) {
   return JSON.parse(JSON.stringify(a));
}

db.prototype.checkValidity = function (tableName, payload){
	var commandTemplate = template[payload['CommandType']];
	var entityToWatch = payload[commandTemplate['ActionEntity']];
	console.log("commandTemplate: ", commandTemplate, "entityToWatch: ", entityToWatch);
	var result = {};
	var self = this;
	if(tableName == "SCENES"){
		if(commandTemplate['Action'] == "add"){
			var SceneEntryList =  entityToWatch["SceneEntryList"];
			var set = false;
			var result = {};
			SceneEntryList.forEach(
				function(sceneItem) {
				 	if(sceneItem['ID'] != "0"){
				 		var sceneDevice = self.getThisDevice(sceneItem['ID']);
				 		if(sceneDevice == undefined){
				 			result = self.clone(reasonCode['SCENE_CREATION_DEVICE_NOT_FOUND']);
				 			result['Success'] = false;
				 			set = true;
				 		}
				 	}
			})
			if(!set)
				result['Success'] = true;
			return result;
		}
	}
}

/*
process.on ("SIGINT", function(){
    console.log("You clicked Ctrl+C!");
    //console.log("final table of scenes: ", TABLE['SCENES']);
	if(!FORTEST){
	    fs.writeFileSync("initSceneList.json", JSON.stringify(TABLE['SCENES']), "utf8");
	    //console.log("final table of devices: ", TABLE['DEVICE']);
	    fs.writeFileSync("initDynamicList.json", JSON.stringify(TABLE['DEVICE']), "utf8");
	    //console.log("final table of clients: ", TABLE['CLIENTS']);
	    fs.writeFileSync("initClientsList.json", JSON.stringify(TABLE['CLIENTS']), "utf8");
	    fs.writeFileSync("GetWirelessSetting.json", JSON.stringify(GetWirelessSetting), "utf8");
	    fs.writeFileSync("RouterSummary.json", JSON.stringify(RouterSummary), "utf8");
  	}
    process.exit(1);
});*/

module.exports = db;
