ReasonCodes = {
'SCENE_CREATION_DEVICE_NOT_FOUND': {'ReasonCode':404,'Reason':'Device not found while creating the scene'}
}
module.exports = ReasonCodes;