
var NC = require('./NotificationConstants.js');
var messageGenerator = {};

var colorIze = function (value, maxVal) {
    if (isNaN(value))
        return;
    intValue = parseInt(value);
    var window = maxVal / 8;
    if (intValue >= 0 && intValue <= 1 * window) {
        return " Color set in red shades";
    } else if (intValue > 1 * window && intValue <= 2 * window) {
        return " Color set in orange shades ";
    } else if (intValue > 2 * window && intValue <= 3 * window) {
        return " Color set in  yellow shades ";
    } else if (intValue > 3 * window && intValue <= 4 * window) {
        return " Color set in  green shades ";
    } else if (intValue > 4 * window && intValue <= 5 * window) {
        return " Color set in  blue shades ";
    } else if (intValue > 5 * window && intValue <= 6 * window) {
        return " Color set in indigo  shades ";
    } else if (intValue > 6 * window && intValue <= 7 * window) {
        return " Color set in  violet shades ";
    } else if (intValue > 7 * window)
        return "Color set in reddish shades";
    else
        return " Color set " + value;

};

messageGenerator.deviceTextMap = {
    '1': {'1': {'true': NC.turnedOn, 'false': NC.turnedOff, 'addValue': false}},
    '2': {'1': {'fn': 'multiSwitchHandler', 'suffix': 'value' != 0 ? '%' : undefined, 'factor': 1, 'condition': {value: 0, 0: NC.turnedOff, 'others': NC.dimmedTo}}},
    '3': {'1': {'true': NC.opened, 'false': NC.closed}},
    '4': {'1': {'fn': 'dimmerFunction', 'suffix': '%', 'prefix': NC.dimmedTo, 'factor': 0.392}, '2': {'true': NC.turnedOn, 'false': NC.turnedOff}},
    '5': {'1': {'fn': 'lockHanlder', 'condition': {value: 0, 0: NC.unlocked, 'others': NC.locked}, addValue: false}},
    '6': {'1': {'0': NC.isRinging, '255': NC.isSilent}},
    '7': {'1': {'prefix': NC.temperatureChange, 'suffix': '\u00B0F', 'addValue': true},
        '2': {'Auto': NC.modeChangeAuto, 'Cool': NC.modeChangeCool, 'Off': NC.modeChangeOff, 'Heat': NC.modeChangeHeat},
        '3': {'prefix': NC.is, 'addValue': true},
        '4': {'prefix': NC.heatingUp, 'suffix': '\u00B0F', 'addValue': true},
        '5': {'prefix': NC.coolingDown, 'suffix': '\u00B0F', 'addValue': true},
        '6': {'prefix': NC.fanState, 'addValue': true},
        '7': {'prefix': NC.fanIs, 'addValue': true}
    },
    '10': {'1': {'true': NC.active, 'false': NC.inactive}},
    '11': {'1': {'true': NC.motionChange, 'false': {DontNotify: true}}},
    '12': {'1': {'true': NC.opened, 'false': NC.closed}},
    '13': {'1': {'false': NC.ok, 'true': NC.fireDected}},
    '14': {'1': {'false': NC.waterStopped, 'true': NC.waterDected}},
    '15': {'1': {'false': NC.ok, 'true': NC.gasDected}},
    '16': {'1': {'true': NC.turnedOn, 'false': NC.turnedOff}},
    '17': {'1': {'true': NC.vibrationStopped, 'false': NC.vibrationDetected}},
    '18': {'1': {'true': NC.active, 'false': NC.inactive}},
    '19': {'1': {'0': NC.isDisarmed, '2': NC.isPerimeter, '3': NC.isArmed}},
    '20': {'1': {'true': NC.active, 'false': NC.inactive}},
    '21': {'1': {'condition': {value: 0, 0: NC.turnedOff, 'others': ' is turned on for '}, 'addValue': true, 'suffix': ' Seconds'}},
    '22': {'1': {'true': NC.turnedOn, 'false': NC.turnedOff}},
    '24': {'1': {'true': NC.presenceDetected, 'false': NC.presenceNotDetected}},
    '25': {'1': {'prefix': NC.illuminanceChange, 'addValue': true, 'suffix': 'Lux'}},
    '26': {'1': {'true': NC.opened, 'false': NC.closed, 'addValue': false}},
    '27': {'1': {'prefix': NC.temperatureChange, 'suffix': '\u00B0F', 'addValue': true}, '2': {'prefix': NC.humidityChange, 'suffix': ' %', 'addValue': true}},
    '28': {'1': {'0': NC.notFullyLocked, '1': NC.locked, '2': NC.unlocked}},
    '29': {'1': {'prefix': NC.temperatureChange, 'suffix': '\u00B0F', 'addValue': true}},
    '32': {'1': {'fn': 'dimmerFunction', 'suffix': '%', 'prefix': NC.dimmedTo, 'factor': 0.392},
        '2': {'true': NC.turnedOn, 'false': NC.turnedOff}, '3': {'fn': 'colorHandler255', 'color': true, 'value': 255}, '4': {'fn': 'saturationHanlder', 'suffix': '%', 'prefix': ' Saturation set to ', 'factor': 0.392}, '5': {'prefix': ' color temperature is'}},
    '36': {'1': {'0': NC.noSmoke, '255': NC.smokeDected}},
    '37': {'1': {'0': NC.waterStopped, '255': NC.waterDected}},
    '38': {'1': {'false': NC.vibrationStopped, 'true': NC.vibrationDetected}},
    '39': {'1': {'true': NC.opened, 'false': NC.closed}},
    '40': {
        '2': {
            '0': NC.waterStopped, '255': NC.waterDected
        },
        '1': {
            'prefix': NC.temperatureChange, 'suffix': '\u00B0F', 'addValue': true
        }
    },
    '41': {'1': {'true': NC.motionChange, 'false': {DontNotify: true}}},
    '42': {'1': {'false': NC.isSilent, 'true': NC.isRinging}},
    '44': {'1': {'true': NC.stateChanged, 'false': NC.stateChanged}},
    '43': {
        '1': {
            'true': NC.swith1_on,
            'false': NC.swith1_off
        },
        '2': {
            'true': NC.swith2_on,
            'false': NC.swith2_off
        }
    },
    '45': {'1': {'true': NC.turnedOn, 'false': NC.turnedOff},
        '2': {'prefix': NC.powerReading, 'addValue': true}},
    '46': {'1': {'prefix': NC.temperatureChange, 'suffix': '\u00B0F', 'addValue': true}},
    '48': {
        '2': {'true': NC.turnedOn, 'false': NC.turnedOff},
        '3': {'fn': 'colorHandler6', 'color': true, 'value': 65535},
        '4': {'fn': 'saturationHanlder', 'suffix': '%', 'prefix': ' Saturation set to ', 'factor': 0.392},
        '5': {'fn': 'brightnessHandler', 'suffix': '%', 'prefix': ' Brightness set to ', 'factor': 0.392}

    },
    '49': {
        '1': {
            'true': NC.motionChange,
            'false': NC.motionStopped
        }, //'prefix':NC.heatingUp, 'suffix':'\u00B0F'
        '3': {
            'prefix': NC.illuminanceChange, 'suffix': '%', 'addValue': true
        },
        '4': {
            'prefix': NC.temperatureChange, 'suffix': '\u00B0F', 'addValue': true
        },
        '5': {
            'prefix': NC.humidityChange, 'suffix': '%', 'addValue': true
        }
    },
    '50': {
        '1': {'true': NC.turnedOn, 'false': NC.turnedOff},
        '2': {'prefix': ""}
    },
    '52': {
        '1': {
            '99': NC.opened,
            '0': NC.closed
        },
        '2': {
            '99': NC.goingUp,
            '0': NC.goingDown
        },
        '3': {
            'true': NC.stop
        }
    },
    '53': {
        '1': {
            '254': NC.opening,
            '0': NC.closed,
            '255': NC.opened,
            '252': NC.closing,
            '253': NC.stop
        }
    },
    '54': {
        '1': {'prefix': NC.temperatureChange, 'suffix': '\u00B0F', 'addValue': true},
        '2': {'prefix': NC.modeChange, 'suffix': '', 'addValue': true},
        '3': {'prefix': NC.heatingUp, 'suffix': '\u00B0F', 'addValue': true},
        '4': {'prefix': NC.coolingDown, 'suffix': '\u00B0F', 'addValue': true},
        '5': {'Auto Low': NC.fanAutoLow, 'On Low': NC.fanLow, 'Unknown 5': NC.Unknown5, 'On High': NC.fanHigh},
        '7': {'prefix': NC.unitsChanged, 'addValue': true},
        '8': {'0': NC.swing_stop, '1': NC.swing_on},
        '9': {'0': NC.power_off, '255': NC.power_on},
        '10': {'prefix': NC.ir_code, 'addValue': true},
        '11': {'prefix': NC.configuration, 'addValue': true}
    },
    '55': {
        '1': {'0': NC.sirenStoped, '1': NC.emergency, '2': NC.fireTone, '3': NC.ambulanceTone, '4': NC.police, '5': NC.doorChime, '6': NC.beep}
    },
    '56': {
        '2': {'prefix': NC.powerReading, 'suffix': 'W', 'addValue': true},
        '3': {'prefix': NC.energyReading, 'suffix': 'kW', 'addValue': true},
        '4': {'prefix': NC.clamp1Power, 'suffix': 'W', 'addValue': true},
        '5': {'prefix': NC.clamp1Energy, 'suffix': 'kW', 'addValue': true},
        '6': {'prefix': NC.clamp2Power, 'suffix': 'W', 'addValue': true},
        '7': {'prefix': NC.clamp2Energy, 'suffix': 'kW', 'addValue': true}
    },
    '57': {
        '10': {'prefix': NC.temperatureChange, 'addValue': true},
        '2': {'heat-cool': NC.modeChangeHC, 'cool': NC.modeChangeCool, 'off': NC.modeChangeOff, 'heat': NC.modeChangeHeat, 'echo': NC.modeChangeEcho},
        '3': {'prefix': NC.targetTemp, 'suffix': '\u00B0F', 'addValue': true},
        '4': {'prefix': NC.humidityChange, 'addValue': true},
        '5': {'prefix': NC.coolingDown, 'suffix': '\u00B0F', 'addValue': true},
        '6': {'prefix': NC.heatingUp, 'suffix': '\u00B0F', 'addValue': true},
        '9': {'true': NC.fan_on, 'false': NC.fan_stopped},
        '11': {'false': NC.offline, 'true': NC.online},
        '14': {'true': NC.usingEmergencyHeat},
        '16': {'prefix': NC.is, 'addValue': true},
        '18': {'-1': NC.error_1, '-2': NC.error_2, '-3': NC.error_3, '-4': NC.error_4, '-5': NC.error_5, '-6': NC.error_6, '-7': NC.error_7, '-8': NC.error_8, '-9': NC.error_9, '-10': NC.error_10, '-11': NC.error_11, '-12': NC.error_12, '-13': NC.error_13, '-14': NC.error_15, '-15': NC.error_15, '-16': NC.error_16, '-17': NC.error_17, '-18': NC.error_18, '503': NC.error_503, '429': NC.tooMany}
    },
    '62': {
        '1': {
            'prefix': NC.temperatureChange, 'suffix': '\u00B0F', 'addValue': true
        },
        '4': {
            'prefix': NC.heatingUp, 'suffix': '\u00B0F', 'addValue': true
        },
        '5': {
            'prefix': NC.coolingDown, 'suffix': '\u00B0F', 'addValue': true
        },
        '2': {
            'prefix': NC.modeChange, 'suffix': '', 'addValue': true
        },
        '6': {
            'prefix': NC.fanChange, 'suffix': '', 'addValue': true
        }
    },
    '63': {
        '1': {
            'true': NC.sirenEnabled,
            'false': NC.sirenDisabled
        },
        '2': {
            'true': NC.sirenRinging,
            'false': NC.sirenSilent
        },
        '3': {
            '1': NC.sirenAlarm,
            '2': NC.sirenSiren,
            '3': NC.sirenDoor
        },
        '4': {
            '1': NC.sirenLow,
            '2': NC.sirenHigh,
            '3': NC.sirenMedium
        },
        '5': {
            'prefix': "'s timer set to ", 'suffix': " sec", 'addValue': true
        }
    }, //64,3,14
    '64': {
        '1': {
            'true': NC.turnedOn,
            'false': NC.turnedOff
        },
        '2': {
            'false': NC.stoppedBlinking,
            'true': NC.isBlinking
        },
        '3': {
            'prefix': NC.setBrightness, 'suffix': '%', 'getValue': true, 'addValue': true
        },
        '4': {
            'prefix': "'s timer set to ", 'suffix': " sec", 'addValue': true
        }
    },
    '58': {
        '3': {'warning': NC.co_warning, 'emergency': NC.co_emergency, 'ok': NC.co_not_detected},
        '4': {'warning': NC.smoke_warning, 'emergency': NC.smoke_emergency, 'ok': NC.smoke_not_detected},
        '5': {'true': NC.offline, 'false': NC.online},
        '7': {'-1': NC.error_1, '-2': NC.error_2, '-3': NC.error_3, '-4': NC.error_4, '-5': NC.error_5, '-6': NC.error_6, '-7': NC.error_7, '-8': NC.error_8, '-9': NC.error_9, '-10': NC.error_10, '-11': NC.error_11, '-12': NC.error_12, '-13': NC.error_13, '-14': NC.error_15, '-15': NC.error_15, '-16': NC.error_16, '-17': NC.error_17, '-18': NC.error_18, '503': NC.error_503, '429': NC.tooMany}
    }
};
var genericIndexHandler = function (deviceType, indexName, value) {
    if (indexName == 'BATTERY' || indexName == "HUMIDITY") {
        return "'s " + indexName.slice(0, 1).toUpperCase() + indexName.slice(1).toLowerCase() + " is " + value + "%";
    } else if (indexName == "TAMPER" && value == 'true')
        return NC.tampered;
    else if (indexName == 'LOW BATTERY' && value == 'true')
        return NC.lowBattery;
    else
        return undefined;
};

var rgbtoHsv = function (r, g, b) {
    var rgb = [];
    rgb[0] = r;
    rgb[1] = g;
    rgb[2] = b;
    for (var i = 0; i < rgb.length; i++) {
        if (rgb[i] == "")
            rgb[i] = 0;
        rgb[i] = parseFloat(rgb[i]);
        if (rgb[i] < 0)
            rgb[i] = 0;
        if (rgb[i] > 255)
            rgb[i] = 255;
    }
    r = rgb[0];
    g = rgb[1];
    b = rgb[2];
    hex = r * 65536 + g * 256 + b;
    hex = hex.toString(16, 6);
    len = hex.length;
    if (len < 6) {
        for (i = 0; i < 6 - len; i++) {
            hex = '0' + hex;
        }
    }
    r /= 255;
    g /= 255;
    b /= 255;
    M = Math.max(r, g, b);
    m = Math.min(r, g, b);
    C = M - m;
    if (C == 0)
        h = 0;
    else if (M == r)
        h = ((g - b) / C) % 6;
    else if (M == g)
        h = (b - r) / C + 2;
    else
        h = (r - g) / C + 4;
    h *= 60;
    if (h < 0)
        h += 360;
    v = M;
    if (v == 0)
        s = 0;
    else
        s = C / v;
    s *= 100;
    v *= 100;
    return Math.ceil(v);
};
var getValue = function (value) {
    var h = value;
    var r = ((parseInt(h) & 0xFF0000) >> 16);
    var g = ((parseInt(h) & 0x00FF00) >> 8);
    var b = ((parseInt(h) & 0x0000FF));
    return value = rgbtoHsv(r, g, b);
};

messageGenerator.getMessage = function getAlertMessage(deviceType, device_name, index, value, json, callback) {
    try {
        var typeMap = messageGenerator.deviceTextMap[deviceType];
        if (typeMap == undefined) {
            json['alert'] = device_name + ' :  value changed';
            return json['alert'];
        }
        var indexValue = typeMap[index];
        json['alert'] = constructMessage(device_name, value, indexValue, json, deviceType);
        return json['alert'];
    } catch (error) {
        console.log("Some random error", error);
        return;
    }
};

function constructMessage(deviceName, value, json, inputJson, deviceType) {
    var IndexNames = ['BATTERY', 'HUMIDITY', 'TAMPER', 'LOW BATTERY'];

    if (IndexNames.indexOf(inputJson['indexName']) > -1) {
        alert = genericIndexHandler(deviceType, inputJson['indexName'], value);
        return alert != undefined ? deviceName + alert : '';
    }
    if (json) {
        var alert = '';
        alert += deviceName;
        if (json.getValue)
            value = getValue(value);
        if (json[value]) {
            if (json[value].DontNotify) {
                return '';
            }
            alert += json[value];
        }
        if (json.condition) {
            alert += value == json.condition.value ? json.condition[value] : json.condition.others;

        }
        if (json.color)
            return alert += colorIze(value, json.value);
        if (json.prefix)
            alert += json.prefix;
        if (json.factor) {
            zero = value * json.factor;
            alert += zero != 0 ? Math.round(value * json.factor) : '';
        }
        if (json.addValue)
            alert += value;
        if (json.suffix)
            alert += json.suffix;
        return alert;
    }
}
module.exports = messageGenerator;
