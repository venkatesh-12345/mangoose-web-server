var databaseConnection = require("../../database/sql/sqlQuery.js");
var simAlmond = require('../TestConfigs/standaloneEnv');
var simAlmondDB = require('../TestConfigs/test1');
var bcrypt = require("bcrypt");

//databaseConnection.Start;
var dbmodifier = {};

dbmodifier.saltAndHash = function (pass, callback){
	bcrypt.genSalt(10, function(err, salt) {
		bcrypt.hash(pass, salt, function(err, hash) {
			return callback(hash);
		});
	});
};

dbmodifier.dbConnection = databaseConnection;

dbmodifier.createUser = function (EmailID,Password,callback){
	const query = 'INSERT INTO ?? (EmailID,Password,EmailValidated) VALUES ( ? , ? , ? ) ';
	dbmodifier.saltAndHash(Password,function(hash){
		const params = [ 'Users',EmailID,hash,0];
		databaseConnection.queryFunction(query, params, function(err, rows) {
		   if (err) {
				callback(err);
		   } else {
			 callback(undefined, rows);
		   }	
		});
	});
};

dbmodifier.createTempass = function(Temppass,userid,callback){
	const query = 'INSERT INTO ?? (UserId,TempPassword) VALUES ( ? , ? )';
	const params = [ 'UserTempPasswords', userid, Temppass];
	databaseConnection.queryFunction(query, params, function(err, rows){
		if(err){
			callback(err);
		}else{
			callback(undefined, rows);
		}
	});
};

dbmodifier.deleteUser = function (EmailID , callback) {
	const query = 'DELETE FROM ?? where EmailID = ? ';
	const params = [ 'Users',EmailID] ;
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
		 callback(err);
	   } 
	   else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.createAlmond = function (AlmondMAC,AlmondID,AlmondName,LongSecret,firmwareVersion,callback){
	const query = 'INSERT INTO ?? (AlmondMAC,AlmondID,AlmondName,LongSecret,FirmwareVersion) VALUES ( ? , ? , ? , ? , ? )';
	const params = [  'AllAlmondPlus' , AlmondMAC , AlmondID , AlmondName , LongSecret , firmwareVersion ];
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
			callback(err);
	   } else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.deleteAlmond = function (AlmondMAC , callback) {
	const query  = 'DELETE FROM ?? where AlmondMAC = ?';
	const params = [ 'AllAlmondPlus' , AlmondMAC ];
	console.log("deleting this almond mac: ", AlmondMAC);
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
			callback(err);
	   } else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.assignUserToAlmond = function (AlmondMAC,Email,callback){
	const query = 'INSERT INTO ?? (AlmondMAC,userID,ownership,AlmondName) SELECT ? , UserID , \'P\' ,AlmondName  from ?? , ?? where EmailID = ? and AlmondMAC = ?';
	const params = [ 'AlmondUsers' , AlmondMAC ,  'Users' ,  'AllAlmondPlus' ,Email,AlmondMAC ];
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
			callback(err);
	   } 
	   else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.unlinkUserToAlmond = function (AlmondMAC ,callback) {
	const query  = 'DELETE FROM ?? where AlmondMAC =  ? '; 	
	const params  = [ 'AlmondUsers' , AlmondMAC  ] ;
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
		 callback(err);
	   } 
	   else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.addScene = function (AlmondMAC,SceneID, SceneName,callback){
	const query = 'INSERT INTO ?? (AlmondMAC , SceneID , SceneName , IsActive) VALUES (? , ? , ? , false ) ';
	const params = [ 'Scene' , AlmondMAC , SceneID , SceneName ];
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
			callback(err);
	   }else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.deleteScene = function (AlmondMAC , SceneID , callback){
	const query = 'DELETE FROM ?? where AlmondMAC = ?  and SceneID =  ? ';
	const params = [ 'Scene' , AlmondMAC , SceneID];
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
		 callback(err);
	   }
	   else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.addWifiClientToAlmond = function(AlmondMAC, ClientId, ClientDetails, callback){
	const query = 'INSERT INTO ?? (AlmondMAC , ClientId , ClientDetails) VALUES (? , ? , ? ) ';
	const params = [ 'WifiClients' , AlmondMAC , ClientId , ClientDetails ];
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
			callback(err);
	   }else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.deleteWifiClient = function(AlmondMAC, ClientID, callback){
	const query = 'DELETE FROM ?? where AlmondMAC = ?  and ClientID =  ? ';
	const params = [ 'WifiClients' , AlmondMAC , ClientID];
	databaseConnection.queryFunction(query, params, function(err, rows) {
	   if (err) {
		 callback(err);
	   }
	   else {
		 callback(undefined, rows);
	   }	
	});
};

dbmodifier.main = function(callback){
	/*var option = 1;
	if(option==1){
		dbmodifier.createUser('2@securifi.com','123456',function (err,rows){
			if(err!=undefined || err!=null){
				console.log("Error : " , err);
			}
			else{
				console.log("Rows returned : " , rows );
			}
		});
	}
	else if(option==2){
		dbmodifier.deleteUser('2@securifi.com',function (err,rows){
			if(err!=undefined || err!=null){
				console.log("Error : " , err);
			}
			else{
				console.log("Rows returned : " , rows );
			}
		});
	}
	else if(option==3){
		dbmodifier.createAlmond ('8315','$2a$10$.Qf.rVTHuMtcoyl.LaPnFekWvG1ltfwTzgWVXrYuUh14auqnPK3y6','testtwo','nothing',function(err,rows){
			if(err!=undefined || err!=null){
				console.log("Error : " , err);
			}
			else{
				console.log("Rows returned : " , rows );
			}
		});
	}
	else if(option==4){
		dbmodifier.deleteAlmond ('8315',function (err,rows){
			if(err!=undefined || err!=null){
				console.log("Error : " , err);
			}
			else{
				console.log("Rows returned : " , rows );
			}
		});
	}
	else if(option==5){
		dbmodifier.assignUserToAlmond ('8315','2@securifi.com',function (err,rows){
			if(err!=undefined || err!=null){
				console.log("Error : " , err);
			}
			else{
				console.log("Rows returned : " , rows );
			}
		});
	}
	else if(option==6){
		dbmodifier.unlinkUserToAlmond('8313' ,function (err,rows){
			if(err!=undefined || err!=null){
				console.log("Error : " , err);
			}
			else{
				console.log("Rows returned : " , rows );
			}
		});
	}
	else if(option==7){
		dbmodifier.addScene('8314','3', 'testscenetwo',function (err,rows){
			if(err!=undefined || err!=null){
				console.log("Error : " , err);
			}
			else{
				console.log("Rows returned : " , rows );
			}
		});
	}
	else if(option==8){
		dbmodifier.deleteScene('8314','3' , function (err,rows){
			if(err!=undefined || err!=null){
				console.log("Error : " , err);
			}
			else{
				console.log("Rows returned : " , rows );
			}
		});
	}*/
	return callback();
};

/*dbmodifier.main(function(){
		console.log("done");
});*/
//added almond 8313,8314 , user 2@securifi.com

/*dbmodifier.createUser('dummy_almond3@securifi.com', '000000', 0, function(err, rows){
	if(err){
		console.log("error creating a new user");
	}else{
		dbmodifier.createAlmond('8444','$2a$10$.Qf.rVTHuMtcoyl.LaPnFekWvG1ltfwTzgWVXrYuUh14auqnPK3y6','Dummy Almond 3','sadsadasdasd','AP2',function(err, rows){
			if(err) return;
			console.log("almond successfult");
		})
	}
})*/

dbmodifier.getValidationToken = function(email, callback) {
    
    databaseConnection.queryFunction('SELECT ValidationToken from ?? where EmailID=?', ['Users', email], function (err, rows) {
        if (err || rows.length === 0) {
            callback(err);
        }
        callback(null, rows[0].ValidationToken);
    });
};

var dbMapper = {
    "devices": {
        "table": "DeviceData",
        "mac": "AlmondMAC",
        "id": "DeviceID",
        "keys": ["DeviceName", "Location", "DeviceType"]
    },
    "scenes": {
        "table": "Scene",
        "mac": "AlmondMAC",
        "id": "SceneID",
        "keys": ["SceneName", "SceneEntryList", "IsActive"]
    },
    "rules": {
        "table": "Rule",
        "mac": "AlmondMAC",
        "id": "ID",
        "keys":["Name", "Valid", "Triggers", "Actions"]
    },
    "wifiClients": {
        "table": "WifiClients",
        "mac": "AlmondMAC",
        "id": "ClientID",
        "keys": ["ClientDetails"]
    }
};
dbmodifier.prepareEnvironDB = function (callback) {
    // loop through all the DBs and insert all of them
    Object.keys(simAlmondDB).forEach(function(db) {
        var query = "INSERT INTO ?? (" + dbMapper[db].mac + ',' + dbMapper[db].id + ',' + dbMapper[db].keys.join() + ") VALUES (?)";
        var valArr = [];
        var params = [];
        Object.keys(simAlmondDB[db]).forEach(function(id) {
            params = []; valArr = [];
            params.push(dbMapper[db].table);
            valArr.push(simAlmond.testEnviron.almondMAC);
            valArr.push(id);
            if(db === "wifiClients") {
                valArr.push(JSON.stringify(simAlmondDB[db][id]));
            } else if (db === "scenes") {
                valArr.push(simAlmondDB[db][id].Name);
                valArr.push(JSON.stringify(simAlmondDB[db][id].SceneEntryList));
                valArr.push(simAlmondDB[db][id].Active);
            } else if (db === "devices") {
                valArr.push(simAlmondDB[db][id].Data.Name);
                valArr.push(simAlmondDB[db][id].Data.Location);
                valArr.push(simAlmondDB[db][id].Data.Type);
            } else {
                return;
            }
            params.push(valArr);
            databaseConnection.queryFunction(query, params, function() {
                //query = ""
                console.log('--------- kjdkfkjdf -----------');
            });
        });
        
    });
    setTimeout(function() {
        callback();
    }, 2000);
};
//dbmodifier.prepareEnvironDB();

module.exports = dbmodifier;

