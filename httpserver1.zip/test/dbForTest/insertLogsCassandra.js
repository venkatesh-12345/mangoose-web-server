var moment = require('moment');
var devTypeMap = require('./NotificationTextGenerator');
var loggerPoint = require('../../database/cassandra/cqlConnection');


var fetchSize = 50;
const ALMOND_MAC = 123456789;
const DEV_ID = 12;
const CLI_ID = 875421;
const MAX_DEV_ID = 10;
const TIME = Date.now();
var date = moment.utc().utcOffset(0);
const CURR_DATE = date.format('YYYY-MM-DD');

var insertLogs = {};

var insert = function (data, table, callback) {
    var dateyear = data.dateyear;//moment(data.time).subtract(day,"days").format('YYYY-MM-DD');
    var query;
    var params = [];
    if (table === "dynamic_update_wifi_client")
        query = "insert into " + table + " (mac, client_mac, time , client_id , client_name , client_type , dateyear , mac_date , userid , value ) values " +
                "(" + data.mac + "," + data.client_mac + "," + data.time + "," + data.client_id + ",'" + data.client_name + "','" + data.client_type + "','" + dateyear + "','" + data.mac + ':' + dateyear + "','" + data.userid + "','" + data.value + "')";
    else if (table === "dynamic_update_log")
        query = "insert into " + table + " (mac, device_id , time , index_id , dateyear , device_name , type , index_name , mac_date , userid , value ) values " +
                "(" + data.mac + "," + data.device_id + "," + data.time + "," + data.index_id + ",'" + dateyear + "','" + data.device_name + "','" + data.device_type + "', '" + data.index_name + "','" + data.mac + ':' + dateyear + "','" + data.userid + "','" + data.value + "')";
    else if (table === 'dynamic_log') {
        query = "INSERT INTO " + table + " (mac, id, time, index_id, dateyear, name, type, index_name, client_id, mac_date, userid, value) VALUES (?,?,?,?,'" + data.dateyear + "',?,?,?,?,?,?,?);";
        params = [data.mac, data.id, data.time, data.index_id, data.name, data.type.toString(), data.index_name, data.client_id, data.mac + ":" + data.dateyear, data.userid, data.value];
    }
    loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
        if (error)
            console.log(error);
        else
            callback();
    });
};

insertLogs.clearDB = function(mac, callback) {
    var query = "DELETE FROM dynamic_log WHERE mac = ? AND id IN ?;";
    var devids = [];
    for (var i = 1; i <= MAX_DEV_ID; i++) {
        devids.push(i);
    }
    devids.push(CLI_ID);
    var params = [mac, devids];
    loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
        callback(error);
    });
}

var devices = [];
function populateDevs() {
    for (var i = 1; i <= MAX_DEV_ID; i++) {
        devices.push(getRandomDevDetails());
    }
}

populateDevs();

function getRandInt(limit) {
    return Math.floor(Math.random() * limit);
}

function getRandomDevDetails(){
    var devTypes = Object.keys(devTypeMap.deviceTextMap);
    var devType = devTypes[Math.floor(Math.random() * devTypes.length)];
    var indexTypes = Object.keys(devTypeMap.deviceTextMap[devType]);
    var indexType = indexTypes[Math.floor(Math.random() * indexTypes.length)];
    var index = devTypeMap.deviceTextMap[devType][indexType];
    var indexValue;
    if(index['true'])
        indexValue = true;
    else if (index['addValue']=== true)
        indexValue = getRandInt(100);
    else if(Number.isInteger(+Object.keys(index)[0])) {
        indexValue = Object.keys(index)[0];
    } else
        indexValue = 'random value';
    
    var indexId = 1;
    var indexName = 'index#1';
    
    
    return {devType:devType, indexId:indexId, indexType:indexType, indexName:indexName, indexValue: indexValue};// return JSON
}

function insertOneRecord(mac, i, callback) {
    var id = getRandInt(10);
    var devData = {
        mac: mac,
        id: id+1,
        time: TIME + i,
        index_id: devices[id].indexId,
        index_name: devices[id].indexName,
        type: devices[id].indexType,
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: devices[id].indexValue + ''
    };
    devData.name = 'name#' + devData.id;
    insert(devData, "dynamic_log", function () {
        callback();     // ****** NOTE ****: comment this if you are using clients also
    });
    /*var cliData = {
        mac: mac,
        id: CLI_ID,
        time: TIME + i,
        index_id: 123456,
        client_id: 12,
        type: "30",
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: "client value"
    };
    cliData.name = 'name#' + cliData.id;
    insert(cliData, "dynamic_log", function () {  // See the note above
        callback();
    });*/
}

insertLogs.createDB = function (mac, totalRec, perdayRec, callback) {
    var nextItemIndex = 0;
    function iterator(err) {
        nextItemIndex++;
        if (nextItemIndex === totalRec) {
            callback(err);
        }
        else {
            if(nextItemIndex % perdayRec ===0) {
                date.subtract(1,'day');
                setTimeout(function() {
                    insertOneRecord(mac, nextItemIndex, function () {
                        iterator();
                    });
                }, 500);
            }
            else
            insertOneRecord(mac, nextItemIndex, function () {
                iterator();
            });
        }
    }
    insertOneRecord(mac, nextItemIndex, function () {
        iterator();
    });
};

module.exports = insertLogs;
