/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var request = require('request');
var dbmodifier = require('./dbmodifier');
var nconf = require('nconf');
require('../TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var httpUrl = nconf.get('httpUrl');
var Affiliation = require('../Simulator/Affiliation/Affiliation.js');
var Almond = require('../Simulator/Almond.js');
var redisConn = require('../../database/redis/redisConnector');
var simAlmond = require('../TestConfigs/standaloneEnv');
var simAlmondDB = require('../TestConfigs/test1');

var accManager = {};
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

function clone(a) {
    return JSON.parse(JSON.stringify(a));
}

function clearFWversion(callback) {
    var key = 'AL_' + testEnv.almondMAC;
    redisConn.query('hdel', {key:key,params: ['version', 'name', 'status', 'server']}, function() {
        callback();
    });
}

function setFWversion(callback) {
    var key = 'AL_' + testEnv.almondMAC;
    redisConn.query('hmset', {key:key, params:['version', testEnv.almondVersion, 'name', testEnv.almondName, 'status', '1', 'server', 'S12']}, function() {
        callback();
    });
}

accManager.offlineAlmondRedis = function(offlineMAC, callback) {
    var key = 'AL_' + offlineMAC;
    redisConn.query('hmset', {key:key,params: ['version', testEnv.almondVersion, 'name', testEnv.almondName, 'status', '0', 'server', 'S12']}, function() {
        callback();
    });
};

accManager.clearAccounts = function (callback) {
    dbmodifier.deleteUser(testEnv.emailID, function (err, rows) {
        if (err)
            return callback(err);
        dbmodifier.deleteAlmond(testEnv.almondMAC, function (err, rows) {
            if (err)
                return callback(err);
            clearFWversion(function (err) {
                callback(err);
                console.log('done');//done();
            });

        });
    });
};

accManager.createAccounts = function (callback) {
    dbmodifier.createUser(testEnv.emailID, testEnv.password, function (err, rows) {
        if (err)
            return callback(err);
        dbmodifier.createAlmond(testEnv.almondMAC, testEnv.almondPlusID, testEnv.almondName, testEnv.longSecret, testEnv.almondVersion, function (err, rows) {
            if (err)
                return callback(err);
            console.log("Almond and User accounts created");
            setFWversion(function (err) {
                callback(err);
            });
        });
    });
};

accManager.getUserIDtempPass = function(loginCreds, callback) {
    var options = {
        method: 'POST',
        url: httpUrl + '/Login',
        headers: {
            'authorization': 'Bearer ',
            'content-type': TYPE_JSON
        },
        body: {
            'emailID': loginCreds.emailID,
            'password': loginCreds.password
        },
        json: true
    };
    request(options, function (err, res, body) {
        if (err)
            return callback(err);
        if(!body)
            return callback(true)
        callback(null, {userID: body.userID, tempPass: body.tempPass});
    });
};

accManager.activateVerifyAccount = function(email, callback) {
    var options = {
        method: 'POST',
        url: httpUrl + '/ResendActivationLink',
        body: {
            'emailID': email
        },
        json: true
    };
    request(options, function (error, response, body) {
        if (error)
            return callback(error);
        dbmodifier.getValidationToken(email, function(err, token) {
            if (err)
                return callback(err);
            options.url = httpUrl + '/VerifyAccount';
            options.body.token = token;
            console.log('body :: ', options.body);
            request(options, function (error, response, body) {
                if (error)
                    callback(error);
                console.log(body);
                callback();
            });
        });
    });
};

accManager.affiliateAlmond = function (callback) {
    var Almond1 = {
        "almondPlusID": testEnv.almondPlusID,
        "almondMAC": testEnv.almondMAC,
        "EmailID": testEnv.emailID,
        "password": testEnv.password,
        "longSecret": testEnv.longSecret,
        "firmwareVersion": testEnv.almondVersion,
        "AlmondName": testEnv.almondName,
        "link": true
    };
    Affiliation(Almond1, function (linked) {
        console.log('##### Almond Affiliation #####  ' + linked);
        var param = clone(Almond1);
        var confs = require('../TestConfigs/test1.json');
        param.devices = confs.devices;
        param.scenes = confs.scenes;
        param.wifiClients = confs.wifiClients;
        param.rules = confs.rules;
        almond = new Almond(param);
        almond.on('cloudconnected', function () {
            console.log(" Almond connected to mobile ");
            //return done();
            accManager.getUserIDtempPass({'emailID': testEnv.emailID, 'password': testEnv.password}, function(err, creds) {
                callback(null, {userID: creds.userID, tempPass: creds.tempPass});
            });
        });
    });
};

accManager.unlinkAlmond = function (callback) {
    var Almond1 = {
        "almondPlusID": testEnv.almondPlusID,
        "almondMAC": testEnv.almondMAC,
        "EmailID": testEnv.emailID,
        "password": testEnv.password,
        "longSecret": testEnv.longSecret,
        "firmwareVersion": testEnv.almondVersion,
        "AlmondName": testEnv.almondName,
        "link": false
    };
    if (testEnviron === 'standaloneEnv') {
        console.log("------------- unlinkUserToAlmond ---------");
        dbmodifier.unlinkUserToAlmond(testEnv.almondMAC, function() {
            callback();
        });
    } else if (testEnviron === 'stagingEnv') {
        Affiliation(Almond1, function (unlinked) {
            almond.killConnection();
            callback();
        });
    }
};

accManager.getAuthToken = function (testEnviron, testInput, callback) {
    console.log('getting auth token from account manager ...');
    if (accManager.accessToken) {
        console.log('returning previous token');
        return callback(null, accManager.accessToken);
    }
    
    var res;
    if (testEnviron !== 'productionEnv')
        accManager.clearAccounts(function (err) {
            if (err)
                return callback(err);
            accManager.createAccounts(function (err) {
                if (err)
                    return callback(err);
                
                if (testEnviron === 'standaloneEnv') {
                    dbmodifier.assignUserToAlmond(testInput.almondMAC, testInput.emailID, function () {
                        dbmodifier.prepareEnvironDB(function() {
                            accManager.getUserIDtempPass({'emailID': testInput.emailID, 'password': testInput.password}, function (err, creds) {
                                res = creds.tempPass + ':' + creds.userID;
                                console.log('---------- standaloneEnv ---------', res);
                                accManager.accessToken = res;
                                callback(err, res);
                            });
                        });
                    });
                } else if (testEnviron === 'stagingEnv') {
                    accManager.affiliateAlmond(function (err, creds) {
                        if (err)
                            return callback(err);
                        res = creds.tempPass + ':' + creds.userID;
                        accManager.accessToken = res;
                        callback(null, res);
                    });
                }
            });
        });
    else {
        console.log('Testing the environment : ', testEnviron);
        accManager.getUserIDtempPass({'emailID': testInput.emailID, 'password': testInput.password}, function (err, creds) {
            res = creds.tempPass + ':' + creds.userID;
            accManager.accessToken = res;
            callback(err, res);
        });
    }
};

accManager.httpDeleteAccount = function (loginCreds, callback) {
    accManager.getUserIDtempPass(loginCreds, function(err, creds) {
        if(err)
            return callback(null,true)
        var options = {
            method: 'POST',
            url: httpUrl + '/DeleteAccount',
            headers: {
                'authorization': 'Bearer '+ creds.tempPass + ':' + creds.userID,
                'content-type': TYPE_JSON
            },
            body: {
                'emailID': loginCreds.emailID,
                'password': loginCreds.password
            },
            json: true
        };
        request(options, function (err, res, body) {
            if (err)
                return callback(err);
            callback(null, true);
        });
    });
};

accManager.httpSignup = function (loginCreds, callback) {
    var options = {
        method: 'POST',
        url: httpUrl + '/SignUp',
        headers: {
            
            'content-type': TYPE_JSON
        },
        body: {
            'emailID': loginCreds.emailID,
            'password': loginCreds.password
        },
        json: true
    };
    request(options, function (err, res, body) {
        if (err)
            return callback(err);
        callback(null, true);
    });
};

module.exports = accManager;
