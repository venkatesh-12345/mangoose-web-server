var moment = require('moment');
var devTypeMap = require('./NotificationTextGenerator');
var cassandra = require('cassandra-driver');
var cassConfig = require('../../config').downloadLogsEndpoint;
console.log('____________________STARTING CLIENT WITH________________________');
console.log(cassConfig);
console.log('_____________________END CONFIG_______________________');

var consistencyVal = cassandra.types.consistencies.one;
var authProvider1 = new cassandra.auth.PlainTextAuthProvider(cassConfig['user'], cassConfig['password']);
const remoteNodes = 2;
const localDc = 'us-east';
var loggerPoint = new cassandra.Client({
    queryOptions: {
        consistency: consistencyVal
    },
    pooling: {
        coreConnectionsPerHost: {
            '0': 2,
            '1': 2
        }
    },
    authProvider: authProvider1,
    keyspace: cassConfig.keySpace,
    contactPoints: cassConfig.host,
    policies: {
        loadBalancing: new cassandra.policies.loadBalancing.DCAwareRoundRobinPolicy(localDc, remoteNodes)
    }
});


var fetchSize = 50;
const ALMOND_MAC = 123456789;
const DEV_ID = 12;
const CLI_ID = 875421;
const MAX_DEV_ID = 10;
const TIME = Date.now();
var date = moment.utc().utcOffset(0);
const CURR_DATE = date.format('YYYY-MM-DD');

var insertLogs = {};

var insert = function (data, callback) {
    var dateyear = data.dateyear;//moment(data.time).subtract(day,"days").format('YYYY-MM-DD');
    var query = 'INSERT INTO scsi.event_log (userid, pk, dateyear, ip, mac, message) VALUES ( ?, now(), ?, ?, ?, ?);';
    var params = [data.userid, data.dateyear, data.ip, data.mac, data.message];
    
    loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
        if (error)
            console.log(error);
        else
            callback();
    });
};

insertLogs.clearDB = function(mac, callback) {
    var query = "DELETE FROM scsi.event_log WHERE mac = ? and dateyear IN ?";
    var params = [mac];
    date = moment.utc().utcOffset(0);
    var dateArr = [];
    for (var i = 0; i < 30; i++) {
        dateArr.push( date.format('YYYY-MM-DD'));
        
        date.subtract(1, 'day');
    }
    params.push(dateArr);
    loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
        callback(error);
    });
}

var devices = [];
function populateDevs() {
    for (var i = 1; i <= MAX_DEV_ID; i++) {
        devices.push(getRandomDevDetails());
    }
}

populateDevs();

function getRandInt(limit) {
    return Math.floor(Math.random() * limit);
}

function getRandomDevDetails(){
    var devTypes = Object.keys(devTypeMap.deviceTextMap);
    var devType = devTypes[Math.floor(Math.random() * devTypes.length)];
    var indexTypes = Object.keys(devTypeMap.deviceTextMap[devType]);
    var indexType = indexTypes[Math.floor(Math.random() * indexTypes.length)];
    var index = devTypeMap.deviceTextMap[devType][indexType];
    var indexValue;
    if(index['true'])
        indexValue = true;
    else if (index['addValue']=== true)
        indexValue = getRandInt(100);
    else if(Number.isInteger(+Object.keys(index)[0])) {
        indexValue = Object.keys(index)[0];
    } else
        indexValue = 'random value';
    
    var indexId = 1;
    var indexName = 'index#1';
    
    
    return {devType:devType, indexId:indexId, indexType:indexType, indexName:indexName, indexValue: indexValue};// return JSON
}

function insertOneRecord(mac, i, callback) {
    var id = getRandInt(10);
    var devData = {
        mac: mac,
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        ip: '127.0.0.1',
        message: "testing with dummy"
    };
    devData.name = 'name#' + devData.id;
    insert(devData, function () {
        callback();     // ****** NOTE ****: comment this if you are using clients also
    });
}

insertLogs.createDB = function (mac, totalRec, perdayRec, callback) {
    var nextItemIndex = 0;
    function iterator(err) {
        nextItemIndex++;
        if (nextItemIndex === totalRec) {
            callback(err);
        }
        else {
            if(nextItemIndex % perdayRec ===0) {
                date.subtract(1,'day');
                setTimeout(function() {
                    insertOneRecord(mac, nextItemIndex, function () {
                        iterator();
                    });
                }, 500);
            }
            else
            insertOneRecord(mac, nextItemIndex, function () {
                iterator();
            });
        }
    }
    insertOneRecord(mac, nextItemIndex, function () {
        iterator();
    });
};

//insertLogs.createDB(123456, 100, 10, function(err) {
//    console.log(err);
//    console.log('--------- inserting done ---------');
//});

insertLogs.clearDB(123456, function(err) {
    if (err)
        console.log(err);
    else
        console.log('clear db Done');
});

module.exports = insertLogs;
