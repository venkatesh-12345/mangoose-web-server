/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var moment = require('moment');
var accManager = require('./dbForTest/accountManager');
var testConfig = require('./TestConfigs/testConfig');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var CLEAR_DB = nconf.get('CLEAR_DB');
var testInput = nconf.get('recentActivity');
//var loggerPoint = require('../database/cassandra/cqlConnection');
var pgClient = require('../database/postgres/pgQueryNew');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';
var date = moment.utc().utcOffset(0);
const CURR_DATE = date.format('YYYY-MM-DD');
var devIdArr = [1, 2, 3];
var cliIdArr = [12131415, 12131416, 12131417];

const TIME = Date.now();
var insert = function (data, category, callback) {
    //console.log("data to insert", data);
    var query;
    var params = [];
    if (category === "device") {
        query = "INSERT INTO recentactivity (mac, id, time, index_id, index_name, name, type, value) VALUES ($1, $2, NOW(), $3, $4, $5, $6, $7)";
        params = [data.mac, data.id, data.index_id, data.index_name, data.name, data.type, data.value];
        
    } else if (category === "client") {
        query = "INSERT INTO recentactivity (mac, id, time, index_id, client_id, index_name, name, type, value) VALUES ($1, $2, NOW(), $3, $4, $5, $6, $7, $8)";
        params = [data.mac, data.id, data.index_id, data.client_id, data.index_name, data.name, data.type, data.value];
        
    }
    //console.log(query);
    //console.log(JSON.stringify(params));
    pgClient.query(query, params, function (err, res) {
        callback(err, res);
    });
};

function clearDB(mac, callback) {
    var query = "DELETE FROM recentactivity WHERE mac = $1 AND id = ANY($2::bigint[]);";
    var params = [mac, devIdArr.concat(cliIdArr)];
    pgClient.query(query, params, function (err, res) {
        console.log(err);
        callback(err);
    });
}

function insertOneRecord(i, callback) {
    var rand = Math.floor(Math.random() * 2);
    var devData = {
        mac: testEnv.almondMAC,
        id: devIdArr[rand],
        time: TIME + i,
        index_id: 1,
        index_name: 'indexName#1',
        type: "20",
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: "device value"
    };
    //console.log(TIME+j);
    devData.name = 'name#' + devData.id;
//    for (var index = 0; index < 3; index++) {
//        devData.id = devIdArr[index];
        insert(devData, "device", function (err, res) {
            //console.log("Insert Done");
        });
//    }
    
    var cliData = {
        mac: testEnv.almondMAC,
        id: cliIdArr[rand],
        time: TIME + i,
        index_id: 123456,
        client_id: 12,
        type: "30",
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: "client value"
    };
    cliData.name = 'name#' + cliData.id;
//    for (var index = 0; index < 3; index++) {
//        cliData.id = cliIdArr[index];
        insert(cliData, "client", function () {
            //console.log("Insert Done");
        });
//    }
    //setTimeout(callback,100);
}

var createDB = function (callback) {
    var nextItemIndex = 0;
    
    setInterval(function () {
        if (nextItemIndex > 1000) {
            clearInterval(this);
            callback();
        }
    insertOneRecord(nextItemIndex, function () {
            
    });
        nextItemIndex++;
    }, 10);
};


describe('MAC recent activity tests : ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                console.log('==================== ---------- : ', AUTH);
                if (testEnviron !== 'productionEnv') {
                    clearDB(testEnv.almondMAC, function (err) {
                        if (err)
                            return done(err);
                        createDB(done);
                    });
                } else
                    done();
            }
        });
    });

    it('bearerTest get RecentActivity no mac', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {},
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Insufficient Data');
            done();
        });
    });

    it('bearerTest get RecentActivity with mac', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                mac: testEnv.almondMAC,
                type: 'all'
            },
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            //console.log(response.statusCode);
            //console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('Result')).to.equal(true);
            //expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
            expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
            expect(body.Result.hasOwnProperty('logs')).to.equal(true);
            if (testEnviron !== 'productionEnv') {
//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, testEnv.almondMAC, 'MAC mismatch');
                assert.include(devIdArr.concat(cliIdArr), parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                //assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.include(["client value", "device value"], body.Result.logs[0].value, 'value mismatch');
            }
            done();
        });
    });
    it('AlmondMAC incorrect ', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                mac: 12345,
                type: 'all'
            },
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    it('bearerTest get RecentActivity for only Devices', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                mac: testEnv.almondMAC,
                type: 'device'
            },
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            //console.log(response.statusCode);
            //console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('Result')).to.equal(true);
            //expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
            expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
            expect(body.Result.hasOwnProperty('logs')).to.equal(true);
            if (testEnviron !== 'productionEnv') {
//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, testEnv.almondMAC, 'MAC mismatch');
                assert.include(devIdArr, parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                //assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("device value", body.Result.logs[0].value, 'value mismatch');
            }
            done();
        });
    });

    it('bearerTest get RecentActivity for only Clients', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                mac: testEnv.almondMAC,
                type: 'client'
            },
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            //console.log(response.statusCode);
            //console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('Result')).to.equal(true);
            //expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
            expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
            expect(body.Result.hasOwnProperty('logs')).to.equal(true);
            if (testEnviron !== 'productionEnv') {
//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, testEnv.almondMAC, 'MAC mismatch');
                assert.include(cliIdArr, parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                //assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("client value", body.Result.logs[0].value, 'value mismatch');
            }
            done();
        });
    });

    it('bearerTest get RecentActivity for specific device', function (done) {
        this.timeout(30000);
        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                mac: testEnv.almondMAC,
                type: 'device',
                id: (testEnviron !== 'productionEnv') ? devIdArr[0].toString() : testInput.specificDevice
            },
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            //console.log(response.statusCode);
            //console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('Result')).to.equal(true);
            //expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
            expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
            expect(body.Result.hasOwnProperty('logs')).to.equal(true);

//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
//                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
            if (testEnviron !== 'productionEnv') {
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, testEnv.almondMAC, 'MAC mismatch');
                assert.equal(devIdArr[0], parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                //assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("device value", body.Result.logs[0].value, 'value mismatch');
            }
            done();
        });
    });

    it('bearerTest get RecentActivity for specific client', function (done) {
        this.timeout(5000);

        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                mac: testEnv.almondMAC,
                type: 'client',
                id: (testEnviron !== 'productionEnv') ? 'b9:1c:57': testInput.specificClient // hex format cliIdArr[0]
            },
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            //console.log(response.statusCode);
            //console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('Result')).to.equal(true);
            //expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
            expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
            expect(body.Result.hasOwnProperty('logs')).to.equal(true);

//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
//                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
            if (testEnviron !== 'productionEnv') {
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, testEnv.almondMAC, 'MAC mismatch');
                assert.equal(cliIdArr[0], parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                //assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("client value", body.Result.logs[0].value, 'value mismatch');
            }
            done();
        });
    });

    it('bearerTest get RecentActivity for multiple devices', function (done) {
        this.timeout(5000);
        var devIds = devIdArr.join();
        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                mac: testEnv.almondMAC,
                type: 'device',
                id: (testEnviron !== 'productionEnv') ? devIds : testInput.multiDevices // hex format cliIdArr[0]
            },
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            //console.log(response.statusCode);
            //console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('Result')).to.equal(true);
            //expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
            expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
            expect(body.Result.hasOwnProperty('logs')).to.equal(true);

//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
//                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
            if (testEnviron !== 'productionEnv') {
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, testEnv.almondMAC, 'MAC mismatch');
                assert.include(devIds, parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                //assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("device value", body.Result.logs[0].value, 'value mismatch');
            }
            done();
        });
    });

    it('bearerTest get RecentActivity for multiple clients', function (done) {
        this.timeout(5000);
        var cliIds = ['b9:1c:57', 'b9:1c:58', 'b9:1c:59'];
        var options = {
            method: 'POST',
            url: URL + '/RecentActivity',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                mac: testEnv.almondMAC,
                type: 'client',
                id: (testEnviron !== 'productionEnv') ? cliIds.join() : testInput.multiClients // hex format cliIdArr[0]
            },
            json: true
        };
        console.log("Before making a request ..");
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            //console.log(response.statusCode);
            //console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('Result')).to.equal(true);
            //expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
            expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
            expect(body.Result.hasOwnProperty('logs')).to.equal(true);

//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
//                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
            if (testEnviron !== 'productionEnv') {
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, testEnv.almondMAC, 'MAC mismatch');
                assert.include(cliIdArr, parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                //assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("client value", body.Result.logs[0].value, 'value mismatch');
            }
            done();
        });
    });

    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
