var CP = require('../database/sql/sqlQuery');
var bcrypt = require('bcrypt');
var DB = {};

DB.insertAllAlmondPlus = function (data, callback) {
	var hashAlmondID;
	DB.deleteAllAlmondPlus({AlmondMAC:data.AlmondMAC}, function(e, o) {	
		if(e){
		  	console.log('Error DB.deleteAllAlmondPlus: ' + e);	
		}
		else {
		  	console.log('Success DB.deleteAllAlmondPlus: ' + o);	
		  	bcrypt.genSalt(10, function(err, salt) {
				bcrypt.hash(data.AlmondID, salt, function(err, hash) {
					hashAlmondID = hash;
					var query = 'INSERT into ?? (AlmondMAC, AlmondID, ProductType) Values(?, ?, ?)';
					var params = ['AllAlmondPlus', data.AlmondMAC, hashAlmondID, data.ProductType];
					CP.queryFunction(query, params, function(e, o) {
						if(e) {
							console.log('dbQueries Error in insertAllAlmondPlus: ' + e);
							return callback(e);
						} else {
							console.log('dbQueries Success in insertAllAlmondPlus: ' + o);
							return callback(null, o);
						}
					});
				});
			});	
		}
	});					
}

DB.insertAllAlmondPlusLongSecret = function (data, callback) {
    var hashAlmondID;
    DB.deleteAllAlmondPlus({AlmondMAC:data.AlmondMAC}, function(e, o) {	
		if(e){
		  	console.log('Error DB.deleteAllAlmondPlus: ' + e);	
		}
		else{
		  	console.log('Success DB.deleteAllAlmondPlus: ' + o);	
		  	bcrypt.genSalt(10, function(err, salt) {
				bcrypt.hash(data.AlmondID, salt, function(err, hash) {
					hashAlmondID = hash;
					var query = 'INSERT into ?? (AlmondMAC, AlmondID, LongSecret, ProductType) Values(?, ?, ?, ?)';
					var params = ['AllAlmondPlus', data.AlmondMAC, hashAlmondID, data.LongSecret, data.ProductType];
					CP.queryFunction(query, params, function(e, o) {
						if(e) {
							console.log('dbQueries Error in insertAllAlmondPlus: ' + e);
							return callback(e);
						} else {
							console.log('dbQueries Success in insertAllAlmondPlus: ' + o);
							o.index = data.index;
							return callback(null, o);
						}
					});
			    });
		    });
		}
	});
}

DB.insertAllAlmondPlusDeviceHash = function (data, callback) {
    var hashAlmondID;
    DB.deleteAllAlmondPlus({AlmondMAC:data.AlmondMAC}, function(e, o) {	
		if(e){
		  	console.log('Error DB.deleteAllAlmondPlus: ' + e);	
		}
		else{
		  	console.log('Success DB.deleteAllAlmondPlus: ' + o);	
		  	bcrypt.genSalt(10, function(err, salt) {
				bcrypt.hash(data.AlmondID, salt, function(err, hash) {
					hashAlmondID = hash;
					var query = 'INSERT into ?? (AlmondMAC, AlmondID, LongSecret, ProductType, StaticDeviceListHash) Values(?, ?, ?, ?, ?)';
					var params = ['AllAlmondPlus', data.AlmondMAC, hashAlmondID, data.LongSecret, data.ProductType, data.DeviceListHash];
					CP.queryFunction(query, params, function(e, o) {
						if(e) {
							console.log('dbQueries Error in insertAllAlmondPlusDeviceHash: ' + e);
							return callback(e);
						} else {
							console.log('dbQueries Success in insertAllAlmondPlusDeviceHash: ' + o);
							return callback(null, o);
						}
					});
			    });
		    });
		}
	});
}

DB.insertAllAlmondPlusSceneHash = function (data, callback) {
    var hashAlmondID;
    DB.deleteAllAlmondPlus({AlmondMAC:data.AlmondMAC}, function(e, o) {	
		if(e){
		  	console.log('Error DB.deleteAllAlmondPlus: ' + e);	
		}
		else{
		  	console.log('Success DB.deleteAllAlmondPlus: ' + o);	
		  	bcrypt.genSalt(10, function(err, salt) {
				bcrypt.hash(data.AlmondID, salt, function(err, hash) {
					hashAlmondID = hash;
					var query = 'INSERT into ?? (AlmondMAC, AlmondID, LongSecret, ProductType, StaticSceneListHash) Values(?, ?, ?, ?, ?)';
					var params = ['AllAlmondPlus', data.AlmondMAC, hashAlmondID, data.LongSecret, data.ProductType, data.SceneListHash];
					CP.queryFunction(query, params, function(e, o) {
						if(e) {
							console.log('dbQueries Error in insertAllAlmondPlusDeviceHash: ' + e);
							return callback(e);
						} else {
							console.log('dbQueries Success in insertAllAlmondPlusDeviceHash: ' + o);
							return callback(null, o);
						}
					});
			    });
		    });
		}
	});
}

DB.deleteAllAlmondPlus = function (data, callback) {
	console.log('Inside DB.deleteAllAlmondPlus');
	var query = 'DELETE FROM ?? WHERE AlmondMAC=?';
	var params = ['AllAlmondPlus', data.AlmondMAC];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteAllAlmondPlus: ' + e);
			return callback(e);
		} else {
			console.log('dbQueries Success in deleteAllAlmondPlus: ' + o);
			return callback(null, o);
		}
	});
}



DB.updateUsers = function (data, callback) {
	var query = 'UPDATE ?? SET FirstName=?, LastName=?, AddressLine1=?, AddressLine2=?, AddressLine3=?, Country=?, ZipCode=? WHERE UserID=?';
	var params = ['Users', data.FirstName, data.LastName, data.AddressLine1, data.AddressLine2, data.AddressLine3, data.Country, data.ZipCode, data.UserID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in updateUsers: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in updateUsers: ' + o);
			callback(null, o);
		}
	});
}

DB.selectUsers = function (data, callback) {
	var query = 'SELECT UserID from ?? where EmailID = ?';
	var params = ['Users', data.EmailID];
	CP.queryFunction(query, params, function(e, rows) {
		if(e) {
			console.log('dbQueries Error in selectUsers: ' + e);
			return callback(e);
		} else {
			console.log('dbQueries Success in selectUsers: ' + rows);
			console.log(rows);
			console.log(rows[0]);
			return callback(null, rows[0]);
		}
	});
}

DB.insertUser = function (data, callback) {
	DB.deleteUser({UserID:data.UserID}, function(e, o) {
		if(e) {
			console.log('Error DB.deleteUser: ' + e);
		}
		else {
		    console.log('success DB.deleteUser: ' + o);
		   	bcrypt.genSalt(10, function(err, salt) {
				bcrypt.hash(data.Password, salt, function(err, hash) {
					data.Password = hash;
					var query = 'INSERT into ?? (UserID, EmailID, Password, EmailValidated) Values(?, ?, ?, ?)';
					var params = ['Users', data.UserID, data.EmailID, data.Password, 0];
					CP.queryFunction(query, params, function(e, o) {
						if(e) {
							console.log('dbQueries Error in insertUser: ' + e);
							callback(e);
						} else {
							console.log('dbQueries Success in insertUser: ' + o);
							o.index = data.index;
							callback(null, o);
						}
					});
				});
			});		
		}
	});
}

DB.deleteUser = function (data, callback) {
	console.log('Inside DB.deleteUser');
	var query = 'DELETE FROM ?? WHERE UserID=?';
	var params = ['Users', data.UserID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteUser: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in deleteUser: ' + o);
			callback(null, o);
		}
	});
}



DB.insertAlmondUsers_verified = function (data, callback) {
	DB.deleteAlmondUsers({AlmondMAC:data.AlmondMAC}, function(e, o) {	
		if(e){
		  	console.log('Error DB.deleteAlmondUsers: ' + e);	
		}
		else {
			console.log('Success DB.deleteAlmondUsers: ');	
			var query = 'INSERT into ?? (AlmondMAC, userID, verified, ownership) Values(?, ?, ?, ?)';
			var params = ['AlmondUsers', data.AlmondMAC, data.userID, data.verified, data.ownership];
			CP.queryFunction(query, params, function(e, o) {
				if(e) {
					console.log('dbQueries Error in insertAlmondUsers: ' + e);
					callback(e);
				} else {
					console.log('dbQueries Success in insertAlmondUsers: ' + o);
					callback(null, o);
				}
			});             
		}
	}); 
}

DB.insertAlmondUsers = function (data, callback) {
	DB.deleteAlmondUsers({AlmondMAC:data.AlmondMAC}, function(e, o) {	
		if(e){
		  	console.log('Error DB.deleteAlmondUsers: ' + e);	
		}
		else {
			console.log('Success DB.deleteAlmondUsers: ');	
			var query = 'INSERT into ?? (AlmondMAC, userID, ownership) Values(?, ?, ?)';
			var params = ['AlmondUsers', data.AlmondMAC, data.userID, data.ownership];
			CP.queryFunction(query, params, function(e, o) {
				if(e) {
					console.log('dbQueries Error in insertAlmondUsers: ' + e);
					callback(e);
				} else {
					console.log('dbQueries Success in insertAlmondUsers: ' + o);
					callback(null, o);
				}
			});
	    }
	}); 
}

DB.deleteAlmondUsers = function (data, callback) {
	console.log('Inside DB.deleteAlmondUsers');
	var query = 'DELETE FROM ?? WHERE AlmondMAC=?';
	var params = ['AlmondUsers', data.AlmondMAC];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteAlmondUsers: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in deleteAlmondUsers: ' + o);
			callback(null, o);
		}
	});
}


DB.insertTempPass = function (data, callback) {
	var TempPassword;	
  	console.log('Success DB.insertTempPass: ');	
  	bcrypt.genSalt(10, function(err, salt) {
		bcrypt.hash(data.TempPassword, salt, function(err, hash) {
			TempPassword = hash;
			// var query = 'INSERT into ?? (AlmondMAC, AlmondID, ProductType) Values(?, ?, ?)';
			var query = 'INSERT INTO ?? (UserID, TempPassword, LastUsedTime) values (?,?,NOW());';
			var params = ['UserTempPasswords', data.userid, TempPassword];
			CP.queryFunction(query, params, function(e, o) {
				if(e) {
					console.log('dbQueries Error in insertTempPass: ' + e);
					return callback(e);
				} else {
					console.log('dbQueries Success in insertTempPass: ' + o);
					return callback(null, o);
				}
			});
		});
	});							
}


DB.insertAlmondSecondaryUsers = function (data, callback) {
	var query = 'INSERT into ?? (AlmondMAC, userID) Values(?, ?)';
	var params = ['AlmondSecondaryUsers', data.AlmondMAC, data.userID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in insertAlmondSecondaryUsers: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in insertAlmondSecondaryUsers: ' + o);
			callback(null, {index:data.index});
		}
	});
}



DB.insertDeviceData = function (data, callback) {
	var query = 'INSERT into ?? (AlmondMAC, DeviceID, DeviceType) Values(?, ?, ?)';
	var params = ['DeviceData', data.AlmondMAC, data.DeviceID, data.DeviceType];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in insertDeviceData: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in insertDeviceData: ' + o);
			callback(null, {index:data.index});
		}
	});
}


DB.deleteDeviceData = function (data, callback) {
	console.log('Inside DB.deleteDeviceData');
	var query = 'DELETE FROM ?? WHERE AlmondMAC=? AND DeviceID=?';
	var params = ['DeviceData', data.AlmondMAC, data.DeviceID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteDeviceData: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in deleteDeviceData: ' + o);
			callback(null, o);
		}
	});
}

DB.insertDeviceValues = function (data, callback) {
	var query = 'INSERT into ?? (AlmondMAC, DeviceID, IndexVal, Name, Value) Values(?, ?, ?, ?, ?)';
	var params = ['DeviceValues', data.AlmondMAC, data.DeviceID, data.IndexVal, data.Name, data.Value];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in insertDeviceValues: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in insertDeviceValues: ' + o);
			callback(null, o);
		}
	});
}

DB.insertNotificationID = function (data, callback) {
	var query = 'INSERT into ?? (PKID, HashVal, RegID, UserID, Platform) Values(?, ?, ?, ?, ?)';
	var params = ['NotificationID', data.PKID, data.HashVal, data.RegID, data.UserID, data.Platform];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in insertNotificationID: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in insertNotificationID: ' + o);
			callback(null, o);
		}
	});
}

DB.deleteNotificationID = function (data, callback) {
	console.log('Inside DB.deleteNotificationID');
	var query = 'DELETE FROM ?? WHERE HashVal=? AND RegID=? AND Platform=? AND UserID=?';
	var params = ['NotificationID', data.HashVal, data.RegID, data.Platform, data.UserID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteNotificationID: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in deleteNotificationID: ' + o);
			callback(null, o);
		}
	});
}

DB.deleteDeviceValues = function (data, callback) {
	console.log('Inside DB.deleteDeviceValues');
	var query = 'DELETE FROM ?? WHERE AlmondMAC=? AND DeviceID=?';
	var params = ['DeviceValues', data.AlmondMAC, data.DeviceID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteDeviceValues: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in deleteDeviceValues: ' + o);
			callback(null, o);
		}
	});
}


DB.insertSceneData = function (data, callback) {
	var query = 'INSERT into ?? (AlmondMAC, SceneID, SceneName, Active) Values(?, ?, ?, ?)';
	var params = ['SceneData', data.AlmondMAC, data.SceneID, data.SceneName, data.Active];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in insertSceneData: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in insertSceneData: ' + o);
			callback(null, {index:data.index});
		}
	});
}


DB.deleteSceneData = function (data, callback) {
	console.log('Inside DB.deleteSceneData');
	var query = 'DELETE FROM ?? WHERE AlmondMAC=? AND SceneID=?';
	var params = ['SceneData', data.AlmondMAC, data.SceneID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteSceneData: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in deleteSceneData: ' + o);
			callback(null, o);
		}
	});
}
DB.deleteSubscription=function(data,callback){
	var query= 'delete from Subscriptions where AlmondMAC=?';
	var params=[data.AlmondMAC];
	CP.queryFunction(query,params,callback)
}
DB.selectSubscription = function(data,callback){
	var query='select * from Subscriptions where AlmondMAC=?';
	var params=[data.AlmondMAC];
	CP.queryFunction(query,params,callback)
}
DB.insertSubscription = function(data,callback){
	try{var query='insert into Subscriptions (AlmondMAC,UserID,Plan,Services) values(?,?,?,?) on duplicate key update Plan=values(Plan),Services=values(Services)';
	var params = [data.AlmondMAC,data.UserID,data.Plan,data.Services];
	console.log('query,params',query,params)
	CP.queryFunction(query,params,function(e,o){
		console.log('in insertSubscription',e,o);
		callback(e,o)
	})}
	catch(e){console.log(e)}
}
DB.insertSceneValues = function (data, callback) {
	var query = 'INSERT into ?? (AlmondMAC, SceneID, DeviceID, DeviceIndex, DeviceValue) Values(?, ?, ?, ?, ?)';
	var params = ['SceneValues', data.AlmondMAC, data.SceneID, data.DeviceID, data.DeviceIndex, data.DeviceValue];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in insertSceneValues: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in insertSceneValues: ' + o);
			callback(null, o);
		}
	});
}


DB.deleteSceneValues = function (data, callback) {
	console.log('Inside DB.deleteSceneValues');
	var query = 'DELETE FROM ?? WHERE AlmondMAC=? AND SceneID=?';
	var params = ['SceneValues', data.AlmondMAC, data.SceneID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteSceneValues: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in deleteSceneValues: ' + o);
			callback(null, o);
		}
	});
}

DB.insertNotificationPreferences = function (data, callback) {
	var query = 'INSERT into ?? (AlmondMAC, DeviceID, UserID, IndexVal, NotificationType) Values(?, ?, ?, ?, ?)';
	var params = ['NotificationPreferences', data.AlmondMAC, data.DeviceID, data.UserID, data.IndexVal, data.NotificationType];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in insertNotificationPreferences: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in insertNotificationPreferences: ' + o);
			callback(null, o);
		}
	});
}

DB.deleteNotificationID = function (data, callback) {
	console.log('Inside DB.deleteNotificationID');
	var query = 'DELETE FROM ?? WHERE HashVal=? AND RegID=? AND Platform=? AND UserID=?';
	var params = ['NotificationID', data.HashVal, data.RegID, data.Platform, data.UserID];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in deleteNotificationID: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in deleteNotificationID: ' + o);
			callback(null, o);
		}
	});
}

DB.insertAlmondPreferences = function (data, callback) {
	var query = 'INSERT into ?? (AlmondMAC, AlmondMode, ModeSetBy) Values(?, ?, ?)';
	var params = ['AlmondPreferences', data.AlmondMAC, data.AlmondMode, data.ModeSetBy];
	CP.queryFunction(query, params, function(e, o) {
		if(e) {
			console.log('dbQueries Error in insertNotificationPreferences: ' + e);
			callback(e);
		} else {
			console.log('dbQueries Success in insertNotificationPreferences: ' + o);
			callback(null, o);
		}
	});
}


DB.getValidationToken = function (userName, callback) {
	CP.queryFunction("SELECT ValidationToken from AlmondplusDB.Users where EmailID =?;", [userName],function(e, output){
		if(e){
		  	console.log("dbQueries Error in getValidationToken: " + e);
		} else {
		  	callback(output);	
		}          
    });
}

DB.setEmailValidated = function (userName, callback) {
	CP.queryFunction("update AlmondplusDB.Users set EmailValidated = 1 where EmailID =?;",[userName],function(e, output){
		if(e){
		  console.log("In error...",e);
		}
		else{
	      callback();		         	
		}          
   });
}

module.exports = DB;