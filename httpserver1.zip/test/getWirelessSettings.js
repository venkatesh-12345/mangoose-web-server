/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var wireless = nconf.get('wireless');
var CLEAR_DB = nconf.get('CLEAR_DB');
console.log(wireless);
var responseMaker = require('./extraFiles/responseMaker');
require('./extraFiles/almondConsumer');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

var sortByKey = function (array, key) {
    return array.sort(function (a, b) {
        var x = a[key];
        var y = b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
};

describe('GetWirelessSettings tests: ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                done();
            }
        });
    });
    it('Success testcase', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/GetWirelessSettings',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                AlmondMAC: testEnv.almondMAC
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            
            expect(response.statusCode).to.equal(200);
            expect(body.success).to.equal(true);
            expect(body.CommandType).to.equal('GetWirelessSettings');
            expect(body.CountryRegion).to.equal(wireless.CountryRegion);
            expect(body.hasOwnProperty('WirelessSetting')).to.equal(true);
            body.WirelessSetting = sortByKey(body.WirelessSetting, 'Type');
            body.WirelessSetting.forEach(function(item, index) {
                console.log('checking index : ', index);
                console.log(item);
                expect(body.WirelessSetting[index].Type).to.equal(wireless.WirelessSetting[index].Type);
                expect(body.WirelessSetting[index].Enabled).to.equal(wireless.WirelessSetting[index].Enabled);
                expect(body.WirelessSetting[index].SSID).to.equal(wireless.WirelessSetting[index].SSID);
                if (!(body.WirelessSetting[index].Type.indexOf('Guest') !== -1 && body.WirelessSetting[index].Enabled == 'false')) {
                    console.log('checking channel also');
                    expect(body.WirelessSetting[index].Channel).to.equal(wireless.WirelessSetting[index].Channel);
                    expect(body.WirelessSetting[index].Security).to.equal(wireless.WirelessSetting[index].Security);
                    expect(body.WirelessSetting[index].WirelessMode).to.equal(wireless.WirelessSetting[index].WirelessMode);
                }
            });
            done();
        });
    });
    it('Wrong almondMAC testcase', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/GetWirelessSettings',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                AlmondMAC: 12345
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});

        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
