/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var CLEAR_DB = nconf.get('CLEAR_DB');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

describe('GetAlmondList tests:', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                done();
            }
        });
    });
    it('GetAlmondList', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/GetAlmondList',
            headers: {
                'content-type': TYPE_X,
                authorization: AUTH
            }
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.CommandType).to.equal('AlmondList');
            expect(body.hasOwnProperty('Almonds')).to.equal(true);
            if (testEnviron !== 'productionEnv') {
                expect(body.Almonds[0].AlmondName).to.equal(testEnv.almondName);
                expect(body.Almonds[0].AlmondMAC + '').to.equal(testEnv.almondMAC);
                expect(body.Almonds[0].FirmwareVersion).to.equal(testEnv.almondVersion);
            }
            done();
        });
    });
    it('GetAlmondList with GET method', function (done) {
        this.timeout(5000);
        var options = {
            method: 'GET',
            url: URL + '/GetAlmondList',
            headers: {
                'content-type': TYPE_X,
                authorization: AUTH
            }
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.success).to.equal(true);
            expect(body.hasOwnProperty('Result')).to.equal(true);
            if (testEnviron !== 'productionEnv') {
                expect(body.Result.Almonds[0].AlmondName).to.equal(testEnv.almondName);
                expect(body.Result.Almonds[0].AlmondMAC + '').to.equal(testEnv.almondMAC);
                expect(body.Result.Almonds[0].FirmwareVersion).to.equal(testEnv.almondVersion);
            }
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
