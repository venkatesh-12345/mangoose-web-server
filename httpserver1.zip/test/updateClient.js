/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var testInput = nconf.get('updateClient');
var CLEAR_DB = nconf.get('CLEAR_DB');
var responseMaker = require('./extraFiles/responseMaker');
require('./extraFiles/almondConsumer');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

describe('ClientUpdate tests : ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                console.log('==================== ---------- : ', AUTH);
                done();
            }
        });
    });
    it('case where client is updated successfully', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/UpdateClient',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'Update': [{
                        'AlmondMAC': testEnv.almondMAC,
                        'Clients': {
                            'ID': testInput.clientID,
                            'Block': 1
                        }
                    }]
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            expect(response.statusCode).to.equal(200);
            console.log(JSON.stringify(body));
            expect(body.success + '').to.equal('true');
            expect(body.hasOwnProperty('Result')).to.equal(true);
            expect(body.Result[0].success + '').to.equal('true');
            expect(body.Result[0].AlmondMAC + '').to.equal(testEnv.almondMAC);
            expect(body.Result[0].hasOwnProperty('Clients')).to.equal(true);
            expect(body.Result[0].Clients.ID + '').to.equal(testInput.clientID + '');
            expect(body.Result[0].Clients.Block + '').to.equal('1');
            done();
        });
    });
    it('case where client is updated successfully unblock', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/UpdateClient',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'Update': [{
                        'AlmondMAC': testEnv.almondMAC,
                        'Clients': {
                            'ID': testInput.clientID,
                            'Block': 0
                        }
                    }]
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            expect(response.statusCode).to.equal(200);
            console.log(JSON.stringify(body));
            expect(body.success + '').to.equal('true');
            expect(body.hasOwnProperty('Result')).to.equal(true);
            expect(body.Result[0].success + '').to.equal('true');
            expect(body.Result[0].AlmondMAC + '').to.equal(testEnv.almondMAC);
            expect(body.Result[0].hasOwnProperty('Clients')).to.equal(true);
            expect(body.Result[0].Clients.ID + '').to.equal(testInput.clientID+ '');
            expect(body.Result[0].Clients.Block + '').to.equal('0');
            done();
        });
    });
    it('wrong almondMAC testcase', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/UpdateClient',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'Update': [{
                        'AlmondMAC': 12345,
                        'Clients': {
                            'ID': testInput.clientID,
                            'Block': 0
                        }
                    }]
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});

        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
