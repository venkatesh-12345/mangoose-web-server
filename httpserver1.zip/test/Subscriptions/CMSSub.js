var assert = require('assert');
var DB = require('../dbQuery')
var config = require('nconf').get('rabbitmq');
var producer = require('../../rabbitmq/producer');
var CP = require('../../database/sql/sqlQuery')
var testConsumer = require('./testConsumer')
var getToken = require("./stripeGetToken");
var userID = '12345678';
var AlmondMAC = '987654321';
var assertFunction;
testConsumer.on('data', function(data) {
    if (typeof(assertFunction) == 'function')
        assertFunction(data);
})
var afterFunction = function(callback) {
    DB.deleteSubscription({ AlmondMAC: AlmondMAC }, callback)
}
describe('Enable Free Subs', function() {
    before(function(done) {
        DB.insertAllAlmondPlus({ AlmondMAC: AlmondMAC, ProductType: 'AL2', AlmondID: '1' }, function(e, o) {
            if (e)
                console.log('err in insertAllAlmondPlus', e)
            if (!e)
                DB.insertUser({ UserID: userID, EmailID: 'dummyprim@securifi.com', Password: '123456', index: 1 }, function(e, o) {
                    if (e) {
                        console.log(" Error in insertUser " + e);
                    } else {
                        console.log(" Success in insertUser " + o);
                        DB.insertAlmondUsers({ AlmondMAC: AlmondMAC, userID: userID, ownership: 'P', LongSecret: 'djhrfhcxrmvrfvgrbgb' }, function(e, o) {
                            if (e) {
                                console.log(" Error in insertAlmondUsers " + e);
                            } else {
                                console.log(" Success in insertAlmondUsers ")
                                CP.queryFunction('insert into SCSIDB.CMS (CMSCode,StripeKey,Plans) values(?,?,?) on duplicate key update StripeKey=values(StripeKey),Plans=values(Plans) ',['CMSTEST','8427785fe420a1650c5df535173cb96a:332af888344c33a458387bc10da3fa6370c5769974302a4ab69e0722adfbbac9bfdf6569f22439f4529aa2a32e0595b0',JSON.stringify([{ "PlanName": "Test Plan", "PlanAmount": "15", "CMSService": "Testservice", "typeOfPlan": "Yearly", "SecurifiService": ["ProMonitoring "], "PlanDescription": "This is test plan" }])],function(err,res){
                                    if(err)
                                        console.log('err in insert CMS',err)
                                    else
                                        done()
                                })
                            }
                        });
                    }
                });
        })
    })
    after(function(done) {
        DB.deleteSubscription({ AlmondMAC: AlmondMAC }, function(e, o) {
            if (e)
                console.log('err in deleteSubscription', e);
            else
                console.log('done deleteSubscription')
            CP.queryFunction('delete from SCSIDB.CMS where CMSCode=?',['CMSTEST'],function(e,o){
                if(e)
                    console.log('eer in delete cms',e)
                else
                    done()
            })
        })
    })
    it('Should Subscribe FreeSubs ', function(done) {
        var request = {
            PlanID: 'Free',
            Android: '7.431.19',
            AlmondMAC: AlmondMAC,
            CommandType: 'SubscribeMe',
            Services: 'IoT',
            unicastID: 1067,
            UserID: userID,
            queue: 'R@'
        }
        // done()
        producer.sendToQueue('S10', JSON.stringify(request))
        assertFunction = function(data) {
            console.log('data', data);
            var payload = JSON.parse(data.payload);
            assert.equal(payload.Success, "true")
            assert.equal(payload.Services, "IoT")
            DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                console.log('selectSubscription**********',e,res)
                if (e)
                    console.log('error', e)

                assert.equal(res[0].Services, "IoT");
                assert.equal(res[0].Plan ,'Free');
                done()
            })
        }
    })
    
    it('Should No Such plan if u give plan not there in subscription', function(done) {
        this.timeout(10000)
        var request = {
            PlanID: 'Paid11M',
            Android: '7.431.19',
            AlmondMAC: AlmondMAC,
            CommandType: 'SubscribeMe',
            StripeToken: 'tok_1BEE8DKsCyFYYP0soVPm3llA', //pk_test_MaZISUSxV2mH3ngnkL7RxilU use https://codepen.io/fmartingr/pen/pGfhy
            CMSCode:'CMSTEST',
            Services: 'IoT_CMS',
            unicastID: 1067,
            UserID: userID,
            queue: 'R@'
        }
        try{
                    getToken("sk_test_nQZhNnWUcgkV5qWngfhlIxb9", function(token) {
                        console.log('token',token)
                        request.StripeToken = token;
                        producer.sendToQueue("S10", JSON.stringify(request));
                    });
                }catch(e){console.log(e)}
        var count = 0;
        assertFunction = function(data) {
            console.log('data', data);
            var payload = JSON.parse(data.payload);
                assert.equal(payload.Success, "false")
                assert.equal(payload.Reason, "Invalid Card Details")
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                    if (e)
                        console.log('error', e)
                    done()
                })
            }

    })
    it('Should Subscibe plan to that specific cms stripe ', function(done) {
        this.timeout(10000)
        var request = {
            PlanID: 'Pro6M',
            Android: '7.431.19',
            AlmondMAC: AlmondMAC,
            CommandType: 'SubscribeMe',
            StripeToken: 'tok_1BEE8LKsCyFYYP0sSCJ3Xr9K', //pk_test_MaZISUSxV2mH3ngnkL7RxilU use https://codepen.io/fmartingr/pen/pGfhy
            CMSCode:'CMSTEST',
            Services: 'IoT_CMS',
            unicastID: 1067,
            UserID: userID,
            queue: 'R@'
        }
                        getToken("sk_test_nQZhNnWUcgkV5qWngfhlIxb9", function(token) {
                        request.StripeToken = token;
                        producer.sendToQueue("S10", JSON.stringify(request));
                    });
        var count = 0;
        assertFunction = function(data) {
            console.log('data', data);
            var payload = JSON.parse(data.payload);
                assert.equal(payload.Success, "true")
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                    if (e)
                        console.log('error', e)
                    assert.equal(res[0].Services, "IoT_CMS");
                    assert.equal(res[0].Plan , 'Pro6M');
                    done()
                })
            }

    })
        it('Should Subscibe plan to that specific cms stripe ', function(done) {
        var request = {
            PlanID: 'Pro1Y',
            Android: '7.431.19',
            AlmondMAC: AlmondMAC,
            CommandType: 'SubscribeMe',
            CMSCode:'CMSTEST',
            savedCard:true,
            Upgrade:true,
            Services: 'IoT_CMS',
            unicastID: 1067,
            UserID: userID,
            queue: 'R@'
        }
                            getToken("sk_test_nQZhNnWUcgkV5qWngfhlIxb9", function(token) {
                        request.StripeToken = token;
                        producer.sendToQueue("S10", JSON.stringify(request));
                    });
        var count = 0;
        assertFunction = function(data) {
            console.log('data', data);
            var payload = JSON.parse(data.payload);
                assert.equal(payload.Success, "true")
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                    if (e)
                        console.log('error', e)
                    assert.equal(res[0].Services, "IoT_CMS");
                    assert.equal(res[0].Plan , 'Pro1Y');
                    done()
                })
            }
    })

})