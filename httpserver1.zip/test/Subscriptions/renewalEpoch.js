// var US = require('../../database/model/userSubsNew');
var assert = require('assert');
var renewalTimes = {};
renewalTimes["Free"] = 1;
renewalTimes["Paid1M"] = 1;
renewalTimes["Paid3M"] = 3;
renewalTimes["Paid6M"] = 6;
renewalTimes["Paid1Y"] = 12;
var US={}
US.generateRenewalEpoch= function(currentEpoch, plan, duration) {
    var Days = duration ? parseInt(duration) * 30 : renewalTimes[plan] * 30;
    if (isNaN(Days)) return null;
    return new Date(currentEpoch + Days * 24 * 60 * 60 * 1000).getTime();
};
describe('Testing Renewal Epoch', function() {
    it('Should get exact renewal Epoch', function(done) {
        var currentEpoch = Date.now()
        var Duration = '6'
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'null', Duration)
        var assertTime=new Date(currentEpoch + 6 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())
        done()
    })
    it('Should get exact renewal Epoch as for FreePlan -1M', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Free', null)
   var assertTime=new Date(currentEpoch + 1 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())
        done()
    })
    it('Should get exact renewal Epoch as for Paid1M -1M', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid1M', null)
        var assertTime=new Date(currentEpoch + 1 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })
    it('Should get exact renewal Epoch as for Paid3M -3M', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid3M', null)
        var assertTime=new Date(currentEpoch + 3 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })
    it('Should get exact renewal Epoch as for Paid6M -6M', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid6M', null)
           var assertTime=new Date(currentEpoch + 6 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })
    it('Should get exact renewal Epoch as for Paid12M -12M', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid1Y', null)
     var assertTime=new Date(currentEpoch + 12 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })
    it('Should get exact renewal Epoch as for Paid12M -12M', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid6Y',12)
         var assertTime=new Date(currentEpoch + 12 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })

    it('Should get Null when unknown Plan', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid12Y',1)
        console.log('**********',recievedEpoch)
         var assertTime=new Date(currentEpoch + 1 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })

    it('Should get Null when unknown Plan', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid1Y',12)
        console.log('**********',recievedEpoch)
         var assertTime=new Date(currentEpoch + 12 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })

    it('Should get Null when unknown Plan', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, null,3)
        console.log('**********',recievedEpoch)
         var assertTime=new Date(currentEpoch + 3 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })

    it('Should get Null when unknown Duration', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid12Y','3')
        console.log('**********',recievedEpoch)
         var assertTime=new Date(currentEpoch + 3 * 30 * 24 * 60 * 60 * 1000)
        assert.equal(recievedEpoch,assertTime.getTime() )
        assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })
        it('Should get Null when unknown Duration', function(done) {
        var currentEpoch = Date.now()
        var recievedEpoch = US.generateRenewalEpoch(currentEpoch, 'Paid12Y','sas1')
        console.log('**********',recievedEpoch)
        //  var assertTime=new Date(currentEpoch + 3 * 30 * 24 * 60 * 60 * 1000)
        // assert.equal(recievedEpoch,assertTime.getTime() )
        // assert.equal(new Date(recievedEpoch).getDate(),assertTime.getDate()) //changes according to date
        // assert.equal(new Date(recievedEpoch).getMonth(),assertTime.getMonth())
        // assert.equal(new Date(recievedEpoch).getFullYear(), assertTime.getFullYear())

        done()
    })

})