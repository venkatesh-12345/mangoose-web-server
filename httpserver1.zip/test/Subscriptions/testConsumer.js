var EventEmitter = require('events').EventEmitter;
var events = new EventEmitter();
var RabbitMQConnector = require('../../rabbitmq/rabbitMQ');
var options = {
    host: 'amqp://127.0.0.1',
    queueName: 'R@',
    maxRetryCount: 3
};
var Consumer = new RabbitMQConnector(options, 'CONSUMER');
//Consumer.connect();
Consumer.on('connected', function () {
    console.log('RabbitMQConnector CONSUMER HTTP server ');
});
Consumer.on('message', function (msg) {
    try { var request = JSON.parse(msg);
    	events.emit('data',request)
    }catch(e){
    	console.log('err in consumer test',e)
    }
})

module.exports= events;