 var stripe = require('stripe');
 var getToken=function(key,callback){
  Stripe=stripe(key);
 Stripe.tokens.create({
  card: {
    "number": '4242424242424242',
    "exp_month": 12,
    "exp_year": 2019,
    "cvc": '123'
  }}
   , function(status, response) {
      if(response)
        callback(response.id)
      console.log('status',status)
    });
 
 }
  
  // getToken('sk_test_nYKYagm3H3IrE5eg5heSxwu3',function(e,res){console.log('e,res',e,res.id)})
  module.exports=getToken;