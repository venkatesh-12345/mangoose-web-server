var assert = require("assert");
var DB = require("../dbQuery");
var config = require("nconf").get("rabbitmq");
var producer = require("../../rabbitmq/producer");
var testConsumer = require("./testConsumer");
var CP = require("../../database/sql/sqlQuery");
var userID = "12345678";
var AlmondMAC = "987654321";
var getToken = require("./stripeGetToken");
var assertFunction;
testConsumer.on("data", function(data) {
    if (typeof assertFunction == "function") assertFunction(data);
});
var afterFunction = function(callback) {
    DB.deleteSubscription({ AlmondMAC: AlmondMAC }, callback);
};
var getSubs = function(mac, callback) {
    CP.queryFunction("select * from Subscriptions where AlmondMAC=?", [mac], callback);
};
describe("Enable Free Subs", function() {
    this.timeout(20000);
    before(function(done) {
        DB.insertAllAlmondPlus({ AlmondMAC: AlmondMAC, ProductType: "AL2", AlmondID: "1" }, function(e, o) {
            if (e) console.log("err in insertAllAlmondPlus", e);
            if (!e)
                DB.insertUser({ UserID: userID, EmailID: "dummyprim@securifi.com", Password: "123456", index: 1 }, function(e, o) {
                    if (e) {
                        console.log(" Error in insertUser " + e);
                    } else {
                        console.log(" Success in insertUser " + o);
                        DB.insertAlmondUsers({ AlmondMAC: AlmondMAC, userID: userID, ownership: "P", LongSecret: "djhrfhcxrmvrfvgrbgb" }, function(
                            e,
                            o
                        ) {
                            if (e) {
                                console.log(" Error in insertAlmondUsers " + e);
                            } else {
                                console.log(" Success in insertAlmondUsers ");
                                done();
                            }
                        });
                    }
                });
        });
    });
    beforeEach(function(done) {
        DB.deleteSubscription({ AlmondMAC: AlmondMAC }, function(e, o) {
            if (e) console.log("err in deleteSubscription", e);
            else console.log("done deleteSubscription");
            done();
        });
    });
    it("Should Subscribe FreeSubs ", function(done) {
        var request = {
            PlanID: "Free",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",
            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        producer.sendToQueue("S10", JSON.stringify(request));
        assertFunction = function(data) {
            console.log("data", data);
            var payload = JSON.parse(data.payload);
            assert.equal(payload.Success, "true");
            assert.equal(payload.Services, "IoT");
            DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                if (e) console.log("error", e);

                assert.equal(res[0].Services, "IoT");
                assert.equal(res[0].Plan, "Free");
                done();
            });
        };
    });
    it("Should Subscribe FreeSubs and through error already Subscribed", function(done) {
        var request = {
            PlanID: "Free",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",
            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        producer.sendToQueue("S10", JSON.stringify(request));
        assertFunction = function(data) {
            console.log("data", data);
            var payload = JSON.parse(data.payload);
            if (payload.Success == "true") producer.sendToQueue("S10", JSON.stringify(request));
            if (payload.Success == "false") {
                assert.equal(payload.Success, "false");
                assert.equal(payload.Reason, "Almond Is Already Subscribed");
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                    if (e) console.log("error", e);

                    assert.equal(res[0].Services, "IoT");
                    assert.equal(res[0].Plan, "Free");
                    assert.equal(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 30 * 24 * 60 * 60 * 1000).getMonth());
                    done();
                });
            }
        };
    });
    it("Should Subscribe FreeSubs and through error already Subscribed", function(done) {
        var request = {
            PlanID: "Paid1M",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",

            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        getToken("sk_test_nYKYagm3H3IrE5eg5heSxwu3", function(token) {
            request.StripeToken = token;
            producer.sendToQueue("S10", JSON.stringify(request));
        });
        var count = 0;
        assertFunction = function(data) {
            console.log("data", data);
            count++;
            var payload = JSON.parse(data.payload);
            if (payload.Success == "true") {
                getToken("sk_test_nYKYagm3H3IrE5eg5heSxwu3", function(token) {
                    request.StripeToken = token;
                    producer.sendToQueue("S10", JSON.stringify(request));
                });
            }
            if (count > 1) {
                assert.equal(payload.Success, "false");
                assert.equal(payload.Reason, "Almond Is Already Subscribed");
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                    console.log('err', e,res)
                    if (e) console.log("error", e);
                    assert.equal(res[0].Services, "IoT");
                    assert.equal(res[0].Plan, "Paid1M");
                    assert.equal(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 30 * 24 * 60 * 60 * 1000).getMonth());
                    done();
                });
            }
        };
    });
    it("Should Subscribe Paid  when already has paid when do Upgrade", function(done) {
        var request = {
            PlanID: "Paid1M",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",
            //pk_test_16DTRcVWTgbRHD1csJpSWFqW use https://codepen.io/fmartingr/pen/pGfhy
            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        getToken("sk_test_nYKYagm3H3IrE5eg5heSxwu3", function(token) {
            request.StripeToken = token;
            producer.sendToQueue("S10", JSON.stringify(request));
        });
        var count = 0;
        assertFunction = function(data) {
            console.log("data*****************8", data);
            count++;
            var payload = JSON.parse(data.payload);
            if (payload.Success == "true" && payload.Services == "IoT") {
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                    console.log("res on frst sub", res);
                    assert.equal(res[0].Services, "IoT");
                    assert.equal(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 30 * 24 * 60 * 60 * 1000).getMonth());
                    assert.equal(res[0].Plan, "Paid1M");
                    request.Upgrade = true;
                    request.Services = "IoT_CMS";
                    request.PlanID = "Paid6M";
                    // getToken("sk_test_nYKYagm3H3IrE5eg5heSxwu3", function(token) {
                    //     request.StripeToken = token;
                        producer.sendToQueue("S10", JSON.stringify(request));
                    // });
                });
            }
            if (payload.Services == "IoT_CMS") {
                console.log("data in 6M", payload);
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                    console.log("res", res);
                    assert.equal(res[0].Services, "IoT_CMS");
                    assert.equal(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 180 * 24 * 60 * 60 * 1000).getMonth());
                    assert.equal(res[0].Plan, "Paid6M");
                    var payment = {
                        Android: "7.48.5",
                        CommandType: "PaymentDetails",
                        Upgrade: true,
                        PlanID: "Paid1Y",
                        AlmondMAC: AlmondMAC,
                        unicastID: 1101,
                        UserID: userID,
                        queue: "R@"
                    };
                    producer.sendToQueue("S10", JSON.stringify(payment));

                });
            }
            if(payload.CommandType=='PaymentDetails'){
                assert.equal(payload.Success,"true");
                assert.equal(payload.Amount,"23.99")
                done()
            }
        };
    });
    it.only("Should Subscribe SavedCard", function(done) {
        var request = {
            PlanID: "Paid1M",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",
            //pk_test_16DTRcVWTgbRHD1csJpSWFqW use https://codepen.io/fmartingr/pen/pGfhy
            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        getToken("sk_test_nYKYagm3H3IrE5eg5heSxwu3", function(token) {
            request.StripeToken = token;
            producer.sendToQueue("S10", JSON.stringify(request));
        });
        var count = 0;
        assertFunction = function(data) {
            console.log("data*****************8", data);
            count++;
            var payload = JSON.parse(data.payload);
            if (payload.Success == "true" && payload.Services == "IoT") {
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                    console.log("res on frst sub", res);
                    assert.equal(res[0].Services, "IoT");
                    assert.equal(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 30 * 24 * 60 * 60 * 1000).getMonth());
                    assert.equal(res[0].Plan, "Paid1M");
                    request.savedCard = true;
                    request.Services = "IoT_CMS";
                    request.PlanID = "Paid6M";
                    request.AlmondMAC=AlmondMAC+2;
                    delete request.StripeToken;
                    // getToken("sk_test_nYKYagm3H3IrE5eg5heSxwu3", function(token) {
                    //     request.StripeToken = token;
                        producer.sendToQueue("S10", JSON.stringify(request));
                    // });
                });
            }
            if (payload.Services == "IoT_CMS") {
                console.log("data in 6M", payload);
                DB.selectSubscription({ AlmondMAC: AlmondMAC+2 }, function(e, res) {
                    console.log("res", res);
                    assert.equal(res[0].Services, "IoT_CMS");
                    assert.equal(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 180 * 24 * 60 * 60 * 1000).getMonth());
                    assert.equal(res[0].Plan, "Paid6M");
                    done()

                });
            }
        };
    });
    it("Should Do Cancel Subs ", function(done) {
         var request = {
            PlanID: "Paid1M",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",
            //pk_test_16DTRcVWTgbRHD1csJpSWFqW use https://codepen.io/fmartingr/pen/pGfhy
            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        getToken("sk_test_nYKYagm3H3IrE5eg5heSxwu3", function(token) {
            request.StripeToken = token;
            producer.sendToQueue("S10", JSON.stringify(request));
        });
        var count = 0;
        assertFunction = function(data) {
            console.log("data", data);
            var payload = JSON.parse(data.payload);
               var request = {
            AlmondMAC: AlmondMAC,
            CommandType: "DeleteSubscription",
            Services: "IoT_CMS",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };     
        if (payload.Success == "true" && payload.CommandType=='SubscribeMe') 
            return producer.sendToQueue("S10", JSON.stringify(request));
            // if (payload.Success == "false") {
            //     assert.equal(payload.Success, "false");
            //     assert.equal(payload.Reason, "Almond is already subscribed");
                DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                        console.log('dn',e,res)
                    // if (e) console.log("error", e);

                    // assert.equal(res[0].Services, "IoT");
                    // assert.equal(res[0].Plan, "Free");
                    // assert.equal(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 30 * 24 * 60 * 60 * 1000).getMonth());
                    done();
                });
            }
    
    });
});
