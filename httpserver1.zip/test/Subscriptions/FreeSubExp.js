var assert = require("assert");
var DB = require("../dbQuery");
var config = require("nconf").get("rabbitmq");
var producer = require("../../rabbitmq/producer");
var testConsumer = require("./testConsumer");
var getToken = require("./stripeGetToken");
var userID = "12345678";
var AlmondMAC = "987654321";
var assertFunction;
testConsumer.on("data", function(data) {
    if (typeof assertFunction == "function") assertFunction(data);
});
var afterFunction = function(callback) {
    DB.deleteSubscription({ AlmondMAC: AlmondMAC }, callback);
};
describe("FreeExp Subs", function() {
    this.timeout(20000);
    before(function(done) {
        DB.insertAllAlmondPlus({ AlmondMAC: AlmondMAC, ProductType: "AL2", AlmondID: "1" }, function(e, o) {
            if (e) console.log("err in insertAllAlmondPlus", e);
            if (!e)
                DB.insertUser({ UserID: userID, EmailID: "dummyprim@securifi.com", Password: "123456", index: 1 }, function(e, o) {
                    if (e) {
                        console.log(" Error in insertUser " + e);
                    } else {
                        console.log(" Success in insertUser " + o);
                        DB.insertAlmondUsers({ AlmondMAC: AlmondMAC, userID: userID, ownership: "P", LongSecret: "djhrfhcxrmvrfvgrbgb" }, function(
                            e,
                            o
                        ) {
                            if (e) {
                                console.log(" Error in insertAlmondUsers " + e);
                            } else {
                                console.log(" Success in insertAlmondUsers ");
                             //   DB.insertSubscription({ AlmondMAC: AlmondMAC, UserID: userID, Plan: "FreeExpired", Services: "IoT" }, function(e, o) {
                               //     if (e) console.log("error in Insert Subscription**", e);
                                    done();
                                //});
                            }
                        });
                    }
                });
        });
    });
    after(function(done) {
        DB.deleteSubscription({ AlmondMAC: AlmondMAC }, function(e, o) {
            if (e) console.log("err in deleteSubscription", e);
            else console.log("done deleteSubscription");
            done();
        });
    });
    it("Should say Already Subscibed ", function(done) {
        var request = {
            PlanID: "Free",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",
            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        producer.sendToQueue("S10", JSON.stringify(request));
        assertFunction = function(data) {
            console.log("data", data);
            var payload = JSON.parse(data.payload);
            assert.equal(payload.Success, "true");
            assert.equal(payload.PlanID, "Free");
            DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                console.log('eeee',e,res)
                // if (e) console.log("error", e);

                assert.equal(res[0].Services, "IoT");
                assert.equal(res[0].Plan, "Free");
                done();
            });
        };
    });
    it("Should say Already Subscibed ", function(done) {
        var request = {
            PlanID: "Free",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",
            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        producer.sendToQueue("S10", JSON.stringify(request));
        assertFunction = function(data) {
            console.log("data", data);
            var payload = JSON.parse(data.payload);
            assert.equal(payload.Success, "false");
            assert.equal(payload.Reason, "Almond Is Already Subscribed");
            DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                if (e) console.log("error", e);

                assert.equal(res[0].Services, "IoT");
                assert.equal(res[0].Plan, "Free");
                done();
            });
        };
    });

    it.only("Should Subscribe Paid Subs", function(done) {
        this.timeout(10000)
        var request = {
            PlanID: "Paid1M",
            Android: "7.431.19",
            AlmondMAC: AlmondMAC,
            CommandType: "SubscribeMe",
            Services: "IoT",
            unicastID: 1067,
            UserID: userID,
            queue: "R@"
        };
        getToken("sk_test_nYKYagm3H3IrE5eg5heSxwu3", function(token) {
            request.StripeToken = token;
            producer.sendToQueue("S10", JSON.stringify(request));
        });
        var count = 0;
        assertFunction = function(data) {
            console.log("data", data);
            var payload = JSON.parse(data.payload);
            assert.equal(payload.Success, "true");
            DB.selectSubscription({ AlmondMAC: AlmondMAC }, function(e, res) {
                if (e) console.log("error", e);
                assert.equal(res[0].Services, "IoT");
                assert.equal(res[0].Plan, "Paid1M");
                console.log(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 30 * 24 * 60 * 60 * 1000).getMonth(),res[0])
                assert.equal(new Date(res[0].RenewalEpoch).getMonth(), new Date(res[0].SubscriptionEpoch + 30 * 24 * 60 * 60 * 1000).getMonth());
                done();
            });
        };
    });
});
