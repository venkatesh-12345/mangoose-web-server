var subscriptionUpdated = {
    "id": "evt_1C7edzDfUIS14iAjP8vHJ49G",
    "object": "event",
    "api_version": "2015-10-16",
    "created": 1521529947,
    "data": { "object": { "id": "sub_BnklxUWYPBIbuW", "object": "subscription", "application_fee_percent": null, "billing": "charge_automatically", "billing_cycle_anchor": 1511161176, "cancel_at_period_end": false, "canceled_at": null, "created": 1511161176, "current_period_end": 1524207576, "current_period_start": 1521529176, "customer": "cus_Bnklx7OKidnHFa", "days_until_due": null, "discount": null, "ended_at": null, "items": { "object": "list", "data": [{ "id": "si_Bnklze3azFGnX8", "object": "subscription_item", "created": 1511161177, "metadata": {}, "plan": { "id": "Paid1M", "object": "plan", "amount": 399, "created": 1485177398, "currency": "usd", "interval": "month", "interval_count": 1, "livemode": true, "metadata": {}, "nickname": null, "product": "prod_BUErV7h0mMKxS4", "trial_period_days": null, "statement_descriptor": null, "name": "1 Month Paid Plan" }, "quantity": 1, "subscription": "sub_BnklxUWYPBIbuW" }], "has_more": false, "total_count": 1, "url": "/v1/subscription_items?subscription=sub_BnklxUWYPBIbuW" }, "livemode": true, "metadata": {}, "plan": { "id": "Paid1M", "object": "plan", "amount": 399, "created": 1485177398, "currency": "usd", "interval": "month", "interval_count": 1, "livemode": true, "metadata": {}, "nickname": null, "product": "prod_BUErV7h0mMKxS4", "trial_period_days": null, "statement_descriptor": null, "name": "1 Month Paid Plan" }, "quantity": 1, "start": 1511161176, "status": "active", "tax_percent": null, "trial_end": null, "trial_start": null }, "previous_attributes": { "current_period_end": 1521529176, "current_period_start": 1519109976 } },
    "livemode": true,
    "pending_webhooks": 2,
    "request": null,
    "type": "customer.subscription.updated"
}

var paymentFailed = {
    "id": "evt_1C8PAIDfUIS14iAjkLcN9kxT",
    "object": "event",
    "api_version": "2015-10-16",
    "created": 1521708774,
    "data": { "object": { "id": "in_1C7InGDfUIS14iAj86mCnip3", "object": "invoice", "amount_due": 399, "application_fee": null, "attempt_count": 2, "attempted": true, "billing": "charge_automatically", "charge": "ch_1C8PAGDfUIS14iAjb8f0c5AN", "closed": false, "currency": "usd", "customer": "cus_CLr7xoD5f5WXcm", "date": 1521445954, "description": null, "discount": null, "due_date": null, "ending_balance": 0, "forgiven": false, "lines": { "object": "list", "data": [{ "id": "sub_CLr7SSo1u6Fz7O", "object": "line_item", "amount": 399, "currency": "usd", "description": null, "discountable": true, "livemode": true, "metadata": {}, "period": { "end": 1524124178, "start": 1521445778 }, "plan": { "id": "Paid1M", "object": "plan", "amount": 399, "created": 1485177398, "currency": "usd", "interval": "month", "interval_count": 1, "livemode": true, "metadata": {}, "nickname": null, "product": "prod_BUErV7h0mMKxS4", "trial_period_days": null, "statement_descriptor": null, "name": "1 Month Paid Plan" }, "proration": false, "quantity": 1, "subscription": null, "subscription_item": "si_CLr7mu9MHBbNGD", "type": "subscription" }], "has_more": false, "total_count": 1, "url": "/v1/invoices/in_1C7InGDfUIS14iAj86mCnip3/lines" }, "livemode": true, "metadata": {}, "next_payment_attempt": 1522140772, "number": "0FEABB3-0002", "paid": false, "period_end": 1521445778, "period_start": 1519026578, "receipt_number": null, "starting_balance": 0, "statement_descriptor": null, "subscription": "sub_CLr7SSo1u6Fz7O", "subtotal": 399, "tax": null, "tax_percent": null, "total": 399, "webhooks_delivered_at": 1521445961 } },
    "livemode": true,
    "pending_webhooks": 2,
    "request": null,
    "type": "invoice.payment_failed"
}

var subscriptionDeleted = {
    "id": "evt_1C8VMaDfUIS14iAjM2R4v4Uo",
    "object": "event",
    "api_version": "2015-10-16",
    "created": 1521732600,
    "data": { "object": { "id": "sub_C5qfNkaIf4Y6ds", "object": "subscription", "application_fee_percent": null, "billing": "charge_automatically", "billing_cycle_anchor": 1515334651, "cancel_at_period_end": false, "canceled_at": 1521732600, "created": 1515334651, "current_period_end": 1523110651, "current_period_start": 1520432251, "customer": "cus_C5qfFAGYx0cGV7", "days_until_due": null, "discount": null, "ended_at": 1521732600, "items": { "object": "list", "data": [{ "id": "si_C5qfnS9eISAEZb", "object": "subscription_item", "created": 1515334652, "metadata": {}, "plan": { "id": "Paid1M", "object": "plan", "amount": 399, "created": 1485177398, "currency": "usd", "interval": "month", "interval_count": 1, "livemode": true, "metadata": {}, "nickname": null, "product": "prod_BUErV7h0mMKxS4", "trial_period_days": null, "statement_descriptor": null, "name": "1 Month Paid Plan" }, "quantity": 1, "subscription": "sub_C5qfNkaIf4Y6ds" }], "has_more": false, "total_count": 1, "url": "/v1/subscription_items?subscription=sub_C5qfNkaIf4Y6ds" }, "livemode": true, "metadata": {}, "plan": { "id": "Paid1M", "object": "plan", "amount": 399, "created": 1485177398, "currency": "usd", "interval": "month", "interval_count": 1, "livemode": true, "metadata": {}, "nickname": null, "product": "prod_BUErV7h0mMKxS4", "trial_period_days": null, "statement_descriptor": null, "name": "1 Month Paid Plan" }, "quantity": 1, "start": 1515334651, "status": "canceled", "tax_percent": null, "trial_end": null, "trial_start": null } },
    "livemode": true,
    "pending_webhooks": 2,
    "request": null,
    "type": "customer.subscription.deleted"
}