/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var wireless = nconf.get('wireless');
var routerSummery = nconf.get('routerSummery');
var CLEAR_DB = nconf.get('CLEAR_DB');
var responseMaker = require('./extraFiles/responseMaker');
require('./extraFiles/almondConsumer');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

var sortByKey = function (array, key) {
    return array.sort(function (a, b) {
        var x = a[key];
        var y = b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
};

describe('RouterSummary tests: ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                
                AUTH = AUTH + res;
                console.log('==================== ---------- : ', AUTH);
                if (testEnviron === 'standaloneEnv') {
                    setTimeout(function() {
                        done();
                    }, 2000);
                } else
                    done();
            }
        });
    });
    it('Success testcase', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/RouterSummary',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                AlmondMAC: testEnv.almondMAC
            },
            json: true
        };
        console.log('sent the request');
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.success).to.equal(true);
            expect(body.CommandType).to.equal('RouterSummary');
            expect(body.hasOwnProperty('WirelessSetting')).to.equal(true);
            body.WirelessSetting = sortByKey(body.WirelessSetting, 'Type');
            body.WirelessSetting.forEach(function(item, index) {
                console.log('checking index : ', index);
                console.log(item);
                expect(body.WirelessSetting[index].Type).to.equal(wireless.WirelessSetting[index].Type);
                expect(body.WirelessSetting[index].Enabled).to.equal(wireless.WirelessSetting[index].Enabled);
                expect(body.WirelessSetting[index].SSID).to.equal(wireless.WirelessSetting[index].SSID);
                
            });
            expect(body.Login).to.equal(routerSummery.Login);
            expect(body.URL).to.equal(routerSummery.URL);
            expect(body.FirmwareVersion).to.equal(routerSummery.FirmwareVersion);
            if (testEnviron === 'stagingEnv') {
                console.log('checking other properties 2');
                expect(body.Uptime).to.equal(routerSummery.Uptime);
                expect(body.RouterUptime).to.equal(routerSummery.RouterUptime);
            } else {
                console.log('checking other properties');
                expect(body.hasOwnProperty('Uptime')).to.equal(true);
                expect(body.hasOwnProperty('TempPass')).to.equal(true);
                expect(body.hasOwnProperty('RouterUptime')).to.equal(true);
                expect(body.RouterMode).to.equal(routerSummery.RouterMode);
            }
            done();
        });
    });
    it('Wrong almondMAC testcase', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/RouterSummary',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                AlmondMAC: 12345
            },
            json: true
        };
        console.log('sent the request');
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if (CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
