/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var CLEAR_DB = nconf.get('CLEAR_DB');
var responseMaker = require('./extraFiles/responseMaker');
require('./extraFiles/almondConsumer');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';


describe('UpdateScene tests: ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                console.log('==================== ---------- : ', AUTH);
                done();
            }
        });
    });
    it('Success testcase', function (done) {
        this.timeout(15000);
        var options = {
            method: 'POST',
            url: URL + '/UpdateScene',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": 4563219881,
                "Scenes": {
                    "ID": 1,
                    "Name": "tester Test123"
                }
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true, dynamic:true, sameDynamic:true});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.reason).to.equal('Scene Updated');
            expect(body.success+'').to.equal('true');
            
            done();
        });
    });
    if (testEnviron === 'standaloneEnv') {
        it('Success false case when almond offline', function (done) {
            this.timeout(15000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    "AlmondMAC": 4563219881,
                    "Scenes": {
                        "ID": 1,
                        "Name": "tester Test123"
                    },
                    timeoutLimit: 10000
                },
                json: true
            };
            if (testEnviron === 'standaloneEnv')
                responseMaker.setProperties({success: false, reason: "Almond Offline"});

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.reason).to.equal('Almond is offline');
                expect(body.success + '').to.equal('false');

                done();
            });
        });
        it('Timeout case when no dynamic', function (done) {
            this.timeout(15000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    "AlmondMAC": 4563219881,
                    "Scenes": {
                        "ID": 1,
                        "Name": "tester Test123"
                    },
                    timeoutLimit: 10000
                },
                json: true
            };
            if (testEnviron === 'standaloneEnv')
                responseMaker.setProperties({success: true, dynamic: false});

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.reason).to.equal('Almond Timedout');
                expect(body.success + '').to.equal('true');

                done();
            });
        });
        it('Timeout case when different dynamic', function (done) {
            this.timeout(15000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    "AlmondMAC": 4563219881,
                    "Scenes": {
                        "ID": 1,
                        "Name": "tester Test123"
                    },
                    timeoutLimit: 10000
                },
                json: true
            };
            if (testEnviron === 'standaloneEnv')
                responseMaker.setProperties({success: true, dynamic: true, sameDynamic:false});

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.reason).to.equal('Almond Timedout');
                expect(body.success + '').to.equal('true');

                done();
            });
        });
        it('wrong almond case', function (done) {
            this.timeout(15000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    "AlmondMAC": 456321881,
                    "Scenes": {
                        "ID": 1,
                        "Name": "tester Test123"
                    },
                    timeoutLimit: 10000
                },
                json: true
            };
            if (testEnviron === 'standaloneEnv')
                responseMaker.setProperties({success: true, dynamic: true, sameDynamic:false});

            request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
        });
    }
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if (CLEAR_DB == 'true') {
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            } else {
                done();
            }
        } else
            done();
    });
});


