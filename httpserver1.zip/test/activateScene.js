/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var dbmodifier = require('./dbForTest/dbmodifier');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var testInputs = nconf.get('activateScene');
var CLEAR_DB = nconf.get('CLEAR_DB');
var responseMaker = require('./extraFiles/responseMaker');
require('./extraFiles/almondConsumer');

console.log(testEnv);
var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

describe('ActivateScene tests : ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                done();
            }
        });
    });
    it('case where Scene gets successfully activated', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/ActivateScene',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'AlmondMAC': testEnv.almondMAC,
                'Scenes': {
                    'ID': testInputs.presentSceneID
                }
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true, dynamic:true, sameDynamic:true});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            expect(response.statusCode).to.equal(200);
            console.log(JSON.stringify(body));
            expect(body.success + '').to.equal('true');
            expect(body.reason).to.equal('Scene Activation Successful');
            done();
        });
    });
    if (testEnviron === 'standaloneEnv') {
        it('case where Mobile success true and no dynamic update', function (done) {
            this.timeout(15000);
            var options = {
                method: 'POST',
                url: URL + '/ActivateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': testEnv.almondMAC,
                    'Scenes': {
                        'ID': testInputs.presentSceneID
                    },
                    timeoutLimit: 10000
                },
                json: true
            };
            if (testEnviron === 'standaloneEnv')
                responseMaker.setProperties({success: true, dynamic: false});

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body));
                expect(body.success + '').to.equal('true');
                expect(body.reason).to.equal('Almond Timedout');
                done();
            });
        });
        it('case where Mobile success true and different dynamic update', function (done) {
            this.timeout(15000);
            var options = {
                method: 'POST',
                url: URL + '/ActivateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': testEnv.almondMAC,
                    'Scenes': {
                        'ID': testInputs.presentSceneID
                    },
                    timeoutLimit: 10000
                },
                json: true
            };
            if (testEnviron === 'standaloneEnv')
                responseMaker.setProperties({success: true, dynamic: true, sameDynamic: false});

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body));
                expect(body.success + '').to.equal('true');
                expect(body.reason).to.equal('Almond Timedout');
                done();
            });
        });
    }
    it('case where scene is already activated', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/ActivateScene',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'AlmondMAC': testEnv.almondMAC,
                'Scenes': {
                    'ID': testInputs.presentSceneID
                }
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:false, reasonCode:'33'});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            expect(response.statusCode).to.equal(200);
            console.log(JSON.stringify(body));
            expect(body.success).to.equal(false);
            expect(body.success + '').to.equal('false');
            expect(body.ReasonCode).to.equal('33');
            expect(body.reason).to.equal('Scene Already Activated');
            done();
        });
    });
    it('Scene not present', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/ActivateScene',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'AlmondMAC': testEnv.almondMAC,
                'Scenes': {
                    'ID': testInputs.notPresentSceneID
                }
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:false, reasonCode:'9'});
        
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.success).to.equal(false);
            expect(body.ReasonCode).to.equal('9');
            expect(body.reason).to.equal('Almond is offline');
            done();
        });
    });
    it('case where almond is offline', function (done) {// NEW
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/ActivateScene',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'AlmondMAC': '25117',
                'Scenes': {
                    'ID': '2'
                }
            },
            json: true
        };
        dbmodifier.createAlmond(25117, testEnv.almondPlusID, testEnv.almondName, testEnv.longSecret, testEnv.almondVersion, function (err, rows) {
            console.log('create almond callback err :', err);
            dbmodifier.assignUserToAlmond(25117, testEnv.emailID, function (err) {
                console.log('assign user to almond err------ : ', err);
                accManager.offlineAlmondRedis(25117, function() {
                    console.log('-------- sending the request ----------');
                    request(options, function (error, response, body) {
                        if (error)
                            done(error);
                        console.log(body);
                        expect(response.statusCode).to.equal(200);
                        expect(body.success).to.equal(true);
                        expect(body.Timeout).to.equal(true);
                        expect(body.reason).to.equal('Almond Offline');
                        dbmodifier.deleteAlmond(25117, function(err, rows) {
                            done();
                        });
                    });
                });
            });
        });
    });
    it('Wrong almondMAC case', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/ActivateScene',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'AlmondMAC': 12345,
                'Scenes': {
                    'ID': testInputs.notPresentSceneID
                }
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:false, reasonCode:'9'});
        
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
