/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var CLEAR_DB = nconf.get('CLEAR_DB');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';


describe('GetScenes tests: ', function () {
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                done();
            }
        });
    });
    it('GetScenes success testcase', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/GetScenes',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": testEnv.almondMAC
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.CommandType).to.equal('GetScenes');
            expect(body.Success).to.equal(true);
            expect(body.Reason).to.equal(undefined);
            expect(body.AlmondMAC + '').to.equal(testEnv.almondMAC);
            expect(body.hasOwnProperty('Scenes')).to.equal(true);
            
            if (testEnviron !== 'productionEnv') {
                expect(body.Scenes.hasOwnProperty('1')).to.equal(true);
                expect(body.Scenes['1'].ID + '').to.equal('1');
                expect(body.Scenes['1'].Name).to.equal('tester');
                expect(body.Scenes['1'].Active).to.equal('false');
                expect(body.Scenes['1'].SceneEntryList[0].ID).to.equal('0');
                expect(body.Scenes['1'].SceneEntryList[0].Index).to.equal('1');
                expect(body.Scenes['1'].SceneEntryList[0].Value).to.equal('home');
                expect(body.Scenes['1'].SceneEntryList[0].Valid).to.equal('true');
                expect(body.Scenes['1'].SceneEntryList[1].ID).to.equal('2');
                expect(body.Scenes['1'].SceneEntryList[1].Index).to.equal('2');
                expect(body.Scenes['1'].SceneEntryList[1].Value).to.equal('Off');
                expect(body.Scenes['1'].SceneEntryList[1].Valid).to.equal('true');
                expect(body.Scenes.hasOwnProperty('2')).to.equal(true);
                expect(body.Scenes['2'].ID + '').to.equal('2');
                expect(body.Scenes['2'].Name).to.equal('pester');
                expect(body.Scenes['2'].Active).to.equal('false');
                expect(body.Scenes['2'].SceneEntryList[0].ID).to.equal('0');
                expect(body.Scenes['2'].SceneEntryList[0].Index).to.equal('1');
                expect(body.Scenes['2'].SceneEntryList[0].Value).to.equal('home');
                expect(body.Scenes['2'].SceneEntryList[0].Valid).to.equal('true');
                expect(body.Scenes['2'].SceneEntryList[1].ID).to.equal('2');
                expect(body.Scenes['2'].SceneEntryList[1].Index).to.equal('2');
                expect(body.Scenes['2'].SceneEntryList[1].Value).to.equal('Auto');
                expect(body.Scenes['2'].SceneEntryList[1].Valid).to.equal('true');
            }
            done();
        });
    });
    it('Wrong AlmondMAC testcase', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/GetScenes',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": 12345
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});
