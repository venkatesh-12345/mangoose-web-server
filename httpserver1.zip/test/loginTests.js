var expect = require('chai').expect;
var request = require('request');
var CP = require('../database/sql/sqlQuery.js');
var dbmodifier = require('./dbForTest/dbmodifier.js');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var URL = nconf.get('httpUrl');
var loginTest = nconf.get('login');
var CLEAR_DB = nconf.get('CLEAR_DB');

function activateVerifyAccount(email, callback) {
    var options = {
        method: 'POST',
        url: URL + '/ResendActivationLink',
        body: {
            'emailID': email
        },
        json: true
    };
    request(options, function (error, response, body) {

        CP.queryFunction('SELECT ValidationToken from ?? where EmailID=?', ['Users', email], function (err, rows) {
            if (err || rows.length == 0) {
                callback(err);
            }
            options.url = URL + '/VerifyAccount';
            options.body.token = rows[0].ValidationToken;
            console.log('body :: ', options.body);
            request(options, function (error, response, body) {
                if (error)
                    callback(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                callback();
            });
        });

    });
}

describe('Login tests', function (done) {
    before(function (done) {
        this.timeout(35000);
        console.log(" How many times");
        if (testEnviron !== 'productionEnv') {
            dbmodifier.createUser(loginTest.email, loginTest.password, function (err, rows) {
                console.log('done');
                done();
                //accManager.activateVerifyAccount(loginTest.email, done);
            });
        } else {
            done();
        }
    });
    var uid = undefined;
    var tempPass = undefined;
    it('Login with emailID and password', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/Login',
            body: {
                'emailID': loginTest.email,
                'password': loginTest.password
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.commandType).to.equal('Login');
            expect(body.success + '').to.equal('true');
            expect(body.hasOwnProperty('userID')).to.equal(true);
            expect(body.hasOwnProperty('tempPass')).to.equal(true);
            expect(body.hasOwnProperty('isActivated')).to.equal(true);
            //expect(body.isActivated).to.equal(1);
            expect(body.hasOwnProperty('minutesRemaining')).to.equal(true);
            uid = body.userID;
            tempPass = body.tempPass;
            done();
        });
    });
    it('Login with userID and tempPass', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/Login',
            body: {
                'userID': uid,
                'tempPass': tempPass
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.commandType).to.equal('Login');
            expect(body.success + '').to.equal('true');
            expect(body.hasOwnProperty('userID')).to.equal(true);
            expect(body.hasOwnProperty('tempPass')).to.equal(true);
            expect(body.hasOwnProperty('isActivated')).to.equal(true);
            //expect(body.isActivated).to.equal(1);
            expect(body.hasOwnProperty('minutesRemaining')).to.equal(true);
            expect(body.hasOwnProperty('FirstName')).to.equal(true);
            expect(body.hasOwnProperty('LastName')).to.equal(true);
            done();
        });
    });
    after(function (done) {
        this.timeout(10000);
        console.log(" How many times");
        if (testEnviron !== 'productionEnv') {
            dbmodifier.deleteUser(loginTest.email, function (err, rows) {
                console.log('done');
                done();
            });
        } else {
            done();
        }
    });
});
