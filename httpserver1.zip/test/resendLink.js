var expect = require('chai').expect;
var request = require('request');
var CP = require('../database/sql/sqlQuery.js');
var dbmodifier = require('./dbForTest/dbmodifier.js');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var URL = nconf.get('httpUrl');
var resendLink = nconf.get('resendLink');

var Almond1 = {
    "almondPlusID": "fjFVUX7u8cWUL6PuNCvjkkjnNZ79V0Sh",
    "almondMAC": 8777,
    "EmailID": "custom1@securifi.com",
    "password": "000000",
    "longSecret": "sadsadasdasd",
    "firmwareVersion": 'AP2-R085by',
    "AlmondName": 'Dummy Almond 3',
    "link": true
}

var prepareUsers = function (callback) {
    dbmodifier.createUser(resendLink.validatedUser.emailID, resendLink.validatedUser.password, function (err, rows) {
        console.log('done');
//            done();
        accManager.activateVerifyAccount(resendLink.validatedUser.emailID, function (error) {
            if (error)
                return callback(error);
            dbmodifier.createUser(resendLink.newUser.emailID, resendLink.newUser.password, function (err, rows) {
                console.log('==========================');
                callback();
            });
        });
    });
};

var removeUsers = function (callback) {
    dbmodifier.deleteUser(resendLink.validatedUser.emailID, function (err, rows) {
        if (err) {
            console.log('------- 1------',err);
            return callback(err);
        }
        dbmodifier.deleteUser(resendLink.newUser.emailID, function (err, rows) {
            console.log('- -- -- - - 1 -- - -  -', err);
            callback(err);
        });
    });
};

describe('Account Activation tests', function (done) {
    before(function (done) {
        this.timeout(10000);
        console.log(" How many times");
        if (testEnviron !== 'productionEnv') {
            prepareUsers(function(err) {
                if(err)
                    console.log(err);
                done(err);
            });
        } else
            done();
    });
    it('no user found ResendActivationLink', function (done) {
        var options = {
            method: 'POST',
            url: URL + '/ResendActivationLink',
            body: {
                'emailID': resendLink.noUser.emailID
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(502);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('No such user');
            done();
        });
    });
    it('successful ResendActivationLink', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/ResendActivationLink',
            body: {
                'emailID': resendLink.newUser.emailID
            },
            json: true
        };
        //dbmodifier.createUser(options.body.emailID, resendLink.newUser.password, function (err, rows) {
            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                done();
            });
        //});
    });
    // Production Env will fail. Find alternate
    it.skip('Account verified successfully', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/VerifyAccount',
            body: {
                'emailID': resendLink.newUser.emailID
            },
            json: true
        };
        CP.queryFunction('SELECT ValidationToken from ?? where EmailID=?', ['Users', resendLink.newUser.emailID], function (err, rows) {
            if (err || rows.length == 0) {
                done(err);
            }
            options.body.token = rows[0].ValidationToken;
            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                done();
            });
        });
    });
    it('ResendActivationLink unsuccessful user already Validated', function (done) {
        var options = {
            method: 'POST',
            url: URL + '/ResendActivationLink',
            body: {
                'emailID': resendLink.validatedUser.emailID
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(502);
            expect(body.success + '').to.equal('false');
            expect(body.reason + '').to.equal('Already Validated');
            done();
        });
    });
    after(function (done) {
        console.log(" How many times -- after");
        if (testEnviron !== 'productionEnv') {
            removeUsers(done);
        } else
            done();
    });
});