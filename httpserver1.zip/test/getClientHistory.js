/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var moment = require('moment');
var accManager = require('./dbForTest/accountManager');
//var loggerPoint = require('../database/cassandra/cqlConnection');
var pgClient = require('../database/postgres/pgQueryNew');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var testInput = nconf.get('getClientHistory');
var CLEAR_DB = nconf.get('CLEAR_DB');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';
const TIME = Date.now();
var date = moment.utc().utcOffset(0);
const CURR_DATE = date.format('YYYY-MM-DD');
var ClientMAC_decimal = testInput.decimalClientMAC;
var ClientMAC_hex = testInput.hexClientMAC;

function getRandInt(limit) {
    return Math.floor(Math.random() * limit);
}
function insertOneRecord(mac, client_mac, i, callback) {
    var id = getRandInt(10);
    var data = {
        mac: mac,
        client_mac: client_mac,
        time: TIME + i,
        client_id: id,
        index_name: null,
        type: getRandInt(60) + '',
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: 'testing value'
    };
    data.name = 'name#' + data.client_mac;
    var query = "insert into recentactivity (mac, id, time, index_id, client_id , name , type , value ) values ($1,$2,NOW(), 0, $3,$4,$5,$6)";
    var params = [data.mac, data.client_mac, data.client_id, data.name, data.type, data.value];
    pgClient.query(query, params, function (error, result) {
        if (error)
            console.log(error);
        else
            callback();
    });
}


function insertDeviceHistory(mac, device_id, totalRec, callback) {
    var nextItemIndex = 0;
    function iterator(err) {
        nextItemIndex++;
        if (nextItemIndex === totalRec) {
            callback(err);
        } else {
            insertOneRecord(mac, device_id, nextItemIndex, function () {
                iterator();
            });
        }
    }
    insertOneRecord(mac, device_id, nextItemIndex, function () {
        iterator();
    });
}

function clearData(mac, client_mac, callback) {
    var query = "DELETE from recentactivity WHERE mac= $1 AND id = $2 ";
    var params = [mac, client_mac];
    pgClient.query(query, params, function (error, result) {
        if (error)
            console.log(error);
        else
            callback();
    });
}

describe('GetClientHistory tests: ', function () {
    var pageState = null;
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                console.log('==================== ---------- : ', AUTH);
                if(testEnviron !== "productionEnv")
                    insertDeviceHistory(testEnv.almondMAC, ClientMAC_decimal, 100, function() {
                        done();
                    });
                else
                    done();
            }
        });
    });
    it('Success testcase', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/GetClientHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "Hub": {
                    "HubMAC": testEnv.almondMAC
                },
                "Client_mac": ClientMAC_hex,
                "Thermostats": [{
                        "Id": 12
                    }],
                "pageState": null
            },
            json: true
        };
        console.log(JSON.stringify(options));
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('pageState')).to.equal(true);
            expect(body.hasOwnProperty('logs')).to.equal(true);
            expect(body.logs[0].mac + '').to.equal(testEnv.almondMAC);
//            expect(body.logs[0].value + '').to.equal('testing value');
//            expect(body.logs[0].client_name + '').to.equal('name#'+testInput.decimalClientMAC);
            expect(body.logs[0].hasOwnProperty('client_id')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('client_type')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('time')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('value')).to.equal(true);
            //expect(body.logs[0].client_mac + '').to.equal(ClientMAC_decimal+'');
            pageState = body.pageState;
            done();
        });
    });
    it('Success testcase with GET method', function (done) {
        this.timeout(10000);
        var options = {
            method: 'GET',
            url: URL + '/GetClientHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": testEnv.almondMAC,
                "client_mac": ClientMAC_hex,
                "type":"wifi_client" ,
                "pageState": null
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('pageState')).to.equal(true);
            expect(body.hasOwnProperty('logs')).to.equal(true);
            expect(body.logs[0].mac + '').to.equal(testEnv.almondMAC);
//            expect(body.logs[0].value + '').to.equal('testing value');
//            expect(body.logs[0].client_name + '').to.equal('name#'+testInput.decimalClientMAC);
            expect(body.logs[0].hasOwnProperty('client_id')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('client_type')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('time')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('value')).to.equal(true);
            //expect(body.logs[0].client_mac + '').to.equal(ClientMAC_decimal+'');
            pageState = body.pageState;
            done();
        });
    });
    it('Success testcase with pageState', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/GetClientHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": testEnv.almondMAC,
                "client_mac": ClientMAC_hex,
                "type":"wifi_client" ,
                "pageState": pageState
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('pageState')).to.equal(true);
            expect(body.hasOwnProperty('logs')).to.equal(true);
            expect(body.logs[0].mac + '').to.equal(testEnv.almondMAC);
//            expect(body.logs[0].value + '').to.equal('testing value');
//            expect(body.logs[0].client_name + '').to.equal('name#'+testInput.decimalClientMAC);
            expect(body.logs[0].hasOwnProperty('client_id')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('client_type')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('time')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('value')).to.equal(true);
            //expect(body.logs[0].client_mac + '').to.equal(ClientMAC_decimal+'');
            //pageState = body.pageState; // Commented to use same pageState for the next testcase also.
            pageState = body.pageState;
            done();
        });
    });
    it('Success testcase with GET method and with pageState ', function (done) {
        this.timeout(10000);
        var options = {
            method: 'GET',
            url: URL + '/GetClientHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
             body: {
                "AlmondMAC": testEnv.almondMAC,
                "client_mac": ClientMAC_hex,
                "type":"wifi_client" ,
                "pageState": pageState
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.hasOwnProperty('pageState')).to.equal(true);
            expect(body.hasOwnProperty('logs')).to.equal(true);
            expect(body.logs[0].mac + '').to.equal(testEnv.almondMAC);
//            expect(body.logs[0].value + '').to.equal('testing value');
//            expect(body.logs[0].client_name + '').to.equal('name#'+testInput.decimalClientMAC);
            expect(body.logs[0].hasOwnProperty('client_id')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('client_type')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('time')).to.equal(true);
            expect(body.logs[0].hasOwnProperty('value')).to.equal(true);
            //expect(body.logs[0].client_mac + '').to.equal(ClientMAC_decimal+'');
            pageState = body.pageState;
            done();
        });
    });
    it('Wrong almondMAC case', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/GetClientHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
             body: {
                "AlmondMAC": 12345,
                "client_mac": ClientMAC_hex,
                "type":"wifi_client" ,
                "pageState": pageState
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else
            done();
    });
});


