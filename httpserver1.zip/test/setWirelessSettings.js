/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var setSSID = nconf.get('setSSID');
var CLEAR_DB = nconf.get('CLEAR_DB');
var responseMaker = require('./extraFiles/responseMaker');
require('./extraFiles/almondConsumer');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

var sortByKey = function (array, key) {
    return array.sort(function (a, b) {
        var x = a[key];
        var y = b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
};

describe('SetWirelessSettings tests: ', function () {
    var timeoutTime = (testEnviron !== 'productionEnv') ? 2000 : 30000;
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                
                AUTH = AUTH + res;
                console.log('==================== ---------- : ', AUTH);
                done();
            }
        });
    });
    it('set SSID test', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/SetWirelessSettings',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "WirelessSetting": {
                    "Type": setSSID.Type,
                    "SSID": setSSID.newSSID
                },
                "AlmondMAC": testEnv.almondMAC
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.CommandType).to.equal('SetWirelessSettings');
            expect(body.success).to.equal(true);
            expect(body.hasOwnProperty('WirelessSetting')).to.equal(true);
            body.WirelessSetting = sortByKey(body.WirelessSetting, 'Type');
            expect(body.WirelessSetting[0].Type).to.equal(setSSID.Type);
            expect(body.WirelessSetting[0].SSID).to.equal(setSSID.newSSID);
            
            done();
        });
    });
    it('set to old SSID test', function (done) {
        this.timeout(35000);
        var options = {
            method: 'POST',
            url: URL + '/SetWirelessSettings',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "WirelessSetting": {
                    "Type": setSSID.Type,
                    "SSID": setSSID.oldSSID
                },
                "AlmondMAC": testEnv.almondMAC
            },
            json: true
        };

        setTimeout(function () {
            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.CommandType).to.equal('SetWirelessSettings');
                expect(body.success).to.equal(true);
                expect(body.hasOwnProperty('WirelessSetting')).to.equal(true);
                body.WirelessSetting = sortByKey(body.WirelessSetting, 'Type');
                expect(body.WirelessSetting[0].Type).to.equal(setSSID.Type);
                expect(body.WirelessSetting[0].SSID).to.equal(setSSID.oldSSID);
                
                done();
            });
        }, timeoutTime);
    });
    it('Wrong almondMAC test', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/SetWirelessSettings',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "WirelessSetting": {
                    "Type": setSSID.Type,
                    "SSID": setSSID.newSSID
                },
                "AlmondMAC": 12345
            },
            json: true
        };
        if (testEnviron === 'standaloneEnv')
            responseMaker.setProperties({success:true});

        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(35000);
        if (testEnviron !== 'productionEnv') {
            if (CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        done(err);
                    });
                });
            else
                done();
        } else {
            setTimeout(done,timeoutTime);
        }
    });
});
