/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var testConfig = require('./TestConfigs/testConfig');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

var sortByKey = function (array, key) {
    return array.sort(function (a, b) {
        var x = a[key];
        var y = b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
};

describe('ChangeAlmondName tests: ', function () {
    before(function (done) {
        this.timeout(25000);
        if (testEnviron === 'stagingEnv')
            accManager.clearAccounts(function (err) {
                if (err)
                    return done(err);
                accManager.createAccounts(function (err) {
                    if (err)
                        return done(err);
                    accManager.affiliateAlmond(function (err, creds) {
                        if (err)
                            return done(err);
                        AUTH = AUTH + creds.tempPass + ':' + creds.userID;
                        done();
                    });
                });
            });
        else {
            console.log('Testing the environment : ', testEnviron);
            accManager.getUserIDtempPass({'emailID': testEnv.emailID, 'password': testEnv.password}, function (err, creds) {
                AUTH = AUTH + creds.tempPass + ':' + creds.userID;
                done();
            });
        }
    });
    it('Success testcase', function (done) {
        this.timeout(15000);
        var options = {
            method: 'POST',
            url: URL + '/ChangeAlmondName',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "CommandType": "DynamicAlmondProperties",
                "AlmondProperties": {
                    "AlmondName": "Almond-321"
                },
                "AlmondMAC": testEnv.almondMAC
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron === 'stagingEnv')
            accManager.unlinkAlmond(function () {
                accManager.clearAccounts(function (err) {
                    done(err);
                });
            });
        else
            done();
    });
});
