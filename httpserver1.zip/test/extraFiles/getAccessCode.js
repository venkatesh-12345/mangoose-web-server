/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var testConfig = require('./TestConfigs/testConfig');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var redisConn = require('../database/redis/redisConnector');

var URL = testConfig.httpUrl;
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

describe('Tests for getAccessCode : ', function () {
    var code = '123457';
    before(function (done) {
        this.timeout(25000);
        accManager.clearAccounts(function (err) {
            if (err)
                return done(err);
            accManager.createAccounts(function (err) {
                if (err)
                    return done(err);
                accManager.affiliateAlmond(function (err, creds) {
                    if (err)
                        return done(err);
                    AUTH = AUTH + creds.tempPass + ':' + creds.userID;
                    testEnv.userID = creds.userID;
                    testEnv.tempPass = creds.tempPass;
                    redisConn.query('hmset', "accessCode:" + code, ['authCode', code, 'clientId', "amazon-echo", 'userId', creds.userID, 'email', testEnv.emailID, 'expires', '1499788956'], function () {
                        done();
                    });
                });
            });
        });
    });
    it(' bearerTest POST GetAccessCode', function (done) {
        this.timeout(5000);
        console.log("Before making a request ..");
        var options = {
            method: 'POST',
            url: URL + '/GetAccessCode',
            headers: {
                'content-type': TYPE_X,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                'user': testEnv.emailID,
                'password': testEnv.password,
                'response_type': 'code',
                'client_id': 'securifi_android_mobile_app',
                'client_secret': '.ncrZ~3-(4Vw(73Z',
                'redirect_uri': 'https://connect.securifi.com'
            },
            json: true
        };
        request(options, function (error, response, body) {
            console.log(error);
//                if (error)
//                    throw new Error(error);
            console.log(response.statusCode);
            console.log(body);
            console.log(response.headers);
            expect(response.headers.location.indexOf('https://connect.securifi.com')).to.equal(0); // redirected URL
            expect(response.statusCode).to.equal(302); //URL redirection status code
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        accManager.unlinkAlmond(function () {
            accManager.clearAccounts(function (err) {
                done(err);
            });
        });
    });
});
