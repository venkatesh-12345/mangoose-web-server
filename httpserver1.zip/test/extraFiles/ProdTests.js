var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var testConfig = require('./TestConfigs/testConfig');
var dbmodifier = require('./dbForTest/dbmodifier.js');
var Affiliation = require('./Simulator/Affiliation/Affiliation.js');
var Almond = require('./Simulator/Almond.js');
var loggerPoint = require('../database/cassandra/cqlConnection');
var redisConn = require('../database/redis/redisConnector');
var moment = require('moment');
var extend = require('util')._extend;

var date = moment.utc().utcOffset(0);
const CURR_DATE = date.format('YYYY-MM-DD');

var URL = testConfig.httpUrl;
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';
var ALMOND_NAME = 'Dummy Almond 3';
var ALMOND_VERSION = 'AP2-R085by';
var ALMOND_MAC = '4563219881';
var EMAIL = "testhttp2@securifi.com";
var PASSWORD = "000000";
var userID = undefined;
var tempPass = undefined;

var sortByKey = function (array, key) {
    return array.sort(function (a, b) {
        var x = a[key];
        var y = b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
};

var Almond1 = {
    "almondPlusID": "fjFVUX7u8cWUL6PuNCvjkkjnNZ79V0Sh",
    "almondMAC": ALMOND_MAC,
    "EmailID": EMAIL,
    "password": PASSWORD,
    "longSecret": "sadsadasdasd",
    "firmwareVersion": ALMOND_VERSION,
    "AlmondName": ALMOND_NAME,
    "link": true
};

function clone(a) {
    return JSON.parse(JSON.stringify(a));
}

function clearAccounts(callback) {
    dbmodifier.deleteUser(Almond1.EmailID, function (err, rows) {
        if (err)
            callback(err);
        dbmodifier.deleteAlmond(Almond1.almondMAC, function (err, rows) {

            callback(err);
            console.log('done');//done();
        });
    });
}

function createAccounts(callback) {
    dbmodifier.createUser(Almond1.EmailID, Almond1.password, function (err, rows) {
        if (err)
            callback(err);
        dbmodifier.createAlmond(Almond1.almondMAC, Almond1.almondPlusID, Almond1.AlmondName, Almond1.longSecret, Almond1.firmwareVersion, function (err, rows) {
            callback(err);
        });
    });
}
var devIdArr = [1,2,3];
var cliIdArr = [12131415,12131416,12131417];
const DEV_ID = 12;
const CLI_ID = 875421;
const TIME = Date.now();
var insert = function (data, table, callback) {
    //console.log("data to insert", data);
    var day = 0;//Math.floor(Math.random() * 3) + 0;
    var dateyear = data.dateyear;//moment(data.time).subtract(day,"days").format('YYYY-MM-DD');
//    var hour = generateRandomhour();
    var error = null;
    var ip = '127.0.0.1';
    var query;
    var params = [];
    if (table === "dynamic_update_wifi_client")
        query = "insert into " + table + " (mac, client_mac, time , client_id , client_name , client_type , dateyear , mac_date , userid , value ) values " +
                "(" + data.mac + "," + data.client_mac + "," + data.time + "," + data.client_id + ",'" + data.client_name + "','" + data.client_type + "','" + dateyear + "','" + data.mac + ':' + dateyear + "','" + data.userid + "','" + data.value + "')";
    else if (table === "dynamic_update_log")
        query = "insert into " + table + " (mac, device_id , time , index_id , dateyear , device_name , type , index_name , mac_date , userid , value ) values " +
                "(" + data.mac + "," + data.device_id + "," + data.time + "," + data.index_id + ",'" + dateyear + "','" + data.device_name + "','" + data.device_type + "', '" + data.index_name + "','" + data.mac + ':' + dateyear + "','" + data.userid + "','" + data.value + "')";
    else if (table === 'dynamic_log') {
        query = "INSERT INTO " + table + " (mac, id, time, index_id, dateyear, name, type, index_name, client_id, mac_date, userid, value) VALUES (?,?,?,?,'" + data.dateyear + "',?,?,?,?,?,?,?);";
        params = [data.mac, data.id, data.time, data.index_id, data.name, data.type.toString(), data.index_name, data.client_id, data.mac + ":" + data.dateyear, data.userid, data.value];
    }
    //console.log(query);
    //console.log(JSON.stringify(params));
    loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
        if (error)
            console.log(error);
        else
            callback();
    });
};

function clearDB(mac, callback) {
    var query = "DELETE FROM dynamic_log WHERE mac = ? AND id IN ?;";
    var params = [mac, devIdArr.concat(cliIdArr)];
    loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
        callback(error);
    });
}

function insertOneRecord(i, callback) {
    var rand = Math.floor(Math.random() * 2);
    var devData = {
        mac: ALMOND_MAC,
        id: devIdArr[rand],
        time: TIME + i,
        index_id: 1,
        index_name: 'indexName#1',
        type: "20",
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: "device value"
    };
    //console.log(TIME+j);
    devData.name = 'name#' + devData.id;
    for (var index = 0; index < 3; index++) {
        devData.id = devIdArr[index];
        insert(devData, "dynamic_log", function () {
            //console.log("Insert Done");
        });
    }
    
    var cliData = {
        mac: ALMOND_MAC,
        id: cliIdArr[rand],
        time: TIME + i,
        index_id: 123456,
        client_id: 12,
        type: "30",
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: "client value"
    };
    cliData.name = 'name#' + cliData.id;
    for (var index = 0; index < 3; index++) {
        cliData.id = cliIdArr[index];
        insert(cliData, "dynamic_log", function () {
            //console.log("Insert Done");
        });
    }
    setTimeout(callback,100);
}

var createDB = function (callback) {
    var nextItemIndex = 0;
    function iterator(err) {
        nextItemIndex++;
        if (nextItemIndex === 100) {
            callback(err);
        } else {
            if (nextItemIndex % 5 === 0)
                date.subtract(1, 'day');
            insertOneRecord(nextItemIndex, function () {
                iterator();
            });
        }
    }
    insertOneRecord(nextItemIndex, function () {
        iterator();
    });
};

describe('Basic Test cases for Http server : ', function () {
    before(function (done) {
        this.timeout(25000);
        clearAccounts(function (err) {
            if (err)
                done(err);
            createAccounts(function (err) {
                if (err)
                    done(err);
                Affiliation(Almond1, function (linked) {
                    console.log('##### Almond Affiliation #####  ' + linked);
                    var param = clone(Almond1);
                    var confs = require('./TestConfigs/test1.json');
                    param.devices = confs.devices;
                    param.scenes = confs.scenes;
                    param.wifiClients = confs.wifiClients;
                    param.rules = confs.rules;
                    almond = new Almond(param);
                    almond.on('cloudconnected', function () {
                        console.log(" Almond connected to mobile ");
                        //return done();
                        var options = {
                            method: 'POST',
                            url: URL + '/Login',
                            headers: {
                                'authorization': 'Bearer ',
                                'content-type': TYPE_JSON
                            },
                            body: {
                                'emailID': Almond1.EmailID,
                                'password': Almond1.password
                            },
                            json: true
                        };
                        request(options, function (err, res, body) {
                            if (err)
                                done(err);
                            AUTH = AUTH + body.tempPass + ':' + body.userID;
                            userID = body.userID;
                            tempPass = body.tempPass;
                            console.log("final AUTH: ", AUTH);
                            done();
                        });
                    });
                });
            });
        });
    });

    describe('Tests for Get Commands : ', function () {
        it('GetAlmondList', function (done) {
            this.timeout(5000);
            var options = {
                method: 'GET',
                url: URL + '/GetAlmondList',
                headers: {
                    'content-type': TYPE_X,
                    authorization: AUTH
                }
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                body = JSON.parse(body);
                expect(body.CommandType).to.equal('AlmondList');
                expect(body.hasOwnProperty('Almonds')).to.equal(true);
                expect(body.Almonds[0].AlmondName).to.equal(ALMOND_NAME);
                expect(body.Almonds[0].AlmondMAC + '').to.equal(ALMOND_MAC);
                expect(body.Almonds[0].FirmwareVersion).to.equal(ALMOND_VERSION);
                done();
            });
        });
        it('GetAllScenes test', function (done) {
            this.timeout(5000);
            var options = {
                method: 'GET',
                url: URL + '/GetAllScenes',
                headers: {
                    'content-type': TYPE_X,
                    authorization: AUTH
                }
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                body = JSON.parse(body);
                expect(body.success).to.equal(true);
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty(ALMOND_MAC)).to.equal(true);
                expect(body.Result[ALMOND_MAC].status).to.equal('1');
                expect(body.Result[ALMOND_MAC].name).to.equal(ALMOND_NAME);
                expect(body.Result[ALMOND_MAC].version).to.equal(ALMOND_VERSION);
                expect(body.Result[ALMOND_MAC].hasOwnProperty('Scenes')).to.equal(true);
                body.Result[ALMOND_MAC].Scenes = sortByKey(body.Result[ALMOND_MAC].Scenes, 'SceneID');

                expect(body.Result[ALMOND_MAC].Scenes[0].SceneID + '').to.equal('1');
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneName).to.equal('tester');
                expect(body.Result[ALMOND_MAC].Scenes[0].hasOwnProperty('SceneEntryList')).to.equal(true);
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneEntryList[0].ID + '').to.equal('0');
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneEntryList[0].Index + '').to.equal('1');
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneEntryList[0].Value + '').to.equal('home');
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneEntryList[0].Valid + '').to.equal('true');
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneEntryList[1].ID + '').to.equal('2');
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneEntryList[1].Index + '').to.equal('2');
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneEntryList[1].Value + '').to.equal('Off');
                expect(body.Result[ALMOND_MAC].Scenes[0].SceneEntryList[1].Valid + '').to.equal('true');

                expect(body.Result[ALMOND_MAC].Scenes[1].SceneID + '').to.equal('2');
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneName).to.equal('pester');
                expect(body.Result[ALMOND_MAC].Scenes[1].hasOwnProperty('SceneEntryList')).to.equal(true);
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneEntryList[0].ID + '').to.equal('0');
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneEntryList[0].Index + '').to.equal('1');
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneEntryList[0].Value + '').to.equal('home');
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneEntryList[0].Valid + '').to.equal('true');
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneEntryList[1].ID + '').to.equal('2');
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneEntryList[1].Index + '').to.equal('2');
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneEntryList[1].Value + '').to.equal('Auto');
                expect(body.Result[ALMOND_MAC].Scenes[1].SceneEntryList[1].Valid + '').to.equal('true');
                done();
            });
        });
        it('GetAllClients test', function (done) {
            this.timeout(5000);
            var options = {
                method: 'GET',
                url: URL + '/GetAllClients',
                headers: {
                    'content-type': TYPE_X,
                    authorization: AUTH
                }
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                body = JSON.parse(body);
                expect(body.success + '').to.equal('true');
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty(ALMOND_MAC)).to.equal(true);
                expect(body.Result[ALMOND_MAC].status).to.equal('1');
                expect(body.Result[ALMOND_MAC].name).to.equal(ALMOND_NAME);
                expect(body.Result[ALMOND_MAC].version).to.equal(ALMOND_VERSION);
                expect(body.Result[ALMOND_MAC].hasOwnProperty('Clients')).to.equal(true);
                body.Result[ALMOND_MAC].Clients = sortByKey(body.Result[ALMOND_MAC].Clients, 'ClientID');
                expect(body.Result[ALMOND_MAC].Clients[0].ClientID + '').to.equal('2');
                expect(body.Result[ALMOND_MAC].Clients[0].hasOwnProperty('ClientDetails')).to.equal(true);
                expect(body.Result[ALMOND_MAC].Clients[0].ClientDetails.Block + '').to.equal('0');
                expect(body.Result[ALMOND_MAC].Clients[0].ClientDetails.CanBlock + '').to.equal('true');
                expect(body.Result[ALMOND_MAC].Clients[0].ClientDetails.Category + '').to.equal('others');
                expect(body.Result[ALMOND_MAC].Clients[0].ClientDetails.Name + '').to.equal('second');
                expect(body.Result[ALMOND_MAC].Clients[0].ClientDetails.MAC + '').to.equal('40:8d:5c:d2:78:64');
                done();
            });
        });
        it('GetAllDevices test', function (done) {
            this.timeout(5000);
            var options = {
                method: 'GET',
                url: URL + '/GetAllDevices',
                headers: {
                    'content-type': TYPE_X,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                }
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                body = JSON.parse(body);
                expect(body.success + '').to.equal('true');
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty(ALMOND_MAC)).to.equal(true);
                expect(body.Result[ALMOND_MAC].status).to.equal('1');
                expect(body.Result[ALMOND_MAC].name).to.equal(ALMOND_NAME);
                expect(body.Result[ALMOND_MAC].version).to.equal(ALMOND_VERSION);
                expect(body.Result[ALMOND_MAC].hasOwnProperty('Devices')).to.equal(true);
                body.Result[ALMOND_MAC].Devices = sortByKey(body.Result[ALMOND_MAC].Devices, 'DeviceID');
                expect(body.Result[ALMOND_MAC].Devices[0].DeviceID + '').to.equal('1');
                expect(body.Result[ALMOND_MAC].Devices[0].DeviceName + '').to.equal('first thermostat');
                expect(body.Result[ALMOND_MAC].Devices[0].DeviceType + '').to.equal('7');
                expect(body.Result[ALMOND_MAC].Devices[0].AssociationTimeStamp + '').to.equal('null');
                expect(body.Result[ALMOND_MAC].Devices[1].DeviceID + '').to.equal('2');
                expect(body.Result[ALMOND_MAC].Devices[1].DeviceName + '').to.equal('main table light');
                expect(body.Result[ALMOND_MAC].Devices[1].DeviceType + '').to.equal('4');
                expect(body.Result[ALMOND_MAC].Devices[1].AssociationTimeStamp + '').to.equal('null')
                done();
            });
        });
        it('GetScenes test', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/GetScenes',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    "Hub": {
                        "HubMAC": ALMOND_MAC
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.CommandType).to.equal('SceneList');
                expect(body.Success).to.equal(true);
                expect(body.Reason).to.equal(null);
                expect(body.AlmondMAC + '').to.equal(ALMOND_MAC);
                expect(body.hasOwnProperty('Scenes')).to.equal(true);
                expect(body.Scenes.hasOwnProperty('1')).to.equal(true);
                expect(body.Scenes['1'].ID + '').to.equal('1');
                expect(body.Scenes['1'].Name).to.equal('tester');
                expect(body.Scenes['1'].Active).to.equal('false');
                expect(body.Scenes['1'].SceneEntryList[0].ID).to.equal('0');
                expect(body.Scenes['1'].SceneEntryList[0].Index).to.equal('1');
                expect(body.Scenes['1'].SceneEntryList[0].Value).to.equal('home');
                expect(body.Scenes['1'].SceneEntryList[0].Valid).to.equal('true');
                expect(body.Scenes['1'].SceneEntryList[1].ID).to.equal('2');
                expect(body.Scenes['1'].SceneEntryList[1].Index).to.equal('2');
                expect(body.Scenes['1'].SceneEntryList[1].Value).to.equal('Off');
                expect(body.Scenes['1'].SceneEntryList[1].Valid).to.equal('true');
                expect(body.Scenes.hasOwnProperty('2')).to.equal(true);
                expect(body.Scenes['2'].ID + '').to.equal('2');
                expect(body.Scenes['2'].Name).to.equal('pester');
                expect(body.Scenes['2'].Active).to.equal('false');
                expect(body.Scenes['2'].SceneEntryList[0].ID).to.equal('0');
                expect(body.Scenes['2'].SceneEntryList[0].Index).to.equal('1');
                expect(body.Scenes['2'].SceneEntryList[0].Value).to.equal('home');
                expect(body.Scenes['2'].SceneEntryList[0].Valid).to.equal('true');
                expect(body.Scenes['2'].SceneEntryList[1].ID).to.equal('2');
                expect(body.Scenes['2'].SceneEntryList[1].Index).to.equal('2');
                expect(body.Scenes['2'].SceneEntryList[1].Value).to.equal('Auto');
                expect(body.Scenes['2'].SceneEntryList[1].Valid).to.equal('true');
                done();
            });
        });
        it('GetClients test', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/GetClients',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    "Hub": {
                        "HubMAC": ALMOND_MAC
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.CommandType).to.equal('ClientsList');
                expect(body.Success).to.equal(true);
                expect(body.Reason).to.equal(null);
                expect(body.AlmondMAC + '').to.equal(ALMOND_MAC);
                expect(body.hasOwnProperty('Clients')).to.equal(true);
                expect(body.Clients.hasOwnProperty('2')).to.equal(true);
                expect(body.Clients['2'].Name).to.equal('second');
                expect(body.Clients['2'].MAC).to.equal('40:8d:5c:d2:78:64');
                expect(body.Clients['2'].Block).to.equal('0');
                expect(body.Clients['2'].CanBlock).to.equal('true');
                expect(body.Clients['2'].Category).to.equal('others');
                done();
            });
        });
        it('GetDeviceData test', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/GetDeviceData',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    "Hub": {
                        "HubMAC": ALMOND_MAC
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.CommandType).to.equal('DeviceList');
                expect(body.Success).to.equal(true);
                expect(body.Reason).to.equal(null);
                expect(body.AlmondMAC + '').to.equal(ALMOND_MAC);
                expect(body.hasOwnProperty('Devices')).to.equal(true);
                expect(body.Devices.hasOwnProperty('1')).to.equal(true);
                expect(body.Devices['1'].Data.Type + '').to.equal('7');
                expect(body.Devices['1'].Data.Name + '').to.equal('first thermostat');
                expect(body.Devices['1'].Data.ID + '').to.equal('1');
                expect(body.Devices.hasOwnProperty('2')).to.equal(true);
                expect(body.Devices['2'].Data.Type + '').to.equal('4');
                expect(body.Devices['2'].Data.Name + '').to.equal('main table light');
                expect(body.Devices['2'].Data.ID + '').to.equal('2');
                done();
            });
        });
    });

    describe('Device Update Tests : ', function () {
        it('case where device value gets successfully updated', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateDeviceIndex',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'Update': [{
                            'AlmondMAC': ALMOND_MAC,
                            'ID': 2,
                            'Index': 2,
                            'Value': 'Cool'
                        }]
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body));
                expect(body.success).to.equal(true);
                expect(body.Result[0].success).to.equal(true);
                expect(body.Result[0].AlmondMAC).to.equal(ALMOND_MAC);
                expect(body.Result[0].ID + '').to.equal('2');
                expect(body.Result[0].Index + '').to.equal('2');
                expect(body.Result[0].Value).to.equal('Cool');
                expect(body.Result[0].success + '').to.equal('true');
                done();
            });
        });
        it('case where we try to update device value with its actual value', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateDeviceIndex',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'Update': [{
                            'AlmondMAC': ALMOND_MAC,
                            'ID': 2,
                            'Index': 2,
                            'Value': 'Cool'
                        }]
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body));
                expect(body.success + '').to.equal('true');
                expect(body.Result[0].AlmondMAC + '').to.equal(ALMOND_MAC);
                expect(body.Result[0].ID + '').to.equal('2');
                expect(body.Result[0].Index + '').to.equal('2');
                expect(body.Result[0].Value).to.equal('Cool');
                expect(body.Result[0].success + '').to.equal('false');
                expect(body.Result[0].reason).to.equal('Same Value Received');
                done();
            });
        });
        it.skip('case where the almond has no access to the device anymore', function (done) {// NEW
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateDeviceIndex',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {'Update': [
                        {
                            'AlmondMAC': '251176217032936',
                            'ID': 7,
                            'Index': 1,
                            'Value': '90'
                        }
                    ]},
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                expect(body.Result[0].success).to.equal(false);
                done();
            });
        });
    });

    describe('ClientUpdate tests : ', function () {
        it('case where client is updated successfully', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/UpdateClient',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'Update': [{
                            'AlmondMAC': ALMOND_MAC,
                            'Clients': {
                                'ID': 2,
                                'Block': 1
                            }
                        }]
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body));
                expect(body.success + '').to.equal('true');
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result[0].success + '').to.equal('true');
                expect(body.Result[0].AlmondMAC + '').to.equal(ALMOND_MAC);
                expect(body.Result[0].hasOwnProperty('Clients')).to.equal(true);
                expect(body.Result[0].Clients.ID + '').to.equal('2');
                expect(body.Result[0].Clients.Block + '').to.equal('1');
                done();
            });
        });
    });

    describe('ChangeMode tests : ', function () {
        it('case where mode is updated successfully', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/ChangeMode',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'mode': 2
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                done();
            });
        });
        it('case where mode is updated successfully', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/ChangeMode',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'mode': 1
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                done();
            });
        });
    });

    describe('ActivateScene tests : ', function () {
        it('case where Scene gets successfully activated', function (done) {
            this.timeout(10000);
            var options = {
                method: 'POST',
                url: URL + '/ActivateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'Scenes': {
                        'ID': '1'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body))
                expect(body.success + '').to.equal('true');
                expect(body.reason).to.equal('Scene Activation Successful');
                done();
            });
        });
        it('case where scene is already activated', function (done) {
            this.timeout(10000);
            var options = {
                method: 'POST',
                url: URL + '/ActivateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'Scenes': {
                        'ID': '1'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                console.log(JSON.stringify(body))
                expect(body.success).to.equal(false);
                expect(body.success + '').to.equal('false');
                expect(body.ReasonCode).to.equal('33');
                expect(body.reason).to.equal('Scene Already Activated');
                done();
            });
        });
        it('case where almond is offline', function (done) {// NEW
            var options = {
                method: 'POST',
                url: URL + '/ActivateScene',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': '251176217032936',
                    'Scenes': {
                        'ID': '2'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                expect(response.statusCode).to.equal(200);
                expect(body.success).to.equal(false);
                done();
            });
        });
    });

    describe('EnableGuestNetwork tests : ', function () {
        it('case where AP2 Guest network is enabled successfully', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/EnableGuestNetwork',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'WirelessSetting': {
                        'Type': 'Guest2G&Guest5G',
                        'Enabled': 'true'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                expect(body.emailId).to.equal(Almond1.EmailID);
                expect(body.hasOwnProperty('Payload')).to.equal(true);
                expect(body.Payload.CommandType).to.equal('SetWirelessSettings');
                expect(body.Payload.Uptime).to.equal('1100086');
                expect(body.Payload.hasOwnProperty('WirelessSetting')).to.equal(true);
                body.Payload.WirelessSetting = sortByKey(body.Payload.WirelessSetting, 'Type');
                expect(body.Payload.WirelessSetting[0].Type).to.equal('Guest2G');
                expect(body.Payload.WirelessSetting[0].Enabled).to.equal('true');
                expect(body.Payload.WirelessSetting[0].SSID).to.equal('Guest-2.4GHz');
                expect(body.Payload.WirelessSetting[0].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Success + '').to.equal('true');
                expect(body.Payload.WirelessSetting[1].Type).to.equal('Guest5G');
                expect(body.Payload.WirelessSetting[1].Enabled).to.equal('true');
                expect(body.Payload.WirelessSetting[1].SSID).to.equal('Guest-5GHz');
                expect(body.Payload.WirelessSetting[1].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[1].Success + '').to.equal('true');
                done();
            });
        });
        it('case where AP2 Guest network is already enabled', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/EnableGuestNetwork',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'WirelessSetting': {
                        'Type': 'Guest2G&Guest5G',
                        'Enabled': 'true'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                expect(body.emailId).to.equal(Almond1.EmailID);
                expect(body.hasOwnProperty('Payload')).to.equal(true);
                expect(body.Payload.CommandType).to.equal('SetWirelessSettings');
                expect(body.Payload.Uptime).to.equal('1100086');
                expect(body.Payload.hasOwnProperty('WirelessSetting')).to.equal(true);
                body.Payload.WirelessSetting = sortByKey(body.Payload.WirelessSetting, 'Type');
                expect(body.Payload.WirelessSetting[0].Type).to.equal('Guest2G');
                expect(body.Payload.WirelessSetting[0].Enabled).to.equal('true');
                expect(body.Payload.WirelessSetting[0].SSID).to.equal('Guest-2.4GHz');
                expect(body.Payload.WirelessSetting[0].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Success + '').to.equal('false');
                expect(body.Payload.WirelessSetting[0].Reason + '').to.equal('enable is same');
                expect(body.Payload.WirelessSetting[1].Type).to.equal('Guest5G');
                expect(body.Payload.WirelessSetting[1].Enabled).to.equal('true');
                expect(body.Payload.WirelessSetting[1].SSID).to.equal('Guest-5GHz');
                expect(body.Payload.WirelessSetting[1].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[1].Success + '').to.equal('false');
                expect(body.Payload.WirelessSetting[1].Reason + '').to.equal('enable is same');
                done();
            });
        });
        it('case where AP2 Guest network is disabled successfully', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/EnableGuestNetwork',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'WirelessSetting': {
                        'Type': 'Guest2G&Guest5G',
                        'Enabled': 'false'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                expect(body.emailId).to.equal(Almond1.EmailID);
                expect(body.hasOwnProperty('Payload')).to.equal(true);
                expect(body.Payload.CommandType).to.equal('SetWirelessSettings');
                expect(body.Payload.Uptime).to.equal('1100086');
                expect(body.Payload.hasOwnProperty('WirelessSetting')).to.equal(true);
                body.Payload.WirelessSetting = sortByKey(body.Payload.WirelessSetting, 'Type');
                expect(body.Payload.WirelessSetting[0].Type).to.equal('Guest2G');
                expect(body.Payload.WirelessSetting[0].Enabled).to.equal('false');
                expect(body.Payload.WirelessSetting[0].SSID).to.equal('Guest-2.4GHz');
                expect(body.Payload.WirelessSetting[0].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Success + '').to.equal('true');
                expect(body.Payload.WirelessSetting[1].Type).to.equal('Guest5G');
                expect(body.Payload.WirelessSetting[1].Enabled).to.equal('false');
                expect(body.Payload.WirelessSetting[1].SSID).to.equal('Guest-5GHz');
                expect(body.Payload.WirelessSetting[1].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[1].Success + '').to.equal('true');
                done();
            });
        });
        it('case where AP2 Guest network is already disabled', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/EnableGuestNetwork',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'WirelessSetting': {
                        'Type': 'Guest2G&Guest5G',
                        'Enabled': 'false'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                expect(body.emailId).to.equal(Almond1.EmailID);
                expect(body.hasOwnProperty('Payload')).to.equal(true);
                expect(body.Payload.CommandType).to.equal('SetWirelessSettings');
                expect(body.Payload.Uptime).to.equal('1100086');
                expect(body.Payload.hasOwnProperty('WirelessSetting')).to.equal(true);
                body.Payload.WirelessSetting = sortByKey(body.Payload.WirelessSetting, 'Type');
                expect(body.Payload.WirelessSetting[0].Type).to.equal('Guest2G');
                expect(body.Payload.WirelessSetting[0].Enabled).to.equal('false');
                expect(body.Payload.WirelessSetting[0].SSID).to.equal('Guest-2.4GHz');
                expect(body.Payload.WirelessSetting[0].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Success + '').to.equal('false');
                expect(body.Payload.WirelessSetting[0].Reason + '').to.equal('enable is same');
                expect(body.Payload.WirelessSetting[1].Type).to.equal('Guest5G');
                expect(body.Payload.WirelessSetting[1].Enabled).to.equal('false');
                expect(body.Payload.WirelessSetting[1].SSID).to.equal('Guest-5GHz');
                expect(body.Payload.WirelessSetting[1].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[1].Success + '').to.equal('false');
                expect(body.Payload.WirelessSetting[1].Reason + '').to.equal('enable is same');
                done();
            });
        });
        it('case where AL2 Guest network is enabled successfully', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/EnableGuestNetwork',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'WirelessSetting': {
                        'Type': 'Guest2G',
                        'Enabled': 'true'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                expect(body.emailId).to.equal(Almond1.EmailID);
                expect(body.hasOwnProperty('Payload')).to.equal(true);
                expect(body.Payload.CommandType).to.equal('SetWirelessSettings');
                expect(body.Payload.Uptime).to.equal('1100086');
                expect(body.Payload.hasOwnProperty('WirelessSetting')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Type).to.equal('Guest2G');
                expect(body.Payload.WirelessSetting[0].Enabled).to.equal('true');
                expect(body.Payload.WirelessSetting[0].SSID).to.equal('Guest-2.4GHz');
                expect(body.Payload.WirelessSetting[0].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Success + '').to.equal('true');
                done();
            });
        });
        it('case where AL2 Guest network is already enabled', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/EnableGuestNetwork',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'WirelessSetting': {
                        'Type': 'Guest2G',
                        'Enabled': 'true'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                expect(body.emailId).to.equal(Almond1.EmailID);
                expect(body.hasOwnProperty('Payload')).to.equal(true);
                expect(body.Payload.CommandType).to.equal('SetWirelessSettings');
                expect(body.Payload.Uptime).to.equal('1100086');
                expect(body.Payload.hasOwnProperty('WirelessSetting')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Type).to.equal('Guest2G');
                expect(body.Payload.WirelessSetting[0].SSID).to.equal('Guest-2.4GHz');
                expect(body.Payload.WirelessSetting[0].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Success + '').to.equal('false');
                expect(body.Payload.WirelessSetting[0].Reason + '').to.equal('Enable is same');
                done();
            });
        });
        it('case where AL2 Guest network is disabled successfully', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/EnableGuestNetwork',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'WirelessSetting': {
                        'Type': 'Guest2G',
                        'Enabled': 'false'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                expect(body.emailId).to.equal(Almond1.EmailID);
                expect(body.hasOwnProperty('Payload')).to.equal(true);
                expect(body.Payload.CommandType).to.equal('SetWirelessSettings');
                expect(body.Payload.Uptime).to.equal('1100086');
                expect(body.Payload.hasOwnProperty('WirelessSetting')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Type).to.equal('Guest2G');
                expect(body.Payload.WirelessSetting[0].Enabled).to.equal('false');
                expect(body.Payload.WirelessSetting[0].SSID).to.equal('Guest-2.4GHz');
                expect(body.Payload.WirelessSetting[0].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Success + '').to.equal('true');
                done();
            });
        });
        it('case where AL2 Guest network is already disabled', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/EnableGuestNetwork',
                headers: {
                    'content-type': TYPE_JSON,
                    'postman-token': '592ffc4a-9af5-cb4d-043b-50f138c50cf4',
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'AlmondMAC': ALMOND_MAC,
                    'WirelessSetting': {
                        'Type': 'Guest2G',
                        'Enabled': 'false'
                    }
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(JSON.stringify(body));
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                expect(body.emailId).to.equal(Almond1.EmailID);
                expect(body.hasOwnProperty('Payload')).to.equal(true);
                expect(body.Payload.CommandType).to.equal('SetWirelessSettings');
                expect(body.Payload.Uptime).to.equal('1100086');
                expect(body.Payload.hasOwnProperty('WirelessSetting')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Type).to.equal('Guest2G');
                expect(body.Payload.WirelessSetting[0].SSID).to.equal('Guest-2.4GHz');
                expect(body.Payload.WirelessSetting[0].hasOwnProperty('Password')).to.equal(true);
                expect(body.Payload.WirelessSetting[0].Success + '').to.equal('false');
                expect(body.Payload.WirelessSetting[0].Reason + '').to.equal('Enable is same');
                done();
            });
        });
    });

    describe('Tests for getAccessToken : ', function () {
        var code = '123457';
        before(function (done) {
            this.timeout(5000);
            redisConn.query('hmset', "accessCode:"+code, ['authCode', code, 'clientId', "amazon-echo", 'userId', userID, 'email', EMAIL, 'expires', '1499788956'], function () {
                done();
            });
        });
        it(' bearerTest POST GetAccessToken', function (done) {// NEW
            this.timeout(5000);
            console.log("Before making a request ..");
            var options = {
                method: 'POST',
                url: URL + '/GetAccessToken',
                headers: {
                    'content-type': TYPE_X,
                    authorization: AUTH
                },
                form: {
                    'grant_type':'authorization_code',
                    'client_id':'amazon-echo',
                    'client_secret':'_8nL&KdM$8qGxF&s',
                    'code': code
                }
            };
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                console.log(response.statusCode);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                assert.equal(JSON.parse(body).token_type, 'bearer', 'token_type is not bearer type');
                assert.isAbove(JSON.parse(body).access_token.indexOf(userID), -1, 'userID not found in access_token');
                //assert(response.statusCode == 556); 
                done();
            });
        });
        it(' bearerTest POST GetAccessCode', function (done) {// NEW
            this.timeout(5000);
            console.log("Before making a request ..");
            var options = {
                method: 'POST',
                url: URL + '/GetAccessCode',
                headers: {
                    'content-type': TYPE_X,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    'user': EMAIL,
                    'password': PASSWORD,
                    'response_type': 'code',
                    'client_id': 'securifi_android_mobile_app',
                    'client_secret': '.ncrZ~3-(4Vw(73Z',
                    'redirect_uri': 'https://connect.securifi.com'
                },
                json: true
            };
            request(options, function (error, response, body) {
                console.log(error);
//                if (error)
//                    throw new Error(error);
                console.log(response.statusCode);
                console.log(body);
                console.log(response.headers);
                expect(response.headers.location.indexOf('https://connect.securifi.com')).to.equal(0); // redirected URL
                expect(response.statusCode).to.equal(302); //URL redirection status code
                done();
            });
        });
    });

    describe('Tests for MAC recent activity ', function () {
        before(function (done) {
            this.timeout(15000);
            clearDB(ALMOND_MAC, function (err) {
                if (err)
                    return done(err);
                createDB(done);
            });
        });
        it('bearerTest get RecentActivity no mac', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/RecentActivity',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {},
                json: true
            };
            console.log("Before making a request ..");
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                console.log(response.statusCode);
                console.log('body---------', body);
                expect(response.statusCode).to.equal(556);
                expect(body.success + '').to.equal('false');
                expect(body.reason).to.equal('Insufficient Data');
                done();
            });
        });
        it('bearerTest get RecentActivity with mac', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/RecentActivity',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    mac: ALMOND_MAC,
                    type: 'all'
                },
                json: true
            };
            console.log("Before making a request ..");
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                //console.log(response.statusCode);
                //console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
                expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
                expect(body.Result.hasOwnProperty('logs')).to.equal(true);

                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.include(devIdArr.concat(cliIdArr), parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.include(["client value", "device value"], body.Result.logs[0].value, 'value mismatch');
                done();
            });
        });
        it('bearerTest get RecentActivity for only Devices', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/RecentActivity',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    mac: ALMOND_MAC,
                    type: 'device'
                },
                json: true
            };
            console.log("Before making a request ..");
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                //console.log(response.statusCode);
                //console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
                expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
                expect(body.Result.hasOwnProperty('logs')).to.equal(true);

                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.include(devIdArr, parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("device value", body.Result.logs[0].value, 'value mismatch');
                done();
            });
        });
        it('bearerTest get RecentActivity for only Clients', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/RecentActivity',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    mac: ALMOND_MAC,
                    type: 'client'
                },
                json: true
            };
            console.log("Before making a request ..");
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                //console.log(response.statusCode);
                //console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
                expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
                expect(body.Result.hasOwnProperty('logs')).to.equal(true);

                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.include(cliIdArr, parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("client value", body.Result.logs[0].value, 'value mismatch');
                done();
            });
        });
        it('bearerTest get RecentActivity for specific device', function (done) {
            this.timeout(5000);
            var options = {
                method: 'POST',
                url: URL + '/RecentActivity',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    mac: ALMOND_MAC,
                    type: 'device',
                    id:devIdArr[0].toString()
                },
                json: true
            };
            console.log("Before making a request ..");
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                //console.log(response.statusCode);
                //console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
                expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
                expect(body.Result.hasOwnProperty('logs')).to.equal(true);

//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
//                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.equal(devIdArr[0], parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("device value", body.Result.logs[0].value, 'value mismatch');
                done();
            });
        });
        it('bearerTest get RecentActivity for specific client', function (done) {
            this.timeout(5000);
            
            var options = {
                method: 'POST',
                url: URL + '/RecentActivity',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    mac: ALMOND_MAC,
                    type: 'client',
                    id:'b9:1c:57' // hex format cliIdArr[0]
                },
                json: true
            };
            console.log("Before making a request ..");
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                //console.log(response.statusCode);
                //console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
                expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
                expect(body.Result.hasOwnProperty('logs')).to.equal(true);

//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
//                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.equal(cliIdArr[0], parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("client value", body.Result.logs[0].value, 'value mismatch');
                done();
            });
        });
        it('bearerTest get RecentActivity for multiple devices', function (done) {
            this.timeout(5000);
            var devIds = devIdArr.join();
            var options = {
                method: 'POST',
                url: URL + '/RecentActivity',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    mac: ALMOND_MAC,
                    type: 'device',
                    id: devIds // hex format cliIdArr[0]
                },
                json: true
            };
            console.log("Before making a request ..");
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                //console.log(response.statusCode);
                //console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
                expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
                expect(body.Result.hasOwnProperty('logs')).to.equal(true);

//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
//                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.include(devIds, parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("device value", body.Result.logs[0].value, 'value mismatch');
                done();
            });
        });
        it('bearerTest get RecentActivity for multiple clients', function (done) {
            this.timeout(5000);
            var cliIds = ['b9:1c:57','b9:1c:58','b9:1c:59'];
            var options = {
                method: 'POST',
                url: URL + '/RecentActivity',
                headers: {
                    'content-type': TYPE_JSON,
                    'cache-control': 'no-cache',
                    authorization: AUTH
                },
                body: {
                    mac: ALMOND_MAC,
                    type: 'client',
                    id: cliIds.join() // hex format cliIdArr[0]
                },
                json: true
            };
            console.log("Before making a request ..");
            request(options, function (error, response, body) {
                if (error)
                    throw new Error(error);
                //console.log(response.statusCode);
                //console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.hasOwnProperty('Result')).to.equal(true);
                expect(body.Result.hasOwnProperty('dateyear')).to.equal(true);
                expect(body.Result.hasOwnProperty('pageState')).to.equal(true);
                expect(body.Result.hasOwnProperty('logs')).to.equal(true);

//                assert.isBelow(body.Result.dateyear, CURR_DATE, 'dateyear not below the current date'); // max records per day are 20 only according to createDB() here.
//                assert.notDeepEqual(body.Result.pageState, null, 'pageState failed');
                assert.deepEqual(body.Result.logs.length, 50, 'Failed at record count'); //  fetchSize = 50
                assert.equal(body.Result.logs[0].mac, ALMOND_MAC, 'MAC mismatch');
                assert.include(cliIdArr, parseInt(body.Result.logs[0].id), 'ID mismatch');
                assert.include([1, 123456], parseInt(body.Result.logs[0].index_id), 'index_id mismatch');
                assert.include(["20", "30"], body.Result.logs[0].type, 'type mismatch');
                assert.include(["755624541"], body.Result.logs[0].userid, 'userid mismatch');
                assert.equal("client value", body.Result.logs[0].value, 'value mismatch');
                done();
            });
        });
    });

    after(function (done) {
        this.timeout(15000);
        var options = {
            method: 'POST',
            url: URL + '/Logout',
            headers: {
                'authorization': 'Bearer ' + AUTH,
                'content-type': TYPE_JSON
            },
            body: {
                'userID': userID,
                'tempPass': tempPass
            },
            json: true
        };
        request(options, function (err, res, body) {
            if (err)
                done(err);
            Almond1.link = false;
            Affiliation(Almond1, function (unlinked) {
                // if(!unlinked) done(new Error('Error during unlinking 1'));
                almond.killConnection();
                dbmodifier.deleteUser(Almond1.EmailID, function (err, rows) {
                    if (err)
                        done(err);
                    dbmodifier.deleteAlmond(Almond1.almondMAC, function (err, rows) {
                        if (err)
                            done(err);
                        done();
                    });
                });
            });
        });
    });
});


describe.skip('test where Client list is empty but user has an almond', function () {
    before(function (done) {
        this.timeout(10000);
        dbmodifier.deleteUser(Almond1.EmailID, function (err, rows) {
            if (err)
                done(err);
            dbmodifier.deleteAlmond(Almond1.almondMAC, function (err, rows) {
                if (err)
                    done(err);
                console.log('done');//done();
                dbmodifier.createUser(Almond1.EmailID, Almond1.password, function (err, rows) {
                    if (err)
                        done(err);
                    dbmodifier.createAlmond(Almond1.almondMAC, '$2a$10$L3Iy8lHAxT6l0gr2V1eynOfFLOzfkte1zXOgN6gK4X1tEaZShDEx2', Almond1.AlmondName, Almond1.longSecret, Almond1.firmwareVersion, function (err, rows) {
                        if (err)
                            done(err);
                        Affiliation(Almond1, function (linked) {
                            var param = clone(Almond1);
                            var confs = require('./TestConfigs/test1.json');
                            param.devices = {};
                            param.scenes = {};
                            param.wifiClients = {};
                            param.rules = {};
                            almond = new Almond(param);
                            almond.on('cloudconnected', function () {
                                var options = {
                                    method: 'POST',
                                    url: URL + '/Login',
                                    headers: {
                                        'authorization': 'Bearer ',
                                        'content-type': TYPE_JSON
                                    },
                                    body: {
                                        'emailID': Almond1.EmailID,
                                        'password': Almond1.password
                                    },
                                    json: true
                                };
                                request(options, function (err, res, body) {
                                    if (err)
                                        done(err);
                                    AUTH = AUTH + body.tempPass + ':' + body.userID;
                                    userID = body.userID;
                                    tempPass = body.tempPass;
                                    console.log("final AUTH: ", AUTH);
                                    done();
                                });
                            });
                        });
                    });
                });
            });
        });

    });
    it('should get an empty Client list', function (done) {
        this.timeout(10000);
        var options = {
            method: 'GET',
            url: URL + '/GetAllClients',
            headers: {
                'content-type': TYPE_X,
                authorization: AUTH
            }
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.success + '').to.equal('true');
            expect(body.hasOwnProperty('Result')).to.equal(true);
            expect(body.Result.hasOwnProperty(ALMOND_MAC)).to.equal(true);
            expect(body.Result[ALMOND_MAC].hasOwnProperty('Clients')).to.equal(true);
            //                expect(body.Result[ALMOND_MAC].status).to.equal('1');
            expect(body.Result[ALMOND_MAC].Clients.length).to.equal(0);
            //                expect(body.Result[ALMOND_MAC].name).to.equal(ALMOND_NAME);
            //                expect(body.Result[ALMOND_MAC].version).to.equal(ALMOND_VERSION);
            done();
        });
    });
    after(function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/Logout',
            headers: {
                'authorization': 'Bearer ' + AUTH,
                'content-type': TYPE_JSON
            },
            body: {
                'userID': userID,
                'tempPass': tempPass
            },
            json: true
        };
        request(options, function (err, res, body) {
            if (err)
                done(err);
            Almond1.link = false;
            Affiliation(Almond1, function (unlinked) {
                // if(!unlinked) done(new Error('Error during unlinking 1'));
                almond.killConnection();
                dbmodifier.deleteUser(Almond1.EmailID, function (err, rows) {
                    if (err)
                        done(err);
                    dbmodifier.deleteAlmond(Almond1.almondMAC, function (err, rows) {
                        if (err)
                            done(err);
                        done();
                    })
                });
            });
        });
    });
});

