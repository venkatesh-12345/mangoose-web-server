var RabbitMQConnector = require('../../rabbitmq/rabbitMQ');
var CP = require('../../database/sql/sqlQuery');
var fs = require('fs');
var parseString = require('xml2js').parseString;
var publisher = require('./responseProducer');
var qConfig =  require('../../config').rabbitmq;
var producerQueue = qConfig.queueName;
var simulatedRes = require('./responseMaker');
var simAlmond = require('../TestConfigs/standaloneEnv');
var simAlmondDB = require('../TestConfigs/test1');
var options = {
    host: 'amqp://127.0.0.1',
    queueName: 'S12',
    maxRetryCount: 3
}
var redis = require('redis')
var redisClient = redis.createClient('6379', '127.0.0.1');

var i = 1;
var Consumer = new RabbitMQConnector(options, 'CONSUMER');
Consumer.on('connected', function() {

    console.log('RabbitMQConnector connected')
    

});
Consumer.on('message', function(msg) {

    console.log('msg****', msg)
    var request = JSON.parse(msg);
    var payload;
    if (request.command != 62&&request.payload)
        payload = JSON.parse(request.payload);
    sendResponseNew(request)
});
var sendResponse = function(queuePayload, request) {
    var payload = {};
    if (request.command == 62) {
        //payload='<root><AlmondModeChangeResponse success="false"><Reason>Almond Mode is wrong</Reason><ReasonCode>1</ReasonCode></AlmondModeChangeResponse></root>'
        //payload='<root><AlmondModeChangeResponse success="true"><Reason>Almond Mode Set Successfully</Reason><ReasonCode>1</ReasonCode></AlmondModeChangeResponse></root>'
        payload = '<root><AlmondNameChangeResponse success="true"><MobileInternalIndex>334</MobileInternalIndex></AlmondNameChangeResponse></root>'
        //payload='<root><AlmondNameChangeResponse success="false"><MobileInternalIndex>334</MobileInternalIndex></AlmondNameChangeResponse></root>'
        return unicast(request, payload, 64)

    }
    if (queuePayload.CommandType == 'UpdateClient')
        payload = { "Success": "true", "ReasonCode": "0" };
    if (queuePayload.CommandType == 'UpdateDeviceIndex') {
    //payload = { "CommandType": "UpdateDeviceIndex", "Success": "true" } //true Case
        payload={CommandType:"UpdateDeviceIndex",Success:"false",Reason:"Same Value Received"}
        //unicast(request, payload1, 1064)
        
        var payload1 = { CommandType: "DynamicIndexUpdated", Action: "UpdateIndex", "HashNow": "fb8095a9a11c9f05c14f4dae0bf7437b", "Devices": { "2": { "DeviceValues": { "10": { "Name": "LED_STATE", "Value": "true", "Type": "94" } } } }, "AlmondMAC": "251176215905521" }
        unicast(request, JSON.stringify(payload1), 1200)
    }
    if (queuePayload.CommandType == 'ActivateScene') {
       // var payload1 = { "CommandType": "DynamicSceneActivated", "Action": "update", "HashNow": "8842eb1c67b95d9dcde7a92fc708eedf", "Scenes": { "2": { "Active": "true", "LastActiveEpoch": "1502884932" } }, "AlmondMAC": request.almondMAC }
        //return unicast(request, JSON.stringify(payload1), 1300)
        payload={"Success":"false","ReasonCode":"33"} //false Case
    }if (request.command == 1100) {
       // var payload1 = { "CommandType": "DynamicSceneActivated", "Action": "update", "HashNow": "8842eb1c67b95d9dcde7a92fc708eedf", "Scenes": { "2": { "Active": "true", "LastActiveEpoch": "1502884932" } }, "AlmondMAC": request.almondMAC }
        //return unicast(request, JSON.stringify(payload1), 1300)
        payload={"Success":"true","ReasonCode":"33"} 
        payload.MobileInternalIndex = queuePayload.MobileInternalIndex;
    return unicast(request, JSON.stringify(payload), 1100)//false Case
    }
    
    payload.MobileInternalIndex = queuePayload.MobileInternalIndex;
    unicast(request, JSON.stringify(payload), 1064)
}

var sendResponseNew = function (request) {
    console.log('--- Got the command ', request.command, ' in consumer simulator ');
    var response = {};
    var estimate = simulatedRes.getProperties();
    switch (request.command) {
        case 62:
            var jsonDoc=undefined;
            parseString(request.payload.toString(), function (err, result) {
                jsonDoc = result;
                if(jsonDoc['root']['AlmondModeChange']){
                    var mode = jsonDoc['root']['AlmondModeChange'][0]['AlmondMode'];
                    var mobileresponse = '<root><AlmondModeChangeResponse success="true"><Reason>Almond Mode Set Successfully</Reason><ReasonCode>1</ReasonCode></AlmondModeChangeResponse></root>';
                    unicast(request, mobileresponse, 64);
                    var AlmondMAC = jsonDoc['root']['AlmondModeChange'][0]['AlmondplusMAC'];
                    var emailID = jsonDoc['root']['AlmondModeChange'][0]['ModeSetBy'];
                    var dynamicResponse = '<root><AlmondplusMAC>' + AlmondMAC + '</AlmondplusMAC><DynamicAlmondMode success="true"><AlmondMode>' + mode + '</AlmondMode><ModeSetBy>' + emailID + '</ModeSetBy></DynamicAlmondMode></root>';
                    unicast(request, dynamicResponse, 154);
                }else{
                    if (estimate.success) {
                        response.commandNumber = 64;
                        response.payload = '<root><AlmondNameChangeResponse success="true"><MobileInternalIndex>675</MobileInternalIndex></AlmondNameChangeResponse></root>';
                    }
                    unicast(request, JSON.stringify(response.payload), response.commandNumber);
                }
                
            });
            break;
        case 1062:
        {
            console.log('Got 1062 command in Consumer simulator ');
            var jsonPacket = JSON.parse(request.payload.toString());
            switch (jsonPacket['CommandType']) {
                case "UpdateClient":
                {
                    console.log('------- UpdateClient 1062 ----------');
                    if (estimate.success) {
                        response.commandNumber = 1064;
                        response.payload = {CommandType:jsonPacket['CommandType'], Success:"true", "MobileInternalIndex": jsonPacket['MobileInternalIndex']};
                        unicast(request, JSON.stringify(response.payload), 1064);
                        response.commandNumber = 1500;
                        var clientID = jsonPacket.Clients.ID;
                        response.payload = {"CommandType":"DynamicClientUpdated","Action":"update","Clients":{},"HashNow":"ab2055f1b6e5c926444b2020ff29b218"};
                        response.payload.Clients[clientID] = {"Name":"android-a67d5bcTest", "Connection":"wireless", "MAC":"98:0c:a5:90:36:4c", "Type":"smartphone", "LastKnownIP":"192.168.1.102", "Active":"false", "UseAsPresence":"true", "LastActiveEpoch":"4260", "Wait":"6", "Block":"1", "Schedule":"0,0,0,0,0,0,0", "Manufacturer":"Motorola (Wuhan) ", "RSSI":"-73", "ForceInActive":"0", "CanBlock":"true", "Category":"Others", "SMEnable":"false", "BWEnable":"false", "IOTEnable":"true", "DNSEnable":"true", "Security":"0"}
                    } else {
                        response.commandNumber = 1064;
                        response.payload = {CommandType:jsonPacket['CommandType'], Success:"false", "MobileInternalIndex": jsonPacket['MobileInternalIndex']};
                    }
                    break;
                }
                case "UpdateDeviceIndex":
                {   console.log('----------- UpdateDeviceIndex -------------');
                    setTimeout(function(){
                        if(estimate.success) {
                                response.commandNumber = 1064;
                                response.payload = {CommandType:jsonPacket['CommandType'], Success:"true", "MobileInternalIndex": jsonPacket['MobileInternalIndex']};
                                if (estimate.dynamic) {
                                    unicast(request, JSON.stringify(response.payload), response.commandNumber);
                                    response.commandNumber = 1200;
                                    var devID = estimate.sameDynamic ? jsonPacket.ID : jsonPacket.ID + 3;
                                    var indexID = jsonPacket.Index;
                                    response.payload = {"CommandType": "DynamicIndexUpdated", "Action": "UpdateIndex", "HashNow": "123456789", "Devices": {}};
                                    response.payload.Devices[devID] = {"DeviceValues": {}};
                                    response.payload.Devices[devID].DeviceValues[indexID] = {"Name": "SWITCH BINARY", "Value": jsonPacket.Value, Type: ""};
                                }
                        } else {
                            response.commandNumber = 1064;
                            response.payload = {CommandType:jsonPacket['CommandType'], Success:"false", "MobileInternalIndex": jsonPacket['MobileInternalIndex'], Reason: estimate.reason};
                            
                        }
                    },2000+(Math.floor(Math.random()*5))*1000);
                    break;
                }
                case "UpdateScene":
                {
                    if (estimate.success) {
                        response.commandNumber = 1064;
                        response.payload = {CommandType:jsonPacket['CommandType'], Success:"true", "MobileInternalIndex": jsonPacket['MobileInternalIndex']};
                        if (estimate.dynamic) {
                            unicast(request, JSON.stringify(response.payload), response.commandNumber);
                            response.commandNumber = 1300;
                            var sceneID = estimate.sameDynamic ? jsonPacket.Scenes.ID : jsonPacket.Scenes.ID+2;
                            var sceneName = jsonPacket.Scenes.Name;
                            response.payload = {"CommandType": "DynamicSceneUpdated", "Action": "update", "HashNow": "123456789", "Scenes": {}};
                            response.payload.Scenes[sceneID] = {Name:sceneName, Active: "true", VoiceCompatible: "false", SceneEntryList: [{"ID":"0","Index":"1","Valid":"true","Value":"home"},{"ID":"2","Index":"1","Valid":"true","Value":"false"}]};
                            
                        }
                    } else {
                        response.commandNumber = 1064;
                        response.payload = {CommandType:jsonPacket['CommandType'], Success:"false", "MobileInternalIndex": jsonPacket['MobileInternalIndex'], Reason: estimate.reason};
                        
                    }
                    break;
                }
                case "ActivateScene":
                {
                    if (estimate.success) {
                        response.commandNumber = 1064;
                        response.payload = {CommandType:jsonPacket['CommandType'], Success:"true", "MobileInternalIndex": jsonPacket['MobileInternalIndex']};
                        if (estimate.dynamic) {
                            unicast(request, JSON.stringify(response.payload), response.commandNumber);
                            response.commandNumber = 1300;
                            var sceneID = estimate.sameDynamic ? jsonPacket.Scenes.ID : jsonPacket.Scenes.ID+2;
                            var sceneName = jsonPacket.Scenes.Name;
                            response.payload = {"CommandType": "DynamicSceneActivated", "Action": "update", "HashNow": "123456789", "Scenes": {}};
                            response.payload.Scenes[sceneID] = {Active: "true", "LastActiveEpoch":"1505298213"};
                            
                        }
                    } else {
                        response.commandNumber = 1064;
                        response.payload = {CommandType:jsonPacket['CommandType'], Success:"false", "MobileInternalIndex": jsonPacket['MobileInternalIndex'], Reason: estimate.reason, ReasonCode: estimate.reasonCode};
                        
                    }
                    break;
                }
                case "ChangeAlmondName":
                {
                    if (estimate.success) {
                        response.commandNumber = 1064;
                        response.payload = {CommandType:jsonPacket['CommandType'], Success:"true", "MobileInternalIndex": jsonPacket['MobileInternalIndex']};
                    }
                }
                    break;
                default:
                    
                    break;
            }
            break;
        }
        case 1100:
        {
            var jsonPacket = JSON.parse(request.payload.toString());
            //var CID = packet.ICID;
            
            response.commandNumber = 1100;
            switch (jsonPacket['CommandType']) {
                case 'RouterSummary':
                    if (estimate.success) {
                        response.payload = {"CommandType": "RouterSummary", "AppID": "1001", "Success": "true", "WirelessSetting": [{"Type": "5G", "Enabled": "false", "SSID": "Apple Network 04a3ad_almond"}, {"Type": "2G", "Enabled": "true", "SSID": "Apple Network 04a3ad_almond2.4G"}, {"Type": "Guest5G", "Enabled": "false", "SSID": "Guest-5GHz"}, {"Type": "Guest2G", "Enabled": "false", "SSID": "Guest-2.4GHz"}], "RouterUptime": "12 days, 17 hrs", "Uptime": "1100086", "URL": "10.10.1.29", "Login": "root", "TempPass": "cmuJR+KFeHD/Aj2RILhe+V+ZNW8pneXuZLHky9elP0E=", "FirmwareVersion": "AP2-R085by"};
                    }
                    
                    break;
                case 'GetWirelessSettings':
                    if (estimate.success) {
                        response.payload = {"CommandType": "GetWirelessSettings", "AppID": "1001", "Success": "true", "RouterUptime": "12 days, 17 hrs", "Uptime": "1100086", "URL": "10.10.1.29", "Login": "root", "TempPass": "cmuJR+KFeHD/Aj2RILhe+V+ZNW8pneXuZLHky9elP0E=", "FirmwareVersion": "AP2-R085by", "CountryRegion":"UNITED STATES (US)"};
                        response.payload.WirelessSetting = simAlmond.wireless.WirelessSetting;
                    } else {
                        response.payload = {};
                    }
                    
                    break;
                case 'SetWirelessSettings':
                {
                    console.log('------------ SetWirelessSettings -----------');
                    var type = jsonPacket["WirelessSetting"]["Type"];
                    var res = {};
                    res.CommandType = jsonPacket.CommandType;
                    res.AppID = jsonPacket.AppID;
                    res.WirelessSetting = [];
                    if (jsonPacket["WirelessSetting"]["Enabled"]) {
                        console.log('----------- Enabled --------------');
                        var result = {Type:type, Enabled:jsonPacket["WirelessSetting"]["Enabled"]};
                        
                        simAlmond.wireless.WirelessSetting.forEach(function(item, index) {
                            if(simAlmond.wireless.WirelessSetting[index].Type === type) {
                                result.SSID = simAlmond.wireless.WirelessSetting[index].SSID;
                                result.Password = 'TestPassword123kjdkjdjdnkjdkf';
                            }
                        });
                        
                        res.WirelessSetting.push(result);
                        if (estimate.success) {
                            res.Success = 'true';
                        } else {
                            res.Success = 'false';
                            res.Reason = 'Enable is same';
                        }
                    }
                    if (jsonPacket["WirelessSetting"]["SSID"]) {
                        if (estimate.success) {
                            var result = {Type:type, SSID:jsonPacket["WirelessSetting"]["SSID"]};
                        } else {
                            
                        }
                        res.WirelessSetting.push(result);
                    }
                    response.payload = res;
                    console.log('---------------- response -------------- ', JSON.stringify(response));
                    break;
                }
                case "RebootRouter":
                    if (estimate.success) {
                        response.payload = {"CommandType":"RebootRouter","Success": "true"};
                    } else {
                        response.payload = {"CommandType":"RebootRouter","Success": "false"};
                    }
                    break;
                default:
                    console.log('-------------- default case 1100 --------------');
                    break;
            }
        }
            break;
        case 1200:
        {
            console.log('--------------- 1200 in almondConsumer -----------------');
            break;
        }
        case 1500:
        {
            console.log('---------------- 1500 in almondConsumer ---------------');
            break;
        }
        default:
            console.log('Got new unknows command ', request);
            break;
    }
    unicast(request, JSON.stringify(response.payload), response.commandNumber);
};

var unicast = function(packet, payload, commandNumber) {
    console.log(" *****************8888888888888")
    var msg = {
        unicastID: parseInt(packet.unicastID),
        command: commandNumber,
        payload: payload,
        AlmondMAC: packet.almondMAC
    };
    msg = JSON.stringify(msg);
    redisExecute('ICID_', 'get', packet.unicastID, null, function(err, queue) {
        console.log('queue', queue, msg)
        if (!err && queue && queue != 'null' && queue != 'undefined') publisher.sendToQueue(producerQueue, msg);
        return;
    })
}
var redisExecute = function(prefix, command, key, values, callback) {
    if (values)
        redisClient[command](prefix + key, values, function(e, o) {
            console.log('inside redisExecute', e, o)
            callback(e, o)
        })
    else
        redisClient[command](prefix + key, function(e, o) {
            console.log('inside redisExecute', e, o)
            callback(e, o)
        })
}


module.exports = Consumer;