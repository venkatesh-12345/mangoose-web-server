/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var RabbitMQConnector = require('../../rabbitmq/rabbitMQ');
var rabbitmqConfig = require('../../config').rabbitmq;
var options = {
    host: rabbitmqConfig.host,//'amqp://127.0.0.1',
    queueName: rabbitmqConfig.queueName,//"QTest",
    maxRetryCount: 3
};

var producer = new RabbitMQConnector(options, 'PRODUCER');
//producer.connect();
producer.on('connected', function () {
    console.log(">>>We are connected  AQ >>>");
    
});

producer.on('reconnecting', function (number, error) {
    //console.log(number);
});

producer.on('error', function () {
    console.log("This is now giving error");
});

var AQP = {};
AQP.sendToQueue = function (queue, message) {
    if (queue) {
        console.log('sending this mesage --> ', message, ' to this queue --> ', queue, ' --- in responseProducer ');
        console.log(options.host);
        options.queueName = queue;
        producer.pushMessage(queue, message);
    } else
        console.log('queue not present in =============> ');
};


module.exports = AQP;

