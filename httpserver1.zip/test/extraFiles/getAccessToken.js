/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var CLEAR_DB = nconf.get('CLEAR_DB');
var redisR = require('redis');
var redisConn = redisR.createClient();

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

describe('Tests for getAccessToken : ', function () {
    var code = '123457';
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                testEnv.userID = res.split(':')[1];
                testEnv.tempPass = res.split(':')[0];
                if (testEnviron !== 'productionEnv') {
                    redisConn.hmset("accessCode:" + code, ['authCode', code, 'clientId', "amazon-echo", 'userId', testEnv.userID, 'email', testEnv.emailID, 'expires', '1499788956'], function () {
                        console.log('################### 2 : ', testEnv.userID);
                        done();
                    });
                } else
                    done();
            }
        });
    });
    it(' bearerTest POST GetAccessToken', function (done) {
        this.timeout(5000);
        console.log("Before making a request ..");
        console.log(AUTH);
        var options = {
            method: 'POST',
            url: URL + '/GetAccessToken',
            headers: {
                'content-type': TYPE_X,
                authorization: AUTH
            },
            form: {
                'grant_type': 'authorization_code',
                'client_id': 'amazon-echo',
                'client_secret': '_8nL&KdM$8qGxF&s',
                'code': code
            }
        };
        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log(body);
            console.log('################## 3 : ', testEnv.userID);
            expect(response.statusCode).to.equal(200);
            assert.equal(JSON.parse(body).token_type, 'bearer', 'token_type is not bearer type');
            assert.isAbove(JSON.parse(body).access_token.indexOf(testEnv.userID), -1, 'userID not found in access_token');
            //assert(response.statusCode == 556); 
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        clearData(testEnv.almondMAC, testInput.deviceID, done);
                    });
                });
            else
                done();
        } else
            done();
    });
});
