/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

resObj = {};

var exporter = {};

exporter.setProperties = function (res) {
    console.log('setting response object ', res);
    resObj = res;
};

exporter.getProperties = function () {
    console.log('getting the response object', resObj);
    return resObj;
};

module.exports = exporter;
