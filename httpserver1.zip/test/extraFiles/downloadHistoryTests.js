var expect = require('chai').expect;
var request = require('request');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var URL = nconf.get('httpUrl');
var testInput = nconf.get('downloadHistory');
var insertLogs = require('./dbForTest/newEventInserts');
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';

var AlmondMAC = testInput.almondMAC;

describe('Download History Tests', function () {
    before(function (done) {
        this.timeout(90000);
        console.log('clearing the database for ', AlmondMAC);
        if (testEnviron !== 'productionEnv') {
            insertLogs.clearDB(AlmondMAC, function() {
                console.log('database cleared... \n creating the database for ', AlmondMAC);
                insertLogs.createDB(AlmondMAC, 100, 20, function() {
                    console.log('database created');
                    done();
                });

            });
        } else
            done();
    });
    it('insufficient data', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/DownloadHistory',
            headers: {
                'content-type': TYPE_X
            },
            form: {}
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(556);
            options.form = {
                mac:testInput.almondMAC
            };
            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(556);
                done();
            });
        });
    });
    it('invalid data', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/DownloadHistory',
            headers: {
                'content-type': TYPE_X
            },
            form: {
                mac:testInput.almondMAC,
                type:'unknownType'
            }
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(556);
            done();
        });
    });
    it('valid data', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/DownloadHistory',
            headers: {
                'content-type': TYPE_X
            },
            form: {
                mac:testInput.almondMAC,
                email:testInput.emailID,
                type:'device'
            }
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            done();
        });
    });
    //Cassandra table properties got changed
    it.skip('single device data', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/DownloadHistory',
            headers: {
                'content-type': TYPE_X
            },
            form: {
                mac:testInput.almondMAC,
                email:testInput.emailID,
                type:'device',
                id:'2'
            }
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            done();
        });
    });
    //Cassandra table properties got changed
    it.skip('multiple device data', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/DownloadHistory',
            headers: {
                'content-type': TYPE_X
            },
            form: {
                mac:testInput.almondMAC,
                email:testInput.emailID,
                type:'device',
                id:'1,2,3'
            }
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            done();
        });
    });
    after(function (done) {
        this.timeout(5000);
        if (testEnviron !== 'productionEnv') {
            insertLogs.clearDB(AlmondMAC, function() {
                done();
            });
        } else
            done();
    });
});
