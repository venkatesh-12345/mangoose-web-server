/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var nconf = require('nconf');
var path = require('path');
var ROOT = path.resolve(__dirname, '.');
nconf.env().argv();
console.log('/******************************************* \n TEST_ENV should be either stagingEnv or productionEnv.\n By default it will take stagingEnv.\n *******************************************/')

// Global variable
testEnviron = nconf.get('TEST_ENV') || 'stagingEnv';

nconf
        .file('testEnviron', ROOT + '/' + testEnviron + '.json');

console.log('config file considered : ', ROOT + '/' + testEnviron + '.json');
