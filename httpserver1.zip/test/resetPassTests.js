var expect = require('chai').expect;
var request = require('request');
var CP = require('../database/sql/sqlQuery.js');
var dbmodifier = require('./dbForTest/dbmodifier.js');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var URL = nconf.get('httpUrl');
const EMAIL = 'prashanth.rangaraju1@securifi.com';

function activateVerifyAccount(callback) {
    var options = {
        method: 'POST',
        url: URL + '/ResendActivationLink',
        body: {
            'emailID': EMAIL
        },
        json: true
    };
    request(options, function (error, response, body) {

        CP.queryFunction('SELECT ValidationToken from ?? where EmailID=?', ['Users', EMAIL], function (err, rows) {
            if (err || rows.length == 0) {
                callback(err);
            }
            options.url = URL + '/VerifyAccount';
            options.body.token = rows[0].ValidationToken;
            console.log('body :: ', options.body);
            request(options, function (error, response, body) {
                if (error)
                    callback(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                callback();
            });
        });

    });
}

describe('ResetPassword tests', function () {
    before(function (done) {
        this.timeout(10000);
        console.log(" How many times");
        dbmodifier.createUser(EMAIL, '000000', function (err, rows) {
            console.log('done');
            //done();
            accManager.activateVerifyAccount(EMAIL, done);
//            activateVerifyAccount(done);
        });
    });
    it('ResetPassword successful', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/ResetPassword',
            body: {
                'emailID': EMAIL
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.success + '').to.equal('true');
            done();
        });
    });
    it('ConfirmResetPassword successful', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/ConfirmResetPassword',
            body: {
                'emailID': EMAIL,
                'password': '111111'
            },
            json: true
        };
        CP.queryFunction('SELECT ValidationToken from ?? where EmailID=?', ['Users', EMAIL], function (err, rows) {
            if (err || rows.length == 0) {
                done(new Error("fail"));
            }
            console.log('-- body -- : ', options.body);
            options.body.token = rows[0].ValidationToken;
            console.log('-- body -- : ', options.body);
            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                done();
            });
        });
    });
    it('Login with emailID and password successful after ResetPassword', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/Login',
            body: {
                'emailID': EMAIL,
                'password': '111111'
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.commandType).to.equal('Login');
            expect(body.success + '').to.equal('true');
            expect(body.hasOwnProperty('userID')).to.equal(true);
            expect(body.hasOwnProperty('tempPass')).to.equal(true);
            expect(body.hasOwnProperty('isActivated')).to.equal(true);
            expect(body.hasOwnProperty('minutesRemaining')).to.equal(true);
            uid = body.userID;
            tempPass = body.tempPass;
            done();
        });
    });
    it('ResetPassword successful', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/ResetPassword',
            body: {
                'emailID': EMAIL
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.success + '').to.equal('true');
            done();
        });
    });
    it('ConfirmResetPassword successful', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/ConfirmResetPassword',
            body: {
                'emailID': EMAIL,
                'password': '000000'
            },
            json: true
        };
        CP.queryFunction('SELECT ValidationToken from ?? where EmailID=?', ['Users', 'prashanth.rangaraju1@securifi.com'], function (err, rows) {
            if (err || rows.length == 0) {
                done(new Error("fail"));
            }
            options.body.token = rows[0].ValidationToken;
            request(options, function (error, response, body) {
                if (error)
                    done(error);
                console.log(body);
                expect(response.statusCode).to.equal(200);
                expect(body.success + '').to.equal('true');
                done();
            });
        });
    });
    after(function (done) {
        this.timeout(5000);
        console.log(" How many times");
        dbmodifier.deleteUser(EMAIL, function (err, rows) {
            console.log('done');
            done();
        });
    });
});
