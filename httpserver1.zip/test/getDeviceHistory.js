/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var assert = require('chai').assert;
var request = require('request');
var moment = require('moment');
var accManager = require('./dbForTest/accountManager');
//var loggerPoint = require('../database/cassandra/cqlConnection');
var pgClient = require('../database/postgres/pgQueryNew');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var testInput = nconf.get('getDeviceHistory');
var CLEAR_DB = nconf.get('CLEAR_DB');

var URL = nconf.get('httpUrl');
var AUTH = 'Bearer ';
var TYPE_X = 'application/x-www-form-urlencoded';
var TYPE_JSON = 'application/json';
const TIME = Date.now();
var date = moment.utc().utcOffset(0);
const CURR_DATE = date.format('YYYY-MM-DD');

function getRandInt(limit) {
    return Math.floor(Math.random() * limit);
}
function insertOneRecord(mac, device_id, i, callback) {
    var id = getRandInt(10);
    var data = {
        mac: mac,
        device_id: device_id,
        time: TIME + i,
        index_id: id,
        index_name: 'index#'+ id,
        type: getRandInt(60),
        dateyear: date.format('YYYY-MM-DD'),
        userid: "755624541",
        value: 'testing value'
    };
    data.name = 'name#' + data.device_id;
    var query = "insert into recentactivity (mac, id , time , index_id , name , type , index_name , value ) values ($1, $2, NOW(), $3, $4, $5, $6,$7)";
    var params = [data.mac, data.device_id, data.index_id, data.name, data.type, data.index_name,  data.value];
    pgClient.query(query, params, function (error, result) {
        if (error)
            console.log(error);
        else
            callback();
    });
}


function insertDeviceHistory(mac, device_id, totalRec, callback) {
    var nextItemIndex = 0;
    function iterator(err) {
        nextItemIndex++;
        if (nextItemIndex === totalRec) {
            callback(err);
        } else {
            insertOneRecord(mac, device_id, nextItemIndex, function () {
                iterator();
            });
        }
    }
    insertOneRecord(mac, device_id, nextItemIndex, function () {
        iterator();
    });
}

function clearData(mac, device_id, callback) {
    var query = "DELETE from recentactivity WHERE mac= $1 AND id = $2 ";
    var params = [mac, device_id];
    pgClient.query(query, params, function (error, result) {
        if (error)
            console.log(error);
        else
            callback();
    });
}

describe('GetDeviceHistory tests: ', function () {
    var pageState = null;
    before(function (done) {
        this.timeout(25000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                AUTH = AUTH + res;
                console.log('==================== ---------- : ', AUTH);
                if(testEnviron !== "productionEnv")
                    insertDeviceHistory(testEnv.almondMAC, testInput.deviceID, 100, function() {
                        done();
                    });
                else
                    done();
            }
        });
    });
    it('Success testcase', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/GetDeviceHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": testEnv.almondMAC,
                "id": testInput.deviceID,
                "pageState": null
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            //expect(body.hasOwnProperty('pageState')).to.equal(true);
            expect(body.hasOwnProperty('logs')).to.equal(true);
            expect(body.logs[0].mac + '').to.equal(testEnv.almondMAC);
            expect(body.logs[0].device_id + '').to.equal(testInput.deviceID+'');
            done();
        });
    });
    it('Success testcase for GET method', function (done) {
        this.timeout(10000);
        var options = {
            method: 'GET',
            url: URL + '/GetDeviceHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": testEnv.almondMAC,
                "id": testInput.deviceID,
                "pageState": null
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            //expect(body.hasOwnProperty('pageState')).to.equal(true);
            expect(body.hasOwnProperty('logs')).to.equal(true);
            expect(body.logs[0].mac + '').to.equal(testEnv.almondMAC);
            expect(body.logs[0].device_id + '').to.equal(testInput.deviceID+'');
            pageState = body.pageState;
            done();
        });
    });
    it('Success testcase with pageState', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/GetDeviceHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": testEnv.almondMAC,
                "id": testInput.deviceID,
                "pageState":  pageState
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            //expect(body.hasOwnProperty('pageState')).to.equal(true);
            expect(body.hasOwnProperty('logs')).to.equal(true);
            expect(body.logs[0].mac + '').to.equal(testEnv.almondMAC);
            expect(body.logs[0].device_id + '').to.equal(testInput.deviceID+'');
            done();
        });
    });
    it('Success testcase with pageState and for GET method', function (done) {
        this.timeout(10000);
        var options = {
            method: 'GET',
            url: URL + '/GetDeviceHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": testEnv.almondMAC,
                "id": testInput.deviceID,
                "pageState": pageState
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            //expect(body.hasOwnProperty('pageState')).to.equal(true);
            expect(body.hasOwnProperty('logs')).to.equal(true);
            expect(body.logs[0].mac + '').to.equal(testEnv.almondMAC);
            expect(body.logs[0].device_id + '').to.equal(testInput.deviceID+'');
            done();
        });
    });
    it('Wrong almondMAC case', function (done) {
        this.timeout(10000);
        var options = {
            method: 'POST',
            url: URL + '/GetDeviceHistory',
            headers: {
                'content-type': TYPE_JSON,
                'cache-control': 'no-cache',
                authorization: AUTH
            },
            body: {
                "AlmondMAC": 12345,
                "id": testInput.deviceID,
                "pageState": pageState
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                throw new Error(error);
            console.log(response.statusCode);
            console.log('body---------', body);
            expect(response.statusCode).to.equal(556);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Access Denied');
            done();
        });
    });
    after(function (done) {
        this.timeout(15000);
        if (testEnviron !== 'productionEnv') {
            if(CLEAR_DB == 'true')
                accManager.unlinkAlmond(function () {
                    accManager.clearAccounts(function (err) {
                        clearData(testEnv.almondMAC, testInput.deviceID, done);
                    });
                });
            else
                done();
        } else
            done();
    });
});


