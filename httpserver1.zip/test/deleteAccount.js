/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var request = require('request');
var dbmodifier = require('./dbForTest/dbmodifier.js');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var URL = nconf.get('httpUrl');
var testInput = nconf.get('deleteAccount');

describe('DeleteAccount Test', function () {
    before(function (done) {
        this.timeout(10000);
        console.log(" How many times");
        // change to signUp
        accManager.httpSignup(testInput, function (err, res) {
            console.log('done');
            done();
            //activateVerifyAccount(done);
        });
    });
    it('Account deletion successful', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/DeleteAccount',
            body: {
                'emailID': testInput.emailID,
                'password': testInput.password
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.success + '').to.equal('true');
            done();
        });
    });
    it('Account deletion unsuccessful', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/DeleteAccount',
            body: {
                'emailID': testInput.emailID,
                'password': testInput.password
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(502);
            expect(body.success + '').to.equal('false');
            expect(body.reason + '').to.equal('No such user');
            done();
        });
    });
    after(function (done) {
        this.timeout(5000);
        console.log(" How many times");
        dbmodifier.deleteUser(testInput.emailID, function (err, rows) {
            console.log('done');
            done();
        });
    });
});
