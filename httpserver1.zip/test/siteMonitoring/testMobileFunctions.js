/**
 * Command to run tests : DATABASE=test mocha testMobileFunctions.js
 */

var mobileFun = require('../../siteMonitoringMobile/mobileFunctions').mobileFun;
var container = require('../../siteMonitoringMobile/mobileFunctions').container;
var testLog = require('./sampleLogs/repeatedDomainsTest');
var assert = require('chai').assert;
var loggerPoint = require('../../database/cassandra/cqlConnection');
var moment = require('moment');
var cassQueries = require('../../siteMonitoringMobile/cqlQueryFun');
var config = require('nconf').get('smTables');
var siteMonitoringTable = config.siteMonitoringTable;
var bandwidthTable = config.bandwidthtable;
var categoryDBTable = config.categoryDBTable;

var almondMAC = 291;
var clientMAC = 0;

var getClassificationFromDB = function(domain_request, callback) {
    if (domain_request.length) {
        const query = "select * from browsing_log_store.site_category_mapping where site IN ?";
        const params = [domain_request];
        loggerPoint.execute(query, params, {
            prepare: true
        }, callback); ///////////query end
    }
    else {
        callback(undefined, []);
    }
};

var filterSites = function(allSites, rows) {
    var sitesPresent = [];
    rows.forEach(function(item) {
        item.clients = allSites[item.site];
        sitesPresent.push(item);
        delete allSites[item.site];
    });
    return {
        missingSites: allSites,
        sitesPresent: sitesPresent
    };
};

var timeTravel = function(TZ) {
    var a = moment.utc();
    var minutes = TZ.substr(3, 2);
    minutes = +minutes;
    var hours = TZ.substr(1, 2);
    hours = +hours;
    var sign = TZ[0];
    var difference = hours * 60 * 60 + minutes * 60;
    difference = difference;
    if (sign == '+') {
        a = a + difference;
    }
    else {
        a = a - difference;
    }
    return (moment(a).format('YYYY-MM-DD'));
};

var getAllSites = function(json) {
    try {
        var clients = Object.keys(json.Data);
    }
    catch (e) {
        console.log(e);
        return;
    }
    var allSites = {};
    clients.forEach(function(item) {
        var sites = json.Data[item].Sites;
        addDomains(sites, allSites, item);
    });
    return allSites;
};


function addDomains(clientSites, allSites, client) {
    Object.keys(clientSites).forEach(function(item) {
        if (!allSites[item])
            allSites[item] = [];
        allSites[item].push({
            Client: client,
            Epoch: clientSites[item][0]
        });
    });
}

var hexToDecimal = function(hex) {
    try {
        var hexWithoutColon = hex.replace(/:/g, "");
        var decimal = parseInt(hexWithoutColon, 16);
        return (decimal);

    }
    catch (e) {
        var decimal = parseInt(hex, 16);
        return decimal;
    }
};

var newCollect = function(almondMAC, date, sitesArray, callback) {
    var clientsArray = {};
    if (almondMAC == undefined || date == undefined) {
        console.log('newCollect called with undefined parameters with almondMAC ', almondMAC, 'and date ', date);
        return;
    }
    var query3 = 'INSERT INTO browsing_log_store.log_2 (mac,client_mac,dateyear,site,category,lastupdated) VALUES (?,?,?,?,?,?)';
    (sitesArray).forEach(function(obj) {
        (obj.clients).forEach(function(item) {

            if (!clientsArray[item.Client])
                clientsArray[[item.Client]] = [];
            var client_mac = hexToDecimal(item.Client);
            var q3 = {
                query: query3,
                params: [almondMAC, client_mac, date, obj.site, obj.category, parseInt(item.Epoch)]
            };
            clientsArray[item.Client].push(q3);

        });
    });
    prepareBatchQuery(clientsArray, almondMAC, callback);

};

var newBatchInsert = function(queries, callback) {
    loggerPoint.batch(queries, {
        prepare: true
    }, function(error, result) {
        callback(error, result);
    });
};

function prepareBatchQuery(client_array, almondMAC, callback) {
    var i = 0;
    if (almondMAC == undefined) {
        console.log('prepareBatchQuery called with undefined parameters with almondMAC ', almondMAC);
        return;
    }
    Object.keys(client_array).forEach(function(obj) {
        if (obj.length != 0) {
            var batchQueries = client_array[obj];
            newBatchInsert(batchQueries, function(error, result) {
                i++;
                if (i >= Object.keys(client_array).length) {
                    if (callback) {
                        callback(error, client_array);
                    }
                }
            });
        }
        else {
            i++;
        }
    });
}


var deleteSite = function(inQuery, callback) {
    loggerPoint.execute(inQuery, function(err, result) {
        if (err) {
            console.log(err, 'cause inQuery is', inQuery);
        }
        if (callback) callback(err, result);
    });
};

/**
 * NOTE: Command to run tests : DATABASE=test mocha testMobileFunctions.js
 */
describe('Testing when pageState exists', function() {


    afterEach(function(done) {
        this.timeout(15000);
        var aCounter = 2;
        var sites = [];
        var s = "'sitePresentinDB.com'";
        sites.push(s);
        while (aCounter <= 200) {
            s = 'sitePresentinDB' + aCounter + '.com';
            s = "'" + s + "'";
            aCounter++;
            sites.push(s);
        }
        var inQuery = 'DELETE from browsing_log_store.site_category_mapping where site in (' + sites.join() + ")";
        loggerPoint.execute("DELETE from browsing_log_store.log_2 where mac = 291 and client_mac IN (0,1)", function(err, result) {
            if (err) {
                console.log(err);
                return;
            }
            deleteSite(inQuery, function(err, result) {
                if (err) {
                    console.log(err);
                    return;
                }
                done();
            });
        });
    });





    beforeEach(function(done) {
        this.timeout(15000);
        var aCounter = 2;
        var sites = [];
        var s = "'sitePresentinDB.com'";
        sites.push(s);
        while (aCounter <= 200) {
            s = 'sitePresentinDB' + aCounter + '.com';
            s = "'" + s + "'";
            aCounter++;
            sites.push(s);
        }
        var inQuery = 'DELETE from browsing_log_store.site_category_mapping where site in (' + sites.join() + ")";
        loggerPoint.execute("DELETE from browsing_log_store.log_2 where mac = 291 and client_mac IN (0,1)", function(err, result) {
            if (err) {
                console.log(err);
                return;
            }

            deleteSite(inQuery, function(err, result) {
                if (err) {
                    console.log(err);
                    return;
                }

                var i = 0;
                sites.forEach(function(item) {
                    var query3 = "INSERT INTO browsing_log_store.site_category_mapping (site , category) VALUES (" + item + ", 1000)";
                    if (i < sites.length) {
                        loggerPoint.execute(query3, function(err, result) {
                            if (err) console.log(err);
                            i++;
                            if (i >= sites.length) {

                                done();
                            }
                        });
                    }
                });
            });
        });
    });





    it.skip("Checking for when pageState exists and dateyear does not", function(done) {
        this.timeout(15000);
        var json = JSON.parse(testLog.SITE_LOG5);
        var allSites = getAllSites(json);
        var dateyear = timeTravel(json['TZ']);
        var pageState = undefined;

        // Is this different every time??????????????/
        getClassificationFromDB(Object.keys(allSites), function(e, result) {
            var filteredSites = filterSites(allSites, result.rows);
            var sitePresent = filteredSites.sitesPresent;
            newCollect(hexToDecimal(json['MAC']), dateyear, sitePresent, function(e, res) {
                mobileFun.getBrowsingDataForClient1(almondMAC, clientMAC, undefined, pageState, function(err, result) {
                    mobileFun.getBrowsingDataForClient1(almondMAC, clientMAC, undefined, result['pageState'], function(err, result) {
                        if (err) console.log(err);
                        var resultCategory = [];
                        var i = 0;
                        var expectedResult = [];
                        while (i < 100) {
                            try {
                                resultCategory.push(result['Data'][i]['Category']);
                            }
                            catch (e) {
                                console.log(e, i, 'i');
                            }
                            expectedResult.push('1000');
                            i++;
                        }
                        assert.deepEqual(resultCategory, expectedResult, 'Category matching fails');
                        done();
                    });

                });
            });
        });
    });




    it.skip("Checking for when pageState and dateyear exist", function(done) {
        this.timeout(15000);
        var json = JSON.parse(testLog.SITE_LOG5);
        var allSites = getAllSites(json);
        var dateyear = timeTravel(json['TZ']);
        var pageState = undefined;
        // Is this different every time??????????????/
        getClassificationFromDB(Object.keys(allSites), function(e, result) {
            var filteredSites = filterSites(allSites, result.rows);
            var sitePresent = filteredSites.sitesPresent;
            newCollect(hexToDecimal(json['MAC']), dateyear, sitePresent, function(e, res) {
                mobileFun.getBrowsingDataForClient1(almondMAC, clientMAC, dateyear, pageState, function(err, result) {
                    mobileFun.getBrowsingDataForClient1(almondMAC, clientMAC, dateyear, result['pageState'], function(err, result) {

                        if (err) console.log(err);
                        var resultCategory = [];
                        var i = 0;
                        var expectedResult = [];
                        while (i < 100) {
                            try {
                                resultCategory.push(result['Data'][i]['Category']);
                            }
                            catch (e) {
                                console.log(e, i, 'i');
                            }
                            expectedResult.push('1000');
                            i++;
                        }
                        assert.deepEqual(resultCategory, expectedResult, 'Category matching fails');
                        done();
                    });
                });
            });
        });
    });



});


describe('Testing Mobile Functions', function() {
    afterEach(function(done) {
        // Deletes sites in array from both the databases

        this.timeout(15000);

        var sites = ["'sitePresentinDB.com'", "'sitePresentinDB2.com'", "'sitePresentinDB3.com'", "'sitePresentinDB4.com'", "'sitePresentinDB5.com'", "'siteAbsentFromDB.com'", "'siteAbsentFromDB2.com'", "'siteAbsentFromDB3.com'", "'siteAbsentFromDB4.com'", "'siteAbsentFromDB5.com'"];
        var inQuery = 'DELETE from browsing_log_store.site_category_mapping where site in (' + sites.join() + ")";
        loggerPoint.execute("DELETE from browsing_log_store.log_2 where mac = 291 and client_mac IN (0,1)", function(err, result) {
            if (err) console.log(err);
            deleteSite(inQuery, function(err, result) {
                if (err) console.log(err);
                done();
            });
        });
    });


    beforeEach(function(done) {
        // Sets up sites in array in category database and deletes them from main database

        this.timeout(15000);
        var sites = ["'sitePresentinDB.com'", "'sitePresentinDB2.com'", "'sitePresentinDB3.com'", "'sitePresentinDB4.com'", "'sitePresentinDB5.com'", "'siteAbsentFromDB.com'", "'siteAbsentFromDB2.com'", "'siteAbsentFromDB3.com'", "'siteAbsentFromDB4.com'", "'siteAbsentFromDB5.com'"];
        var inQuery = 'DELETE from browsing_log_store.site_category_mapping where site in (' + sites.join() + ")";
        loggerPoint.execute("DELETE from browsing_log_store.log_2 where mac = 291 and client_mac IN (0,1)", function(err, result) {
            if (err) console.log(err);
            deleteSite(inQuery, function(err, result) {
                if (err) console.log(err);
                var i = 0;
                sites.forEach(function(item) {
                    var query3 = "INSERT INTO browsing_log_store.site_category_mapping (site , category) VALUES (" + item + ", 1000)";
                    if (i < sites.length) {
                        loggerPoint.execute(query3, function(err, result) {
                            if (err) console.log(err);
                            i++;
                            if (i >= sites.length) {
                                done();
                            }
                        });
                    }
                });
            });
        });
    });



    it.skip('Checking for basic functionality with dateyear undefined', function(done) {
        this.timeout(15000);
        var json = JSON.parse(testLog.SITE_LOG);
        var allSites = getAllSites(json);
        var dateyear = timeTravel(json['TZ']);
        getClassificationFromDB(Object.keys(allSites), function(e, result) {
            var filteredSites = filterSites(allSites, result.rows);
            var sitePresent = filteredSites.sitesPresent;
            newCollect(hexToDecimal(json['MAC']), dateyear, sitePresent, function(e, res) {
                mobileFun.getBrowsingDataForClient1(almondMAC, clientMAC, undefined, undefined, function(err, result) {
                    if (err) console.log(err);
                    var resultSites = [];
                    var i = 0;
                    while (i < 10) {
                        resultSites.push(result['Data'][i]['Domain']);
                        i++;
                    }
                    var expectedSites = ['sitePresentinDB.com', 'sitePresentinDB2.com', 'sitePresentinDB3.com', 'sitePresentinDB4.com', 'sitePresentinDB5.com', 'siteAbsentFromDB.com', 'siteAbsentFromDB2.com', 'siteAbsentFromDB3.com', 'siteAbsentFromDB4.com', 'siteAbsentFromDB5.com'];
                    resultSites.sort();
                    expectedSites.sort();
                    assert.deepEqual(resultSites, expectedSites, "Server Response Fails");
                    done();
                });
            });
        });
    });

    it.skip('Checking for pageState undefined but invalid dateyear', function(done) {
        this.timeout(15000);
        var json = JSON.parse(testLog.SITE_LOG);
        var allSites = getAllSites(json);
        var dateyear = timeTravel(json['TZ']);
        getClassificationFromDB(Object.keys(allSites), function(e, result) {
            var filteredSites = filterSites(allSites, result.rows);
            var sitePresent = filteredSites.sitesPresent;
            newCollect(hexToDecimal(json['MAC']), dateyear, sitePresent, function(e, res) {
                mobileFun.getBrowsingDataForClient1(almondMAC, clientMAC, '1919-09-13', undefined, function(err, result) {
                    if (err) console.log(err);
                    assert.equal(result.Data.length, 0, "Server Response Fails");
                    done();
                });
            });
        });
    });

    it.skip('Checking for basic functionality with valid dateyear defined and pageState undefined', function(done) { // RAJA
        this.timeout(15000);
        var json = JSON.parse(testLog.SITE_LOG);
        var allSites = getAllSites(json);
        var dateyear = timeTravel(json['TZ']);
        getClassificationFromDB(Object.keys(allSites), function(e, result) {
            var filteredSites = filterSites(allSites, result.rows);
            var sitePresent = filteredSites.sitesPresent;
            newCollect(hexToDecimal(json['MAC']), dateyear, sitePresent, function(e, res) {
                mobileFun.getBrowsingDataForClient1(almondMAC, clientMAC, '4019-09-13', undefined, function(err, result) {
                    if (err) console.log(err);
                    var resultSites = [];
                    var i = 0;
                    while (i < 10) {
                        resultSites.push(result['Data'][i]['Domain']);
                        i++;
                    }
                    var expectedSites = ['sitePresentinDB.com', 'sitePresentinDB2.com', 'sitePresentinDB3.com', 'sitePresentinDB4.com', 'sitePresentinDB5.com', 'siteAbsentFromDB.com', 'siteAbsentFromDB2.com', 'siteAbsentFromDB3.com', 'siteAbsentFromDB4.com', 'siteAbsentFromDB5.com'];
                    resultSites.sort();
                    expectedSites.sort();
                    assert.deepEqual(resultSites, expectedSites, "Server Response Fails");
                    done();
                });
            });
        });
    });

});

var payload1 = {
        'UserId': '32123',
        'TempPass': 'dfkjhkfjfjdsfjkjf',
        'AMAC': '251176215905232',
        'CMAC': '207609387599067',
        'search' : 'SuggestRating',
        'today' : '2017-04-04',
        'TZ' : '0500',
        'value' : '2017-03-31',
        'suggestedValue' : '1a',
        'pageState' : ''
    };

var payload2 = {
        'UserId': '30005',
        'TempPass': 'dfkjhkfjfjdsfjkjf',
        'AMAC': '251176215905200',
        'CMAC': '207609387599067',
        'search' : 'SuggestRating',
        'today' : '2017-04-04',
        'TZ' : '0500',
        'value' : '2017-03-31',
        'suggestedValue' : '1a',
        'pageState' : ''
    };
var payload3 = {
        'UserId': '30005',
        'TempPass': 'dfkjhkfjfjdsfjkjf',
        'AMAC': '251176220101316',
        'CMAC': '207609387599067',
        'search' : 'SuggestRating',
        'today' : '2017-04-04',
        'TZ' : '0500',
        'value' : '2017-03-31',
        'suggestedValue' : '1a',
        'pageState' : ''
    };
var payload4 = {
        'UserId': '30023',
        'TempPass': '9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
        'AMAC': '251176215907620',
        'CMAC': '207609387599067',
        'search' : 'SuggestRating',
        'today' : '2017-04-04',
        'TZ' : '0500',
        'value' : '2017-03-31',
        'suggestedValue' : '1a',
        'pageState' : ''
    };

describe('Testing loginAuthCheck', function() {
    this.timeout(0);
    it("test case 1", function (done) {
        mobileFun.loginAuthCheck(payload1, function(err, res) {
            if(err || res.length == 0) {
                console.log('Authentication Failed  --- 1 ---');
            } else {
                console.log('Authentication Pass --- 1 ---');
            }
            //done();
        });
        setTimeout(function(){
          done();
        },3000);
    });
    it("test case 2", function (done) {
        mobileFun.loginAuthCheck(payload2, function(err, res) {
            if(err || res.length == 0) {
                console.log('Authentication Failed --- 2 ---');
            } else {
                console.log('Authentication Pass --- 2 ---');
            }
            done();
        });
    });
    it("test case 3", function (done) {
        mobileFun.loginAuthCheck(payload3, function(err, res) {
            if(err || res.length == 0) {
                console.log('Authentication Failed --- 3 ---');
            } else {
                console.log('Authentication Pass --- 3 ---');
            }
            done();
        });
    });
    it("test case 4", function (done) {
        mobileFun.loginAuthCheck(payload4, function(err, res) {
            if(err || res.length == 0) {
                console.log('Authentication Failed --- 4 ---');
            } else {
                console.log('Authentication Pass --- 4 ---');
            }
            done();
        });
    });
});

describe('Testing chopDomain', function () {
    it("chopDomain", function() {
        sites = ['abc.google.com','google.com','1.google.com','google.co.in','www.google.co.in','www.google.com.in','www.google.com.com','it','','.'];
        assert.equal("google.com", mobileFun.chopDomain(sites[0]), 'chopDomain error occured');
        assert.equal("google.com", mobileFun.chopDomain(sites[1]), 'chopDomain error occured');
        assert.equal("google.com", mobileFun.chopDomain(sites[2]), 'chopDomain error occured');
        assert.equal("google.co.in", mobileFun.chopDomain(sites[3]), 'chopDomain error occured');
        assert.equal("google.co.in", mobileFun.chopDomain(sites[4]), 'chopDomain error occured');
        assert.equal("google.com.in", mobileFun.chopDomain(sites[5]), 'chopDomain error occured');
        assert.equal("com.com", mobileFun.chopDomain(sites[6]), 'chopDomain error occured');
        assert.equal("it", mobileFun.chopDomain(sites[7]), 'chopDomain error occured');
        assert.equal("", mobileFun.chopDomain(sites[8]), 'chopDomain error occured');
        assert.equal(".", mobileFun.chopDomain(sites[9]), 'chopDomain error occured');
    });
});

var UC_case1 = {
    'UserId':'30023',
    'TempPass':'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    'AMAC':'251176215907620',
    'CMAC':'207609387599067',
    'search':'SuggestRating',
    'value':'facebook.com',
    'suggestedValue':26
};
var UC_case2 = {
    'UserId':'30023',
    'TempPass':'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    'AMAC':'251176215907620',
    'CMAC':'207609387599067',
    'search':'SuggestRating',
    'value':'facebook.com',
    'suggestedValue':'a'
};
var UC_case3 = {
    'UserId':'30023',
    'TempPass':'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    'AMAC':'251176215907620',
    'CMAC':'207609387599067',
    'search':'SuggestRating',
    'value':'facebook.com',
    'suggestedValue':'a'
};

describe('Testing UpdateCategory', function () {
    before(function (done) {
        // insert into site category mapping
        this.timeout(5000);
        var query = "insert into browsing_log_store." + categoryDBTable +" (site , category , date ) values (? , ? ,?) ";
        var params = [ 'facebook.com', '14', '2017-05-19' ];
        cassQueries.executeQuery(query, params, function(error,result){
            done();
        });
    });
    it('Valid case', function (done) {
        mobileFun.UpdateCategory(UC_case1,function (r) {
            var resQuery = r.query;
            var resParams = r.params;
            console.log('==== : ', r.query);
            console.log(resQuery);
            var expQuery = "insert into browsing_log_store.categorysuggestion (category , mac , oldsubcategory , suggestedsubcategory ) values (? , ? , ? ,?) ";
            var expParams = [ 14, '251176215907620', '3', 26 ];
            assert.deepEqual('1', r.querystatus, 'Failed for valid case');
            assert.deepEqual(expQuery, resQuery, 'Failed for valid case');
            assert.deepEqual(JSON.stringify(expParams), JSON.stringify(resParams), 'Failed for valid case');
            done();
        });
    });
    it('Invalid value case', function (done) {
        mobileFun.UpdateCategory(UC_case2,function (r) {
            assert.deepEqual('0', r.querystatus, 'Failed for Invalid value case');
            done();
        });
    });
    it('Site not present case', function (done) {
        mobileFun.UpdateCategory(UC_case3,function (r) {
            assert.deepEqual('0', r.querystatus, 'Failed for Invalid value case');
            done();
        });
    });
});


var cQCase1 = {
    'UserId':'30023',
    'TempPass':'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    'AMAC':'251176215907620',
    'CMAC':'207609387599067',
    'search':'',
    'value':'',
    'pageState':null
};
var cQCase2 = {
    'UserId':'30023',
    'TempPass':'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    'AMAC':'251176215907620',
    'CMAC':'207609387599067',
    'search':'',
    'value':'',
    'IOT':1,
    'pageState':null
};
var cQCase3 = {
    'UserId':'30023',
    'TempPass':'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    'AMAC':'251176215907620',
    'CMAC':'207609387599067',
    'search':'""',
    'value':'""',
    'pageState':null
};
var cQCase4 = {
	"UserId":"30023",
	"TempPass":"9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e",
	"AMAC":"251176215907620",
	"CMAC":"207609387599067",
	"search":"DataUsageReset",
	"today":"2017-04-04",
	"TZ":"0500",
	"value":"31-03-2017",
	"pageState":"null"
};
var cQCase5 = {
	"UserId":"30023",
	"TempPass":"9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e",
	"AMAC":"251176215907620",
	"CMAC":"207609387599067",
	"search":"DataUsageReset",
	"today":"2017-04-04",
	"TZ":"0500",
	"value":"5",
	"pageState":"null"
};

describe('Testing constructQuery', function () {
    it('WebHistory IOT case', function () {
        var res = mobileFun.constructQuery(cQCase2);
        var exp = {query:'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.iot WHERE mac = ? AND client_mac = ?',params:['251176215907620', '207609387599067']};
        assert.deepEqual(exp,res, 'Failed for WebHistory IOT case');
    });
    it('WebHistory case', function () {
        var res = mobileFun.constructQuery(cQCase1);
        var exp = {query:'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ?',params:['251176215907620', '207609387599067']};
        assert.deepEqual(exp,res, 'Failed for WebHistory case');
    });
    it('Invalid search', function () {
        var res = mobileFun.constructQuery(cQCase3);
        var exp = undefined;
        assert.deepEqual(exp,res, 'Failed for Invalid search case');
    });
    it('Invalid value', function () {
        var res = mobileFun.constructQuery(cQCase4);
        var exp = undefined;
        assert.deepEqual(exp,res, 'Failed for Invalid value case');
    });
    it('Valid search case', function () {
        var res = mobileFun.constructQuery(cQCase5);
        console.log(JSON.stringify(res));
        var exp = {"query":"INSERT INTO SiteMonitoring.BW_Reset_info (mac, client_mac, date , TZ) VALUES( ?, ? ,? , ?) ON DUPLICATE KEY UPDATE mac = ? , client_mac = ? ,  date = ? , TZ = ?","params":["251176215907620","207609387599067","5","0500"]};
        assert.deepEqual(exp,res, 'Failed for Valid search case');
    });
});

describe('Testing logRowParser', function () {
    var input, res, exp;
    it('undefined input', function () {
        res = mobileFun.logRowParser(undefined);
        assert.deepEqual(undefined, res, 'Failed for undefined input');
    });
    it('"hit" property removal', function () {
        input = {hit:123456};
        res = mobileFun.logRowParser(input);
        assert.deepEqual({}, res, 'Failed for hit removal');
    });
    it('partial input', function () {
        input = {hit:123456,site:'google.com',dateyear:'2017-04-18'};
        exp = {Domain:'google.com',Date:'2017-04-18'};
        res = mobileFun.logRowParser(input);
        assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for partial input');
    });
    it('valid input', function () {
        var currTime = new Date(1492512089);
        input = {dateyear:"2017-04-18",site:"getpostman.com",category:5,lastupdated:currTime,subcategory:1};
        exp = {"Domain":"getpostman.com","subCategory":"5","Category":"1","Date":"2017-04-18","LastVisitedEpoch":1492512089};
        res = mobileFun.logRowParser(input);
        assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for valid input');
    });
});

describe('Testing getBrowsingDataForClient1', function () {
    var query, params, res, exp;
    it('undefined input', function (done) {
        mobileFun.getBrowsingDataForClient1(undefined, undefined, null, function(err, res) {
            if (err) {
                console.log('error === : ', err);
            } else if (res) {
                console.log('result === : ', JSON.stringify(res));
            }
            done();
        });
    });
    it('no matching rows', function (done) {
        this.timeout(10000);
        query = 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND dateyear = ?;';
        params = [ '251176215905232', '53164086224762', '2017-04-25' ];
        mobileFun.getBrowsingDataForClient1(query, params, null, function(err, res) {
            if (err) {
                console.log('error === : ', err);
                done('Failed query');
            } else if (res) {
                console.log('result === : ', JSON.stringify(res));
                exp = {Data:[]};
                assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for "no matching rows" case');
                done();
            }
        });
    });
    
});

describe('Testing getBrowsingDataForClient1 --2--', function () {
    var AMAC = '251176215000000';
    var CMAC = '531640862000000';
    var entryCount = [20, 110]; // changing these numbers will effect asserts
    var index = 0;
    beforeEach(function (done) {
        this.timeout(10000);
        var insertDB = function () {
            var queries = [];
            var query = "INSERT INTO browsing_log_store.log_3 (mac, client_mac, site, category, dateyear) VALUES ( ?, ?, ?, 1000, '2017-04-24');";
            var params;
            for (var i = 0; i < entryCount[index]; i++) { // entry more than fetchSize
                params = [AMAC, CMAC, 'sitePresent'+ (i+1) + '.com'];
                var entry = {query:query,params:params};
                queries.push(entry);
            }
            cassQueries.newBatchInsert(queries, function(error, result) {
                if (error) {
                    console.log("Error in insertDB",error);
                } else {
                    done(error);
                }
            });
        };
        insertDB();
        index++;
    });
    
    it('pageState is null', function (done) {
        query = 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND dateyear <= ?';
        params = [ AMAC, CMAC, '2017-04-25' ];
        mobileFun.getBrowsingDataForClient1(query, params, null, function(err, res) {
            if (err) {
                console.log('error === : ', err);
            } else if (res) {
                //console.log('result === : ', JSON.stringify(res));
                if(res.pageState)
                    mobileFun.getBrowsingDataForClient1(query, params, res.pageState, function(err, res) {
                        if (err) {
                            console.log('error  222 === : ', err);
                        } else {
                            //console.log('result 222 === : ', JSON.stringify(res));
                            //done();   // Below done() should be called
                        }
                    });
                else {
                    var exp = {
                        "Data":[{"lastupdated":null,"subcategory":null,"Domain":"sitePresent1.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent10.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent11.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent12.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent13.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent14.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent15.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent16.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent17.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent18.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent19.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent2.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent20.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent3.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent4.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent5.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent6.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent7.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent8.com","subCategory":"1000","Date":"2017-04-24"},
                            {"lastupdated":null,"subcategory":null,"Domain":"sitePresent9.com","subCategory":"1000","Date":"2017-04-24"}]
                    };
                    assert.deepEqual(JSON.stringify(res), JSON.stringify(exp), 'Failed for pageState is null');
                    done();
                }
            }
            
        });
    });
    
    it('pageState not null', function (done) {
        
        query = 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND dateyear <= ?';
        params = [ AMAC, CMAC, '2017-04-25' ];
        mobileFun.getBrowsingDataForClient1(query, params, null, function(err, res) {
            if (err) {
                console.log('error === : ', err);
            } else if (res) {
                //console.log('result === : ', JSON.stringify(res));
                if(res.pageState) {
                    console.log('re-quering with pageState ==: ', res.pageState);
                    mobileFun.getBrowsingDataForClient1(query, params, res.pageState, function(err, res) {
                        if (err) {
                            console.log('error  222 === : ', err);
                        } else {
                            var exp = {
                                "Data":[{"lastupdated":null,"subcategory":null,"Domain":"sitePresent90.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent91.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent92.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent93.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent94.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent95.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent96.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent97.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent98.com","subCategory":"1000","Date":"2017-04-24"},
                                    {"lastupdated":null,"subcategory":null,"Domain":"sitePresent99.com","subCategory":"1000","Date":"2017-04-24"}]
                            };
                            assert.deepEqual(JSON.stringify(res), JSON.stringify(exp), 'Failed for pageState not null');
                            done();
                        }
                    });
                }
                else {
                    //done();   // Above done() should be called
                }
            }
            
        });
    });
    
    afterEach(function (done) {
        var deleteDB = function () {
            var queries = [{query:"DELETE FROM browsing_log_store.log_3 where mac = ? AND client_mac = ?;", params:[AMAC, CMAC]}
            ];
            cassQueries.newBatchInsert(queries, function(error, result) {
                if (error) {
                    console.log("Error in insertDB",error);
                } else {
                    done(error);
                }
            });
        };
        deleteDB();
    });
});

/******* YOU NEED TO EXPOERT THE 'container' OBJECT FOR THESE TESTS******/
var pW_payload = {
    'UserId':'30023',
    'TempPass':'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    'AMAC':'251176215907620',
    'CMAC':'207609387599067',
    'search':'LastWeek',
    'value':'2017-04-25'
};
var pW_missingParam = {
    'UserId':'30023',
    'TempPass':'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    'AMAC':'251176215907620',
    'CMAC':'207609387599067',
    'search':'LastWeek'
};

describe('Testing container', function () {
    it('missing param pastWeek', function (done) {
        var params = [];
        var expParams = [];
        var res = container.pastWeek(pW_missingParam,params);
        assert.deepEqual(undefined, res, 'Failed for missing param pastWeek');
        assert.deepEqual(JSON.stringify(expParams), JSON.stringify(params), 'Failed for missing params pastWeek');
        done();
    });
    it('valid pastWeek', function (done) {
        var params = [];
        var expParams = ['207609387599067', '2017-04-25'];
        var res = container.pastWeek(pW_payload,params);
        assert.deepEqual('2017-04-18', res, 'Failed for valid');
        assert.deepEqual(JSON.stringify(expParams), JSON.stringify(params), 'Failed for valid pastWeek');
        done();
    });
    it('valid getWeekDay', function (done) {
        var params = [];
        var payload = {CMAC:'207609387599067',value:'2017-04-25'};
        var expParams = ['207609387599067'];
        var exp = [ '2017-04-25', '2017-04-18', '2017-04-11', '2017-04-04', '2017-03-28', '2017-03-21', '2017-03-14' ];
        var res = container.getWeekDay(payload, params);
        assert.deepEqual(JSON.stringify(expParams), JSON.stringify(params), 'Failed for valid getWeekDay');
        assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for valid getWeekDay');
        done();
    });
    it('missing params getWeekDay', function (done) {
        var params = [];
        var payload = {CMAC:'207609387599067'};
        var expParams = [];
        var exp = undefined;
        var res = container.getWeekDay(payload, params);
        assert.deepEqual(JSON.stringify(expParams), JSON.stringify(params), 'Failed for missing params getWeekDay');
        assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for missing params getWeekDay');
        done();
    });
    it('valid getHour LastHour case', function (done) {
        var params = [];
        var payload = {search:'LastHour',CMAC:'207609387599067', value:'12:30',today:'2017-04-25'};
        var expParams = ['207609387599067', 11];
        var exp = '2017-04-25';
        var res = container.getHour(payload, params);
        assert.deepEqual(JSON.stringify(expParams), JSON.stringify(params), 'Failed for valid getHour LastHour case');
        assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for valid getHour LastHour case');
        done();
    });
    it('valid getHour PresentHour case', function (done) {
        var params = [];
        var payload = {search:'PresentHour',CMAC:'207609387599067', value:'12:30',today:'2017-04-25'};
        var expParams = ['207609387599067', '12'];
        var exp = '2017-04-25';
        var res = container.getHour(payload, params);
        assert.deepEqual(JSON.stringify(expParams), JSON.stringify(params), 'Failed for valid getHour PresentHour case');
        assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for valid getHour PresentHour case');
        done();
    });
    it('missing params getHour PresentHour case', function (done) {
        var params = [];
        var payload = {search:'PresentHour',CMAC:'207609387599067'};
        var expParams = [];
        var exp = undefined;
        var res = container.getHour(payload, params);
        assert.deepEqual(JSON.stringify(expParams), JSON.stringify(params), 'Failed for missing params getHour PresentHour');
        assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for missing params getHour PresentHour');
        done();
    });
    it('missing params getHour LastHour case', function (done) {
        var params = [];
        var payload = {search:'LastHour',CMAC:'207609387599067'};
        var expParams = [];
        var exp = undefined;
        var res = container.getHour(payload, params);
        assert.deepEqual(JSON.stringify(expParams), JSON.stringify(params), 'Failed for missing params getHour LastHour');
        assert.deepEqual(JSON.stringify(exp), JSON.stringify(res), 'Failed for missing params getHour LastHour');
        done();
    });
    
    it('valid domainQuery', function (done) {
        var params = [];
        var payload = {search:'Domain',CMAC:'207609387599067', value: 'gOOgLe.Com', today: '2017-05-15'};
        var expParams = [payload.CMAC, ['2017-05-15', '2017-05-14', '2017-05-13', '2017-05-12', '2017-05-11', '2017-05-10', '2017-05-09'], 'google.com'];
        var exp = 'google.con';
        var res = container.domainQuery(payload, params);
        console.log(JSON.stringify(params));
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed for valid domainQuery');
        assert.deepEqual(res, exp, 'Failed for valid domainQuery result');
        done();
    });
    
    it('deleteBandwidth valid', function (done) {
        this.timeout(5000);
        var init = function (callback) {
            var query = 'update browsing_log_store.' + bandwidthTable + ' SET rx=rx-? ,tx=tx-? WHERE mac= ? AND client_mac=?  AND dateyear=? ;';
            var params = [0, 0, '12345', '6789', '2017-05-15'];
            cassQueries.executeQuery(query, params, function(error,result){
                if(error || !result)
                    console.log('init Failed');
                else {
                    query = 'update browsing_log_store.' + bandwidthTable + ' SET rx=rx+1024 ,tx=tx+2048 WHERE mac= ? AND client_mac=?  AND dateyear=? ;';
                    params = ['12345', '6789', '2017-05-15'];
                    cassQueries.executeQuery(query, params, function(error,result){
                        if(error || !result)
                            console.log('init Failed');
                        else {
                            callback();
                        }
                    });
                }
            });
        };
        init(function () {
            var payload = {AMAC:'12345',CMAC:'6789', today: '2017-05-15'};
            var params = [];
            var res = container.deleteBandwidth(payload, params);
            console.log(res);
            setTimeout(function() {
                check();
            }, 2000);
        });
        
        check = function () {
            var query = 'SELECT rx, tx FROM browsing_log_store.' + bandwidthTable + ' WHERE mac= ? AND client_mac=?  AND dateyear=? ;';
            var params = ['12345', '6789', '2017-05-15'];
            cassQueries.executeQuery(query, params, function(error,result){
                if(error || !result || !result.rows.length === 0)
                    done('check Failed');
                else {
                    console.log(result);
                    assert.deepEqual(Number(result.rows[0].rx), 0, 'Failed for rx');
                    assert.deepEqual(Number(result.rows[0].tx), 0, 'Failed for tx');
                    done();
                }
            });
        };
    });
    
    it('getBandwidth valid', function (done) {
        var params = [];
        var payload = {CMAC:'207609387599067', value: '1', today: '2017-05-15'};
        var expParams = [payload.CMAC, payload.today];
        var exp = '2017-05-14';
        var res = container.getBandwidth(payload, params);
        assert.deepEqual(res, exp, 'Failed for res');
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed for params');
        
        params = [];
        payload.value = '7';
        exp = '2017-05-08';
        res = container.getBandwidth(payload, params);
        assert.deepEqual(res, exp, 'Failed for res');
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed for params');
        
        params = [];
        payload.value = '30';   // 30 or 31 depends on the month
        exp = '2017-04-15';
        res = container.getBandwidth(payload, params);
        assert.deepEqual(res, exp, 'Failed for res');
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed for params');
        
        done();
    });
    
    it('getEpoch valid', function (done) {
        var params = [];
        var payload = {CMAC:'207609387599067', value: 'google.com', today: '2017-05-15'};
        var expParams = [payload.CMAC, payload.today];
        var exp = payload.value;
        var res = container.getEpoch(payload, params);
        assert.deepEqual(res, exp, 'Failed getEpoch for res');
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed getEpoch for params');
        done();
    });
    
    it('getValue valid', function (done) {
        var params = [];
        var payload = {CMAC:'207609387599067', value: 'google.com'};
        var expParams = [payload.CMAC];
        var exp = payload.value;
        var res = container.getValue(payload, params);
        assert.deepEqual(res, exp, 'Failed getValue for res');
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed getValue for params');
        done();
    });
    
    it('DataUsageReset invalid', function (done) {
        var params = [];
        var payload = {CMAC:'207609387599067', value: 'google.com', TZ: '+0530'};
        var expParams = [];
        var exp = undefined;
        var res = container.DataUsageReset(payload, params);
        assert.deepEqual(res, exp, 'Failed DataUsageReset for res');
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed DataUsageReset for params');
        
        payload = {CMAC:'207609387599067', value: '32', TZ: '+0530'};
        res = container.DataUsageReset(payload, params);
        assert.deepEqual(res, exp, 'Failed DataUsageReset for res');
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed DataUsageReset for params');
        
        done();
    });
    
    it('DataUsageReset valid', function (done) {
        var params = [];
        var payload = {CMAC:'207609387599067', value: '1', TZ: '+0530'};
        var expParams = [payload.CMAC, payload.value];
        var exp = payload.TZ;
        var res = container.DataUsageReset(payload, params);
        assert.deepEqual(res, exp, 'Failed DataUsageReset for res');
        assert.deepEqual(JSON.stringify(params), JSON.stringify(expParams), 'Failed DataUsageReset for params');
        done();
    });
});
