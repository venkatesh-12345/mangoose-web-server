var mobileFun = require('../../siteMonitoringMobile/mobileFunctions').mobileFun;
var container = require('../../siteMonitoringMobile/mobileFunctions').container;
var client = require('./ClientRequest');
var assert = require('chai').assert;
var moment = require('moment');
var cassQueries = require('../../siteMonitoringMobile/cqlQueryFun');
var testSuit = require('./sampleLogs/testInputs.js');
var CP = require('../../database/sql/sqlQuery');
var currDate = moment(moment.utc()).utcOffset(330).format('YYYY-MM-DD');
var tommDate = moment(moment.utc().add(1,'days')).utcOffset(330).format('YYYY-MM-DD');

function createUser (callback) {
    var query = 'insert into AllAlmondPlus (AlmondMAC, AlmondName) values (?);';
    var params = [testSuit.AMAC, 'TestAlmond'];
    CP.queryFunction(query, [params], function (err, rows) {
        query = 'insert into UserTempPasswords (UserId, TempPassword) values (?);';
        params = [testSuit.UserId, testSuit.TempPass];
        CP.queryFunction(query, [params], function (err, rows) {
            console.log(err);
            if (err) callback(err);
            query = 'insert into Users (UserId, EmailID, Password) values (?);';
            params = [testSuit.UserId, 'testing@securifi.com', '000000'];
            CP.queryFunction(query, [params], function (err, rows) {
                console.log(err);
                if (err) callback(err);
                query = 'insert into AlmondUsers (AlmondMAC, userID, ownership) values(?);';
                params = [testSuit.AMAC, testSuit.UserId, 'P'];
                CP.queryFunction(query, [params], function (err, rows) {
                    console.log(err);
                    callback(err);
                });
            });
        });
    });
}

function deleteUser(callback) {
    var query = 'delete from AllAlmondPlus where AlmondMAC = ?';
    var params = [testSuit.AMAC];
    CP.queryFunction(query, params, function (err, rows) {
        query = 'delete from UserTempPasswords where UserId = ? and TempPassword = ?;';
        params = [testSuit.UserId, testSuit.TempPass];
        CP.queryFunction(query, params, function (err, rows) {
            if (err) callback(err);
            query = 'delete from Users where UserID = ? ;';
            params = [testSuit.UserId];
            CP.queryFunction(query, params, function (err, rows) {
                if (err) callback(err);
                query = 'delete from AlmondUsers where AlmondMAC = ? and userID = ?;';
                params = [testSuit.AMAC, testSuit.UserId];
                CP.queryFunction(query, params, function (err, rows) {
                    callback(err);
                });
            });
        });
    });
}

/*
 * NOTE: Database insertion logic is there in SiteMonitoring almond server.
 * path: notification-worker/test/forMobileServerTest.js
 * Just run the file (node forMobileServerTest.js), it will insert the neccessary
 * data into the cassandra tables.
 * Check the AMAC and CMAC are same before proceeding. (CMAC will be the first client using in the payloads.)
 */
describe('Testing Server', function () {
    before(function (done) {
        this.timeout(5000);
        // insert into db
        deleteUser(function(err) {
            createUser(function (err) {
                done(err);
            });
        });
        console.log('---------- 1 ---------');
        
    });
    it('Login Auth valid case', function (done) {
        this.timeout(5000);
        var exp = {"Data":[],"AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC};
        client.performRequest(testSuit.loginAuth3, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                var resp = JSON.parse(body);
                assert.deepEqual(resp.AMAC, exp.AMAC, 'Failed for Login Auth valid case');
                assert.deepEqual(resp.CMAC, exp.CMAC, 'Failed for Login Auth valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Login Auth fail case', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.loginAuth4, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, 'Failed ReasonCode 1234', 'Failed for Suggest rating valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    
    it('Suggest rating valid case', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.validSR, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, '', 'Failed for Suggest rating valid case');
                var query = 'SELECT * FROM browsing_log_store.categorysuggestion where mac= ? AND category= ?;';
                var params = [testSuit.validSR.AMAC, 14];  // 14 for facebook.com
                cassQueries.executeQuery(query, params, function(error,result){
                    if(error || !result || result.rows.length === 0)
                        done('Suggest Rating Failed');
                    else {
                        assert.deepEqual(result.rows[0].suggestedsubcategory, testSuit.validSR.suggestedValue, 'Failed for Suggest rating valid case');
                        done();
                    }
                });
            }
            else
                console.log(err);
        });
    });
    it('Suggest rating invalid site', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.invalidSiteSR, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, 'Send Correct Request', 'Failed for Suggest rating invalid site');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Suggest rating incorrect', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.incorrectSR, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, 'Send Correct Request', 'Failed for Suggest rating incorrect');
                done();
            }
            else
                console.log(err);
        });
    });
    it('LastWeek valid case', function (done) {
        this.timeout(5000);
        var currDate = moment(moment.utc()).utcOffset(330).format('YYYY-MM-DD');
        var exp = {
            "Data":[{"Domain":"buysellads.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"github.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":currDate,"LastVisitedEpoch":1491296504},
                {"Domain":"hipchat.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1494823545},
                {"Domain":"jslint.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"json.org","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"jsonlint.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"momentumdash.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1491296253},
                {"Domain":"npmjs.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1494823365}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":tommDate,"search":"LastWeek"
        };
        client.performRequest(testSuit.lastWeek, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for LastWeek valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('DataUsageReset valid case', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.dataUsageReset, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, 'Done', 'Failed for DataUsageReset');
                var query = 'SELECT * FROM SiteMonitoring.BW_Reset_info where mac= ? AND client_mac= ?;';
                var params = [testSuit.dataUsageReset.AMAC, testSuit.dataUsageReset.CMAC];
                CP.queryFunction(query, params, function(err, rows) {
                    if (err || rows.length == 0) {
                        done('DataBase entry failed');
                    } else {
                        console.log(rows);
                        assert.deepEqual(rows[0].date, testSuit.dataUsageReset.value, 'Failed for DataUsageReset valid case');
                        done();
                    }
                });
            }
            else
                console.log(err);
        });
    });
    it('DataUsageReset incorrect case', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.incorrectDUR, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, 'Please Send Correct Request Pattern', 'Failed for DataUsageReset');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Web History valid case', function (done) {
        this.timeout(5000);
        var exp = {
            "Data":[{"Domain":"buysellads.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"github.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":currDate,"LastVisitedEpoch":1491296504},
                {"Domain":"hipchat.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1494823545},
                {"Domain":"jslint.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"json.org","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"jsonlint.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"momentumdash.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1491296253},
                {"Domain":"npmjs.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1494823365},
                {"Domain":"atlassian.net","subCategory":"4","Category":"1","Date":"2017-05-09","LastVisitedEpoch":1494288999},
                {"Domain":"facebook.com","subCategory":"14","Category":"3","Date":"2017-05-09","LastVisitedEpoch":1494287139},
                {"Domain":"github.com","subCategory":"5","Category":"1","Date":"2017-05-09","LastVisitedEpoch":1494289659},
                {"Domain":"facebook.com","subCategory":"14","Category":"3","Date":"2017-05-07","LastVisitedEpoch":1494132939},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":"2017-05-07","LastVisitedEpoch":1494133599}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC
        };
        client.performRequest(testSuit.webHistory, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Web History valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Web History IOT valid case', function (done) { // need to check the code -- 1
        this.timeout(10000);
        client.performRequest(testSuit.webHistoryIOT, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
            }
            else
                console.log(err);
            done();
        });
    });
    it('Web History invalid case', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.invalidWebHistory, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, 'Please Send Correct Request Pattern', 'Failed for Web History invalid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('FromThisDate valid case', function (done) {
        this.timeout(5000);
        var exp = {
            "Data":[{"Domain":"facebook.com","subCategory":"14","Category":"3","Date":"2017-05-07","LastVisitedEpoch":1494132939},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":"2017-05-07","LastVisitedEpoch":1494133599}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":"2017-05-07","search":"FromThisDate"
        };
        client.performRequest(testSuit.fromThisDate, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for FromThisDate valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Bandwidth valid', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.bandwidthValid, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                var exp = {"Data":{"RX":35213,"TX":32247},"AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":"1","search":"Bandwidth","Bandwidth":1};
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Bandwidth valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Clear Bandwidth', function (done) {
        this.timeout(5000);
        client.performRequest(testSuit.clearBW, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                //assert.deepEqual(body, JSON.stringify(exp), 'Failed for FromThisDate valid case');
                var query = 'SELECT * FROM browsing_log_store.bandwidthmonitor where mac= ? AND client_mac= ?;';
                var params = [testSuit.clearBW.AMAC, testSuit.clearBW.CMAC];
                cassQueries.executeQuery(query, params, function(error,result){
                    if(error || !result || result.rows.length === 0)
                        done('Clear Bandwidth Failed');
                    else {
                        assert.deepEqual(Number(result.rows[0].rx), 0, 'Failed for Clear Bandwidth rx');
                        assert.deepEqual(Number(result.rows[0].tx), 0, 'Failed for Clear Bandwidth tx');
                        done();
                    }
                });
            }
            else
                console.log(err);
        });
    });
    it('Last Hour valid', function (done) {
        this.timeout(5000);
        var exp = {
            "Data":[{"Domain":"hipchat.com","subCategory":"4","Category":"1","Date":testSuit.lastHour.today,"LastVisitedEpoch":1494823545},
                {"Domain":"npmjs.com","subCategory":"5","Category":"1","Date":testSuit.lastHour.today,"LastVisitedEpoch":1494823365}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":testSuit.lastHour.value,"search":"LastHour"
        };
        client.performRequest(testSuit.lastHour, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Last Hour valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Domain valid', function (done) {
        this.timeout(5000);
        var exp = {
            "Data":[{"Domain":"facebook.com","subCategory":"14","Category":"3","Date":"2017-05-09","LastVisitedEpoch":1494287139},
                {"Domain":"facebook.com","subCategory":"14","Category":"3","Date":"2017-05-07","LastVisitedEpoch":1494132939}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":"facebook.com","search":"Domain"
        };
        client.performRequest(testSuit.domainSearch, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Last Hour valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Category search valid', function (done) {
        this.timeout(5000);
        var currDate = moment(moment.utc()).utcOffset(330).format('YYYY-MM-DD');
        var exp = {
            "Data":[{"Domain":"buysellads.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"github.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":currDate,"LastVisitedEpoch":1491296504},
                {"Domain":"hipchat.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1494823545},
                {"Domain":"jslint.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"json.org","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"jsonlint.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1491296254},
                {"Domain":"momentumdash.com","subCategory":"4","Category":"1","Date":currDate,"LastVisitedEpoch":1491296253},
                {"Domain":"npmjs.com","subCategory":"5","Category":"1","Date":currDate,"LastVisitedEpoch":1494823365},
                {"Domain":"atlassian.net","subCategory":"4","Category":"1","Date":"2017-05-09","LastVisitedEpoch":1494288999},
                {"Domain":"github.com","subCategory":"5","Category":"1","Date":"2017-05-09","LastVisitedEpoch":1494289659},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":"2017-05-07","LastVisitedEpoch":1494133599}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":"1","search":"Category"
        };
        client.performRequest(testSuit.categorySearch, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Last Hour valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Date search valid', function (done) {
        this.timeout(5000);
        var exp = {"Data":[{"Domain":"facebook.com","subCategory":"14","Category":"3","Date":"2017-05-07","LastVisitedEpoch":1494132939},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":"2017-05-07","LastVisitedEpoch":1494133599}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":"2017-05-07","search":"Date"
        };
        client.performRequest(testSuit.dateSearch, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Last Hour valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Weekday valid', function (done) {
        this.timeout(5000);
        var exp = {
            "Data":[{"Domain":"facebook.com","subCategory":"14","Category":"3","Date":"2017-05-07","LastVisitedEpoch":1494132939},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":"2017-05-07","LastVisitedEpoch":1494133599}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":"2017-05-07","search":"WeekDay"
        };
        client.performRequest(testSuit.weekdaySearch, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Last Hour valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Epoch valid', function (done) {
        this.timeout(5000);
        var exp = {
            "Data":[{"Domain":"google.com","Date":testSuit.epochSearch.today,"Epochs":[1491296504]}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":"google.com","search":"Epoch"
        };
        client.performRequest(testSuit.epochSearch, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Last Hour valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Present Hour', function (done) {
        this.timeout(5000);
        var exp = {
            "Data":[{"Domain":"buysellads.com","subCategory":"4","Category":"1","Date":testSuit.presentHour.today,"LastVisitedEpoch":1491296254},
                {"Domain":"github.com","subCategory":"5","Category":"1","Date":testSuit.presentHour.today,"LastVisitedEpoch":1491296254},
                {"Domain":"google.com","subCategory":"50","Category":"1","Date":testSuit.presentHour.today,"LastVisitedEpoch":1491296504},
                {"Domain":"jslint.com","subCategory":"5","Category":"1","Date":testSuit.presentHour.today,"LastVisitedEpoch":1491296254},
                {"Domain":"json.org","subCategory":"5","Category":"1","Date":testSuit.presentHour.today,"LastVisitedEpoch":1491296254},
                {"Domain":"jsonlint.com","subCategory":"5","Category":"1","Date":testSuit.presentHour.today,"LastVisitedEpoch":1491296254},
                {"Domain":"momentumdash.com","subCategory":"4","Category":"1","Date":testSuit.presentHour.today,"LastVisitedEpoch":1491296253}],
            "AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"value":testSuit.presentHour.value,"search":"PresentHour","ChangeHour":1
        };
        client.performRequest(testSuit.presentHour, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Present Hour valid case');
                done();
            }
            else
                console.log(err);
        });
    });
    it('Clear History', function (done) {
        this.timeout(5000);
        var exp = {"Data":[],"AMAC":testSuit.AMAC,"CMAC":testSuit.CMAC,"search":"ClearHistory"};
        client.performRequest(testSuit.clearHistory, function(err, resStatus, body) {
            if (!err && resStatus == 200) {
                console.log("Responce = ", body);
                assert.deepEqual(body, JSON.stringify(exp), 'Failed for Clear History');
                done();
            }
            else
                console.log(err);
        });
    });
    after(function (done) {
        // remove from db
        this.timeout(5000);
        // insert into db
        deleteUser(function (err) {
            done(err);
        });
    });
});
