var request = require('request');
var fs = require('fs');

var performRequest = {};
performRequest = function (payload, callback) {
    // Set the headers
    var headers = {
        'User-Agent': 'Super Agent/0.0.1',
        'Content-Type': 'application/x-www-form-urlencoded'
    };
    // Configure the request
    var options = {
    	key: fs.readFileSync(__dirname +'/../../certs/Securifi_2016_key.pem', 'utf8'),
    	cert: fs.readFileSync(__dirname +'/../../certs/securifi.crt', 'utf8'),
    	ca : [fs.readFileSync(__dirname +'/../../certs/gd_bundle-g2-g1-2.crt', 'utf8')],
        url: 'https://local.securifi.com:10442/SiteMonitoring', // redirected local.securifi.com to 127.0.0.1 locally
        //url: 'https://sitemonitoring-abhilashsecurifi.c9users.io:8081',
        //url: 'https://localhost:8081',
        method: 'POST',
        headers: headers,
        form: payload
    };
    request(options, function(error, response, body) {
        callback(error, response.statusCode, body);
    });
};

module.exports = {performRequest:performRequest};
