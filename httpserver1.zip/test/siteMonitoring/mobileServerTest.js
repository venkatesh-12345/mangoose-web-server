var mobileFun = require('../../siteMonitoringMobile/mobileFunctions.js');
var assert = require('chai').assert;
var qf = require('../../siteMonitoringMobile/cqlQueryFun');
var loggerPoint = require('../../database/cassandra/cqlConnection');
var config = require('nconf').get('tables');
var siteMonitoringTable = config.siteMonitoringTable;
var BandwidthTable = config.bandwidthtable;


var constructBatchDelete = function(payload, query) {
  var queries = [];
  payload.forEach(function(item) {
    console.log(item);
    var q3 = {
      query: query,
      params: [item.AMAC, item.CMAC, item.value]
    };
    queries.push(q3);
  })
  return queries;
}

var constructBatchInsert = function(payload) {
  var queries = [];
  payload.forEach(function(item) {
    console.log(item);
    query = 'INSERT INTO browsing_log_store.' + siteMonitoringTable + ' (mac,client_mac,dateyear,site,category,lastupdated,lastupdatedhour,subCategory) VALUES (?,?,?,?,?,?,?,?)';

    var q3 = {
      query: query,
      params: [item.AMAC, item.CMAC, item.value, 'testingMobile.com', 1, 1234567891, 12, 1]
    };
    queries.push(q3);
  })
  return queries;
}



function Insert(mac, client_mac, dateyear, site, category, epoch, lastHour, subCategory, callback) {
  query = 'INSERT INTO browsing_log_store.' + siteMonitoringTable + ' (mac,client_mac,dateyear,site,category,lastupdated,lastupdatedhour,subCategory) VALUES (?,?,?,?,?,?,?,?)';
  console.log("Inserted");
  loggerPoint.execute(query, [mac, client_mac, dateyear, site, category, epoch, lastHour, subCategory], {
    prepare: true
  }, function(e, o) {
    if (e) {
      //logger.logError("Error in insertIntoSiteMonitoring", e);
      console.log('Error in insertIntoSiteMonitoring', e);
    }
    else
      callback(o);
  });
}


describe("Testing FromThisDate", function() {

  var payload = [{
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'FromThisDate',
    'value': '2016-10-05'
  }, {
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'FromThisDate',
    'value': '2016-10-06'
  }]


  before(function(done) {
    this.timeout(15000);
    //console.log(constructBatchInsert(payload));
    var param = constructBatchInsert(payload);
    qf.newBatchInsert(param, function(error, result) {
      done();
    })

  });

  after(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.' + siteMonitoringTable + ' where mac = ? and client_mac = ? and dateyear = ?';
    //params = [payload1.AMAC,payload1.CMAC,payload1.FromThisDate];
    //console.log(constructBatchDelete(payload,query));
    param = constructBatchDelete(payload, query);
    qf.newBatchInsert(param, function(error, result) {
      done();
    })

  });

  it("MAC CMAC Date", function(done) {
    this.timeout(5000);
    pageState = undefined;
    payload1 = {
      'AMAC': '123',
      'CMAC': '12345',
      'search': 'FromThisDate',
      'value': '2016-10-06'
    }

    var query = (mobileFun.constructQuery(payload1)).query;
    //console.log("query =  ",query);
    var params = (mobileFun.constructQuery(payload1)).params;
    console.log("query =  ", params);

    mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {

      console.log('Result is1 = ', JSON.stringify(result.Data));
      result = JSON.stringify(result.Data);
      var arr = [];
      var data1 = JSON.parse(result)[0];
      var data2 = JSON.parse(result)[1];
//      console.log(JSON.parse(result)[0]);
    //  assert.equal(data1.mac, payload[1].AMAC, 'fails for hex 0');
     // assert.equal(data1.client_mac, payload[1].CMAC, 'fails for hex 0');
      assert.equal(data1.Date, payload[1].value, 'fails for hex 0');
//      assert.equal(data2.mac, payload[0].AMAC, 'fails for hex 0');
//      assert.equal(data2.client_mac, payload[0].CMAC, 'fails for hex 0');
      assert.equal(data2.Date, payload[0].value, 'fails for hex 0');
      done();
    })
    console.log("Params are" , params);
    console.log(payload1['AMAC']);
    assert.equal(query, 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND dateyear <= ?', 'fails for hex 0');
    assert.deepEqual(params, [payload1['AMAC'], payload1['CMAC'], payload1['value']], 'fails for hex 0');
  });
})


describe("Testing LastWeek", function() {

  var payload = [{
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'LastWeek',
    'value': '2016-10-05'
  }, {
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'LastWeek',
    'value': '2016-10-06'
  }, {
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'LastWeek',
    'value': '2016-09-27'
  }]


  before(function(done) {
    this.timeout(15000);
    var param = constructBatchInsert(payload);
    qf.newBatchInsert(param, function(error, result) {
      done();
    })

  });

  after(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.' + siteMonitoringTable + ' where mac = ? and client_mac = ? and dateyear = ?';
    //params = [payload1.AMAC,payload1.CMAC,payload1.FromThisDate];
    //console.log(constructBatchDelete(payload,query));
    param = constructBatchDelete(payload, query);
    qf.newBatchInsert(param, function(error, result) {
      done();
    })

  });

  it("MAC CMAC LastWeek", function(done) {
    this.timeout(5000);
    pageState = undefined;
    payload1 = {
      'AMAC': '123',
      'CMAC': '12345',
      'search': 'LastWeek',
      'value': '2016-10-07'
    }

    var query = (mobileFun.constructQuery(payload1)).query;
    var params = (mobileFun.constructQuery(payload1)).params;

    mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {
      var length = (result.Data).length;
      console.log('Result is1 = ', JSON.stringify(result.Data));
      result = JSON.stringify(result.Data);
      var arr = [];
      var data1 = JSON.parse(result)[0];
      var data2 = JSON.parse(result)[1];
      // var data2 = JSON.parse(result)[1];
//      assert.equal(data1.mac, payload[1].AMAC, 'fails for hex 0');
//      assert.equal(data1.client_mac, payload[1].CMAC, 'fails for hex 0');
      assert.equal(data1.Date, payload[1].value, 'fails for hex 0');
  //    assert.equal(data2.mac, payload[0].AMAC, 'fails for hex 0');
    //  assert.equal(data2.client_mac, payload[0].CMAC, 'fails for hex 0');
      assert.equal(data2.Date, payload[0].value, 'fails for hex 0');
      assert.equal(length, 2, 'fails for hex 0');
      done();
    })
    assert.equal(query, 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND dateyear < ? AND dateyear >= ?', 'fails for hex 0');
    //assert.deepEqual(params, [ payload1['AMAC'], payload1['CMAC'] , '2016-09-05' , '2016-09-29' ], 'fails for hex 0');
  });
})


describe("Testing WeekDay", function() {

  var payload = [{
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'LastWeek',
    'value': '2016-10-10'
  }, {
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'LastWeek',
    'value': '2016-09-27'
  }]


  before(function(done) {
    this.timeout(15000);
    var param = constructBatchInsert(payload);
    qf.newBatchInsert(param, function(error, result) {
      done();
    })

  });

  after(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.' + siteMonitoringTable + ' where mac = ? and client_mac = ? and dateyear = ?';
    //params = [payload1.AMAC,payload1.CMAC,payload1.FromThisDate];
    //console.log(constructBatchDelete(payload,query));
    param = constructBatchDelete(payload, query);
    qf.newBatchInsert(param, function(error, result) {
      done();
    })

  });

  it("MAC CMAC WeekDay", function(done) {
    this.timeout(5000);
    pageState = undefined;
    payload1 = {
      'AMAC': '123',
      'CMAC': '12345',
      'search': 'WeekDay',
      'value': '2016-10-10'
    }

    var query = (mobileFun.constructQuery(payload1)).query;
    var params = (mobileFun.constructQuery(payload1)).params;

    mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {
      var length = (result.Data).length;
      console.log('Result is1 = ', JSON.stringify(result.Data));
      result = JSON.stringify(result.Data);
      var arr = [];
      var data1 = JSON.parse(result)[0];
      // var data2 = JSON.parse(result)[1];
      //assert.equal(data1.mac, payload[0].AMAC, 'fails for hex 0');
      //assert.equal(data1.client_mac, payload[0].CMAC, 'fails for hex 0');
      assert.equal(data1.Date, payload[0].value, 'fails for hex 0');
      assert.equal(length, 1, 'fails for hex 0');
      done();
    })
    assert.equal(query, "SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND dateyear IN ?", 'fails for hex 0');
    //assert.deepEqual(params, [ payload1['AMAC'], payload1['CMAC'] , '2016-09-05' , '2016-09-29' ], 'fails for hex 0');
  });
})

describe("Testing Date", function() {

  var payload = [{
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'Date',
    'value': '2016-10-05'
  }, {
    'AMAC': '123',
    'CMAC': '12346',
    'search': 'Date',
    'value': '2016-10-05'
  }]


  before(function(done) {
    this.timeout(15000);
    //console.log(constructBatchInsert(payload));
    var param = constructBatchInsert(payload);
    qf.newBatchInsert(param, function(error, result) {
      done();
    })

  });

  after(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.' + siteMonitoringTable + ' where mac = ? and client_mac = ? and dateyear = ?';
    //params = [payload1.AMAC,payload1.CMAC,payload1.FromThisDate];
    //console.log(constructBatchDelete(payload,query));
    param = constructBatchDelete(payload, query);
    qf.newBatchInsert(param, function(error, result) {
      done();
    })

  });

  it("MAC CMAC Date", function(done) {
    this.timeout(5000);
    pageState = undefined;
    payload1 = {
      'AMAC': '123',
      'CMAC': '12345',
      'search': 'Date',
      'value': '2016-10-05'
    }

    var query = (mobileFun.constructQuery(payload1)).query;
    //console.log("query =  ",query);
    var params = (mobileFun.constructQuery(payload1)).params;
    console.log("query =  ", params);

    mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {

      console.log('Result is1 = ', JSON.stringify(result.Data));
      result = JSON.stringify(result.Data);
      var arr = [];
      var data1 = JSON.parse(result)[0];
      var data2 = JSON.parse(result)[1];
      // var data2 = JSON.parse(result)[1];
      //assert.equal(data1.mac, payload[0].AMAC, 'fails for hex 0');
      //assert.equal(data1.client_mac, payload[0].CMAC, 'fails for hex 0');
      assert.equal(data1.Date, payload[0].value, 'fails for hex 0');
      done();
    })
    assert.equal(query, 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND dateyear = ?', 'fails for hex 0');
    assert.deepEqual(params, [payload1['AMAC'], payload1['CMAC'], payload1['value']], 'fails for hex 0');
  });
})


describe("Testing Domain", function() {

  var payload = [{
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'Domain',
    'value': 'facebook.com',
    'today': '2016-10-12'
  }, {
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'Domain',
    'value': 'face',
    'today': '2016-10-11'
  }, {
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'Domain',
    'value': 'faca',
    'today': '2016-10-12'
  }, {
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'Domain',
    'value': 'facee.com',
    'today': '2016-10-03'
  }, {
    'AMAC': '123',
    'CMAC': '12345',
    'search': 'Domain',
    'value': 'face.net',
    'today': '2016-10-10'
  }]


  before(function(done) {
    this.timeout(15000);
    //console.log(constructBatchInsert(payload));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      query = 'INSERT INTO browsing_log_store.' + siteMonitoringTable + ' (mac,client_mac,dateyear,site,category,lastupdated,lastupdatedhour,subCategory) VALUES (?,?,?,?,?,?,?,?)';

      var q3 = {
        query: query,
        params: [item.AMAC, item.CMAC, item.today, item.value, 1, 1234567891, 12, 1]
      };
      queries.push(q3);
    })
    qf.newBatchInsert(queries, function(error, result) {
      done();
    })

  });

  after(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.' + siteMonitoringTable + ' where mac = ? and client_mac = ? and dateyear = ? and site = ?';
    //params = [payload1.AMAC,payload1.CMAC,payload1.FromThisDate];
    //console.log(constructBatchDelete(payload,query));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      var q3 = {
        query: query,
        params: [item.AMAC, item.CMAC, item.today, item.value]
      };
      queries.push(q3);
    })
    qf.newBatchInsert(queries, function(error, result) {
      done();
    })

  });

  it("MAC CMAC Domain", function(done) {
    this.timeout(5000);
    pageState = undefined;
    payload1 = {
      'AMAC': '123',
      'CMAC': '12345',
      'search': 'Domain',
      'value': 'face',
      'today': '2016-10-12'
    }

    var query = (mobileFun.constructQuery(payload1)).query;
    //console.log("query =  ",query);
    var params = (mobileFun.constructQuery(payload1)).params;
    console.log("query =  ", params);

    mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {
      var length = (result.Data).length;
      console.log('Result is1 = ', JSON.stringify(result.Data));
      result = JSON.stringify(result.Data);
      var arr = [];
      var data1 = JSON.parse(result)[0];
      var data2 = JSON.parse(result)[1];
      var data3 = JSON.parse(result)[2];
      // var data2 = JSON.parse(result)[1];
      //assert.equal(data1.mac, payload[0].AMAC, 'fails for hex 0');
      //assert.equal(data1.client_mac, payload[0].CMAC, 'fails for hex 0');
      assert.equal(data1.Domain, payload[0].value, 'fails for hex 0');
      //assert.equal(data2.mac, payload[1].AMAC, 'fails for hex 0');
      //assert.equal(data2.client_mac, payload[1].CMAC, 'fails for hex 0');
      assert.equal(data2.Domain, payload[1].value, 'fails for hex 0');
      //assert.equal(data3.mac, payload[4].AMAC, 'fails for hex 0');
      //assert.equal(data3.client_mac, payload[4].CMAC, 'fails for hex 0');
      assert.equal(data3.Domain, payload[4].value, 'fails for hex 0');
      assert.equal(length, 3, 'fails for hex 0');
      done();
    })
    assert.equal(query, 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND dateyear IN ? AND site >= ? AND site < ?', 'fails for hex 0');
    //assert.deepEqual(params, [ payload1['AMAC'], payload1['CMAC'] , payload1['value'] ], 'fails for hex 0');
  });
})

describe("Testing LastHour", function() {

  var payload = [{
      'AMAC': '123',
      'CMAC': '12345',
      'site': 'test1.com',
      'value': '15',
      'today': '2016-10-12'
    }, {
      'AMAC': '123',
      'CMAC': '12345',
      'site': 'test2.com',
      'value': '15',
      'today': '2016-10-12'
    }, {
      'AMAC': '123',
      'CMAC': '12345',
      'site': 'test3.com',
      'value': '16',
      'today': '2016-10-12'
    }]
    // 

  beforeEach(function(done) {
    this.timeout(15000);
    //console.log(constructBatchInsert(payload));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      query = 'INSERT INTO browsing_log_store.' + siteMonitoringTable + ' (mac,client_mac,dateyear,site,category,lastupdated,lastupdatedhour,subCategory) VALUES (?,?,?,?,?,?,?,?)';
      var q3 = {
        query: query,
        params: [item.AMAC, item.CMAC, item.today, item.site, 1, 1234567891, item.value, 1]
      };
      queries.push(q3);
    })
    qf.newBatchInsert(queries, function(error, result) {
      done();
    })

  });

  afterEach(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.' + siteMonitoringTable + ' where mac = ? and client_mac = ? and dateyear = ? and site = ?';
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      var q3 = {
        query: query,
        params: [item.AMAC, item.CMAC, item.today, item.site]
      };
      queries.push(q3);
    })
    qf.newBatchInsert(queries, function(error, result) {
      done();
    })

  });

  it("MAC CMAC PresentHour", function(done) {
    this.timeout(5000);
    pageState = undefined;
    payload1 = {
      'AMAC': '123',
      'CMAC': '12345',
      'search': 'PresentHour',
      'value': '16:30',
      'today' : '2016-10-12'
    }

    var query = (mobileFun.constructQuery(payload1)).query;
    //console.log("query =  ",query);
    var params = (mobileFun.constructQuery(payload1)).params;
    console.log("query =  ", params);

    mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {
      var changeHour = result.ChangeHour;
      console.log('ChangeHour is ', JSON.stringify(result));
      result = JSON.stringify(result.Data);
      var arr = [];
      var data1 = JSON.parse(result)[0];
      // var data2 = JSON.parse(result)[1];
      //assert.equal(data1.mac, payload[2].AMAC, 'fails for hex 0');
      //assert.equal(data1.client_mac, payload[2].CMAC, 'fails for hex 0');
      assert.equal(data1.Date, payload[2].today, 'fails for hex 0');
      //assert.equal(data1.lastupdatedhour, 16, 'fails for hex 0');
      done();
    })
    assert.equal(query, 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND lastupdatedhour = ? AND dateyear = ?', 'fails for hex 0');
    //assert.deepEqual(params, [ payload1['AMAC'], payload1['CMAC'] , payload1['value'] ], 'fails for hex 0');
  });
  it("MAC CMAC LastHour", function(done) {
    this.timeout(5000);
    pageState = undefined;
    payload1 = {
      'AMAC': '123',
      'CMAC': '12345',
      'search': 'LastHour',
      'value': '16:30',
      'today' : '2016-10-12'
    }

    var query = (mobileFun.constructQuery(payload1)).query;
    //console.log("query =  ",query);
    var params = (mobileFun.constructQuery(payload1)).params;
    console.log("query =  ", params);

    mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {

      console.log('Result is1 = ', JSON.stringify(result.Data));
      result = JSON.stringify(result.Data);
      var arr = [];
      var data1 = JSON.parse(result)[0];
      var data2 = JSON.parse(result)[1];
      //assert.equal(data1.mac, payload[0].AMAC, 'fails for hex 0');
      //assert.equal(data1.client_mac, payload[0].CMAC, 'fails for hex 0');
      assert.equal(data1.Date, payload[0].today, 'fails for hex 0');
      //assert.equal(data1.lastupdatedhour, 15, 'fails for hex 0');
      //assert.equal(data2.mac, payload[1].AMAC, 'fails for hex 0');
      //assert.equal(data2.client_mac, payload[1].CMAC, 'fails for hex 0');
      assert.equal(data2.Date, payload[1].today, 'fails for hex 0');
      //assert.equal(data2.lastupdatedhour, 15, 'fails for hex 0');
      done();
    })
    assert.equal(query, 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.'+siteMonitoringTable+' WHERE mac = ? AND client_mac = ? AND lastupdatedhour = ? AND dateyear = ?', 'fails for hex 0');
    //assert.deepEqual(params, [ payload1['AMAC'], payload1['CMAC'] , payload1['value'] ], 'fails for hex 0');
  });
})

describe("Testing Category", function() {

  var payload = [{
    'AMAC': '123',
    'CMAC': '12347',
    'site': 'testingcategory1',
    'value': '1',
    'today': '2016-10-12'
  }, {
    'AMAC': '123',
    'CMAC': '12347',
    'site': 'testingcategory2',
    'value': '1',
    'today': '2016-10-11'
  }, {
    'AMAC': '123',
    'CMAC': '12347',
    'site': 'testingcategory3',
    'value': '2',
    'today': '2016-10-12'
  }]


  before(function(done) {
    this.timeout(15000);
    //console.log(constructBatchInsert(payload));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      query = 'INSERT INTO browsing_log_store.' + siteMonitoringTable + ' (mac,client_mac,dateyear,site,category,lastupdated,lastupdatedhour,subCategory) VALUES (?,?,?,?,?,?,?,?)';

      var q3 = {
        query: query,
        params: [item.AMAC, item.CMAC, item.today, item.site, 3, 1234567891, 12, item.value]
      };
      queries.push(q3);
    })
    qf.newBatchInsert(queries, function(error, result) {
      done();
    })

  });

  after(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.' + siteMonitoringTable + ' where mac = ? and client_mac = ? and dateyear = ? and site = ?';
    //params = [payload1.AMAC,payload1.CMAC,payload1.FromThisDate];
    //console.log(constructBatchDelete(payload,query));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      var q3 = {
        query: query,
        params: [item.AMAC, item.CMAC, item.today, item.site]
      };
      queries.push(q3);
    })
    qf.newBatchInsert(queries, function(error, result) {
      done();
    })

  });

  it("MAC CMAC Category", function(done) {
    this.timeout(5000);
    pageState = undefined;
    payload1 = {
      'AMAC': '123',
      'CMAC': '12347',
      'search': 'Category',
      'value': '1',
      'today': '2016-10-12'
    }

    var query = (mobileFun.constructQuery(payload1)).query;
    //console.log("query =  ",query);
    var params = (mobileFun.constructQuery(payload1)).params;
    console.log("query =  ", params);

    mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {
      var length = (result.Data).length;
      console.log('Result is1 = ', JSON.stringify(result.Data));
      result = JSON.stringify(result.Data);
      var arr = [];
      var data1 = JSON.parse(result)[0];
      var data2 = JSON.parse(result)[1];
      // var data2 = JSON.parse(result)[1];
      //assert.equal(data1.mac, payload[0].AMAC, 'fails for hex 0');
      //assert.equal(data1.client_mac, payload[0].CMAC, 'fails for hex 0');
      assert.equal(data1.Category, payload[0].value, 'fails for hex 0');
      //assert.equal(data2.mac, payload[1].AMAC, 'fails for hex 0');
      //assert.equal(data2.client_mac, payload[1].CMAC, 'fails for hex 0');
      assert.equal(data2.Category, payload[1].value, 'fails for hex 0');
      done();
    })
    assert.equal(query, 'SELECT dateyear,site,category,lastupdated,subcategory FROM browsing_log_store.log_3 WHERE mac = ? AND client_mac = ? AND subCategory = ?', 'fails for hex 0');
    //assert.deepEqual(params, [ payload1['AMAC'], payload1['CMAC'] , payload1['value'] ], 'fails for hex 0');
  });
})


describe("Testing Bandwidth", function() {

  var payload = [{
    'AMAC': '123455',
    'CMAC': '12347',
    'site': 'testingcategory1',
    'value': '1',
    'today': '2016-10-12',
    'rx': '5',
    'tx': '7'
  }, {
    'AMAC': '123455',
    'CMAC': '12346',
    'site': 'testingcategory2',
    'value': '1',
    'today': '2016-10-11',
    'rx': '5',
    'tx': '7'
  }, {
    'AMAC': '123455',
    'CMAC': '12348',
    'site': 'testingcategory3',
    'value': '2',
    'today': '2016-10-12',
    'rx': '5',
    'tx': '7'
  }]


  before(function(done) {
    this.timeout(15000);
    //console.log(constructBatchInsert(payload));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      query = 'update browsing_log_store.' + BandwidthTable + ' set rx = rx + ? , tx = tx + ? where mac = ? and client_mac = ? and dateyear = ?';

      var q3 = {
        query: query,
        params: [parseInt(item.rx), parseInt(item.tx), parseInt(item.AMAC), parseInt(item.CMAC), item.today]
      };
      queries.push(q3);
    })
    //console.log(queries);
    qf.counterBatch(queries, function(error, result) {
      //console.log("Error = ",error);
      //console.log("Result",result);
      done();
    }) 

  });

  after(function(done) {
    this.timeout(15000);
    query = 'update browsing_log_store.' + BandwidthTable + ' set rx = rx - ? , tx = tx - ? where mac = ? and client_mac = ? and dateyear = ?';
    //params = [payload1.AMAC,payload1.CMAC,payload1.FromThisDate];
    //console.log(constructBatchDelete(payload,query));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      var q3 = {
        query: query,
        params: [parseInt(item.rx), parseInt(item.tx), parseInt(item.AMAC), parseInt(item.CMAC), item.today]
      };
      queries.push(q3);
    })
    qf.counterBatch(queries, function(error, result) {
      console.log(error);
      done();
    })

  });

  it("MAC CMAC Bandwidth", function(done) {
    this.timeout(5000);
    pageState = undefined;
    var i = 0;

    payload.forEach(function(item)
    {
      payload1 = {
      'AMAC': item.AMAC,
      'CMAC': item.CMAC,
      'search': 'Bandwidth',
      'today': item.today,
      'value' : 1
      }
      console.log("-----------------------------------------",payload1.today);

      var query = (mobileFun.constructQuery(payload1)).query;
      var params = (mobileFun.constructQuery(payload1)).params;
      //console.log("query =  ", query);
      //console.log("params = ", params);

      mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {
        console.log('Result is1 = ', JSON.stringify(result.Data));
        result = JSON.stringify(result.Data);
        var arr = [];
        var data1 = JSON.parse(result)[0];
        console.log("_++++++++_+_++++++++++++++++++++++++++++++++++++++++++____________",data1.rx);
         assert.equal(data1.rx, item.rx, 'fails for hex 0');
         assert.equal(data1.tx, item.tx, 'fails for hex 0');
        i++;
        if(i == payload.length)
        {
          done();
        }
      })
      assert.equal(query, 'SELECT rx,tx FROM browsing_log_store.bandwidthmonitor WHERE mac = ? AND client_mac = ? AND dateyear <= ? AND dateyear > ?', 'fails for hex 0');
    })
  });
})


describe("Testing Epochs", function() {

  var payload = [{
    'AMAC': '123456',
    'CMAC': '12347',
    'site': 'testingcategory1',
    'value': '1',
    'today': '2016-10-12',
    'epochs' : '1234567891'
  }, {
    'AMAC': '123456',
    'CMAC': '12347',
    'site': 'testingcategory2',
    'value': '1',
    'today': '2016-10-12',
    'epochs' : '1234567892'
  }, {
    'AMAC': '123456',
    'CMAC': '12347',
    'site': 'testingcategory1',
    'value': '2',
    'today': '2016-10-12',
    'epochs' : '1234567893'
  }]


  before(function(done) {
    this.timeout(15000);
    //console.log(constructBatchInsert(payload));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      query = 'update browsing_log_store.'+siteMonitoringTable+' set epochs = epochs + ? where mac = ? and client_mac = ? and dateyear = ? and site = ?';

      var q3 = {
        query: query,
        params: [[parseInt(item.epochs)], parseInt(item.AMAC), parseInt(item.CMAC), item.today,item.site]
      };
      queries.push(q3);
    })
    //console.log(queries);
    qf.newBatchInsert(queries, function(error, result) {
      console.log("Error = ",error);
      //console.log("Result",result);
      done();
    }) 

  });

  after(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.' + siteMonitoringTable + '  where mac = ? and client_mac = ? and dateyear = ? and site = ?';
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      var q3 = {
        query: query,
        params: [parseInt(item.AMAC), parseInt(item.CMAC),item.today, item.site]
      };
      queries.push(q3);
    })
    qf.newBatchInsert(queries, function(error, result) {
      console.log(error);
      done();
    })

  });

  it("MAC CMAC Epoch", function(done) {
    this.timeout(10000);
    pageState = undefined;
    var i = 0;

    //payload.forEach(function(item)
  //  {
      payload1 = {
      'AMAC': payload[0].AMAC,
      'CMAC': payload[0].CMAC,
      'search': 'Epoch',
      'today': payload[0].today,
      'value' : 'testingcategory1'
      }

      var query = (mobileFun.constructQuery(payload1)).query;
      var params = (mobileFun.constructQuery(payload1)).params;

      mobileFun.getBrowsingDataForClient1(query, params, pageState, function(error, result) {
        console.log('Result is1 = ', JSON.stringify(result.Data));
        result = JSON.stringify(result.Data);
        var arr = [];
        var data1 = JSON.parse(result)[0];
//        console.log("_++++++++_+_++++++++++++++++++++++++++++++++++++++++++____________",data1.rx);
         assert.equal(data1.Domain, payload1.value, 'fails for hex 0');
         assert.equal(data1.Date, payload1.today, 'fails for hex 0');
         assert.deepEqual(data1.Epochs, [ parseInt(payload[0].epochs), parseInt(payload[2].epochs) ], 'fails for hex 0');

          done();
      })
      assert.equal(query, 'SELECT dateyear,site,epochs FROM browsing_log_store.'+siteMonitoringTable+' WHERE mac = ? AND client_mac = ? AND dateyear = ? and site = ?', 'fails for hex 0');
//    })
  });
})


describe("Testing SuggesCategory", function() {

  var payload = [{
    'AMAC': '12345678',
    'CMAC': '1234712',
    'search' : 'SuggestRating',
    'value': 'facebook.com',
    'today': '2016-10-12',
    'epochs' : '1234567891',
    'suggestedValue' : '7',
  }, {
    'AMAC': '12345678',
    'CMAC': '1234712',
    'search': 'SuggestRating',
    'value': 'baidu.com',
    'today': '2016-10-12',
    'epochs' : '1234567892',
    'suggestedValue' : '8'
  }]


  before(function(done) {
    this.timeout(15000);
    //console.log(constructBatchInsert(payload));
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      query = 'INSERT into browsing_log_store.categorysuggestion (category,mac,oldsubcategory,suggestedsubcategory) values (14 , ?,1 ,1)';
      var q3 = {
        query: query,
        params: [ parseInt(item.AMAC)]
      };
      queries.push(q3);
    })
    //console.log(queries);
    qf.newBatchInsert(queries, function(error, result) {
      if(error) console.log(error);
      //console.log("Result",result);
      done();
    }) 

  });

  after(function(done) {
    this.timeout(15000);
    query = 'delete from browsing_log_store.categorysuggestion  where mac = ? and category = ?';
    var queries = [];
    payload.forEach(function(item) {
      //console.log(item);
      var q3 = {
        query: query,
        params: [parseInt(item.AMAC), 14]
      };
      queries.push(q3);
    })
    qf.newBatchInsert(queries, function(error, result) {
      console.log(error);
      done();
    })
  });

  it("MAC CMAC SuggessCategory", function(done) {
    this.timeout(10000);
    pageState = undefined;
    var i = 0;

    //payload.forEach(function(item)
  //  {
      payload1 = {
      'AMAC': payload[0].AMAC,
      'CMAC': payload[0].CMAC,
      'search': 'SuggestRating',
      'today': payload[0].today,
      'suggestedValue' : 5,
      'value' : payload[0].value
      }

      mobileFun.UpdateCategory(payload1,function(query){
        //console.log("Returned_______________________________",query,"++++++++++++++++++++++++++++++++");
        assert.equal(query.querystatus, 1 , 'Query Not proper or wrong variables passed');
        mobileFun.getBrowsingDataForClient1(query.query, query.params, pageState, function(error, result) {
          if(error) console.log(error);
          query = "select * from browsing_log_store.categorysuggestion where mac = 12345678 and category = 14";
          loggerPoint.execute(query,function(error,result){
            if(error) console.log(error);
            //console.log(result.rows[0].suggestedsubcategory);
            assert.equal(result.rows[0].suggestedsubcategory, 5 , 'Query Not proper or wrong variables passed');
            done();
          })
        })
      });
  });
})

