var assert = require('chai').assert;
var handler = require('../handling-IOT-ScanResults.js');
var data = require('./IOTtestData.js');

describe('Testing IOT Scanner handler', function() {
var body1,body2;
    beforeEach(function() {
        this.timeout(15000);
        body1 = data.wrongResult;
        body2 = data.correctData;
    });

    it("testing IOT Handler function", function() {
    	json1 = handler.validateJson(body1);
    	json2 = handler.validateJson(body2);
    });
});