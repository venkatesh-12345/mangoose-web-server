var multiline = require("multiline"),

SITE_LOG = multiline(function() {
/*
{
	"MAC": "123",
	"TZ": "+0530",
	"Data": {
		"0": {
			"RX": "67002",
			"TX": "93639",
			"Sites": {
				"sitePresentinDB.com": ["12345", "1"],
				"sitePresentinDB2.com": ["12345", "1"],
				"sitePresentinDB3.com": ["12345", "1"],
				"sitePresentinDB4.com": ["12345", "1"],
				"sitePresentinDB5.com": ["12345", "1"],
				"siteAbsentFromDB.com": ["1472734360", "1"],
				"siteAbsentFromDB2.com": ["1472734360", "1"],
				"siteAbsentFromDB3.com": ["1472734360", "1"],
				"siteAbsentFromDB4.com": ["1472734360", "1"],
				"siteAbsentFromDB5.com": ["1472734360", "1"]
			}
		}
	}
}
*/
});
SITE_LOG5= multiline(function(){
/*
{
	"MAC": "123",
	"TZ": "+0530",
	"Data": {
		"0": {
			"RX": "67002",
			"TX": "93639",
			"Sites": {
				"sitePresentinDB.com": ["12345", "1"],
				"sitePresentinDB2.com": ["12345", "1"],
				"sitePresentinDB3.com": ["12345", "1"],
				"sitePresentinDB4.com": ["12345", "1"],
				"sitePresentinDB5.com": ["12345", "1"],
				"sitePresentinDB6.com": ["12345", "1"],
				"sitePresentinDB7.com": ["12345", "1"],
				"sitePresentinDB8.com": ["12345", "1"],
				"sitePresentinDB9.com": ["12345", "1"],
				"sitePresentinDB10.com": ["12345", "1"],
				"sitePresentinDB11.com": ["12345", "1"],
				"sitePresentinDB12.com": ["12345", "1"],
				"sitePresentinDB13.com": ["12345", "1"],
				"sitePresentinDB14.com": ["12345", "1"],
				"sitePresentinDB15.com": ["12345", "1"],
				"sitePresentinDB16.com": ["12345", "1"],
				"sitePresentinDB17.com": ["12345", "1"],
				"sitePresentinDB18.com": ["12345", "1"],
				"sitePresentinDB19.com": ["12345", "1"],
				"sitePresentinDB20.com": ["12345", "1"],
				"sitePresentinDB21.com": ["12345", "1"],
				"sitePresentinDB22.com": ["12345", "1"],
				"sitePresentinDB23.com": ["12345", "1"],
				"sitePresentinDB24.com": ["12345", "1"],
				"sitePresentinDB25.com": ["12345", "1"],
				"sitePresentinDB26.com": ["12345", "1"],
				"sitePresentinDB27.com": ["12345", "1"],
				"sitePresentinDB28.com": ["12345", "1"],
				"sitePresentinDB29.com": ["12345", "1"],
				"sitePresentinDB30.com": ["12345", "1"],
				"sitePresentinDB31.com": ["12345", "1"],
				"sitePresentinDB32.com": ["12345", "1"],
				"sitePresentinDB33.com": ["12345", "1"],
				"sitePresentinDB34.com": ["12345", "1"],
				"sitePresentinDB35.com": ["12345", "1"],
				"sitePresentinDB36.com": ["12345", "1"],
				"sitePresentinDB37.com": ["12345", "1"],
				"sitePresentinDB38.com": ["12345", "1"],
				"sitePresentinDB39.com": ["12345", "1"],
				"sitePresentinDB40.com": ["12345", "1"],
				"sitePresentinDB41.com": ["12345", "1"],
				"sitePresentinDB42.com": ["12345", "1"],
				"sitePresentinDB43.com": ["12345", "1"],
				"sitePresentinDB44.com": ["12345", "1"],
				"sitePresentinDB45.com": ["12345", "1"],
				"sitePresentinDB46.com": ["12345", "1"],
				"sitePresentinDB47.com": ["12345", "1"],
				"sitePresentinDB48.com": ["12345", "1"],
				"sitePresentinDB49.com": ["12345", "1"],
				"sitePresentinDB50.com": ["12345", "1"],
				"sitePresentinDB51.com": ["12345", "1"],
				"sitePresentinDB52.com": ["12345", "1"],
				"sitePresentinDB53.com": ["12345", "1"],
				"sitePresentinDB54.com": ["12345", "1"],
				"sitePresentinDB55.com": ["12345", "1"],
				"sitePresentinDB56.com": ["12345", "1"],
				"sitePresentinDB57.com": ["12345", "1"],
				"sitePresentinDB58.com": ["12345", "1"],
				"sitePresentinDB59.com": ["12345", "1"],
				"sitePresentinDB60.com": ["12345", "1"],
				"sitePresentinDB61.com": ["12345", "1"],
				"sitePresentinDB62.com": ["12345", "1"],
				"sitePresentinDB63.com": ["12345", "1"],
				"sitePresentinDB64.com": ["12345", "1"],
				"sitePresentinDB65.com": ["12345", "1"],
				"sitePresentinDB66.com": ["12345", "1"],
				"sitePresentinDB67.com": ["12345", "1"],
				"sitePresentinDB68.com": ["12345", "1"],
				"sitePresentinDB69.com": ["12345", "1"],
				"sitePresentinDB70.com": ["12345", "1"],
				"sitePresentinDB71.com": ["12345", "1"],
				"sitePresentinDB72.com": ["12345", "1"],
				"sitePresentinDB73.com": ["12345", "1"],
				"sitePresentinDB74.com": ["12345", "1"],
				"sitePresentinDB75.com": ["12345", "1"],
				"sitePresentinDB76.com": ["12345", "1"],
				"sitePresentinDB77.com": ["12345", "1"],
				"sitePresentinDB78.com": ["12345", "1"],
				"sitePresentinDB79.com": ["12345", "1"],
				"sitePresentinDB80.com": ["12345", "1"],
				"sitePresentinDB81.com": ["12345", "1"],
				"sitePresentinDB82.com": ["12345", "1"],
				"sitePresentinDB83.com": ["12345", "1"],
				"sitePresentinDB84.com": ["12345", "1"],
				"sitePresentinDB85.com": ["12345", "1"],
				"sitePresentinDB86.com": ["12345", "1"],
				"sitePresentinDB87.com": ["12345", "1"],
				"sitePresentinDB88.com": ["12345", "1"],
				"sitePresentinDB89.com": ["12345", "1"],
				"sitePresentinDB90.com": ["12345", "1"],
				"sitePresentinDB91.com": ["12345", "1"],
				"sitePresentinDB92.com": ["12345", "1"],
				"sitePresentinDB93.com": ["12345", "1"],
				"sitePresentinDB94.com": ["12345", "1"],
				"sitePresentinDB95.com": ["12345", "1"],
				"sitePresentinDB96.com": ["12345", "1"],
				"sitePresentinDB97.com": ["12345", "1"],
				"sitePresentinDB98.com": ["12345", "1"],
				"sitePresentinDB99.com": ["12345", "1"],
				"sitePresentinDB100.com": ["12345", "1"],
				"sitePresentinDB101.com": ["12345", "1"],
				"sitePresentinDB102.com": ["12345", "1"],
				"sitePresentinDB103.com": ["12345", "1"],
				"sitePresentinDB104.com": ["12345", "1"],
				"sitePresentinDB105.com": ["12345", "1"],
				"sitePresentinDB106.com": ["12345", "1"],
				"sitePresentinDB107.com": ["12345", "1"],
				"sitePresentinDB108.com": ["12345", "1"],
				"sitePresentinDB109.com": ["12345", "1"],
				"sitePresentinDB110.com": ["12345", "1"],
				"sitePresentinDB111.com": ["12345", "1"],
				"sitePresentinDB112.com": ["12345", "1"],
				"sitePresentinDB113.com": ["12345", "1"],
				"sitePresentinDB114.com": ["12345", "1"],
				"sitePresentinDB115.com": ["12345", "1"],
				"sitePresentinDB116.com": ["12345", "1"],
				"sitePresentinDB117.com": ["12345", "1"],
				"sitePresentinDB118.com": ["12345", "1"],
				"sitePresentinDB119.com": ["12345", "1"],
				"sitePresentinDB120.com": ["12345", "1"],
				"sitePresentinDB121.com": ["12345", "1"],
				"sitePresentinDB122.com": ["12345", "1"],
				"sitePresentinDB123.com": ["12345", "1"],
				"sitePresentinDB124.com": ["12345", "1"],
				"sitePresentinDB125.com": ["12345", "1"],
				"sitePresentinDB126.com": ["12345", "1"],
				"sitePresentinDB127.com": ["12345", "1"],
				"sitePresentinDB128.com": ["12345", "1"],
				"sitePresentinDB129.com": ["12345", "1"],
				"sitePresentinDB130.com": ["12345", "1"],
				"sitePresentinDB131.com": ["12345", "1"],
				"sitePresentinDB132.com": ["12345", "1"],
				"sitePresentinDB133.com": ["12345", "1"],
				"sitePresentinDB134.com": ["12345", "1"],
				"sitePresentinDB135.com": ["12345", "1"],
				"sitePresentinDB136.com": ["12345", "1"],
				"sitePresentinDB137.com": ["12345", "1"],
				"sitePresentinDB138.com": ["12345", "1"],
				"sitePresentinDB139.com": ["12345", "1"],
				"sitePresentinDB140.com": ["12345", "1"],
				"sitePresentinDB141.com": ["12345", "1"],
				"sitePresentinDB142.com": ["12345", "1"],
				"sitePresentinDB143.com": ["12345", "1"],
				"sitePresentinDB144.com": ["12345", "1"],
				"sitePresentinDB145.com": ["12345", "1"],
				"sitePresentinDB146.com": ["12345", "1"],
				"sitePresentinDB147.com": ["12345", "1"],
				"sitePresentinDB148.com": ["12345", "1"],
				"sitePresentinDB149.com": ["12345", "1"],
				"sitePresentinDB150.com": ["12345", "1"],
				"sitePresentinDB151.com": ["12345", "1"],
				"sitePresentinDB152.com": ["12345", "1"],
				"sitePresentinDB153.com": ["12345", "1"],
				"sitePresentinDB154.com": ["12345", "1"],
				"sitePresentinDB155.com": ["12345", "1"],
				"sitePresentinDB156.com": ["12345", "1"],
				"sitePresentinDB157.com": ["12345", "1"],
				"sitePresentinDB158.com": ["12345", "1"],
				"sitePresentinDB159.com": ["12345", "1"],
				"sitePresentinDB160.com": ["12345", "1"],
				"sitePresentinDB161.com": ["12345", "1"],
				"sitePresentinDB162.com": ["12345", "1"],
				"sitePresentinDB163.com": ["12345", "1"],
				"sitePresentinDB164.com": ["12345", "1"],
				"sitePresentinDB165.com": ["12345", "1"],
				"sitePresentinDB166.com": ["12345", "1"],
				"sitePresentinDB167.com": ["12345", "1"],
				"sitePresentinDB168.com": ["12345", "1"],
				"sitePresentinDB169.com": ["12345", "1"],
				"sitePresentinDB170.com": ["12345", "1"],
				"sitePresentinDB171.com": ["12345", "1"],
				"sitePresentinDB172.com": ["12345", "1"],
				"sitePresentinDB173.com": ["12345", "1"],
				"sitePresentinDB174.com": ["12345", "1"],
				"sitePresentinDB175.com": ["12345", "1"],
				"sitePresentinDB176.com": ["12345", "1"],
				"sitePresentinDB177.com": ["12345", "1"],
				"sitePresentinDB178.com": ["12345", "1"],
				"sitePresentinDB179.com": ["12345", "1"],
				"sitePresentinDB180.com": ["12345", "1"],
				"sitePresentinDB181.com": ["12345", "1"],
				"sitePresentinDB182.com": ["12345", "1"],
				"sitePresentinDB183.com": ["12345", "1"],
				"sitePresentinDB184.com": ["12345", "1"],
				"sitePresentinDB185.com": ["12345", "1"],
				"sitePresentinDB186.com": ["12345", "1"],
				"sitePresentinDB187.com": ["12345", "1"],
				"sitePresentinDB188.com": ["12345", "1"],
				"sitePresentinDB189.com": ["12345", "1"],
				"sitePresentinDB190.com": ["12345", "1"],
				"sitePresentinDB191.com": ["12345", "1"],
				"sitePresentinDB192.com": ["12345", "1"],
				"sitePresentinDB193.com": ["12345", "1"],
				"sitePresentinDB194.com": ["12345", "1"],
				"sitePresentinDB195.com": ["12345", "1"],
				"sitePresentinDB196.com": ["12345", "1"],
				"sitePresentinDB197.com": ["12345", "1"],
				"sitePresentinDB198.com": ["12345", "1"],
				"sitePresentinDB199.com": ["12345", "1"],
				"sitePresentinDB200.com": ["12345", "1"]
			}
		}
	}
}
*/
})
SITE_LOG3 = multiline(function(){
/*
{
	"MAC": "123",
	"TZ": "+0530",
	"Data": {
		"0": {
			"RX": "67002",
			"TX": "93639",
			"Sites": {
				"siteMain.com": ["12345", "1"]
			}
		}
	}
}
*/
});
SITE_LOG2 = multiline(function(){
/*
{
	"MAC": "123",
	"TZ": "+0530",
	"Data": {
		"0": {
			"RX": "67002",
			"TX": "93639",
			"Sites": {
				"sitePresentinDB.com": ["12345", "1"],
				"sitePresentinDB2.com": ["123456", "1"],
				"sitePresentinDB3.com": ["123457", "1"],
				"sitePresentinDB4.com": ["123458", "1"],
				"sitePresentinDB5.com": ["123459", "1"],
				"siteAbsentFromDB.com": ["1472734360", "1"],
				"siteAbsentFromDB2.com": ["1472734360", "1"],
				"siteAbsentFromDB3.com": ["1472734360", "1"],
				"siteAbsentFromDB4.com": ["1472734360", "1"],
				"siteAbsentFromDB5.com": ["1472734360", "1"]
			}
		},
		"1": {
			"RX": "00000",
			"TX": "00000",
			"Sites": {
				"siteClient1.com": ["123451", "1"],
				"sitePresentinDB.com": ["123450", "1"]
			}
		}
	}
}
*/
});


SITE_LOG4 = multiline(function(){
/*

{"Data":{
	"MAC": "123",
	"TZ": "+0530",
	"Data": {
		"0": {
			"RX": "67002",
			"TX": "93639",
			"Sites": {
				"sitePresentinDB.com": ["12345", "1"],
				"sitePresentinDB2.com": ["123456", "1"],
				"sitePresentinDB3.com": ["123457", "1"],
				"sitePresentinDB4.com": ["123458", "1"],
				"sitePresentinDB5.com": ["123459", "1"],
				"siteAbsentFromDB.com": ["1472734360", "1"],
				"siteAbsentFromDB2.com": ["1472734360", "1"],
				"siteAbsentFromDB3.com": ["1472734360", "1"],
				"siteAbsentFromDB4.com": ["1472734360", "1"],
				"siteAbsentFromDB5.com": ["1472734360", "1"]
			}
		},
		"1": {
			"RX": "00000",
			"TX": "00000",
			"Sites": {
				"sitePresentinDB.com": ["123450", "1"]
			}
		}
	}
}
}
*/

});


exports.SITE_LOG = SITE_LOG;
exports.SITE_LOG2 = SITE_LOG2;
exports.SITE_LOG3 = SITE_LOG3;
exports.SITE_LOG4 = SITE_LOG4;
exports.SITE_LOG5 = SITE_LOG5;

