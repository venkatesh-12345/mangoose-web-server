var moment = require('moment');
var UserId = '987654321';
var TempPass = '1a2b3c4d5e6f7g8h9i';
var AMAC = '11223344';
var CMAC = '12131415';
var currDate = moment(moment.utc()).utcOffset(330).format('YYYY-MM-DD');
var currTime = moment(moment.utc()).utcOffset(330).format('HH:mm');
var tommDate = moment(moment.utc().add(1,'days')).utcOffset(330).format('YYYY-MM-DD');

loginAuth1 = {
    UserId:'32123',
    TempPass:'dfkjhkfjfjdsfjkjf',
    AMAC:'251176215905232',
    CMAC:'207609387599067',
    search:'',
    value:'',
    pageState:null
};

loginAuth2 = {
    UserId:'30005',
    TempPass:'dfkjhkfjfjdsfjkjf',
    AMAC:'251176215905200',
    CMAC:'207609387599067',
    search:'',
    value:'',
    pageState:null
};

loginAuth3 = {
    UserId: UserId,
    TempPass: TempPass,
    AMAC: AMAC,
    CMAC: CMAC,
    search:'',
    value:'',
    pageState:null
};

loginAuth4 = {
    UserId:'30023',
    TempPass:'9a9beeb806977422b912ada1727ba0e0e2640a4dd6f7c30ec488db955b21b38bd9111ff4e1b71e9669fd22a837f03fbfbf9d51476ee69cb5a8a18fc73eceb92e',
    AMAC:'251176215907620',
    CMAC:'207609387599067',
    search:'',
    value:'',
    pageState:null
};

validSR = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'SuggestRating',
    value:'facebook.com',
    suggestedValue:1,
    pageState:null
};

invalidSiteSR = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'SuggestRating',
    value:'siteNotPresent.com',
    suggestedValue:26,
    pageState:null
};

incorrectSR = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'SuggestRating',
    value:'facebook.com',
    suggestedValue:'a',
    pageState:null
};

lastWeek = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'LastWeek',
    value:tommDate, // one day former than the current date
    pageState:null
};

dataUsageReset = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'DataUsageReset',
    TZ:'+0530',
    value:1,
    pageState:null
};

incorrectDUR = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'DataUsageReset',
    TZ:'+0530',
    value:'35',
    pageState:null
};

webHistory = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'',
    value:'',
    pageState:null
};

webHistoryIOT = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'',
    value:'',
    'IOT':1,
    pageState:null
};

invalidWebHistory = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'""',
    value:'""',
    pageState:null
};

fromThisDate = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:'FromThisDate',
    value:'2017-05-07',
    pageState:null
};

bandwidthValid = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"Bandwidth",
    today:currDate,
    value: 1    // 1 | 7 | 31
    
};

clearBW = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"ClearBandwidth",
    today:currDate,
    value:"ClearBandwidth"
};

lastHour = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"LastHour",
    today: currDate,
    value:currTime
};

presentHour = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"PresentHour",
    today: currDate,
    value:currTime
};

domainSearch = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"Domain",
    value:"facebook.com",
    today: "2017-05-11"
};

categorySearch = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"Category",
    value:1
};

epochSearch = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"Epoch",
    today: currDate,
    value:"google.com"
};

dateSearch = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"Date",
    value:"2017-05-07"
};

weekdaySearch = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"WeekDay",
    value:"2017-05-07"
};

clearHistory = {
    UserId:UserId,
    TempPass:TempPass,
    AMAC:AMAC,
    CMAC:CMAC,
    search:"ClearHistory"
};

module.exports = {
    UserId: UserId,
    TempPass: TempPass,
    AMAC: AMAC,
    CMAC: CMAC,
    loginAuth1: loginAuth1,
    loginAuth2: loginAuth2,
    loginAuth3: loginAuth3,
    loginAuth4: loginAuth4,
    validSR: validSR,
    invalidSiteSR: invalidSiteSR,
    incorrectSR: incorrectSR,
    lastWeek: lastWeek,
    dataUsageReset: dataUsageReset,
    incorrectDUR: incorrectDUR,
    webHistory: webHistory,
    webHistoryIOT: webHistoryIOT,
    invalidWebHistory: invalidWebHistory,
    fromThisDate: fromThisDate,
    bandwidthValid: bandwidthValid,
    clearBW: clearBW,
    lastHour: lastHour,
    presentHour: presentHour,
    domainSearch: domainSearch,
    categorySearch: categorySearch,
    epochSearch: epochSearch,
    dateSearch: dateSearch,
    weekdaySearch: weekdaySearch,
    clearHistory: clearHistory
};
