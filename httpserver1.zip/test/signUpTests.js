var expect = require('chai').expect;
var request = require('request');
var dbmodifier = require('./dbForTest/dbmodifier.js');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var URL = nconf.get('httpUrl');
var CP = require('../database/sql/sqlQuery');
var testInput = nconf.get('signUp');


describe('SignUp tests', function () {
    before(function (done) {
        this.timeout(5000);
        accManager.httpDeleteAccount(testInput, function (err, rows) {
            console.log('done');
            done();
        });
    });
    it('SignUp is successful', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/SignUp',
            body: {
                'emailID': testInput.emailID,
                'password': testInput.password
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            expect(body.success + '').to.equal('true');
            if (testEnviron === 'productionEnv')
                return done();
            console.log('checking the email entry in database ...');
            var query = "select * from Users where EmailID= ? ;";
            var params = [testInput.emailID];
            CP.queryFunction(query, params, function (err, rows) {
                if(err || !rows || rows.length === 0)
                    done("error");
                else {
                    console.log(JSON.stringify(rows));
                    expect(rows[0].EmailID).to.equal(testInput.emailID);
                    expect(rows[0].Date).to.not.equal(null);
                    expect(rows[0].UserID).to.not.equal(null);
                    expect(rows[0].ValidationToken).to.not.equal(null);
                    done();
                }
            });
        });
    });
    it('SignUp is unsuccessful Email Taken', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/SignUp',
            body: {
                'emailID': testInput.emailID,
                'password': testInput.password
            },
            json: true
        };

        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log("Email Taken response ",body);
            expect(response.statusCode).to.equal(502);
            expect(body.success + '').to.equal('false');
            expect(body.reason).to.equal('Email Taken');
            done();
        });
    });
    after(function (done) {
        this.timeout(5000);
        accManager.httpDeleteAccount(testInput, function (err, rows) {
            console.log('done');
            done();
        });
    });
});

