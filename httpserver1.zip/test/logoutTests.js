/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var expect = require('chai').expect;
var request = require('request');
var dbmodifier = require('./dbForTest/dbmodifier.js');
var accManager = require('./dbForTest/accountManager');
var nconf = require('nconf');
require('./TestConfigs/configTestEnviron');
var testEnv = nconf.get('testEnviron');
var URL = nconf.get('httpUrl');
var CLEAR_DB = nconf.get('CLEAR_DB');
var userID = undefined;
var tempPass = undefined;

describe('', function () {
    before(function (done) {
        this.timeout(15000);
        accManager.getAuthToken(testEnviron, testEnv, function(err, res) {
            if (err) {
                console.log(err);
                done(err);
            } else {
                console.log('access token string ---> ', res);
                tempPass = res.split(':')[0];
                userID = res.split(':')[1];
                done();
            }
        });
    });
    it('Logout test successful', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/Logout',
            body: {
                'userID': userID,
                'tempPass': tempPass
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(200);
            expect(body.success + '').to.equal('true');
            done();
        });
    });
    it('Logout test unsuccessful invalid userID and password', function (done) {
        this.timeout(5000);
        var options = {
            method: 'POST',
            url: URL + '/Logout',
            body: {
                'userID': userID,
                'tempPass': tempPass
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error)
                done(error);
            console.log(JSON.stringify(body));
            expect(response.statusCode).to.equal(502);
            expect(body.success + '').to.equal('false');
            expect(body.reason + '').to.equal('Invalid UserID or TempPass');
            done();
        });
    });
    after(function (done) {
        this.timeout(10000);
        console.log(" How many times");
        if (testEnviron !== 'productionEnv') {
            if (CLEAR_DB == 'true')
                dbmodifier.deleteUser(testEnv.emailID, function (err, rows) {
                    console.log('done');
                    done();
                });
            else {
                // Updating the Bearer token with the new one after Logout
                console.log('account manager token updated HERE');
                accManager.getUserIDtempPass({'emailID': testEnv.emailID, 'password': testEnv.password}, function (err, creds) {
                    res = creds.tempPass + ':' + creds.userID;
                    accManager.accessToken = creds.tempPass + ':' + creds.userID;
                    done();
                });
            }
        } else {
            accManager.getUserIDtempPass({'emailID': testEnv.emailID, 'password': testEnv.password}, function (err, creds) {
                res = creds.tempPass + ':' + creds.userID;
                accManager.accessToken = creds.tempPass + ':' + creds.userID;
                done();
            });
        }
    });
});