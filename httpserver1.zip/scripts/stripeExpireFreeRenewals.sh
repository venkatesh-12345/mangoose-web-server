#!/bin/sh/
SERVICE='stripeExpireFreeRenewals'
if ps ax | grep -v grep | grep $SERVICE > /dev/null
then
  echo "$SERVICE is running"
else
  echo "$SERVICE is not running"
  /usr/local/bin/node /home/ubuntu/HttpServer/stripeExpireFreeRenewals.js 	
fi
