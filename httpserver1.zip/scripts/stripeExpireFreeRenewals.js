var fs = require('fs');
var CP = require('../database/sql/sqlQuery');
var table=require('../util/table');
var genericModel=require('./database/model/genericModel');
var updateEndPoints = require('../broadcast/updateEndPoints');

var expireFreesubscriptions = function () {
    fs.readFile('./emailIDs.txt', function (err, data) {
        data = data.toString();
        if (!err) {
            var userIDs = [];
            var emailIDs = data.split("\n");
            console.log(emailIDs);
            CP.queryFunction("Select UserID FROM ?? Where EmailID IN (?)", ['AlmondplusDB.Users', emailIDs], function (usererr, userrows) {
                if (!usererr) {
                    for (var i = 0; i < userrows.length; i++) {
                        userIDs.push(userrows[i].UserID);
                    }
                    console.log(userIDs);
                    console.log("In getAllFreeSubscriptions");
                    var epochTime = (new Date).getTime();
                    console.log("Epoch Now : " + epochTime);
                    CP.queryFunction("Select * FROM ?? where Plan=? AND UserID IN (?) AND RenewalEpoch < ?", ['AlmondplusDB.Subscriptions', 'Free', userIDs, epochTime], function (suberr, subrows) {
                        if (!suberr) {
                            updateDBonExpire(subrows);
                        }
                    });
                }
            });
        }
    });
}

function updateDBonExpire(subrows) {
    console.log("Rows:");
    console.log(subrows);
    console.log(subrows.length);
    var values = [], almondMAC;
    for (var i = 0; i < subrows.length; i++) {
        almondMAC = subrows[i].AlmondMAC;
        values.push([subrows[i].UserID, almondMAC, 'FreeExpired']);
        updateEndPoints.broadcaster(almondMAC, JSON.stringify({CommandType: "DeleteSubscription", AlmondMAC: almondMAC, PlanID: 'FreeExpired'}), 1012);
        updateEndPoints.removeSubscription(almondMAC);
    }
    console.log(values);
    if (values.length > 0) {
        genericModel.insertUpdate(table.SUBSCRIPTIONS,{UserID:values[0],AlmondMAC:values[1],Plan:values[2]}, function (experr, exprows) {
            if (experr) {
                console.log("Error");
                console.log(experr);
            } else {
                console.log(" Result is ... ");
                console.log(exprows);
            }
        });
    }
}

setTimeout(function () {
    console.log("Expiring the free subscriptions")
    expireFreesubscriptions();
}, 8000);
