var moment = require('moment');
var fs = require('fs');
const del = require('del');
//var json2csv = require('json2csv');
var archiver = require('archiver');
var loggerPoint = require('../database/cassandra/cqlDownloadLogsEndpoint');
var errorCodesForClients = require('../ErrorCodes/errorCodesForClients');
var EM = require('../email/emailDispatcher');


const fetchSize = 100;
const MAX_FILE_SIZE = 500 * 1024; // 500KB change this to the optimum value
var fields = ['mac', 'ip', 'message', 'userid', 'time'];
var fieldNames = ['AlmondMAC', 'IP Address', 'Event', 'User', 'Time'];
/**
 * @property {Array} fields -indicate column names in the cassandra table
 * @property {Array} fieldNames -indicate corresponding column names in the csv file
 * 
 * NOTE: These two properties should be in sync.
 */
const csvConfig = {fields: fields, fieldNames: fieldNames};

//create a tmp directory for storing the files temporarily
const tmpDir = __dirname + '/tmp/';

if (!fs.existsSync(tmpDir)){
    fs.mkdirSync(tmpDir);
}

function archiveInit(req) {
    
    req.archive = archiver('zip', {
        zlib: {level: 9} // Sets the compression level. 
    });
    
    req.archive.on('warning', function (err) {
        console.log('got the warning event on archive');
        if (err.code === 'ENOENT') {
            // log warning 
        } else {
            // throw error 
            throw err;
        }
    });
    
    req.archive.on('error', function (err) {
        console.log('got error event on archive');
        throw err;
    });
    
    req.archive.on('end', function (err) {
        console.log('got END event on archive');
    });
}

function validateReq(req) {
    if(req.mac && req.email && req.type && req.type ==='device') {
        return true;
    }
    return false;
}

function prepareQuery() {
    var query = {};
    query.query = "select mac, dateyear, ip, message, userid, toTimestamp(pk) as time  from scsi.event_log where mac = ? and dateyear = ?;";
    query.params = [];
    return query;
    
}

function validateRow(row, req) { // filtering if any
    if(req.type === 'device' && row.client_id ) {
        return false;
    }
    return true;
}

function data2csvStr(data){
    var csv = [];
    csvConfig.fields.forEach(function(item , index) {
        csv.push(data[item]);
    });
    return csv.join() + '\n';
}

var downloadBlock = function (req, query, date, callback) {

    loggerPoint.eachRow(query.query, query.params, {prepare: 1, fetchSize: fetchSize}, function (n, row) {
        if (validateRow(row, req))
            req.wstream.write(data2csvStr(row));
    }, function (err, result) {
        if (err) {
            console.log(err);
            return callback(true, undefined, {'error': 'true'});
        }
            if(req.wstream.bytesWritten > MAX_FILE_SIZE) {
                var newFile = req.filePrefix + '_' + req.files.length + '.csv';
                req.files.push(newFile);
                req.wstream.end();
                req.wstream = fs.createWriteStream(tmpDir + newFile);
                req.wstream.write(csvConfig.fieldNames.join() + '\n');
            }
            if (result.nextPage) {
                result.nextPage();
            } else {
                callback(null);
            }
    });
};

var download = function (req, query, callback) {
    var date = moment.utc().utcOffset(0);

    var currDate = date.format('YYYY-MM-DD');
    var endDate = (date.clone()).subtract(2, 'month').format('YYYY-MM-DD');
    req.files = [];
    req.filename = req.filePrefix + '.csv';
    req.files.push(req.filename);
    req.wstream = fs.createWriteStream(tmpDir + req.filename);
    req.wstream.write(csvConfig.fieldNames.join() + '\n');
    var recCallback = function (err) {
        if (!err) {
            date.subtract(1, 'day');
            query.params = [];
            query.params.push(req.mac);// check the conditions
            query.params.push(date.format('YYYY-MM-DD'));
            if (date.format('YYYY-MM-DD') > endDate)
                setTimeout(function() {
                    downloadBlock(req, query, date.format('YYYY-MM-DD'), recCallback);
                }, 500);
            else {
                req.wstream.end();
                callback();
            }
        }
    };
    var nonrecCallback = function (err) {
        req.wstream.end();
        callback(err);
    };
    if(req.id) {
        downloadBlock(req, query, undefined, nonrecCallback);
    }
    else {
        query.params.push(req.mac);
        query.params.push(date.format('YYYY-MM-DD'));
        downloadBlock(req, query, date.format('YYYY-MM-DD'), recCallback);
    }
};

var emailFiles = function(req, callback) {
    if (req.files.length > 1) {
        var filePath = tmpDir + req.filePrefix + '.zip';
        var output = fs.createWriteStream(filePath);
        output.on('close', function () {
            console.log(req.archive.pointer() + ' total bytes');
            console.log('archiver has been finalized and the output file descriptor has closed.');
        });
        req.archive.pipe(output);
        req.archive.glob('./scripts/tmp/' + req.filePrefix + '*.csv');
        
        req.archive.finalize();
        req.emailFile = req.filePrefix+ '.zip';
        EM.sendDownloadHistory(req, filePath, "application/zip", function(err) {
            callback(err);
        });
    } else {
        var filePath = tmpDir + req.filePrefix + '.csv';
        req.emailFile = req.filePrefix+ '.csv';
        EM.sendDownloadHistory(req, filePath, "text/csv", function(err) {
            callback(err);
        });
    }
};

var downloadHistory = function (req, res) {
    try {
        req.filePrefix =  req.mac + '_' + (Math.floor( Date.now() % 1000 )*1000 + Math.floor(Math.random() * 1000));
        if (!validateReq(req)) {
            return sendResponse(res, errorCodesForClients.INSUFFIENT_DATA, {error:"Insufficient Data"});// error 
        }
        archiveInit(req);
        var query = prepareQuery(req);
        if(!query)
            return sendResponse(res, errorCodesForClients.INTERNAL_SERVER_ERROR, {error:"Internal Server Error"});
        sendResponse(res, 200);
        // Handle the catch block after sending the response
        console.log(JSON.stringify(query));
        download(req, query, function (err) {
            if (err)
                return console.log(err);
            console.log('Files created --: ', req.files.join());
            emailFiles(req, function(err) {
                if(err)
                    console.log('Email Not sent');
                else
                    console.log('Email Sent');
                setTimeout(function () {
                    del([tmpDir + req.filePrefix + '*']).then(paths => {
                        console.log('Deleted files and folders:\n', paths.join('\n'));
                    });
                }, 2000);
            });
        });
    } catch (error) {
        console.error(error);
        return sendResponse(res, errorCodesForClients.INTERNAL_SERVER_ERROR, {});
    }

};

function sendResponse(res, statusCode, json) {
    var body = JSON.stringify(json);
    if (body == undefined)
        return res.sendStatus(statusCode);
    else
        return res.status(statusCode).send(body);
}

module.exports = {
    downloadHistory:downloadHistory
};
