var moment = require('moment');
var loggerPoint = require('../database/cassandra/cqlConnection');

var fetchSize = 50;
var copydb = {};

var updateTable = function (action, date, callback) {
    if(action === 'updateDeviceTable')
        var query = "SELECT mac,device_id,time,index_id,device_type FROM dynamic_update_log where dateyear='" + date + "';";
    else if (action === 'copyClient')
        var query = "SELECT * FROM dynamic_update_wifi_client where dateyear='" + date + "';";
    var param = [];
    var totalCount = 0;
    var doneCount = 0;
    var fullResult;

    loggerPoint.eachRow(query, param, {prepare: true, fetchSize: fetchSize, pageState: null}, function (n, row) {
        totalCount++;
        if(action === 'updateDeviceTable') {
            var query = "insert into dynamic_update_log (mac, device_id , time , index_id , type) values (?, ?, ?, ?, ?);";
            var params = [row.mac, row.device_id, row.time, row.index_id, row.device_type.toString()];
        } else if (action === 'copyClient') {
            var query = "insert into dynamic_update_log (mac, device_id , time , dateyear , device_name , type , client_id, pk , mac_date , userid , value , index_id) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 123456)";
            var params = [row.mac, row.client_mac, row.time, row.dateyear, row.client_name, row.client_type, row.client_id, row.pk, row.mac_date, row.userid, row.value];
        }
        loggerPoint.execute(query, params, {prepare: true}, function (error, result) {
            if (error) {
                console.log("Error in execute insert ", error);
                callback(error, result);
            } else {
                doneCount++;
                if ((doneCount % fetchSize) === 0 && fullResult.nextPage) {
                    fullResult.nextPage();
                } else if (doneCount === totalCount) {
                    callback(null, fullResult);
                }
            }
        });

    }, function (err, result) {
        if (!err && result) {
            fullResult = result;
            if (!result.nextPage && doneCount === totalCount)
                callback(null, result);
        } else
            callback(err);
    });
};

copydb.totalUpdateTable= function (action, callback) {
    var date = moment.utc().utcOffset(0);

    var currDate = date.format('YYYY-MM-DD');
    console.log('currDate ', currDate);
    var oneMonthDate = (date.clone()).subtract(1, 'month').format('YYYY-MM-DD');
    console.log('oneMonthDate ', oneMonthDate);
    var recCallback = function (err) {
        if (!err) {
            date.subtract(1, 'day');
            if (date.format('YYYY-MM-DD') > oneMonthDate)
                updateTable(action, date.format('YYYY-MM-DD'), recCallback);
            else {
                console.log('end of the History for one mounth');
                console.log('============== END of the process =============');
                callback();
                //process.exit();
            }
        }
    };
    updateTable(action, date.format('YYYY-MM-DD'), recCallback);
};


//copydb.totalUpdateTable('updateDeviceTable', function () {
//    console.log('### device update done ###');
//    copydb.totalUpdateTable('copyClient', function () {
//        console.log('### client insert done ###');
//    });
//});


module.exports = copydb;
