var emailDispatch = require("../email/emailDispatcher.js");
var genericModel = require("../database/model/genericModel");
var US = require("../database/model/userSubscription");
var broadcast = require("../broadcast/updateEndPointNew");
var table = require("../util/table");
var SE = {};
var setRenewalTime = function(customerID, subscriptionID, renewalEpoch, planID, cancelAtEnd) {
    genericModel.select(table["SUBSCRIPTIONS"], { SubscriptionID: subscriptionID, CustomerID: customerID }, function(err, rows) {
        if (err || !rows || rows.length == 0) return;
        rows[0].RenewalEpoch = renewalEpoch;
        let splitPlan = rows[0].Plan.split("-");
        if (planID) {
            if (splitPlan.length > 1) rows[0].Plan = planID + "-" + splitPlan[1];
            else rows[0].Plan = planID;
        }
        if (cancelAtEnd) rows[0].Status = "CancelAtEnd";
        else if(rows[0].Status=='CancelAtEnd')
            rows[0].Status='Active';
        else if (rows[0].Status.indexOf("Fail") > -1) rows[0].Status = "Active";     
        broadcast.broadcastToMobile(
            rows[0].AlmondMAC,
            JSON.stringify({
                CommandType: "DynamicSubscriptionStatusUpdate",
                AlmondMAC: rows[0].AlmondMAC,
                Status: rows[0].Status,
                MonitoringStatus:rows[0].MonitoringStatus,
                PlanID: planID,
                PlanName: splitPlan[1],
                RenewalEpoch: rows[0].RenewalEpoch,
                Services: rows[0].Services,
                VATCode:false,
                CMSCode:rows[0].CMSCode
            }),
            1012
        );
        genericModel.insertUpdate(table["SUBSCRIPTIONS"], rows[0], function(err, rows) {
            console.log("err,res in setRenewalTime", err, rows);
        });
    });
};
var broadCastSubscriptionDeletion = function(subscriptionID) {
    try {
        genericModel.select(table["SUBSCRIPTIONS"], { SubscriptionID: subscriptionID }, function(err, rows) {
            if (rows.length == 1) {
                genericModel.select(table["CMSAffiliations"], { AlmondMAC: rows[0].AlmondMAC }, function(e, affs) {
                    console.log(" Here broadCastDelete in stripe events ",rows[0]);
                    if (e || affs.length == 0) return US.broadCastDelete(rows[0], function() {});
                    rows[0].CMSCode = affs[0].CMSCode;
                    return US.broadCastDelete(rows[0], function() {});
                });
            }
        });
    } catch (e) {
        console.log(e);
    }
};

var alertFailedPayment = function(eventType, subscriptionID, attempt) {
    genericModel.select(table["SUBSCRIPTIONS"], { SubscriptionID: subscriptionID }, function(err, rows) {
        if (rows.length == 1) {
            if (attempt == 1) {
                var epoch = Date.now() + 3 * 7 * 24 * 60 * 60 * 1000;
                rows[0].Status = "Fail-" + epoch + "";
                broadcast.broadcastToMobile(
                    rows[0].AlmondMAC,
                    JSON.stringify({
                        CommandType: "DynamicSubscriptionStatusUpdate",
                        AlmondMAC: rows[0].AlmondMAC,
                        Status: rows[0].Status,
                        MonitoringStatus:rows[0].MonitoringStatus,
                        PlanID: rows[0].PlanID.split("-")[0],
                        PlanName: rows[0].PlanID.split("-")[1],
                        RenewalEpoch: rows[0].RenewalEpoch,
                        Services: rows[0].Services,
                        CMSCode:rows[0].CMSCode,
                        VATCode:false
                    }),
                    1012
                );
                genericModel.insertUpdate(table["SUBSCRIPTIONS"], rows[0], function(err, rows) {});
            }
            genericModel.select(table["USERS"], { userID: rows[0].UserID }, function(err, emailrows) {
                var paramData = { eventType: eventType, AlmondMAC: rows[0].AlmondMAC };
                emailDispatch.notifyUser(emailrows[0].EmailID, paramData, function(e, email) {});
                emailDispatch.notifySecurifi(emailrows[0].EmailID, paramData, function(e, email) {});
            });
        }
    });
};

SE.updateDB = function(eventType, responseObj) {
    var customerID = "",
        subscriptionID = "",
        renewal = "",
        planID = "";
    switch (eventType) {
        case "customer.subscription.updated":
            if (responseObj.data.object.customer) customerID = responseObj.data.object.customer;
            if (responseObj.data.object.plan) planID = responseObj.data.object.plan.id;
            subscriptionID = responseObj.data.object.id;
            renewal = responseObj.data.object.current_period_end;
            renewal = renewal * 1000;
            var cancelAtEnd = responseObj.data.object.cancel_at_period_end;
            setRenewalTime(customerID, subscriptionID, renewal, planID, cancelAtEnd);
            break;
        case "customer.subscription.deleted":
            subscriptionID = responseObj.data.object.id;
            broadCastSubscriptionDeletion(subscriptionID);
            break;
        case "invoice.payment_failed":
            subscriptionID = responseObj.data.object.id;
            var attempt = responseObj.data.object.attempt_count;
            alertFailedPayment(eventType, subscriptionID, attempt);
            break;
        default:
            break;
    }
};

module.exports = SE;
