var olderResponses = {
	'guestNetwork': function(responseJSON){
		console.log("inside old guest network response");
		if(responseJSON.WirelessSetting){
			if(responseJSON.WirelessSetting[0].Success==undefined){
				responseJSON.WirelessSetting[0].Success = responseJSON.Success;
				delete responseJSON.Success;
			}
		}else{
			responseJSON.WirelessSetting = [];
			var temp = {};
			temp.Success = responseJSON.Success;
			temp.Type = responseJSON.Type;
			temp.SSID = responseJSON.SSID;
			temp.Password = responseJSON.Password;
			temp.Reason = responseJSON.Reason;
			responseJSON.WirelessSetting.push(temp);
			delete responseJSON.Success;
			delete responseJSON.Type;
			delete responseJSON.SSID;
			delete responseJSON.Password;
			delete responseJSON.Reason;
		}
		console.log("parsed response from AL2: ", responseJSON);
	}
};

module.exports = olderResponses;