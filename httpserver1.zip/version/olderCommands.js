var olderCommands = {
	'getModeCommand': function(req, emailID){
		return '<root><AlmondModeChange><AlmondplusMAC>'+req.AlmondMAC+'</AlmondplusMAC>'+
		'<AlmondMode>'+req.mode+'</AlmondMode>'+ // (2 = Home, 3 = Away)
		'<ModeSetBy>'+emailID+'</ModeSetBy>'+
		'<MobileInternalIndex>'+Math.floor(Math.random()*1000+1)+'</MobileInternalIndex>'+
		'</AlmondModeChange>'+
		'</root>'
	}
}

module.exports = olderCommands;