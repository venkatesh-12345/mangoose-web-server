var RabbitMQConnector = require('./rabbitMQ');
var rabbitmqConfig = require('../config.js').rabbitmq;
//var host = 'amqps://oldrabbit.securifi.com';
var options = {
    host: rabbitmqConfig.host,
    queueName: rabbitmqConfig.queueName,
    maxRetryCount: 3
};

var producer = new RabbitMQConnector(options, 'PRODUCER');
//producer.connect();
producer.on('connected', function () {
    console.log(">>>We are connected  AQ >>>");
});

producer.on('reconnecting', function (number, error) {
    //console.log(number);
});

producer.on('error', function () {
    console.log("This is now giving error");
});

var AQP = {};
AQP.sendToQueue = function (queue, message) {
    if (queue) {
        options.queueName = queue;
        producer.pushMessage(queue, message);
    }
};

module.exports = AQP;
