var RabbitMQConnector = require('./rabbitMQ');
var userSubscriptions = require('../database/model/userSubscription.js');
var rabbitmqConfig = require('nconf').get('rabbitmq');
var responseHandler= require('../almondEndpoint/responseHandler')
var tracker = require('../tracking')
var alexa=require('../controllers/alexa');
var options = {
    host: rabbitmqConfig.host,
    queueName: rabbitmqConfig.queueName,
    maxRetryCount: 3
};

var httpClient= require('../httpClientNew');

var C = {};
var Consumer = new RabbitMQConnector(options, 'CONSUMER');
//Consumer.connect();
Consumer.on('connected', function () {
    console.log('RabbitMQConnector CONSUMER HTTP server ');
});
Consumer.on('reconnecting', function (number, error) {
    //console.log(number);
});

Consumer.on('error', function (err) {
    tracker.error(err)
    console.log("This is now giving error");
})

Consumer.on('message', function (msg) {
    try {
        var request = JSON.parse(msg);
        console.log('consumer*****',request)
        if(request.id==2020)
            return httpClient.sendFromStore(request);
        var cmdType = request.CommandType;
        if(request.alexa&&cmdType=="DeleteAccount")
            alexa.removeAccessToken(request)
        else if (request.alexa){
            var payload=JSON.parse(request.payload)
            if(payload.CommandType == 'DynamicDeviceRemoved' || payload.CommandType == 'DynamicSceneRemoved'){
                request.payload=payload
                alexa.removeDevice(request)
            }else
                alexa.indexUpdate(request);
        }
        else if (cmdType == "SubscribeMe")
            userSubscriptions.Subscribe(request);
        else if (cmdType == "DeleteSubscription")
            userSubscriptions.DeleteSubscription(request);
        else if (cmdType == "DeleteCustomerOnly")
            userSubscriptions.DeleteCustomerObject(request, true);
        else if (cmdType == "DeleteSubscriptionOnly")
            userSubscriptions.DeleteSubscriptionObject(request, true);
        else if (cmdType == "PaymentDetails")
            userSubscriptions.getUpgradeData(request);
        else if (cmdType == "UpdateCard")
            userSubscriptions.UpdateCard(request);
        else
            responseHandler.process(request,request.command)
    } catch (error) {
          tracker.error(error.stack)
        console.log(" error in consumer.js ", error.stack);
    }
});

module.exports = C;
