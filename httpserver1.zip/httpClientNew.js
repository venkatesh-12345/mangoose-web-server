var HTTP={};
storeReq={};
HTTP.sendFromStore=function(data){
  if(data && storeReq[data.commandID]){
      clearTimeout(storeReq[data.commandID].setTimeout)
      storeReq[data.commandID].write(JSON.stringify(data));
      storeReq[data.commandID].end()
      delete storeReq[data.commandID];

      return 
    }
}
HTTP.store=function(id,response,server){
  if(!id  || !response)
    return;
    storeReq[id]=response;
    storeReq[id].setTimeout=setTimeout(function(){
      storeReq[id].send(JSON.stringify({ success: true, Timeout: true, reason: 'Almond Timedout' }))
    },1*60*1000)
}

module.exports=HTTP;