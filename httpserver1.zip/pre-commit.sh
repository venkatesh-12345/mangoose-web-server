files=$(git diff-index --name-only HEAD | grep -P '\.js$')

for file in $files; do
	echo "Files : $file"
	if [ -f $file ];then
  esvalidate $file

  if [ $? -eq 1 ]; then
    echo "Syntax error: $file"
    exit 1
  fi
fi
done