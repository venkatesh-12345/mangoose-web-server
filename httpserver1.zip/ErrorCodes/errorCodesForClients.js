var ErrorCodesForClient = {};
ErrorCodesForClient.DEVICE_ERROR = 559;
ErrorCodesForClient.ALMOND_OFFLINE = 558;
ErrorCodesForClient.TIME_OUT = 560;
ErrorCodesForClient.INTERNAL_SERVER_ERROR = 500;
ErrorCodesForClient.DEPENDENT_SERVICE_UNAVAILABLE =503;
ErrorCodesForClient.USER_UNAUTHORIZED = 401;
ErrorCodesForClient.DEVICE_UNAUTHORIZED = 403;
ErrorCodesForClient.UNKNOWN  = 557;
ErrorCodesForClient.INSUFFIENT_DATA = 556;

ErrorCodesForClient.DATABASE_ERROR = 502;
module.exports = ErrorCodesForClient;