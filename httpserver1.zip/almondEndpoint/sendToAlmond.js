var RM = require('../database/redis/redisStore')
var server_name = require('nconf').get('rabbitmq').queueName;
var AQP = require('../rabbitmq/producer');
var generator = require('./randomNumberGenerator');
var tracker = require('../tracking')

var store = {};

store.send = function(data,params,handler,callback) {
    if (params.server)
        return sendToQueue(data,params,handler, true, callback);
    RM.getAlmond(params.almondMAC, function(e, o) {
        if (o && o.status == '1'){
            params.server=o.server
            sendToQueue(data,params, handler,false, callback);
        }
        else {
            var payload = {
                'success': true,
                'Timeout': true,
                reason: "Almond Offline"
            }
            handler.responseWriter(data, 200, JSON.stringify(payload), true)
        }
    })
}

function sendToQueue(data,params, handler,affiliation, callback) {
    generator.getCode(10, function(e, commandID) {
        if (e || !commandID) return;
        if (affiliation)
            RM.setCode(params.request.Code, params.almondMAC + ',' + server_name + ',' + data.userid + ',' + commandID+','+params.lastEmail+','+false, function(err, o) {})
        var st = { unicastID: commandID, mobileCommand: params.responseId, command: params.requestId, payload: data.requestPayload, almondMAC: params.almondMAC };
        AQP.sendToQueue(params.server, JSON.stringify(st));

        RM.setQueue(server_name, data.userid, 1, function(e, o) {});
        if(!params.alexa)
            handler.storeInHash(commandID, data,params);
        if (callback){
            delete params.server
            callback(commandID);
        }
    })
}





module.exports = store;
