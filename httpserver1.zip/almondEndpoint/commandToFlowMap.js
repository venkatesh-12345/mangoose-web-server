var map = {
    'device/updateIndex': {
        method: 'update',
        fields: ['Update'],
        CommandType: 'UpdateDeviceIndex',
        responseId:1064,
        id: 1062
    },
    'client/update': {
        method: 'update',
        fields: ['Update'],
        CommandType: 'UpdateClient',
        responseId:1064,
        id: 1062

    },
    'almond/changeMode': {
        method: 'changeMode',
        fields: ['AlmondMAC'],
        CommandType: 'UpdateClient',
        responseId:64,
        id: 62
    },
    EnableGuestNetwork: {
        method: 'RouterSummary',
        fields: ['AlmondMAC', 'WirelessSetting'],
        CommandType: 'SetWirelessSettings',
        responseId:1100,
        id: 1100
    },
    'scene/activate': {
        method: 'RouterSummary',
        fields: ['AlmondMAC', 'Scenes'],
        CommandType: 'ActivateScene',
        responseId:1064,
        id: 1062
    },
    'router/summary': {
        method: 'RouterSummary',
        fields: ['AlmondMAC'],
        CommandType: 'RouterSummary',
        responseId:1100,
        id: 1100
    },
    'wirelessSettings/get': {
        method: 'RouterSummary',
        fields: ['AlmondMAC'],
        CommandType: 'GetWirelessSettings',
        responseId:1100,
        id: 1100
    },
    'wirelessSettings/set': {
        method: 'RouterSummary',
        fields: ['AlmondMAC', 'WirelessSetting'],
        CommandType: 'SetWirelessSettings',
        responseId:1100,
        id: 1100
    },
    'router/reboot': {
        method: 'RouterSummary',
        fields: ['AlmondMAC'],
        CommandType: 'RebootRouter',
        responseId:1100,
        id: 1100
    },
    'almond/link': {
        method: 'affiliationUserRequest',
        fields: ['Code','emailID'],
        CommandType: 'RebootRouter',
        responseId:1100,
        id: 1100
    },
    'scene/update': {
        method: 'RouterSummary',
        fields: ['AlmondMAC', 'Scenes'],
        CommandType: 'UpdateScene',
        responseId:1064,
        id: 1062
    },
    'almond/changeName': {
        method: "ChangeName",
        fields: ["AlmondMAC", "AlmondName"],
        CommandType: "ChangeAlmondName",
        responseId:64,
        id: 62
    },
};

module.exports = map;