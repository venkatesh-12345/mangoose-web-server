var RM = require('../database/redis/redisConnector')
var generator ={}
var async =require('async')
var M = require('../database/redis/mapper.js')
var server_name = require('nconf').get('rabbitmq').queueName;
var get_random_string = function(data) {
    var chars = data.chars; //'23456789ABCDEFGHJKLMNPQRSTUVWXTZabcdefghkmnopqrstuvwxyz';
    var len = 9;

    var string = '';
    for (var i = 0; i < len; i++) {
        var randomNumber = Math.floor(Math.random() * chars.length);
        string += chars.substring(randomNumber, randomNumber + 1);
    }
    return string; 
}

var Random_Key = function (data, callback)
{
    var code = get_random_string(data);
    RM.query(M.GETALL,data.prefix+code,function(err,rows){
        if (err || (rows && rows.length>0)) {
            return callback(null, 'Code exists or Database error');
        }       
        return callback(code ,null);
  });
}

generator.getCode = function (timeout, finalCallback)
{
    var data = { chars: '123456789', prefix: M.ICID, time: timeout, values: server_name };
    async.waterfall([
    function(callback){Random_Key(data, callback);}, Random_Key, Random_Key], function (code, error) {
        if (error) return finalCallback(error, null);
        RM.query('setex',{key:data.prefix+code, params:[data.time, data.values]}, function(err,out){
            if (err) {
                var res = 'Redis_Affiliation_Error';
                return finalCallback(res, null);
            }
            else{
                var res = code;
                return finalCallback(null, res);     
            }
        })

    });
}

module.exports = generator;
