var ResponseHandler = {}
ResponseHandler.requests={};
var RM = require('../database/redis/redisStore')
var server_name = require('nconf').get('rabbitmq').queueName;
var fs = require('fs');
var alexaResponseGenerator=require('../alexa/responseGenerator');
var store=require('./sendToAlmond');
var tracker = require('../tracking')
function findResponseListeners(message, command) {
    var almondResponse = JSON.parse(message.payload);
    if(almondResponse.CommandType.indexOf('List')>-1 || almondResponse.CommandType=='DynamicDeviceRemoved' || almondResponse.CommandType=='DynamicDeviceAdded')
       return;
    console.log(" FindResponseListeners  ",Object.keys(ResponseHandler.requests).length);
    var key = command + "-" + message.AlmondMAC;
    var value;
    if (command == 1200) {
        var firstDeviceId = Object.keys(almondResponse.Devices)[0];
        var values = almondResponse.Devices[firstDeviceId].DeviceValues;
        var index = Object.keys(values)[0];
        key += "-" + firstDeviceId + "-" + index,
            value = values[index].Value;
            console.log(" Here in pyaload ",key,value);
    }
    else
        key += "-" + Object.keys(almondResponse.Scenes)[0];

    for (var i in ResponseHandler.requests) {
        var requestData = ResponseHandler.requests[i];
        console.log(" listener key in ResponseHandler.request, key from dynamic ",requestData.listenerKey,key);
        if (requestData.listenerKey != key)
            continue;
        if(requestData.isLock&&requestData.responded){
            delete requestData.isLock
            ResponseHandler.clearData(requestData);
            return alexaResponseGenerator.lockResponseHandler(requestData,message);
        }
        var responsePayload = ResponseHandler[requestData.responseProcessor](requestData,almondResponse,value);
        ResponseHandler.responseWriter(requestData, 200, responsePayload);
        break;
    }
}

ResponseHandler.process = function(almondResponse, command) {
    if (command == 1200 || command == 1300) {
        findResponseListeners(almondResponse, command);
    }
    else {
        var requestObject = ResponseHandler.requests[command==2020?almondResponse.commandID:almondResponse.unicastID];
        if(!requestObject)
            return 
        requestObject.id=almondResponse.unicastID;
        if(requestObject.isLock&&requestObject.responded){
            delete requestObject.isLock
            ResponseHandler.clearData(requestObject);
            return alexaResponseGenerator.lockResponseHandler(requestObject,almondResponse)
         }
        else 
            delete requestObject.isLock;
        var responsePayload;
         if (command == 1026)
            responsePayload = JSON.stringify({ "success": true, "data": almondResponse.payload });
        if (command == 64) {
            responsePayload = JSON.stringify({ "success": true, "reason": 'Almond mode set successfully' });
        }
        if (command == 1100) {
            var response = JSON.parse(almondResponse.payload);
            response.success = true;
            responsePayload = JSON.stringify(response);
        }
        else if (command == 1064) {
            responsePayload = handleMobileCommandResponse(requestObject, almondResponse);
        }
        else if(command==2020)
            return sendStatus(requestObject,almondResponse)
        //console.log(requestObject.isLock,requestObject.responded,requestObject.responseProcessor,requestObject.requestPayload,'---------in responseHandler')
        
        ResponseHandler.responseWriter(requestObject, 200, responsePayload);
    }
}

function sendStatus(req,data){
    // console.log('!REQ>RESPONSE',req)
    if(!req || ! req.response || ! data)
        return
    //console.log('inside write',data)
      req.response.write(JSON.stringify(data));
      req.response.totalCount--;
      if(req.response.totalCount>0)
        return;
    req.response.end()
    clearTimeout(data.setTimeout);
  
}

function handleMobileCommandResponse(data, json) {
    var almondResponse = JSON.parse(json.payload)
    if (data.responseProcessor)
        return ResponseHandler[data.responseProcessor](data,almondResponse, 1064);
    try{
        var payload = JSON.parse(data.requestPayload);
    }catch(error){
        console.log('error while parsing')
        return
    }
    payload.success = (almondResponse.Success == 'true');
    payload.reason = almondResponse.Reason;
    return JSON.stringify({ 'success': true, "Result": [payload]});

}

ResponseHandler.hueHandler = function(requestData, almondResponse, value) {
    var payload = JSON.parse(requestData.requestPayload);
    if (value != 'false')
        payload.success = true;
    else {
        payload.success = false;
        payload.reason = 'Hue Offline';
    }
    return JSON.stringify({ "success": true, "Result": [payload] })
}


ResponseHandler.nestHandler = function(requestData, almondResponse, value) {
    if (value != 200) {
        var payload = JSON.parse(requestData.requestPayload);
        payload.success = false;
        payload.reason = 'nest';
        return JSON.stringify({ "success": true, "Result": [payload] })
    }
}

ResponseHandler.sceneHandler = function(request, almondResponse, command) {
    var response;
    if (almondResponse.CommandType == 'DynamicSceneActivated')
        response = { "success": true, "reason": "Scene Activation Successful" }
    else if (almondResponse.CommandType === 'DynamicSceneUpdated')
        response = { success: true, reason: "Scene Updated" };
    else if (command === 1064 && almondResponse.Success == 'false') {
        response = { 'success': false, 'ReasonCode': almondResponse.ReasonCode, "reason": (almondResponse.ReasonCode == "33") ? 'Scene Already Activated' : ((almondResponse.ReasonCode == "9")? "Scene does not exists" :'Almond is offline' )};
    }
    if(request.alexa){
        response=alexaResponseGenerator.getResponse(request.event,almondResponse,request.response,'sendResponse');
        ResponseHandler.clearData(request);
    }
    return JSON.stringify(response);
}
function clearOtherRequest(data){
    var id=data.id;
        for(var i in data.ids){
            if(id!=data.ids[i]){
                data.id=data.ids[i];
                ResponseHandler.clearData(data);
            }
        }
        data.id=id;
}
ResponseHandler.alexaHandler = function(requestData, almondResponse, value) {
    var payload = JSON.parse(requestData.requestPayload);
    payload.success = (almondResponse.Success == 'true');
    payload.value=requestData.value;
    payload.previousValue=requestData.previousValue
    payload=alexaResponseGenerator.getResponse(requestData.event,payload,requestData.response,'sendResponse')
    ResponseHandler.clearData(requestData);
    if(requestData.ids)
        clearOtherRequest(requestData);
    return  payload;

}

ResponseHandler.responseWriter = function(data, statusCode, body, dontClear) {
    fs.appendFile("AlexaReq", new Date() + body + "\n", function(e, o) {});
    if (data.responded || !body)
        return;
    data.responded = true;
    tracker.logResponse(Date.now()-data.response.TimeStamp,statusCode)
    data.response.status(statusCode).send(body);
    if (dontClear)
        return;
    ResponseHandler.clearData(data);
};
ResponseHandler.clearData=function(data) {
    clearTimeout(data.setTimeout)
    if(data.isLock)
        return;
    delete ResponseHandler.requests[data.id];
    if (data.userid){
        var count=0;
        for (var i in ResponseHandler.requests) {
            if(ResponseHandler.requests[i].userid==data.userid)
                count++;
        }
        if(count==0)
            RM.setQueue(server_name, data.userid, 0, function(e, o) {})
    }
}
ResponseHandler.storeInHash=function(id, data,params) {
    data.id = id;
    ResponseHandler.requests[id] = data;
    timeoutRequest(data,params);
}
ResponseHandler.send=function(data,params,callback){
    store.send(data,params,ResponseHandler,callback)
}
function timeoutRequest(data,params) {
    console.log('create timeout*******;', data.id,params.timeoutLimit);
    data.setTimeout = setTimeout(function() {
        if(data.ids&&!data.isLock)
            clearOtherRequest(data);
        if(data.isLock)
            return lockTimeout(data)
        ResponseHandler.responseWriter(data, 200, JSON.stringify({ success: true, Timeout: true, reason: 'Almond Timedout' }))
        
    }, params.timeoutLimit)
}
function lockTimeout(data){
    ResponseHandler.responseWriter(data, 200, JSON.stringify(data.deferredResponse))
    var newData={
        userid:data.userid,
        isLock:data.isLock,
        responded:data.responded,
        event:data.event,
        correlationToken:data.correlationToken,
        messageId:data.messageId,
        value:data.value,
        id:data.id,
        userid:data.userid,
        clientId:data.clientId,
        endpointId:data.endpointId,
        listenerKey:data.listenerKey,
    }
    ResponseHandler.requests[data.id]=newData;
    delete data;
    newData.setTimeout=setTimeout(function(){
        ResponseHandler.clearData(newData);
    },15*1000);
}
module.exports = ResponseHandler;
