var AWS = require('aws-sdk');

var SNS = {};

AWS.config.update({accessKeyId: 'AKIAJJ3OESHKWUPGWT2A',
    secretAccessKey: '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'});

AWS.config.update({region: 'us-east-1'});
var sns = new AWS.SNS();

var arnPrefix = 'arn:aws:sns:us-east-1:126603117351:';

SNS.Publish = function (data, callback) {
    var params = {
        TargetArn: arnPrefix + data.topic,
        Message: JSON.stringify(data.message).toString(),
        Subject: data.subject
    };

    sns.publish(params, function (err, data) {
        if (err) {
            console.log('Error sending a message ', err);
            return callback(err, null);
        } else {
            console.log('Sent message: ', data.MessageId);
            return callback(null, data.MessageId);
        }
    });
};

module.exports = SNS;
