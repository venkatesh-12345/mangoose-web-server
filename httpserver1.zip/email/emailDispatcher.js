var settings = require('../configs/settings');
var ES = require('./emailSettings');
var SNS = require('./awsSns.js');
var fs= require('fs')
var SERVER_NAME  = settings.SERVER_NAME;
var EM = {};
EM.product = ES.product;

var request = require('request');
var URL_SHORTENER_APIKEY = 'AIzaSyCo-Xta4gGQ1-ByXKAowfV3wU4pRvxN7fI';
//EM.nodeLB = 'https://nodeLB-1553508487.us-east-1.elb.amazonaws.com';
//Migrated to emailSettings.js -- ES.LB 
//EM.nodeLB = 'https://connect.securifi.com';

function encode(str) {
return  str.replace(/\%/g,"%25")
                    .replace(/\!/g,"%21")
                    .replace(/\#/g,"%23")
                    .replace(/\$/g,"%24")
                    .replace(/\&/g,"%26")
                    .replace(/\'/g,"%27")
                    .replace(/\*/g,"%2A")
                    .replace(/\+/g,"%2B")
                    .replace(/\-/g,"%2D")
                    .replace(/\//g,"%2F")
                    .replace(/\=/g,"%3D")
                    .replace(/\?/g,"%3F")
                    .replace(/\^/g,"%5E")
                    .replace(/\_/g,"%5F")
                    .replace(/\`/g,"%60")
                    .replace(/\{/g,"%7B")
                    .replace(/\|/g,"%7C")
                    .replace(/\}/g,"%7D")
                    .replace(/\~/g,"%7E")
}

EM.server = require('emailjs/email').server.connect({
	host 	    : ES.host,
	user 	    : ES.user,
	password    : ES.password,
	ssl		    : true
});


EM.sendAndRecordEmail = function(data, callback)
{	
	if(data.Subject=='PASSWORD_RESET'){
		EM.composeEmail(data, callback, function(res){
			EM.server.send({
			from         : ES.sender,
			to           : data.EmailID,
			subject      : ES.product +' Account '+ data.Subject,
			text         : data.Subject,
			attachment   : res
			}, callback );
		});
	} else {
		EM.server.send({
			from         : ES.sender,
			to           : data.EmailID,
			subject      : ES.product +' Account Email Verification',
			text         : 'Email Verification',
			attachment   : EM.composeValidateAccountEmail(data)
		}, callback );
	}	
}

EM.dispatchResetPasswordLink = function(account, callback)
{	
	EM.composeEmail(account, callback, function(res){
		EM.server.send({
			from         : ES.sender,
			to           : account.EmailID,
			subject      : ES.product +' Account Password Reset',
			text         : 'Password Reset',
			attachment   : res
		}, callback );
	})
}


EM.sendMailToTrackingService = function(account, callback)
{
	EM.composeEmail(account, callback, function(res){
		EM.server.send({
			from         : ES.sender,
			to           : account.EmailID,
			subject      : ES.product +' Account Password Reset',
			text         : 'Password Reset',
			attachment   : res
		}, callback );
	})
}



EM.composeEmail = function(o, mcallback, callback)
{
	//if(o.Subject==RM.PASSWORD_RESET){
		var link;
        if(o.SERVER_NAME)
            link = o.SERVER_NAME + '/confirm-reset?email='+encode(o.EmailID)+'&token='+o.ValidationToken;
        else
            link = ES.LB + '/confirm-reset?email='+encode(o.EmailID)+'&token='+o.ValidationToken;
        
		//var html ='<html><head><title>Securifi. Inc.,</title></head><body>';
		function htmlGetter(ll){
			var html ='<html><head><title>'+ES.company+'</title></head><body>';
			html+= '<p>Hi there,';
			html+='</p><p>We received a password reset request from you.';
			html+='</p><p>Please click <a href=\''+ll+'\'>this link</a> to reset your password.';
			html+='</p><p>If you are not able to access the above link, copy and paste the below link into your browser.</p>';
			html+=ll;
			html+='<p>Thank You';
			html+='</p><p>'+ES.esignature;
			html+='</p></body></html>';

			return html;
		}
//logger.APP.debug('Email content: ' + html);
		if(o.echo_params){

			var builtQuery = '?email=' + encode(o.EmailID) + '&token=' + o.ValidationToken + '&client_id=' + o.echo_params.client_id + '&response_type=' + o.echo_params.response_type 
        		+ '&state=' + o.echo_params.state + '&scope=' + o.echo_params.scope + '&redirect_uri=' + o.echo_params.redirect_uri;
			link = o.SERVER_NAME + '/login/confirm-reset' + builtQuery;
			console.log("link: ", link);

			var options = {
				url: 'https://www.googleapis.com/urlshortener/v1/url?key=' + URL_SHORTENER_APIKEY,
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				json: {
					'longUrl': link
				}
			}

			request(options, function(err, response, body){
				if(err || body.hasOwnProperty('error')){
					console.log("something wrong with the shorten url call")
					return mcallback(true);
				}
				console.log(body);
				if(body.hasOwnProperty('id')){
					return callback([{data:htmlGetter(body.id), alternative:true}]);
				}
				return mcallback(true);
			});
		} else {
			return callback([{data:htmlGetter(link), alternative:true}]);
		}
	//}else{
	//	EM.composeValidateAccountEmail(o);
	//}
}

EM.dispatchValidateAccountLink = function(account, prefix, callback)
{
	EM.server.send({
		from         : ES.sender,
		to           : account.EmailID,
		subject      : ES.product +' Account Email Verification',
		text         : 'Email Verification',
		attachment   : EM.composeValidateAccountEmail(account)
	},  function(e, m){
			if (e) {
				console.log(e);
	            SNS.Publish({
	                    topic: 'securifi-email-logs',
	                    message: e,
	                    subject: prefix + ' Mail Send Failure - ' + account.EmailID
	                },
	                function(e, o) {});
	            callback(false);
	        } else {
	            SNS.Publish({
	                    topic: 'securifi-email-logs',
	                    message: m,
	                    subject: prefix + ' Mail Send Success - ' + account.EmailID
	                },
	                function(e, o) {});
	            callback(true);
	        }
		});
}

EM.composeValidateAccountEmail = function(o)
{
        var link;
        if(o.SERVER_NAME)
             link = o.SERVER_NAME + '/verify-account?email='+encode(o.EmailID)+'&token='+o.ValidationToken;
        else
             link = ES.LB + '/verify-account?email='+encode(o.EmailID)+'&token='+o.ValidationToken; 
	//var link = EM.nodeLB+'/verify-account?email='+encode(o.EmailID)+'&token='+o.ValidationToken;
//	var link = ES.LB+'/verify-account?email='+encode(o.EmailID)+'&token='+o.ValidationToken;
	//var html = '<html><head><title>Securifi. Inc,</title></head><body>';
	var html = '<html><head><title>'+ES.company+'</title></head><body>';
	html += '<p>Hi there,</p>';
	html += '<p>Thank you for creating '+ES.product+' account.</p>';
	html += '<p>Please confirm your email address by clicking on ';
	html += '<a href=\''+link+'\'>this link</a><br></p>';
	html += '<p>If you are not able to access the above link, copy and paste the below link into your browser.</p>';
	html += link;

	//if (config.data.PROVIDER == 'securifi') {
		html +='<p>You might also find our <a href='+ES.FORUM+'>community forum</a> helpful. There are a lot of smart home enthusiasts who post there frequently.';
	// }else{
	// 	html +='<p>Be sure to follow us on Facebook and Twitter at Chathomescreen.';  
	// }

	html +='</p><p>Thank You';
	//html +='</p><p>The Almond+ Team';
	html +='</p><p>'+ES.esignature;
	html +='</p></body></html>';
//logger.APP.debug('Email content: ' + html);
	return  [{data:html, alternative:true}];
}

EM.dispatchErrorLog = function(err, ip, callback)
{
	EM.server.send({
		from         : ES.sender,
		to           : ES.monitor,
		subject      : 'Crash Log - Server IP :'+ ip,
		text         : 'something went wrong... :(',
		attachment   : EM.composeErrorEmail(err, ip)
	}, callback );
}

EM.connectionErrorLog = function(err, callback)
{
	EM.server.send({
		from         : ES.sender,
		to           : ES.monitor,
		subject      : 'Connection lost ☹ - Server IP :'+ SERVER_NAME,
		text         : 'something went wrong... :(',
		attachment   : EM.composeErrorEmail(err, SERVER_NAME)
	}, callback );
}

EM.dispatchErrorOutput = function(err, ip, callback) {
	EM.server.send({
		from         : ES.sender,
		to           : ES.monitor,
		subject      : 'STDERROR - Server ID :'+ ip,
		text         : 'There are errors in the output... :(',
		attachment   : EM.composeErrorEmail(err, ip)
	}, callback );
};

EM.dispatchAppRestart = function(err, ip, callback) {
	EM.server.send({
		from         : ES.sender,
		to           : ES.monitor,
		subject      : 'Application Restarted:'+ ip,
		text         : 'STDERR tail... :(',
		attachment   : EM.composeErrorEmail(err, ip)
	}, callback );
};

EM.sendMessage = function(msg, subject, callback)
{
	EM.server.send({
		from         : ES.sender,
		to           : ES.monitor,
		subject      : subject,
		text         : 'something went wrong... :(',
		attachment   : [{data:msg, alternative:true}]
	}, callback );
}

EM.composeErrorEmail = function(err, ip)
{
	var html = '<html><body>';
	html += '<h1>Server Error Log - '+ip+'</h1><br>';
	html += err+'<br>'; 
	html += err.stack?err.stack:err+'<br>'; 
	html += '</body></html>';

	return  [{data:html, alternative:true}];
}

EM.notifyUser = function(EmailID, data,callback)
{
	var subject = '';
	if(data.eventType == 'invoice.payment_failed'){
		subject = 'Payment for subscription on the almond '+data.AlmondMAC +' was  Unsuccessful';
	}else if(data.eventType == 'invoice.payment_succeeded'){
		subject = 'Payment for subscription on the almond '+data.AlmondMAC +' was  Successful';
	}
	EM.server.send({
		from         : ES.sender,
		to           : EmailID,
		subject      : subject,
		text         : 'Subscription Payment',
		attachment   : EM.composeUserEmail(data)
	}, function(e,res){
		var data= e?e:res;
		fs.appendFile('Emails.txt',JSON.stringify(data)+'\n',function(){})
		return callback(e,res)
	} );
}

EM.composeUserEmail = function(data)
{
	var html='';
	if(data.eventType == 'invoice.payment_failed') {
		html+='Your payment for the subscription on the almond '+data.AlmondMAC+' was not successful.\n';
		html+='Please verify and update your card details\n';
		html+='Thank you';
	}else{
		html+='Your payment for the subscription on the almond '+data.AlmondMAC+' was successful.\n';
		html+='Thank you';
	}
	return  [{data:html, alternative:true}];
}

EM.notifySecurifi = function(EmailID, data,callback)
{
	var subject = '';
	if(data.eventType == 'invoice.payment_failed'){
		subject = 'Subscription Payment Unsuccessful '+EmailID;
	}else if(data.eventType == 'invoice.payment_succeeded'){
		subject = 'Subscription Payment Successful '+EmailID;
	}
	EM.server.send({
		from         : ES.sender,
		to           : ES.monitor,
		subject      : subject,
		text         : 'Subscription Payment',
		attachment   : EM.composeFailureSecurifiEmail(data)
	}, callback );
}

EM.composeFailureSecurifiEmail = function(data)
{
	var html='';
	if(data.eventType == 'invoice.payment_failed') {
		html+='Customer payment for the subscription on '+data.AlmondMAC+' was not successful.\n';
	}else{
		html+='Customer payment for the subscription on '+data.AlmondMAC+' was successful.\n';
	}
	return  [{data:html, alternative:true}];
}

EM.sendDownloadHistory = function (req, path, type, callback) {
    var message	= {
        text:	"History of Devices for " + req.mac, 
        from:	ES.sender,
        to:     req.email,
        //cc:		"else <else@your-email.com>",
        subject:	"History of Devices for " + req.mac,
        attachment: 
        [
           //{data:"<html>i <i>hope</i> this works!</html>", alternative:true},
           {path:path, type:type, name:req.emailFile}
        ]
    };
    EM.server.send(message, callback);
};
function getServices(service){
var map={'IoT':'IoT Service','CMS':'ProMonitoring Service' ,'IoT_CMS':'ProMonitoring & IoT Services'};
return map[service]?map[service]:'';
}

EM.subscriptionNote=function(payload,add,planName){
	let payment=(!payload.VATCode||payload.VATCode=='Stripe')?'Stripe':'VAT Code'
	var html ='<html><head><title>'+ES.company+'</title></head><body>';
			html+= '<p>Hi there,';
			if(add)
				html+='<p>We received  subscription from User '+ payload.EmailID+' of AlmondMAC- '+payload.AlmondMAC+' for  Plan -'+planName+' has Services '+ getServices(payload.Services)+ ' Payment through '+payment+'</p>';
			else html+='<p>We received  Cancel subscription  from User '+ payload.EmailID+' of AlmondMAC- '+payload.AlmondMAC+' for  Plan -'+planName+' has Services '+getServices(payload.Services)+' Payment through '+payment+'</p>';
			html+='<p>Thank You';
			html+='</p><p>'+ES.esignature;
			html+='</p></body></html>';
			return  [{data:html, alternative:true}];
}
function getPlanName(plan,planName){
	if(planName)
		return planName
	if(!plan || plan.split('-').length==1)
		return plan;
	return plan.split('-')[1]
}

EM.notifyMail= function(req,add,callback){
var subject = 'Subscription  Cancelled';
	if(add)
		subject = 'Successfully Subscribed ';
	var toMail=['cloud@securifi.com']
	if(req.CMSEmail)
		toMail.push(req.CMSEmail)
	EM.server.send({
		from         : ES.sender,
		to           : toMail.join(),
		subject      : subject,
		text         : 'Subscription ',
		attachment   : EM.subscriptionNote(req,add,getPlanName(req.PlanID,req.PlanName))
	}, function(e,res){
		var data= e?e:res;
		fs.appendFile('Emails.txt',JSON.stringify(data)+'\n',function(){})
		return callback(e,res)

	} );
}	
EM.sendFile = function(path,subject,callback){
	EM.server.send({
		from         : ES.sender,
		to           : ES.monitor,
		subject      : subject,
		text         : new Date(),
		attachment   : [{name: 'stats.csv', path: path,type:'application/csv'}]
	}, callback );
}

module.exports = EM;

