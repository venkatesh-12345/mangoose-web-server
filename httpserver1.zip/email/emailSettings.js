var config = require('../config.js');
var email=config.EMAIL
if (config.PROVIDER == 'securifi' || !config.PROVIDER) {
    module.exports = {
        /*	
         host		: 'smtp.gmail.com',
         user 		: 'securifi.cloud@gmail.com',
         password 	: 'longreach',
         sender		: 'Nirav Uchat <nirav.uchat@gmail.com>',
         adminEmail		: 'nirav@securifi.com'
         */
        host: 'email-smtp.us-east-1.amazonaws.com',
        user: email.USER,
        password: email.PASSWORD,
        sender: 'Securifi.com <support@securifi.com>',
        adminEmail: 'support@securifi.com',
        monitor: 'cloud@securifi.com',
        LB: 'https://connect.securifi.com',
        FORUM: 'https://forum.securifi.com',
        company: 'Securifi, Inc.',
        product: 'Almond',
        esignature: 'Securifi Team'
    };
} else if (config.PROVIDER == 'cox') {
    module.exports = {
        host: 'email-smtp.us-east-1.amazonaws.com',
        user: email.USER,
        password: email.PASSWORD,
        sender: 'Homescreenrouter.com <welcome@homescreenrouter.com>',
        adminEmail: 'support@homescreenrouter.com',
        monitor: 'cloud@securifi.com',
        LB: 'https://connect.homescreenrouter.com',
        FORUM: 'https://forum.homescreenrouter.com',
        company: 'Cox Communications',
        product: 'HomeScreen',
        esignature: 'The HomeScreen Team'
    };
}
