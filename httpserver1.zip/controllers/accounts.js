var moment = require('moment');
var errorCodesForClients = require('./../ErrorCodes/errorCodesForClients.js');
var EM = require('./../email/emailDispatcher');
var redisStore= require('../database/redis/redisStore');
var producer = require('./../rabbitmq/producer')
var genericModel = require('../database/model/genericModel');
var table = require('./../util/table');
var bcrypt = require('bcrypt');
var crypto = require('crypto');
var fs = require('fs')
var tracker= require('./../tracking')
var accCmd = {};

var mapping = {
    reset: {
        keys: ['emailID'],
        comparePassword: false,
        model: 'resetPassword'
    },
    add: {
        keys: ['emailID', 'password'],
        comparePassword: false,
        noUsersCheck: true,
        model: 'signup'
    },
    sendActivation: {
        keys: ['emailID'],
        comparePassword: false,
        model: 'resendActivationLink'
    },
    delete: {
        keys: ['emailID', 'password'],
        comparePassword: true,
        model: 'deleteAccount'
    },
    verify: {
        keys: ['emailID', 'token'],
        comparePassword: false,
        model: 'verifyAccount'
    },
    confirmReset: {
        keys: ['emailID', 'password','token'],
        comparePassword: false,
        model: 'confirmResetPassword'
    },
    logout: {
        keys: ['userID', 'tempPass'],
        comparePassword: false,
        model: 'logout'
    }
};




function get_random_string(len) {
    var chars = '23456789ABCDEFGHJKLMNPQRSTUVWXTZabcdefghkmnopqrstuvwxyz';
    len = len ? len : 6;
    var string = '';
    for (var i = 0; i < len; i++) {
        var randomNumber = Math.floor(Math.random() * chars.length);
        string += chars.substring(randomNumber, randomNumber + 1);
    }
    return string;
}

var saltAndHash = function (request, callback) {
    bcrypt.genSalt(10, function (err, salt) {
        if (err)
            return;
        bcrypt.hash(request.password, salt, function (err, hash) {
            request.password = hash;
            return callback();
        });
    });
};

function validate(keys, request) { // validator function
    var validity = true;
    if (keys)
        keys.forEach(function (currentValue) {
            if (!request[currentValue])
                validity = false;
        });
    return validity;
}

function emailValidateAccountLink(dataToDispatch, msg, callback) {
    EM.dispatchValidateAccountLink(dataToDispatch, msg, function(result) {
        if (result)
            return callback( 200, {'success': "true"});
        return callback( 502, {
            'success': false,
            'reason': 'EmailServer Down'
        });
    });
}

function addSecondaryUser(mac, userid, emailID, callback) {
    genericModel.insertUpdate(table.ALMOND_SUSER, { AlmondMAC: mac, userID: userid }, function(e, res) {
        if (!e && res && res.affectedRows > 0) {
            redisStore.setSecondaryUser(mac, userid, function(er, res) {
                redisStore.getAlmond(mac, function(err, redisData) {
                    if (redisData && redisData.status == 1) {
                        producer.sendToQueue(
                            redisData.server,
                            JSON.stringify({
                                command: 2222,
                                payload: JSON.stringify({ CommandType: "UserInviteRequest", AlmondMAC: mac, UserID: userid + "" }),
                                unicastID: 0,
                                AlmondMAC: mac
                            })
                        );
                    }
                });
            });
        }
        genericModel.deleteWithConditions(table.INVITEDEMAILS, {equal:{ EmailID: emailID }}, function(e, res) {
            console.log("removed insertUser");
        });
    });
}

accCmd.invitedEmail = function(emailID) {
    genericModel.select(table.INVITEDEMAILS, { EmailID: emailID }, function(e, res) {
        if(err&&err=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE"
            });
        if (e || !res || res.length < 1) return;
        genericModel.select(table.USERS, { emailID: emailID }, function(e, uRows) {
            if (e || !uRows || uRows.length < 1) return;
            addSecondaryUser(res[0].AlmondMAC, uRows[0].UserID, emailID, function(e, sUser) {});
        });
    });
};
accCmd.signup = function (request, callback, rows) {
    if (Object.keys(rows).length > 0)
        return callback( 502, {
            'success': false,
            'reason': 'Email Taken'
        });
    saltAndHash(request, function (hash) {
        request.token = get_random_string(32);
        request.EmailValidated = '0';
        request.Date = new Date();
        genericModel.insertUpdate(table.USERS, request, function (err, rows) { // insert
            if(err&&err=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE"
            });
            var dataToDispatch = {
                EmailID: request.emailID,
                ValidationToken: request.token
            };
            if (request.serverName)
                dataToDispatch.SERVER_NAME = request.serverName;
            emailValidateAccountLink(dataToDispatch, 'Signup Activation', callback);
            if(rows.affectedRows==1)
                accCmd.invitedEmail(request.emailID);
        });
    });
};

accCmd.resendActivationLink = function (request, callback, rows) {
    if (rows.EmailValidated == 1) {
        return callback( 502, {
            'success': false,
            'reason': 'Already Validated'
        });
    }
    request.token =  get_random_string(32);
    request.userID = rows.UserID;
    genericModel.insertUpdate(table.USERS, request, function (e, out) { // update
        if(e&&e=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE"
            });
        if (!out)
            return;

        var dataToDispatch = {
            EmailID: request.emailID,
            ValidationToken: request.token
        };
        if (request.serverName)
            dataToDispatch.SERVER_NAME = request.serverName;
        emailValidateAccountLink(dataToDispatch, 'Resend Activation', callback);
    });
};

accCmd.process = function (request, callback, command) {
    try {
        var mapper = mapping[command];
        callback.TimeStamp= Date.now()
        var validity = validate(mapper.keys, request);
        if (!validity)
            return callback( 502);
        var response = {
            'success': false,
            reason: 'No such user'
        };
        authenticate(table.USERS, request, mapper.comparePassword, function (e, o) {
            if(e&&e=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE"
            });
            if (!mapper.noUsersCheck && (!o || o.length === 0))
                return callback( 502, response);
            var funcName = mapper.model;
            accCmd[funcName](request, callback, o);
        });
    } catch (error) {
        console.error(error);
        return callback(errorCodesForClients.INTERNAL_SERVER_ERROR);
    }

};

var insertTemppassword = function (rows, callback) {
    var buf = crypto.randomBytes(64);
    var tempPass = buf.toString('hex');
    var data = {
        userID: rows.UserID,
        tempPass: tempPass,
        LastUsedTime: new Date()
    };
    genericModel.insertUpdate(table.USER_TEMP_PASSWORDS, data, function (err, resRows) { // insert
        console.log('Error  ',err);
        rows.tempPass = tempPass;
        return callback();
    });
};


var authenticate = function (table, request, needCompare, callback) {
    var password = request.password;
    delete request.password;
    genericModel.select(table, request, function (err, rows) {
        if(err&&err=='MAINTENANCE')
            return callback("MAINTENANCE",null);
        if (password)
            request.password = password;
        if (!rows || rows.length === 0) {
            console.log('authenticate rows length zero');
            return callback(null, rows);
        }
        if (!needCompare)
            return callback(null, rows[0]);
        bcrypt.compare(request.password, rows[0].Password, function (err, res) {
            if(request.emailID.indexOf("zenthermostat")>-1 || request.emailID.indexOf("zen_securifi")>-1)
                rows[0].zen=true; 
            return callback(null, rows[0], res);
        });

    });

};


var loginResponseHandler = function (callback, rows, errorCode) {
    if (errorCode)
        return callback( 502);
    var diff = moment(rows.Date).add(7, 'days').diff(new Date(), 'minutes');
    var dateHour = moment(rows.Date).format('h');
    var minRemaining = diff;
    if (diff < 0)
        if (dateHour >= 8)
            minRemaining = (8 - dateHour + 24) * 60;
        else
            minRemaining = (8 - dateHour) * 60;
    var result = {
        "commandType": "Login",
        "success": true,
        "userID": rows.UserID,
        "tempPass": rows.tempPass,
        "isActivated": rows.EmailValidated,
        "minutesRemaining": (rows.isActivated) ? minRemaining : "",
        "FirstName": rows.FirstName,
        "LastName": rows.LastName,
        "Zen":rows.zen
    };

    return callback( 200, result);
};


function validateLogin(request, callback) {
    if (request.emailID && request.password)
        return {
            firstLogin: true
        };
    else if (request.userID && request.tempPass)
        return {
            firstLogin: false
        };
    callback( 502);
    return null;
}


accCmd.login = function (request, callback, cmndType) {
    try {
        var validity = validateLogin(request, callback);
        if (!validity)
            return;
        if (validity.firstLogin) {
            authenticate(table.USERS, request, true, function (error, rows, bcryptRes) {
                if(error && error=='MAINTENANCE')
                    return callback( 503, {
                        "error": "MAINTENANCE"
                    });
                if (!rows || !bcryptRes) {
                    return loginResponseHandler(callback, rows, true);
                }
                insertTemppassword(rows, function (e, out) {
                    loginResponseHandler(callback, rows, false);
                });
            });
        } else {
            genericModel.select(table.USER_TEMP_PASSWORDS, request, function (err, rows) {
                if (rows.length !== 0)
                    authenticate(table.USERS, request, false, function (error, rows, bcryptRes) {
                        rows.tempPass = request.tempPass;
                        loginResponseHandler(callback, rows, false);
                    });
            });
        }
    } catch (error) {
        console.error(error);
        return callback(errorCodesForClients.INTERNAL_SERVER_ERROR);
    }
};


accCmd.deleteAccount = function (request, callback, rows) {
    delete request.password;
    delete request.emailID;
    request.userID = rows.UserID;
    genericModel.deleteWithConditions(table.USERS, {equal:{userID:rows.UserID}}, function (e, o) {
        if(err&&err=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE"
            });
        console.log('AM.Delete_Account - User Data deleted');
        return callback( 200, {"success": true});
    });
};


//req.body: emailID, token
accCmd.verifyAccount = function (request, callback, rows) {
    request.EmailValidated = 1;
    request.userID = rows.UserID;
    genericModel.insertUpdate(table.USERS, request, function (err, rows) {
        if(err&&err=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE"
            });
        if (rows.affectedRows > 0)
            callback( 200, {"success": true});
    }); // update

};

//req.body:
accCmd.resetPassword = function (request, callback, rows) {
    request.userID = rows.UserID;// check
    var token = get_random_string(32);
    request.token = token;
    genericModel.insertUpdate(table.USERS, request, function (e, out) { // update
        if(e&&e=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE"
            });
        if (!out)
            return;

        out.ValidationToken = token;
        out.Subject = 'PASSWORD_RESET';
        out.EmailID = request.emailID;
        if (request.serverName)
            out.SERVER_NAME = request.serverName;
        if (request.echo_params)
            out.echo_params = request.echo_params;
            EM.sendAndRecordEmail(out, function(e, m) {
                return callback( 200, {
                    success: !e ? true : false
                });
            });
    });
};

accCmd.confirmResetPassword = function (request, callback, rows) {
    request.userID = rows.UserID;
    saltAndHash(request, function (hash) {
        request.token = '';
        genericModel.deleteWithConditions(table.USER_TEMP_PASSWORDS,{equal:{userID:request.userID},null:{ClientName:'true'}},function(e,res){
            if(e&&e=='MAINTENANCE')
                return callback( 503, {
                    "error": "MAINTENANCE"
                });
            genericModel.insertUpdate(table.USERS, request, function (e, out) {
                if (!out)
                    return;
                return callback( 200, {
                    success: !e ? true : false
                });
            });
        });
    });
};

accCmd.logout = function (request, callback, rows) {
    genericModel.deleteWithConditions(table.USER_TEMP_PASSWORDS, {equal:request}, function (err, rows) {
        if(err&&err=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE"
            });
        if (rows.affectedRows == 0)
            return callback( 502, {
                'success': false,
                'reason': 'Invalid UserID or TempPass'
            });
        else
            return callback(200, {"success": true});
    });
};
accCmd.do =function(body,callback){
    body.commandType=body.commandType.split('/')[1];
    var path=body.commandType;
    if(mapping[path])
        path='process';
    accCmd[path](body,callback,body.commandType);
}
module.exports = accCmd
