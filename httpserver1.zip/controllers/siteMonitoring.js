var moment = require('moment');
var cat = require('../siteMonitoring/categoryMapping.js');
var loggerPoint = require('../database/cassandra/cqlConnection');
var util = require("util")
var sql = require('../database/sql/sqlQuery');
var queries = require('../siteMonitoring/queries')
var config = require('../config.js').smTables;
var siteMonitoringTable = config.history;
var bandwidthTable = config.bandwidthtable;
var categorySuggestionTable = config.categorySuggestionTable;
var BW_Reset_info = config.BW_Reset_info;
var processor = {};

var weekSearch = function(payload, result) {
    result.params.push(payload['value']);
    var weekDate = payload['value'].split('-');
    var time = (new Date(weekDate[0], weekDate[1] - 1, weekDate[2]).getTime() / 1000) - 604800;
    result.params.push(moment(time * 1000).format('YYYY-MM-DD'));
}

var weekDaySearch = function(payload, result) {
    result.params.push(getDomainDate(payload['value']));
}

var hourSearch = function(payload, result) {
    if (payload['search'] == 'LastHour')
        result.params.push(payload['value'].substr(0, 2) - 1);
    else
        result.params.push(payload['value'].substr(0, 2));
    result.params.push(payload['today']);
}

var domainSearch = function(payload, result) {
    var myDomain = payload['value'].toLowerCase();
    result.params.push(getDomainDate(payload['today']));
    result.params.push(myDomain);
    var c = myDomain;
    var e = c.slice(0, (c.length - 1)) + String.fromCharCode(c.charCodeAt(c.length - 1) + 1);
    result.params.push(e);
}

function getDomainDate(day) {
    var weekDate = day.split('-');
    var dates = [];
    for (var i = 0; i < 7; i++) {
        var time = (new Date(weekDate[0], weekDate[1] - 1, weekDate[2]).getTime() / 1000) - (86400 * i);
        dates.push((moment(time * 1000).format('YYYY-MM-DD')));
    }
    return dates;
}

var deleteBandwidth = function(payload, params) {
    if(payload['today'].indexOf('-')<4)
        payload['today']=payload['today'].split("-").reverse().join("-");
    var query = 'select rx,tx,dateyear from browsing_log_store.' + bandwidthTable + ' where mac = ? and client_mac = ? and dateyear=?';
    var params = [payload['AMAC'], payload['CMAC'],payload['today']];
    loggerPoint.execute(query, params,{prepare: true}, function(error, result) {
        if (result == undefined || result.rows.length == 0) {
            return;
        }
        else {
            //for(var i in result.rows){
               var rx = parseInt(result.rows[0].rx);
               var tx = parseInt(result.rows[0].tx);
                query = 'update  browsing_log_store.bandwidthmonitor set rx = rx-? , tx = tx-?  where mac = ? and client_mac = ? and dateyear = ?';
                params = [rx, tx, payload['AMAC'], payload['CMAC'], result.rows[0].dateyear];
                loggerPoint.execute(query, params,{prepare: true}, function(error, result) {
                    ;//logger.logMobileError("Error in DeleteBandwidth ->" + error);
                })
            //}
        }
    })
    return payload['CMAC'];
}

var getBandwidth = function(payload, result) {
    result.params.push(payload['today']);
    var weekDate = payload['today'].split('-');
    var time = (new Date(weekDate[0], weekDate[1] - 1, weekDate[2]).getTime() / 1000) - 86400 * payload['value'];
    console.log("Date is = ", (moment(time * 1000).format('YYYY-MM-DD')));
    result.params.push(moment(time * 1000).format('YYYY-MM-DD'));
}

var epochSearch = function(payload, result) {
    result.params.push(payload['today']);
    result.params.push(payload['value']);
}

var valueSearch = function(payload, result) {
    result.params.push(payload['value']? payload.value: moment().format("YYYY-MM-DD"));
}

var dataUsageReset = function(payload, result) {
    if (payload['value'] >= 1 && payload['value'] <= 31 && payload['TZ']) {
        result.params.push(payload['value']);
        result.params.push(payload['TZ']);
    }
}

var noFunction = function(payload, result) {}

var executeReset = function(result, callback) {
    result.params=result.params.concat(result.params);
    sql.queryFunction(result.query, result.params, callback);
}

var isNumeric = function(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

var suggesetRating = function(payload, result) {
    result.params = [[payload['value']]];
    result.payload = payload;
}

processor.chopDomain = function(site) {
    var splitedSite = site.split(".");
    var length = splitedSite.length;
    if (splitedSite.length >= 3) {
        if (splitedSite[length - 2].length <= 3 && splitedSite[length - 1].length <= 2) {
            return (splitedSite[length - 3] + '.' + splitedSite[length - 2] + '.' + splitedSite[length - 1]);
        }
        else {
            return (splitedSite[length - 2] + '.' + splitedSite[length - 1]);
        }
    }
    else
        return site;
}

function executeChangeCategory(data, callback) {
    if (!isNumeric(data.payload.suggestedValue))
        return callback("Incorrect payload", null);
    loggerPoint.execute(data.query, data.params, function(error, result) {
        if (!result || !result.rows || result.rows.length == 0)
            return callback("Site Not found", null);
        var query = 'insert into browsing_log_store.' + categorySuggestionTable + ' (category , mac , oldsubcategory , suggestedsubcategory ) values (? , ? , ? ,?) ';
        var category = parseInt(result.rows[0].category);
        var params = [category, data.payload['AMAC'], cat[category]['category'], data.payload['suggestedValue']];
        loggerPoint.execute(query, params, { prepare : true }, callback);
    });
}

processor.getQuery = function(payload) {
    var table = (Object.prototype.hasOwnProperty.call(payload, 'IOT') && payload.IOT =='1') ? config.iot : config.history;
    var result = { query: util.format(queries.SELECT, table), params: [payload.AMAC, payload.CMAC] };
    var searchString = payload.search;
    if (!searchString)
        return result;

    var queryBuilder = mapper[searchString];
    if (!queryBuilder)
        return { error: "This Search is not Supported" };

    if (!Object.prototype.hasOwnProperty.call(payload, 'value')|| (!payload.value &&  searchString!='Date') ||(!payload.TZ &&  searchString =='DataUsageReset') || (queryBuilder.extraParams && !payload[queryBuilder.extraParams]))
        return { error: "Paramters are missing" };
    console.log(" HERER&&&&&&&&&&&&&&&&&&& ", queryBuilder.query)
    if(queryBuilder.execute)
        result.execute=queryBuilder.execute
    queryBuilder.get(payload, result);
    result.query = util.format(queryBuilder.query, queryBuilder.table ? queryBuilder.table : table);
    return result;
}

function sendResponse(res, error, data) {
    if (error)
        return res.status(200).send({ success: false, reason: error });
    res.status(200).send(data);

}
function handleResponse(payload, data) {
    var responseJSON = {};
    responseJSON['pageState'] = data.pageState?data.pageState:undefined;
    responseJSON['AMAC'] = payload['AMAC'];
    responseJSON['CMAC'] = payload['CMAC'];
    if (payload['search']) {
        responseJSON['value'] = payload['value'];
        responseJSON['search'] = payload['search'];
    }
    if (data.rows&&data.rows.length < 100 && payload.search == 'PresentHour') {
        responseJSON['ChangeHour'] = 1;
    }
    var responseHandler = (payload.search == 'Bandwidth') ? bandwidthResponse : otherResponse;
    responseHandler(data.rows, responseJSON);
    return responseJSON;
}

function bandwidthResponse(rows, responseJSON) {
    var data = { RX: 0, TX: 0 };
    if(!responseJSON.pageState)
        responseJSON.pageState=null;
    rows.forEach(function(item) {
        data.RX += parseInt(item.rx);
        data.TX += parseInt(item.tx);
    });
    responseJSON['Data'] = data;
}

function otherResponse(rows, responseJSON) {
    if(rows){
        rows.forEach(function(item) {
            item.Domain = processor.chopDomain(item.Domain);
            if(item['LastVisitedEpoch'])
	     	item['LastVisitedEpoch']=item['LastVisitedEpoch'].getTime();
            if(item['epochs']!=undefined){
                var arrays = [];
                item['epochs'].forEach(function(item2){
                    arrays.push(item2.getTime());
                })
                item['Epochs'] = arrays;
                delete item.epochs;
            }
            if(item['subCategory']!=undefined)
                item['subCategory'] = item['subCategory'].toString();
            if(item['Category']!=undefined)
                item['Category'] = item['Category'].toString();
            if(item['Category']==null)
                item['Category']='null';
            if(item['subCategory']==null)
                item['subCategory']='null';
        });
    }
    responseJSON['Data'] = rows;
}

processor.do = function(payload,callback) {
    if ( !payload.CMAC|| !payload.AMAC || !payload.UserId || !payload.TempPass )
        return callback(200,{error:'Improper JSON'})
    loginAuthCheck(payload,function(e,r){
        if(e && e=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE mode"
            });
        if(e||!r){
            return callback(502,JSON.stringify({"error": 'oauth error'}))
        }
        var pageState=payload.pageState?payload.pageState:null;
        var data = processor.getQuery(payload);
        if (data.error)
            return callback(200, data.error)
        if (!data.execute){
            loggerPoint.execute(data.query, data.params,{prepare: true,fetchSize: 100,pageState: pageState},  function(e, o) {
    	    if(e&&!o)
                    return callback(200,e);            
    	    return callback(200, handleResponse(payload, o));
            });
        }
        else
            data.execute(data, function(e, o) {
                if(!e&&o)
                    return callback(200, {success:true});
                else 
                    return callback(200,e);  
            })
    })
}
var mapper = {
    FromThisDate: { get: valueSearch, query: queries.dateSearch },
    Category: { get: valueSearch, query: queries.categorySearch },
    Date: { get: valueSearch, query: queries.thisDateSearch },
    LastWeek: { get: weekSearch, query: queries.weekSearch },
    Domain: { get: domainSearch, query: queries.domainSearch, extraParams: "today" },
    WeekDay: { get: weekDaySearch, query: queries.weekDaySearch },
    LastHour: { get: hourSearch, query: queries.hourSearch, extraParams: "today" },
    PresentHour: { get: hourSearch, query: queries.hourSearch, extraParams: "today" },
    Bandwidth: { get: getBandwidth, query: queries.getBandwidth,table:config.bandwidthtable, extraParams: "today" },
    Epoch: { get: epochSearch, query: queries.epochSearch, extraParams: "today",table:config.history },
    ClearHistory: { get: noFunction, query: queries.clearHistory },
    ClearBandwidth: { get: deleteBandwidth, query: queries.deleteBandwidth, table: config.bandwidthtable },
    DataUsageReset: { get: dataUsageReset, query: queries.dataUsageReset, execute: executeReset, table: config.BW_Reset_info },
    SuggestRating: { get: suggesetRating, query: queries.suggestRating, execute: executeChangeCategory, table: config.categoryDBTable },
}
var loginAuthCheck = function (payload, callback) {
    var almondMAC = payload.AMAC
    var userId = payload.UserId
    var tempPass = payload.TempPass;
    var params = ['UserTempPasswords', userId, tempPass];
    var query = 'SELECT * FROM ?? where UserId=?  AND TempPassword=? LIMIT 1';
    sql.queryFunction(query, params, function(err, rows) {
        if (err || rows.length == 0)
            callback(err, null);
        else if (rows.length == 1) {
            query = 'SELECT AlmondMAC, userID FROM ?? where AlmondMAC=? AND userID=? '+
                'UNION '+
                'SELECT AlmondMAC, userID FROM ?? where AlmondMAC=? AND userID=? ';
            params = ['AlmondUsers', almondMAC, userId, 'AlmondSecondaryUsers', almondMAC, userId];
            sql.queryFunction(query, params, function (err, rows) {
                if (err || rows.length == 0) 
                    callback(err, null);
                else if (rows.length == 1) 
                    callback(err, rows);
            });
        }
    });
};
module.exports = processor;
