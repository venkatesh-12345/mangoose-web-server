var builder = {};
function OrderAlmondMAC(type, rows) {
    var reply = {};
    for (var i in rows) {
        if (!reply.hasOwnProperty(rows[i]['AlmondMAC'])) {
            reply[rows[i]['AlmondMAC']] = {};
            reply[rows[i]['AlmondMAC']][type] = [];
            if (rows[i].flag)
                continue;
        }
        reply[rows[i]['AlmondMAC']][type].push(rows[i]);
        delete rows[i]['AlmondMAC'];
    }
    return reply;
}
function multi(row,replies,type,values){
    var entities=OrderAlmondMAC(type,row);
    var i=0;
     for (var key in entities){
        if(values&&entities.hasOwnProperty(key)){
            if(!replies[key])
                continue;
            for(var keys in entities[key][type]){
                try{
                    var value=JSON.parse(replies[key][0])
                }catch(err){
                    continue;
                }
                entities[key][type][keys].deviceValue=value[entities[key][type][keys].DeviceID];
            }
        }
        else if (entities.hasOwnProperty(key)) {
            entities[key].status = replies[i][0];
            entities[key].name = replies[i][1];
            entities[key].version = replies[i][2];
            i++;
        }
    }
    return entities
}
var response=function(command,requestJson,rows, status, version){
    var commandType="CloudResponse";
    var mac=null;
    if(requestJson){
        commandType=requestJson.commandType;
        mac=requestJson.AlmondMAC;
    }
    var payload={CommandType:commandType,Success:true,AlmondMAC:mac};
    if(status && version){
        payload.status = status;
        payload.version = version;
    }
    if(rows){
        var tag=Object.keys(rows)[0];
        payload[tag]=rows[tag];
    }
    return (payload);
}
builder.do = function(wrapper, rows, deviceValues,status,version,payload) {

    if (!wrapper.builder || !rows || rows.length <= 0)
        return {};
    var modifiedRows = {};
    var list = {};
    if(wrapper.builder.indexOf('multi')>=0){
        return {success:true,Result:builder[wrapper.builder](rows,deviceValues,modifiedRows)};
    }
    modifiedRows[wrapper.builder] = list;    
    for (var i = 0; i < rows.length; i++) {
        changeColumn(rows[i],wrapper.mapping);
        builder[wrapper.builder](list, rows[i], deviceValues);
    }
    return response(payload.commandType,payload,modifiedRows,status,version);
};
function changeColumn(row,mapping){
    for(var i=0;i<mapping.keys.length;i++){
        if(mapping.required[i]!=mapping.keys[i]){
            row[mapping.required[i]]=row[mapping.keys[i]];
            delete row[mapping.keys[i]];
        }
    }
}

builder.Clients = function(rowsObject, row) {
    rowsObject[row.ID] = JSON.parse(row.Clients);
};

builder.multiClient = function( rows,replies) {
    for (var i in rows){
        if (rows[i]['ClientDetails']) {
            rows[i]['ClientDetails'] = JSON.parse(new Buffer(rows[i].ClientDetails, 'binary').toString());
            rows[i]['ClientDetails'] = {
                "Block": rows[i]['ClientDetails'].Block,
                "CanBlock": rows[i]['ClientDetails'].CanBlock,
                "Category": rows[i]['ClientDetails'].Category,
                "Name": rows[i]['ClientDetails'].Name,
                "MAC": rows[i]['ClientDetails'].MAC
            };
        } else
            rows[i].flag = true;
    }
    return multi(rows,replies,'Clients');
};
builder.multiDeviceValues=function(rows ,deviceValues){
    return multi(rows,deviceValues,'Devices',true);
}
builder.Scenes = function(rowsObject, row) {
    row.SceneEntryList = JSON.parse(row.SceneEntryList);
    rowsObject[row.ID] = row;
};

builder.Rules = function(rowsObject, row) {
    row.Triggers = JSON.parse(row.Triggers);
    row.Results = JSON.parse(row.Results);
    rowsObject[row.ID] = row;
};

builder.Devices = function(rowsObject, row, deviceValues) {
    rowsObject[row.ID] = { Data: row };
    rowsObject[row.ID].DeviceValues = deviceValues ? deviceValues[row.ID] : {};
};

builder.multiDevice=function(row,replies){
    return multi(row,replies,'Devices')
}
builder.multiAlmond=function(rows,replies,modifiedRows){
    var modifiedRows={};
    modifiedRows['Almonds']=[];
    for(var i in rows){    
        rows[i].FirmwareVersion = replies[i][2];
        rows[i].status = replies[i][0];
        rows[i].AlmondName=replies[i][1];
        rows[i].mode=replies[i][3]
        modifiedRows['Almonds'].push(rows[i]);
    }
    return modifiedRows
}
builder.multiScene=function(rows,replies){
 for (var i in rows){
    if (rows[i]['SceneEntryList'])
        rows[i]['SceneEntryList'] = JSON.parse(new Buffer(rows[i].SceneEntryList, 'binary').toString());
    else
        rows[i].flag = true;
}
    return multi(rows,replies,'Scenes')
}

module.exports = builder;
