var redis = require("../database/redis/redisConnector");
var producer = require("../rabbitmq/producer");
var config = require("../config.js");
var storeRes = require("../almondEndpoint/responseHandler");
var broadCaster= require('../broadcast/updateEndPointNew')
var processor = {};
function getServer(body, callback) {
    if (!body) return callback(true);
    redis.query("hgetall", "AL_" + body.almondMAC, function(e, res) {
        if (e || !res) return callback(true);
        return callback(null, res);
    });
}
function sendToQueue(server, data) {
    if(server && data)
    producer.sendToQueue(server, JSON.stringify(data));
}

var findAndSend=function(data, callback) {
    if (!data.almondMAC) return callback(502);
    getServer(data, function(er, replies) {
        if (er || !replies) return callback(502);
        if (replies.status == "1" && replies.server) {
            sendToQueue(replies.server, data);
            return callback(200);
        } else return callback(502);
    });
}

function checkIP(request) {
    try{
         return (config.portalIP.indexOf(request.headers['x-forwarded-for'].split(",")[0]) > -1);
    }catch(error){
        console.log("Send to Queue  error ",error);
        return false;
    }
}

processor.do = function(request, callback, response) {
    var toEntity = request.get("server");
    if (!checkIP(request) || !request.body || !toEntity) {
        return callback(502);
    }
    try {
        if (toEntity == "almond") findAndSend(request.body, callback);
        else if (toEntity == "background") {
            if (request.body.command == 1030)
                getServer(request.body, function(e, res) {
                    if (e) return callback(502);
                    request.body.server = res.server;
                    sendToQueue(config.background_queue, request.body);
                    return callback(200);
                });
            else {
                sendToQueue(config.background_queue, request.body);
                return callback(200);
            }
        }else if(toEntity=='mobile'){
            broadCaster.broadcastToMobile(request.body.AlmondMAC,request.body.payload,request.body.command)
             return callback(200);
        } 
        else if (toEntity == "findAlmond" && request.body.AlmondMAC) {
            var commandID=Math.floor(Math.random()*1000)
              var payload={"id":2020,"res":"{}",commandID:commandID,"len":16}
            payload.almondMAC=request.body.AlmondMAC ;
            payload.queue = config.rabbitmq.queueName;
            for(var i=0;i<config.servers.length;i++)
                sendToQueue(config.servers[i], payload);
            response.totalCount=config.servers.length;
            storeRes.storeInHash(payload.commandID, {response:response},{timeoutLimit:2*60*1000});
        } else return callback(502);
    } catch (e) {
        console.log(e);
        return callback(502);
    }
};

module.exports = processor;
