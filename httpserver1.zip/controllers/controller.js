var device = require('../database/model/device');
var genericModel = require('../database/model/genericModel');
var column=require('../util/columns').columns;
var table=require('../util/table')
var notificationFetcher = require('../database/model/notificationFetcher.js');
var recentActivity=require('../database/model/macRecentActivity.js')
var wrapper = {};

wrapper = {
    devices: {
        model: device.execute,
        builder: "Devices",
        mapping: column.DeviceData
    },
    'devices/getAll': {
        model: device.executeQuery,
        builder: "multiDevice",
    },
    'devices/getAll/values':{
       model: device.executeQuery,
       builder: "multiDeviceValues",
    },
    'scenes': {
        model: genericModel.get,
        builder: "Scenes",
        mapping: column.SCENE,

    },
    'scenes/getAll': {
        model: device.executeQuery,
        builder: "multiScene",
    },
    'rules': {
        model: genericModel.get,
        builder: "Rules",
        mapping: column.RULE,
    },
    'clients': {
        model: genericModel.get,
        builder: "Clients",
        mapping: column.WIFICLIENTS,
    },
    'clients/getAll': {
        model: device.executeQuery,
        builder: "multiClient",
    },
    'almonds':{
        model: device.executeQuery,
        builder: "multiAlmond",
    },
    'devices/history':{
        model:notificationFetcher.getLogs,
    },
    'clients/history':{
        model:notificationFetcher.getLogs,
    },
    'RecentActivity':{
        model:recentActivity.execute,
        responseMaker:true
    }



}

module.exports = wrapper;