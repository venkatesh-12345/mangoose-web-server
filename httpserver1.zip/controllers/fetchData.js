var rowBuilder = require('./rowBuilder'),
    controller = require('./controller');
var processor = {};

processor.do = function(payload,callback) {
    var pathController = controller[payload.commandType];
    if (!pathController)
        return callback(404,{error:'Cannot GET '+payload.commandType });
    pathController.model(pathController.mapping,payload, payload.commandType, function(error, rows, deviceValues, status, version) {
    	if(error)
    		return callback(200,{error:error});
    	if(pathController.builder){
	    var listResponse = rowBuilder.do(pathController, rows, deviceValues,status,version,payload);
            if(payload.commandType=='almonds')
                listResponse=listResponse.Result;
        }
	    else
	    	var listResponse=rows
	    if(pathController.responseMaker)
	    	listResponse={"success":true,"Result":listResponse}
	    callback( 200,listResponse);
    });
}
module.exports = processor;
