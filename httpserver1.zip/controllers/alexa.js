var mapper = require('../alexa/mapper.js');
var deviceControl=require('../alexa/deviceControl');
var redisStore = require('../database/redis/redisStore.js')
var executor = {};
var errors=require('../alexa/errors').types;
var table=require('../util/table')
var genericModel = require('../database/model/genericModel');
var processor=require('../alexa/responseGenerator');
var gateway=require('../alexa/gateway');
var discovery=require('../alexa/discovery');
var config = require('../config.js');
var validate={}

validate.isNumber=function(value){
    if(isNaN(value)&&(!value || !value.value || isNaN(value.value)))
        return errors.INVALID_VALUE;
}
validate.isNonZero=function(value){
    if(value==0&&(!value || !value.value || value.value==0))
        return errors.SAME_VALUE_RECEIVED;
}
validate.rangeCheck=function(value){
    if(value < 0|| value > 100)
        return errors.VALUE_OUT_OF_RANGE;
}

var getValues=function(deviceValues,supportedIndexes,event){
    var device={};
    for(var i in deviceValues){
        var indexData=deviceValues[i];
        if(supportedIndexes.indexOf(parseInt([indexData.Type]))>=0){
            var genericIndex=mapper.GENERICINDEXES[indexData.Type]
            device[genericIndex.tag]=genericIndex;
            device[genericIndex.tag].index=i;
            device[genericIndex.tag].value=indexData.Value;
            if(event=='ReportState'&&genericIndex.reportState)
                device.control=genericIndex.reportState;

        }
    }
    return device;

}
 
var formBody=function(req){
    var body={};
    try{
        body.event =req.body.event.header.name;
        body.thisTemplate = mapper.TEMPLATE[body.event];
        if (!body.thisTemplate)
            return  { success: false, reasonCode: 12 };
        body.targetValue = body.thisTemplate.param?req.body.event.payload[body.thisTemplate.param]:body.thisTemplate.value;
        var applianceInformation = req.body.event.endpoint.endpointId.split(':');
        body.almondMAC = applianceInformation[0];
        body.deviceId = applianceInformation[1];

        var error;
        var validators=body.thisTemplate.validators;
        if(validators){
            for(var i in validators){
                error = validate[validators[i]](body.targetValue);
                if(error)
                    return {reasonCode:error}
            }
        }
        return body
    }catch(error){
        return null
    }
}

executor.do = function(req, res) {
    var body=formBody(req); 
    if(!body || body.reasonCode ) return processor.getResponse(req.body.event,body.reasonCode?body:{reasonCode:errors.DEVICE_ACTION_NOT_PRESENT},res,'sendResponse');   
    redisStore.getDevice(body,function(error){
            var id=req.body.event.endpoint.endpointId.split(':')
            var payload={
                CommandType:id.length==2?"DynamicDeviceRemoved":"DynamicSceneRemoved",
                Action:"remove",
                AlmondMAC:id[0]
            }
            var type=id.length==2?'Devices':'Scenes'
            payload[type]={}
            payload[type][id[1]]={}
            executor.removeDevice({almondMAC:id[0],payload:payload,alexa:true,users: [ req.get('Authorization').split(' ')[1].split(':')[1]]})
            processor.getResponse(req.body.event,{reasonCode:errors.DEVICEVALUES_NOT_PRESENT},res,'sendResponse');
        },
        function(error, deviceValues) {
            var values=getValues(deviceValues,body.thisTemplate.supportedIndexes,body.event);
            values.deviceType=req.body.event.endpoint.cookie.deviceType;
            var functionName = values.control?values.control:body.thisTemplate.get; //  need to add Seperate method for deviceType 2
            deviceControl.constructResponse(req,res,body,functionName,values)
        }
    );
}
executor.discovery=function(req,res){
    genericModel.executeQuery('scenesAndDevices',[req.user.id,req.user.id,req.user.id,req.user.id],function(err1,rows){
        if(!err1&&rows){
            discovery.do(req.body.event,rows,res);
        }else{
            return processor.getResponse(req.body.event,{reasonCode:errors.INVALID_AUTHORIZATION_CREDENTIAL},res,'sendResponse');
        }
    })

}
executor.removeDevice=function(packet){
    var userids=packet.users;
    var payload=packet.payload;
    var type=payload.CommandType=='DynamicDeviceRemoved'?'Devices':'Scenes';
    var mac=packet.almondMAC;
    var deviceID = Object.keys(payload[type])[0];
    var clientId=config.alexaGateway.clientId
    processor.removeHandler({
        mac:mac,
        endpoint:mac+':'+deviceID+(type=='Devices'?'':'s'),
        deviceId:deviceID,
        userids:userids,
        clientId:clientId
    })
}
executor.removeAccessToken=function(req){
    gateway.alexaDisable(req.userID);
}
executor.accessToken=function(req,res){
    var data=req.body;
    var accessToken=req.get('Authorization').split(' ')[1].split(':');
    data.UserId=accessToken[1];
    data.tempPass=accessToken[0];
    gateway.getAccessToken('code',req.body.event.payload.grant.code,data,function(err,response){
        if(!err&&response){
            genericModel.deleteWithConditions(table.USER_TEMP_PASSWORDS,{equal:{userID:data.UserId,ClientName:data.clientId},notEqual:{tempPass:data.tempPass}},function(e,result){
                return processor.getResponse(req.body.event,{success:true},res,'sendResponse');
            })
        }
        else
            return processor.getResponse(req.body.event,{success:false,reasonCode:21},res,'sendResponse')
    })
}
executor.indexUpdate=function(packet){
    console.log(packet.users,'----------userids')
    var userids=packet.users;
    var payload=parseJSON(packet.payload);
    var mac=packet.almondMAC;
    var deviceID = Object.keys(payload.Devices)[0];
    var deviceValues = payload.Devices[deviceID].DeviceValues;
    var index = Object.keys(deviceValues)[0];
    var indexValues = deviceValues[index];
    redisStore.getDevice({almondMAC:mac,deviceId:deviceID},null,function(err,deviceValues){
        var clientId=config.alexaGateway.clientId
        deviceValues[index]=indexValues;
        var thisDevice = getValues(deviceValues,mapper.GENERICINDEXES[indexValues.Type].secondaryIndexes.concat(parseInt(indexValues.Type)),'ReportState');
        var value=deviceControl[thisDevice.control](thisDevice)
        if(value.reasonCode)
            return;
        processor.changeReportHandler({
            mac:mac,
            deviceId:deviceID,
            data: value,
            genericIndex:indexValues.Type,
            userids:userids,
            clientId:clientId
        })
    })
}


function parseJSON(json){
    try {
        return JSON.parse(json);
    } catch (e) {
        console.log(" JSon error",e)
        return null;
    }
}




module.exports = executor;
