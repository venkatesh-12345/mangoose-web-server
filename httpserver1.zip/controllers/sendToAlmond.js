var genericModel = require('../database/model/genericModel.js');
var table=require('../util/table.js')
var RM = require('../database/redis/redisStore.js');
var olderCommands = require('../version/olderCommands.js');
var handler=require('../almondEndpoint/responseHandler');
var extend = require('util')._extend;
var fs = require("fs");
var flowMapping = require('../almondEndpoint/commandToFlowMap.js');

var processor = {};
processor.do = function(req, res, path) {
    path=path.substring(1);
    if(!req || !req.body)
        return;
    var data = {},params={};
    res.TimeStamp=Date.now()
    res.commandType=path;    
    data.userid = req.user.id;
    data.response = res;
    params.timeoutLimit =req.body.timeoutLimit?req.body.timeoutLimit+ 100: 90000;
    params.request = req.body;
    fs.appendFile("AlexaReq", new Date() + path + "\n", function(e, o) {});
    var worker = flowMapping[path];
    if (!worker)
        return;
    if (!validate(worker.fields, params.request))
        return handler.responseWriter(data, 200, JSON.stringify({ 'success': false, 'reason': 'Incorrect request body' }), true);
    params.requestId = worker.id;
    params.responseId=worker.responseId;
    builder[worker.method](data, params,worker, function(almondMAC, payload) {
        console.log(" almondMAC payload ", almondMAC, payload)
        params.almondMAC = almondMAC;
        data.requestPayload = payload;
        handler.send(data,params);
    });
}


function sendRequest(data,params,payload,index){
    data.requestPayload=JSON.stringify(payload[index]);
    handler.send(data,params,function(id){
        data.ids.push(id);
        index++;
        if(index!=payload.length){
            clearTimeout(data.setTimeout)
            sendRequest(data,params,payload,index)
        }
    })
}
processor.sendTwoReuqest = function(data,params,payload) {
    var worker = flowMapping['device/updateIndex'];
    params.requestId = worker.id;
    params.responseId=worker.responseId
    data.requestPayload=JSON.stringify(payload[0]);
    params.almondMAC=payload[0].AlmondMAC;
    data.responseProcessor='alexaHandler';
    params.callback=true;
    if(data.isLock){
        data.listenerKey='1200-'+params.almondMAC+'-'+payload[0].ID+'-'+payload[0].Index;        
    }
    handler.send(data,params,function(id1){
        if(payload.length>1){
            data.ids=[id1];
            clearTimeout(data.setTimeout)
            sendRequest(data,params,payload,1)
        }
    })     
}
processor.alexaScene=function(data,params,payload){
    var worker=flowMapping['scene/activate'];
    params.requestId = worker.id;
    params.responseId=worker.responseId
    builder[worker.method](data, params,worker, function (almondMAC, payload) {
        console.log(" almondMAC payload ", almondMAC, payload)
        params.almondMAC = almondMAC;
        data.requestPayload = payload;
        data.alexa=true;
        handler.send(data,params);
    });
}


var builder = {}
builder.changeMode = function(data, params,worker, callback) {
    genericModel.select(table.USERS,{userID:data.userid}, function(err, rows) {
        if (err) {
            return handler.responseWriter(data, 502, JSON.stringify({ 'success': false, 'reason': err }), true);
        }
        if (rows.length == 0) {
            return handler.responseWriter(data, 502, JSON.stringify({ 'success': false, 'reason': 'No user with this userid' }), true);
        }
        callback(params.request.AlmondMAC, olderCommands.getModeCommand(params.request, rows[0]['EmailID']));
    });
}
builder.ChangeName=function(data,params,worker,callback){
     return callback(params.request.AlmondMAC,'<root><AlmondNameChange><AlmondplusMAC>'+params.request['AlmondMAC']+'</AlmondplusMAC><NewName>'+params.request['AlmondName']+'</NewName><MobileInternalIndex>'+Math.floor(Math.random() * 1000 + 1)+'</MobileInternalIndex></AlmondNameChange></root>')

}

builder.RouterSummary = function(data, params,worker, callback) {
    var requestPayload = {
        "AppID": 1001,
        "MobileInternalIndex": Math.floor(Math.random() * 1000 + 1),
        "CommandType": worker.CommandType
    };
    for (var i in worker.fields) {
        requestPayload[worker.fields[i]] = params.request[worker.fields[i]];
    }
    if (worker.CommandType == 'ActivateScene' || worker.CommandType == 'UpdateScene') {
        data.listenerKey = '1300-' + requestPayload.AlmondMAC + '-' + requestPayload.Scenes.ID;
        data.responseProcessor = 'sceneHandler';
    }
    callback(params.request.AlmondMAC, JSON.stringify(requestPayload));
}




builder.update = function(data,params, worker, callback) {
    var command = params.request['Update'][0];
    var listenerKey = '1200-' + command.AlmondMAC + '-' + command.ID;
    if (command.hasOwnProperty('hue')) {
        delete command.hue;
        data.responseProcessor = 'hueHandler';
        data.listenerKey = listenerKey + '-10';
    }
    if (command.hasOwnProperty('nest')) {
        data.responseProcessor = 'nestHandler';
        data.listenerKey = listenerKey + '-18';
        delete command.nest;
    }
    if (command.hasOwnProperty('hue4')) {
        delete command.hue;
        data.responseProcessor = 'hueHandler';
        data.listenerKey = listenerKey + '-6';
    }
    command.CommandType = worker.CommandType;
    command.MobileInternalIndex = Math.floor(Math.random() * 1000 + 1);

    callback(command.AlmondMAC, JSON.stringify(command));
}

builder.affiliationUserRequest = function(data, params,worker, callback) {
    var almondMAC;
    RM.getCode(params.request.Code, function(e, o) {
        var command = { success: false, CommandType: "AffiliationUserCompleteResponse", reasonCode: 3, reason: 'Invalid Code' }
        if (o && o.server) {
            var emailID = params.request.emailID;
            params.lastEmail=false;
            if(emailID==o.lastEmail || data.userid==o.lastEmail)
                params.lastEmail=true;
            params.server = o.server;
            command = '<root><AffiliationAlmondComplete success="true"><EmailID>' + emailID + '</EmailID><LongSecret>' + o.longSecret + '</LongSecret></AffiliationAlmondComplete></root>'
            almondMAC = o.mac;
            params.requestId = 24;
            if(o.isJson=='true'){
                params.isJson=true;
                genericModel.select(table.CMSAffiliations,{AlmondMAC:o.mac}, function(err,codeData) {
                    if(codeData.length>0 && codeData[0]){
                        params.CMSCode=codeData[0].CMSCode;
                        params.CustomID=codeData[0].CustomerID;
                    }
                    command= JSON.stringify({CommandType:'AffiliationAlmondComplete', Success:'true',EmailID: emailID ,LongSecret: o.longSecret ,CustomerID:params.CustomID,CMSCode:params.CMSCode});
                    params.requestId =1020;
                    return callback(almondMAC,command)
        
                })
            }
            else
                return callback(almondMAC,command)
        }else{
             return handler.responseWriter(data, 200, JSON.stringify({ 'success': false, 'reason': 'Code not found' }), true);
        }

    })
}

function validate(keys, request) {
    if (!request)
        return false;

    var valid = true;
    for (var i in keys) {
        if (!request[keys[i]]) {
            valid = false;
            break;
        }
    }
    return valid;
}
module.exports = processor;