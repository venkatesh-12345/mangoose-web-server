module.exports={
    'zenUsers':{
        query:'select UserID from AlmondUsers where UserID in (select UserID from Users where EmailID like "%zenthermostat%" or EmailID like "%zen_securifi%" )'
    },
    'zenMacs':{
        query:'select AlmondMAC from AlmondUsers where UserID in (select UserID from Users where EmailID like "%zenthermostat%" or EmailID like "%zen_securifi%" )'
    },
    'getSubscription':{
        query:'select S.AlmondMAC,S.Plan,S.SubscriptionEpoch Subscription,S.RenewalEpoch Renew,AU.AlmondName Name from AlmondplusDB.Subscriptions S,AlmondplusDB.AlmondUsers AU where S.UserID in (select UserID from Users where EmailID = ?) and S.AlmondMAC = AU.AlmondMAC',
        params:['email']
    },
    'getUsers':{
        table:'Users',
        params:['emailID'],
        action:'select'
    },
    'getAlmondUsersEmail':{
        query:'select * from AlmondUsers where UserID in (select UserID from Users where EmailID=?)',
        params:['email'],
        action:'select'
    },
    'getSubscription':{
        table:'Subscriptions',
        params:['AlmondMAC'],
        action:'select'
    },
    'getAlmondUsersMac':{
        query:'select U.EmailID,U.EmailValidated,U.UserID,AU.AffiliationTS from Users U,AlmondUsers AU where U.UserID = AU.UserID and AU.AlmondMAC = ?',
        params:['AlmondMAC']
    },
    'getDevices':{
        query:'select * from DeviceData where AlmondMAC=?;',
        params:['AlmondMAC'],
    },
    'getClientsMAC':{
        query:'select CONVERT(ClientDetails USING utf8),ClientID from WifiClients where AlmondMAC=?',
        params:['AlmondMAC']
    },
    'removeAffiliation':{
        table:'AlmondUsers',
        params:['AlmondMAC'],
        action:'delete'
    },
    'getAlmond':{
        table:'AllAlmondPlus',
        params:['AlmondMAC'],
        action:'select'
    },
    'changeDeviceType':{
        query:'update DeviceData set DeviceType=? where AlmondMAC=? and DeviceID=?',
        params:['DeviceType','AlmondMAC','DeviceID']
    },
    'validateEmail':{
        query:'update Users SET EmailValidated = 1 where EmailID = ?',
        params:['email']
    },
    'getUsersUserId':{
        table:'Users',
        params:['userID'],
        action:'select'
    },
    'getAL3':{
        query:"select U.EmailID,U.Date,ALP.AlmondMAC, ALP.ProductType,ALP.FirmwareVersion,AU.AffiliationTS from Users U ,AlmondUsers AU,AllAlmondPlus ALP where (ALP.ProductType like '%AL3%' or ALP.FirmwareVersion like '%AL3%') and AU.AlmondMAC = ALP.AlmondMAC and U.UserID = AU.UserID ",
        params:[]
    },
    'getAlmondProperties':{
        table:'AlmondProperties2',
        params:['AlmondMAC'],
        action:'select'
    },
    'getFirmwareUpdate':{
        table:'FirmwareUpdate',
        params:['AlmondMAC'],
        action:'select'
    },
    'getAlmondFWUpdate':{
        table:'AlmondFWUpdate',
        params:['AlmondMAC'],
        action:'select'
    },
    'getAlmondUsersAll':{
        query:'SELECT AlmondMAC MAC, ownership Own FROM AlmondUsers WHERE userID=? Union SELECT AlmondMAC, userid FROM AlmondSecondaryUsers WHERE userID = ?',
        params:['UserID','UserID']
    },
    'insertAlmondFWUpdate':{
        table:'insert into AlmondFWUpdate (AlmondMAC,OldFirmware, NewFirmware, UpdateStatus, SetTime) values(?,?,?,?,?) on duplicate key update UpdateStatus = values(UpdateStatus),SetTime = values(SetTime),EndTime = null, OldFirmware=values(OldFirmware), NewFirmware = values(NewFirmware)',
        params:['AlmondMAC','oldVersion','version','UpdateStatus','SetTime']
    },
    'insertAlmondUsers':{
        query:'INSERT INTO AlmondUsers (AlmondMAC,UserID,ownership,LongSecret,FirmwareVersion,AffiliationTS) Values ? on duplicate key update AlmondMAC = values(AlmondMAC),ownership = values(ownership),UserID = values(UserID),LongSecret = values(LongSecret)',
        params:['data'],        
    },
    'getAlmonds':{
        query:'SELECT * FROM  AllAlmondPlus WHERE AlmondMAC IN (?)',
        params:['AlmondMACS'],
    },
    'insertAlmondUsersWithIgnore':{
        query:'INSERT IGNORE INTO AllAlmondPlus (AlmondID,AlmondMAC,FactoryUploadTS,FactoryAdmin,FirmwareVersion, ProductType,CloudID ) VALUES ?',
        params:['data']
    },
    'getUsersMac':{
        query:'select AlmondMAC from AlmondUsers where AlmondMAC in (?)',
        params:['AlmondMACS']
    },
    'insertFirmwareUpdate':{
        table:'FirmwareUpdate',
        params:['AlmondMAC', 'Status', 'Time'],
        action:'insert'
    },
}
