var genericModel=require('../database/model/genericModel');
var RC=require('../database/redis/redisConnector.js')
var config = require("../config.js");
var mapping=require('./dashBoardMap.js')

function checkIP(request) {
    try{
         return (config.portalIP.indexOf(request.headers['x-forwarded-for'].split(",")[0]) > -1);
    }catch(error){
        console.log("Send to Queue  error ",error);
        return false;
    }
}
var processor = function(request,callback) {
    if (!checkIP(request)) {
        return callback(502);
    }
    var payload=request.body
    var mapper=mapping[payload.command];
    if(mapper && mapper.query){
        var params=[]
        for(var i in mapper.params)
            params.push(payload[mapper.params[i]])
        genericModel.execute(mapper.query,params,function(err,res){
            if(err&&err=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE mode"
            });
            if(!err)
                callback( 200,res);
            else
                callback(500,{error:err});
        })
    }else if(mapper){
        var params={}
        for(var i in mapper.params)
            params[mapper.params[i]]=payload[mapper.params[i]]
        genericModel[mapper.action](mapper.table,params,function(err,res){
            if(err&&err=='MAINTENANCE')
            return callback( 503, {
                "error": "MAINTENANCE mode"
            });
            if(!err)
                callback( 200,res);
            else
                callback(500,{error:err});
        })
    }else{
        if(payload.command=='multi'){
            var multi=RC.multi();
            var params=payload.json;
            for(var i in params){
                if(params[i][0]=='hgetall')
                    multi[params[i][0]](params[i][1])
                else
                    multi[params[i][0]](params[i][1],params[i][2])
            }
            multi.exec(function(err,res){
                if(!err)
                    callback( 200,res);
                else
                    callback(500,{error:err});
            })
        }else if(payload.command=='setQuery'){
            RC.query(payload.query,{key:payload.key,params:payload.params},function(err,res){
                if(!err)
                    callback( 200,res);
                else
                    callback(500,{error:err});
            })
        }else if(payload.command=='getQuery'){
            RC.query(payload.query,payload.key,function(err,res){
                if(!err)
                    callback( 200,res);
                else
                    callback(500,{error:err});
            })
        }
    }
}
module.exports = processor;
