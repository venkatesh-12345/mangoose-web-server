module.exports = {
    "0": {
        "categoryName": "Incorrect",
        "category": "0"
    },
    "1": {
        "categoryName": "Real Estate",
        "category": "1"
    },

    "2": {
        "categoryName": "Computer and Internet Security",
        "category": "1"
    },

    "3": {
        "categoryName": "Financial Services",
        "category": "1"
    },

    "4": {
        "categoryName": "Business and Economy",
        "category": "1"
    },

    "5": {
        "categoryName": "Computer and Internet Info",
        "category": "1"
    },

    "6": {
        "categoryName": "Auctions",
        "category": "2"
    },

    "7": {
        "categoryName": "Shopping",
        "category": "1"
    },

    "8": {
        "categoryName": "Cult and Occult",
        "category": "3"
    },

    "9": {
        "categoryName": "Travel",
        "category": "1"
    },

    "10": {
        "categoryName": "Abused Drugs",
        "category": "4"
    },

    "11": {
        "categoryName": "Adult and Pornography",
        "category": "4"
    },

    "12": {
        "categoryName": "Home and Garden",
        "category": "1"
    },

    "13": {
        "categoryName": "Military",
        "category": "3"
    },

    "14": {
        "categoryName": "Social Networking",
        "category": "3"
    },

    "15": {
        "categoryName": "Dead Sites",
        "category": "1"
    },

    "16": {
        "categoryName": "Individual Stock Advice and Tools",
        "category": "1"
    },

    "17": {
        "categoryName": "Training and Tools",
        "category": "1"
    },

    "18": {
        "categoryName": "Dating",
        "category": "5"
    },

    "19": {
        "categoryName": "Sex Education",
        "category": "3"
    },

    "20": {
        "categoryName": "Religion",
        "category": "2"
    },

    "21": {
        "categoryName": "Entertainment and Arts",
        "category": "1"
    },

    "22": {
        "categoryName": "Personal sites and Blogs",
        "category": "2"
    },

    "23": {
        "categoryName": "Legal",
        "category": "1"
    },

    "24": {
        "categoryName": "Local Information",
        "category": "1"
    },

    "25": {
        "categoryName": "Streaming Media",
        "category": "3"
    },

    "26": {
        "categoryName": "Job Search",
        "category": "1"
    },

    "27": {
        "categoryName": "Gambling",
        "category": "4"
    },

    "28": {
        "categoryName": "Translation",
        "category": "1"
    },

    "29": {
        "categoryName": "Reference and Research",
        "category": "1"
    },

    "30": {
        "categoryName": "Shareware and Freeware",
        "category": "2"
    },

    "31": {
        "categoryName": "Peer to Peer",
        "category": "3"
    },

    "32": {
        "categoryName": "Marijuana",
        "category": "4"
    },

    "33": {
        "categoryName": "Hacking",
        "category": "4"
    },

    "34": {
        "categoryName": "Games",
        "category": "3"
    },

    "35": {
        "categoryName": "Philosophy and Political Advocacy",
        "category": "2"
    },

    "36": {
        "categoryName": "Weapons",
        "category": "4"
    },

    "37": {
        "categoryName": "Pay to Surf",
        "category": "5"
    },

    "38": {
        "categoryName": "Hunting and Fishing",
        "category": "3"
    },

    "39": {
        "categoryName": "Society",
        "category": "1"
    },

    "40": {
        "categoryName": "Educational Institutions",
        "category": "1"
    },

    "41": {
        "categoryName": "Online Greeting cards",
        "category": "1"
    },

    "42": {
        "categoryName": "Sports",
        "category": "1"
    },

    "43": {
        "categoryName": "Swimsuits & Intimate Apparel",
        "category": "3"
    },

    "44": {
        "categoryName": "Questionable",
        "category": "5"
    },

    "45": {
        "categoryName": "Kids",
        "category": "1"
    },

    "46": {
        "categoryName": "Hate and Racism",
        "category": "4"
    },

    "47": {
        "categoryName": "Personal Storage",
        "category": "3"
    },

    "48": {
        "categoryName": "Violence",
        "category": "4"
    },

    "49": {
        "categoryName": "Keyloggers and Monitoring",
        "category": "5"
    },

    "50": {
        "categoryName": "Search Engines",
        "category": "1"
    },

    "51": {
        "categoryName": "Internet Portals",
        "category": "1"
    },

    "52": {
        "categoryName": "Web Advertisements",
        "category": "3"
    },

    "53": {
        "categoryName": "Cheating",
        "category": "4"
    },

    "54": {
        "categoryName": "Gross",
        "category": "4"
    },

    "55": {
        "categoryName": "Web based email",
        "category": "1"
    },

    "56": {
        "categoryName": "Malware Sites",
        "category": "4"
    },

    "57": {
        "categoryName": "Phishing and Other Frauds",
        "category": "4"
    },

    "58": {
        "categoryName": "Proxy Avoidance and Anonymizers",
        "category": "5"
    },

    "59": {
        "categoryName": "Spyware and Adware",
        "category": "4"
    },

    "60": {
        "categoryName": "Music",
        "category": "1"
    },

    "61": {
        "categoryName": "Government",
        "category": "1"
    },

    "62": {
        "categoryName": "Nudity",
        "category": "4"
    },

    "63": {
        "categoryName": "News and Media",
        "category": "1"
    },

    "64": {
        "categoryName": "Illegal",
        "category": "4"
    },

    "65": {
        "categoryName": "Content Delivery Networks",
        "category": "3"
    },

    "66": {
        "categoryName": "Internet Communications",
        "category": "1"
    },

    "67": {
        "categoryName": "Bot Nets",
        "category": "4"
    },

    "68": {
        "categoryName": "Abortion",
        "category": "3"
    },

    "69": {
        "categoryName": "Health and Medicine",
        "category": "2"
    },

    "71": {
        "categoryName": "SPAM URLs",
        "category": "4"
    },

    "74": {
        "categoryName": "Dynamically Generated Content",
        "category": "1"
    },

    "75": {
        "categoryName": "Parked Domains",
        "category": "1"
    },

    "76": {
        "categoryName": "Alcohol and Tobacco",
        "category": "4"
    },

    "77": {
        "categoryName": "Private IP Addresses",
        "category": "1"
    },

    "78": {
        "categoryName": "Image and Video Search",
        "category": "1"
    },

    "79": {
        "categoryName": "Fashion and Beauty",
        "category": "3"
    },

    "80": {
        "categoryName": "Recreation and Hobbies",
        "category": "1"
    },

    "81": {
        "categoryName": "Motor Vehicles",
        "category": "1"
    },

    "82": {
        "categoryName": "Web Hosting",
        "category": "1"
    },
    "1000": {
        "categoryName": "Incorrect",
        "category": "1000"
    }
}