
function define(name, value) {
    Object.defineProperty(exports, name, {
        value: value,
        enumerable: true
    });
}


var SELECT = 'SELECT dateyear as "Date",site as "Domain",category as "subCategory",lastupdated as "LastVisitedEpoch",subcategory as "Category" FROM browsing_log_store.%s WHERE mac = ? AND client_mac = ? '
var BANDWIDTH ='SELECT rx,tx FROM browsing_log_store.%s WHERE mac = ? AND client_mac = ? AND dateyear <= ? AND dateyear > ?';

define("SELECT", SELECT);
define("weekSearch", SELECT + ' AND dateyear < ? AND dateyear >= ?');
define("weekDaySearch",SELECT +' AND dateyear IN ?');
define("hourSearch",SELECT +'AND lastupdatedhour = ? AND dateyear = ?');
define("domainSearch",SELECT+ 'AND dateyear IN ? AND site >= ? AND site < ?');
define("epochSearch",'SELECT dateyear as "Date",site as "Domain",epochs FROM browsing_log_store.%s WHERE mac = ? AND client_mac = ? AND dateyear = ? and site = ?' );
define("dateSearch",SELECT+'AND dateyear <= ?');
define("thisDateSearch",SELECT+'AND dateyear = ?');
define("getBandwidth",BANDWIDTH);
define("categorySearch",SELECT+'AND subCategory = ?');
define("clearHistory",'DELETE FROM browsing_log_store.%s where mac = ? AND client_mac = ?');
define("deleteBandwidth",'delete from browsing_log_store.%s where mac=? AND client_mac=?')
define("suggestRating","select * from browsing_log_store.%s where site IN ?");
define("dataUsageReset",'INSERT INTO AlmondplusDB.%s (mac, client_mac, date , TZ) VALUES( ?, ? ,? , ?) ON DUPLICATE KEY UPDATE mac = ? , client_mac = ? ,  date = ? , TZ = ?');
