/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var loggerPoint = require('../database/cassandra/cqlConnection');
var config = require('nconf').get('smTables');
var categoryDBTable = config.categoryDBTable;
//var logger = require('./stats/logger.js');

var mqf = {};

mqf.executeQuery = function (query, params, callback) {
  //  logger.incrementPendingCount();
    loggerPoint.execute(query, params, {prepare: true}, function (e, o) {
        if (e) {
            //logger.logError("Error in Executing the Query", e);
            console.log('Error in insertIntoSiteMonitoring', e);
        }
        //logger.updateCount(e);
        //console.log("Batch",qs);
        callback(e, o);
    });
};

mqf.newBatchInsert = function (queries, callback) {
    if (queries.length != 0) {
        //console.log(queries);
    //    logger.updatePendingCount('Batch');
      //  logger.incrementPendingCount();
        loggerPoint.batch(queries, {
            prepare: true
        }, function (error, result) {
        //    logger.updateCount(error);
            callback(error, result);
        });
    } else
        callback("", []);
};


mqf.counterBatch = function (queries, callback) {
    if (queries.length != 0) {
        //logger.incrementPendingCount();
        //console.log("++++++++++++++++++++++++++++++++++",queries);
        loggerPoint.batch(queries, {counter: true, prepare: true}, function (error, result) {
          //  logger.updateCount(error);
            //console.log("________________________________",result);
            callback(error, result);
        });
    } else
        callback("", []);
};

mqf.getClassificationFromDB = function (domain_request, callback) {// move this to mobileFunctions
    if (domain_request.length) {
        const query = "select * from browsing_log_store." + categoryDBTable + " where site IN ?";
        const params = [domain_request];
        loggerPoint.execute(query, params, {
            prepare: true
        }, callback); ///////////query end
    } else {
        callback(undefined, []);
    }
};

module.exports = mqf;


