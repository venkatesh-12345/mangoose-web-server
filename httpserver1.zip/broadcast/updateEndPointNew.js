var RS = require("../database/redis/redisStore.js");
var producer = require("../rabbitmq/producer.js");

var UA = {};

var get_random_string = function(len) {
    var chars = "23456789ABCDEFGHJKLMNPQRSTUVWXTZabcdefghkmnopqrstuvwxyz";
    len = len ? len : 6;
    var string = "";
    for (var i = 0; i < len; i++) {
        var randomNumber = Math.floor(Math.random() * chars.length);
        string += chars.substring(randomNumber, randomNumber + 1);
    }
    return string;
};

function writeToMobileSockets(users, response, command) {
    var st = {
        type: "broadcast",
        userList: users,
        payload: response,
        command: command
    };
    checkMobileStatus(users, st);
}

function checkMobileStatus(Users, st) {
    var sentQueues = [];
    RS.getUsers(Users, function(err, replies) {
        if (err || !replies) return;
        for (var i in replies) {
            if (!replies[i]) continue;
            var keys = Object.keys(replies[i]);
            keys.forEach(function(key) {
                if (key && key.indexOf("Q_") == 0 && replies[i][key] > 0 && sentQueues.indexOf(key.substring(2, key.length)) == -1) {
                    sentQueues.push(key.substring(2, key.length));
                }
            });
        }
        for (var i in sentQueues) producer.sendToQueue(sentQueues[i], JSON.stringify(st));
    });
}

var checkVersion = function(version) {
    var supportVersions = { AL2: "R102b", AL3: "R021a", A1A: "R016a" };
    if (supportVersions[version.split("-")[0]] > version.split("-")[1]) return true;
    return false;
};
var getService = function(services, status) {
    if (services == "IoT_CMS" || services == "CMS_IoT") return "4,".concat(status ? "1,1" : "0,0");
    if (services == "IoT") return "4,".concat(status ? "1,0" : "0,0");
    if (services == "CMS") return "4,".concat(status ? "0,1" : "0,0");
    return;
};
UA.broadcastToMobile = function(AlmondMAC, payload, command) {
    RS.getAlmond(AlmondMAC, function(err, o) {
        if (err || !o || !o._)
            //Not Affiliated
            return;
        var users = [o.userID];
        users = users.concat(getSusers(o));
        writeToMobileSockets(users, payload, command);
    });
};

UA.broadcastToAlmondandMobile = function(request, command, add) {
    if (!request) return;
    var ServiceData = add ? "2,1" : "2,0";
    if (request.Services) ServiceData = getService(request.Services, add);
    var token = get_random_string(25);
    var data = {
        id: 9999,
        command: 1062,
        payload: JSON.stringify({ CommandType: "ChangeAlmondProperties", Subscription: ServiceData, AlmondMAC: request.AlmondMAC, MobileInternalIndex: Math.floor(Math.random() * 1000 + 10) }),
        commandID: 0,
        len: 16,
        almondMAC: request.AlmondMAC,
        debug: false,
        remove: !add,
        token: token
    };
    RS.getAlmond(request.AlmondMAC, function(err, o) {
        if (err || !o || !o._)
            //Not Affiliated
            return;
        if (checkVersion(o.version)) {
            data.command = 9999;
            data.payload = JSON.stringify({ CommandType: "Subscription", Enable: "false" });
            RS.setAlmondValues(request.AlmondMAC, ["subscriptionToken", add ? token : ""], function(err, o) {});
        }
        if (o.server && o.status == 1) producer.sendToQueue(o.server, JSON.stringify(data));
        var users = [o.userID];
        users = users.concat(getSusers(o));
        console.log("UpdateEndPoints ",JSON.stringify(request));
        writeToMobileSockets(users, JSON.stringify(request), command);
    });
};

function getSusers(data) {
    var users = [];
    Object.keys(data).forEach(function(key) {
        if (key.indexOf("SUSER_") == 0) users.push(key.split("SUSER_")[1]);
    });
    return users;
}

module.exports = UA;
