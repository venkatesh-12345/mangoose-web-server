var messages = require("./errors").messages;
var errors=require('./errors').types;
var deviceControl={};
deviceControl.activateScene=function(deviceValues,targetTemp,device){
    return {success:true,commandList:[],request:{AlmondMAC:deviceValues.almondMAC,Scenes:{ID:deviceValues.deviceId}}};
}
deviceControl.setTemperature=function(deviceValues, targetTemp, device) {
    var result = canTempBeChanged(deviceValues, device);
    if (result.reasonCode) {
        result.success = false;
        return result;
    }
    var commands=[];
    var previouseTargetTemp;
    if (result.mode == device.modes.AUTO) {
        previouseTargetTemp=(parseInt(deviceValues[device.heatIndex].Value) - 2 + parseInt(deviceValues[device.coolIndex].Value) + 1) / 2;
        commands.push({ Index: device.heatIndex, Value: Math.round(targetTemp + 2) });
        commands.push({ Index: device.coolIndex, Value: Math.round(targetTemp - 1) });
        
    }else{
        var index = device.targetIndex ? device.targetIndex : (result.mode == device.modes.HEAT ? device.heatIndex : device.coolIndex);
        previouseTargetTemp=deviceValues[index].Value;
        commands.push({ Index: index, Value: Math.round(targetTemp) });
    }
    var currentMode=alexaMode(result.mode,device)
    if(previouseTargetTemp==targetTemp)
        return {'success': false,'reasonCode': errors.SAME_VALUE_RECEIVED, Value:targetTemp,mode:currentMode,previousValue:previouseTargetTemp};
    return {'success':true,value:targetTemp,mode:currentMode,previousValue:previouseTargetTemp,commandList: commands}
}

deviceControl.adjustTemperature=function(deviceValues, delta, device) {
    var result = canTempBeChanged(deviceValues, device);
    if (result.reasonCode) {
        result.success = false;
        return result;
    }
    var mode=result.mode;
    result=getTargetTemp(mode,device,deviceValues,delta)
    if (result.targetTemp > device.maxTemp ||result.targetTemp < device.minTemp)
        return {'success': false,'reasonCode':errors.TEMPERATURE_VALUE_OUT_OF_RANGE,'Value':result.targetTemp,'max':device.maxTemp,'min':device.minTemp};
    var currentMode=alexaMode(mode,device);
    return {'success':true,value:result.targetTemp,mode:currentMode,previousValue:result.targetTemp-delta,commandList:result.commands};
}
deviceControl.setMode=function(deviceValues,delta,device){
    var result=canTempBeChanged(deviceValues, device, true) 
    if (result.reasonCode) {
        result.success = false;
        return result;
    }
    if(result.mode==device.modes[delta])
        return {'success': false,'reasonCode':  errors.SAME_VALUE_RECEIVED,Value:getTargetTemp(device.modes[delta],device,deviceValues,0).targetTemp,mode:delta,};
    var targetTemp;
    return {success:true,value:getTargetTemp(device.modes[delta],device,deviceValues,0).targetTemp,mode:delta,commandList:[{Index:device.modeIndex,Value:device.modes[delta]}]};
}
deviceControl.reportTemp=function(deviceValues, delta,device){
    var result=canTempBeChanged(deviceValues,device);
    if (result.reasonCode) {
        if(result.mode==device.modes.ECO){
            return {success:true,mode:'OFF',temp:{"value":39, "scale": "FAHRENHEIT"}};
        }
        result.success = false;
        return result;
    }
    var currentMode=alexaMode(result.mode, device)
    if (result.reasonCode == 0) {
        result.success = true;
        result.mode=currentMode
        return result;
    }
    return { success: true, mode: currentMode, temp: { "value": getTargetTemp(result.mode, device,deviceValues,0).targetTemp, "scale": "FAHRENHEIT" }};
}
function alexaMode(mode,device){
    var keys=Object.keys(device.modes);
    for(var i in keys){
        if(device.modes[keys[i]]==mode)
        {
            return keys[i];
            break;
        }
    }
}
function getTargetTemp(mode, device,deviceValues,delta) {
    var targetTemp;
    var commands = [];
    if (mode == device.modes.AUTO) {
        var targetHeatTemp = parseInt(deviceValues[device.heatIndex].Value) + delta;
        var targetCoolTemp = parseInt(deviceValues[device.coolIndex].Value) + delta;
        targetTemp = (targetHeatTemp - 2 + targetCoolTemp + 1) / 2;
        commands.push({ Index: device.heatIndex, Value: Math.round(targetHeatTemp) });
        commands.push({ Index: device.coolIndex, Value: Math.round(targetCoolTemp) });
    }
    else {
        var index = device.targetIndex ? device.targetIndex : (mode == device.modes.HEAT ? device.heatIndex : device.coolIndex);
        targetTemp = parseInt(deviceValues[index].Value) + delta;
        commands.push({ Index: index, Value: Math.round(targetTemp) });
    }
    return { targetTemp: targetTemp, commands: commands }
}
function canTempBeChanged(deviceValues, obj, setMode) {
    var result = { mode: deviceValues[obj.modeIndex].Value };

    if (result.mode == obj.modes.OFF || result.mode == obj.modes.ECO)
        result.reasonCode = setMode ? 0 : errors.THERMOSTAT_IS_OFF;

    if (!obj.nest)
        return result;
    if (deviceValues[obj.isOnline].Value == 'false')
        result.reasonCode = errors.DEVICE_IS_OFFLINE;

    if (deviceValues[obj.awayIndex].Value != 'home') 
        result.reasonCode = errors.NEST_IS_IN_AWAY_MODE;

    return result;
}

deviceControl.reportSensorTemperature=function(deviceValues,value,device){
    var Value=deviceValues[this.Index].Value;
    return {'success':true,temperature:{"value":parseInt(Value),"scale":"FAHRENHEIT"}};
}
deviceControl.reportPower=function(deviceValues, delta,device){
    var isTurnedOff = false;
    var Value=deviceValues[device.Index].Value
    if(Value==false||Value=='false'||Value==0)
        isTurnedOff=true;
    Value=isTurnedOff?"OFF":"ON";
    if(device.LightIndex){
        var valueNow = parseInt(deviceValues[device.LightIndex]['Value']);
        var brightness=Math.round(valueNow*100/device.LightHigh);
    }
    if(device.HueIndex){
        var color={
            "hue": Math.round(parseInt(deviceValues[device.HueIndex]['Value'])*360/device.HueHigh),
            "saturation": Math.round(parseInt(deviceValues[device.SaturationIndex]['Value'])*100/255)/100,
            "brightness": brightness/100
        }
    }
    if(device.TempIndex){
        var colorTemperatureInKelvin=parseInt(deviceValues[device.TempIndex]['Value']);
        if(device.colorTemp[deviceValues[device.TempIndex]['Value']]&&JSON.stringify(device.colorTemp[deviceValues[device.TempIndex]['Value']])==JSON.stringify(color))
            color=undefined;
        else
            colorTemperatureInKelvin=undefined;            
    }
    return {'success':true,power:Value,brightness:brightness,color:color,colorTemperatureInKelvin:colorTemperatureInKelvin};
}
deviceControl.indexValue=function(currentState, targetValue, device) {
    if ((currentState[device.Index].Value == this.Value)||(this.Value=='100'&&currentState[device.Index].Value>0))
        return {'success': false,'reasonCode':  errors.SAME_VALUE_RECEIVED,Value:this.response};
    return {'success':true,value:this.response,isLock:device.isLock,commandList:[{
        Index: device.Index,
        Value: this.Value
    }]}
}

deviceControl.adjustBrightness=function(deviceValues, percent, device) {
    var currentValue = deviceValues[device.LightIndex].Value;
    var targetValue = Math.round(parseInt(currentValue) + (percent * (device.LightHigh - device.LightLow) / 100))
    if (targetValue > device.LightHigh || targetValue < device.LightLow)
        return {'success': false,'reasonCode':errors.VALUE_OUT_OF_RANGE,'Value':targetValue};
    var commandList=[];
    if(deviceValues[device.Index].Value=='false'&&device.HueIndex&&!device.TempIndex)
        commandList.push({Index:device.Index,Value:'true'});
    commandList.push({Index: device.LightIndex,Value: targetValue});
    return {'success':true,value:Math.round(targetValue*100/device.LightHigh),commandList:commandList};
}

deviceControl.setBrightness=function(deviceValues, percent, device) {
    var currentValue = deviceValues[device.LightIndex].Value;
    var targetValue = Math.round(percent * (device.LightHigh) / 100);
    if(currentValue==targetValue)
        return {'success': false,'reasonCode': errors.SAME_VALUE_RECEIVED,Value:Math.round(targetValue*100/device.LightHigh)};
    var commandList=[];
    if(deviceValues[device.Index].Value=='false'&&device.HueIndex&&!device.TempIndex)
        commandList.push({Index:device.Index,Value:'true'});
    commandList.push({Index: device.LightIndex,Value: targetValue});
    return {success:true,value:Math.round(targetValue*100/device.LightHigh),commandList:commandList};
}
deviceControl.setColor=function(deviceValues,value,device){
    var currentHue=deviceValues[device.HueIndex].Value;
    var currentSaturation=deviceValues[device.SaturationIndex].Value;
    var currentBrightness=deviceValues[device.LightIndex].Value;
    var targetHue=Math.round(value.hue*device.HueHigh/360);
    var targetSaturation=Math.round(value.saturation*device.SaturationHigh);
    var targetBrightness=Math.round(value.brightness*device.LightHigh);
    if(currentHue==targetHue&&currentSaturation==targetSaturation&&currentBrightness==targetBrightness)
        return {'success': false,'reasonCode': errors.SAME_VALUE_RECEIVED,Value:value};
    var commands=[]
    if(deviceValues[device.Index].Value=='false'&&device.HueIndex&&!device.TempIndex)
        commands.push({Index:device.Index,Value:'true'});
    if(currentBrightness!=targetBrightness)
        commands.push({Index:device.LightIndex,Value:targetBrightness});
    if(currentSaturation!=targetSaturation)
        commands.push({Index:device.SaturationIndex,Value:targetSaturation});
    if(currentHue!=targetHue)
        commands.push({Index:device.HueIndex,Value:targetHue});
    return {success:true,value:value,commandList:commands}
}
deviceControl.setColorTemperature=function(deviceValues, value, device) {
    var currentValue = parseInt(deviceValues[device.TempIndex].Value);
    if ((currentValue == device.TempHigh && this.sign == 1) || (currentValue == device.TempLow && this.sign < 0))
        return {success: false, reasonCode: errors.VALUE_OUT_OF_RANGE }

    var targetValue;
    if (!this.sign)
        targetValue = getColor(value);
    else {
        var temp = currentValue + (this.sign * 1000)
        if (temp >= device.TempHigh)
            targetValue = device.TempHigh;
        else if (temp <= device.TempLow)
            targetValue = device.TempLow;
        else
            targetValue = getColor(temp);
    }
    var colorTemp=device.colorTemp[targetValue];
    if(device.colorTemp[targetValue]){
        var color=deviceControl.setColor(deviceValues,device.colorTemp[targetValue],device);
    }
    var commandList=[]
    if (targetValue == currentValue&&(!color||(!color.success)))
        return { success: false, reasonCode: errors.SAME_VALUE_RECEIVED ,Value:targetValue}
    else if(targetValue!=currentValue)
        commandList= [{ Index: device.TempIndex, Value: targetValue + '' }];
    if(color)
        commandList=color.commandList.concat(commandList);
    return  {success:true, value: targetValue, commandList: commandList };
}
function getColor(value) {
    return parseInt(1000000 / (parseInt(1000000 / value)));
}
deviceControl.reportLock=function(deviceValues,value,device){
    var lockstate=deviceValues[device.Index].Value;
    lockstate=lockstate==this.Lock?'LOCKED':'UNLOCKED';
    return {success:true,lockState:lockstate}
}
module.exports=deviceControl;
