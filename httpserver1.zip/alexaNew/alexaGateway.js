var request = require('request');
var url = require('nconf').get('alexaGateway');
var alexaGateway={}
var alexaToken=require('./accessToken.js')
var clone=require('./clone').clone
var lockResponse={
  "context": {
    "properties": [
          {
            "namespace": "Alexa.LockController",
            "name": "lockState",
            "value": "LOCKED",
            "timeOfSample": "2017-02-03T16:20:50.52Z",
            "uncertaintyInMilliseconds": 0
          }
     ]
  },
  "event": {
    "header": {
      "namespace": "Alexa",
      "name": "Response",
      //"messageId":"asdfafffasdfffsdfsdfsf",
      //"correlationToken": "dFMb0z+PgpgdDmluhJ1LddFvSqZ/jCc8ptlAKulUj90jSqg==",
      "payloadVersion": "3"
    }
  }
}


 var post = function(result,res) {
    result.event.endpoint.scope.token=res.accessToken
    var options = {
        method: 'POST',
        url: url[res.region],
        headers: {
            'authorization': 'Bearer ' + res.accessToken,
            'content-type': 'application/json'
        },
        body: result,
        json: true
    };
    request(options, function(err, res, resBody) {
        return console.log(err,res.statusCode,resBody,'--------------in alexaGateway-----------------');
    });
}

alexaGateway.responseHandler=function(data,almondResponse){
    try{
       var  payload=JSON.parse(almondResponse.payload);
    }catch(error){
        return console.log('Error ',error);
    }
    if((almondResponse.command==1064&&payload.Success=='true')||(almondResponse.command==1200)){
        var response=clone(lockResponse);
        response.event.header.correlationToken=data.correlationToken;
        response.event.endpoint={}
        response.event.endpoint.scope={
            type:'BearerToken',
        }
        response.event.endpoint.endpointId=data.endpointId
        response.context.properties[0].value=data.value;
        response.context.properties[0].timeOfSample=new Date();
        response.event.payload={}
        alexaToken.get(data.endpointId,data.clientId,function(err,res){
            if(!err&&res)
                post(response,res);
        })
        clearTimeout(data.setTimeout)
    }

}
module.exports = alexaGateway;
