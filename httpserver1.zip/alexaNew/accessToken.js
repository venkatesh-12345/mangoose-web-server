var request = require('request');
var fs=require('fs');
var buf=require('../configs/sample.json')
var redisConn = require('../database/redis/redisConnector');
var genericModel = require('../database/model/genericModel');
var table=require('../util/table');
var M=require('../database/redis/mapper.js')
var alexa={};
var clone=require('./clone').clone
var options = {
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'charset':'UTF-8'
    },
    form:{
        grant_type:'authorization_code',
    }
};
function sendRequest(tag,code,data,callback){
    var option=clone(options);
    option.form[tag]=code;
    if(tag=='refresh_token')
       option.form.grant_type=tag;
    var clientId=data.clientId
    option.url= buf[clientId].autherization_url;
    option.form.client_id=buf[clientId].clientID;
    option.form.client_secret=buf[clientId].ClientSecret;
    request(option, function(err, response, resBody) {
       if(response && response.statusCode==200){
           try{
               var body=JSON.parse(resBody);
           }catch(error){
                return console.log('error',error)
           }
           data.token=body.access_token;
           var refresh_token=body.refresh_token;
           var accessToken=data.accessToken;
           var params = {userID: data.UserId, tempPass: data.tempPass,alexaToken:body.access_token,refreshToken:refresh_token,startTime:new Date(),region:data.region};
           if(tag!='refresh_token')
               genericModel.insertUpdate(table.USER_TEMP_PASSWORDS, params, function(e,o){});
           redisConn.query('hgetall',M.USER+data.UserId,function(err,res){
               if(!err&&res){
                   var keys = Object.keys(res)
                   var multi=redisConn.localMulti()
                       if(!multi)
                           return callback(true)
                   for (var i in keys){
                       var entry =  keys[i].split('_');
                       if (keys[i].indexOf(M.PREFIX_PMAC)==0||keys[i].indexOf(M.PREFIX_SMAC)==0)
                       {
                           multi.hmset('DV_'+entry[1],[data.clientId,JSON.stringify(params)])
                       }
                   }
                   multi.exec(function(){})
               }
               callback(null,true);
           })
       }
       else 
           callback(true)
   })
}
alexa.set=function(req,res){
	var data=req.body;
	var accessToken=req.get('Authorization').split(' ')[1].split(':');
    data.UserId=accessToken[1];
    data.tempPass=accessToken[0];
	sendRequest('code',data.code,data,function(err,response){
        if(!err&&response){
            genericModel.deleteWithConditions(table.USER_TEMP_PASSWORDS,{equal:{userID:data.UserId,ClientName:data.clientId},notEqual:{tempPass:data.tempPass}},function(e,result){
                return res.status(200).send({success:true});
			})
		}
		else
	        return res.status(200).send({success:false,reasonCode:21})
	})
}
alexa.get=function(endpointID,clientId,callback){
    if(!endpointID)
        return;
    var almond=endpointID.split(':')[0];
    redisConn.localQuery('hmget',{key:'DV_'+almond,params:clientId},function(e,o){
        if(e&&!o)
            return callback(e,o);
        try{
            var params=JSON.parse(o);
        }catch(e){}
        if(!params.startTime||(new Date()-new Date(params.startTime)>3600000)){
            var data={UserId:params.UserId,tempPass:params.TempPassword,region:params.region,clientId:clientId};
            sendRequest('refresh_token',params.refreshToken,data,function(err,res){
                if(!err&&res)
                    return callback(null,{accessToken:data.token,region:data.region})
                    return callback(err,res);
            })
        }else{
            return callback(null,{accessToken:params.alexaToken,region:params.region});
        }
    })
}
module.exports=alexa;
