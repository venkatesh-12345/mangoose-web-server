var devices={};
var methods=require('./deviceControl.js')
devices.ACTIONS = {
	'DecreaseColorTemperature':[],
	'IncreaseColorTemperature':[],
	'SetColorTemperature':['isNumber'],
	'Activate':[],
	'SetColor':[],
	'Lock':[],
	'Unlock':[],
	'TurnOn':[],
	'TurnOff':[],
	'AdjustBrightness':['isNumber','isNonZero'],
	'SetBrightness':['isNumber','rangeCheck'],
	'SetTargetTemperature':['isNumber','tempRangeCheck'],
	'AdjustTargetTemperature':['isNumber','isNonZero'],
	'SetThermostatMode':['targetExists'],
	'ReportState':[]
}
devices.DEVICES = {
    32: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        AdjustBrightness: {
            get: methods.adjustBrightness,
        },
        SetBrightness: {
            get: methods.setBrightness,
        },
        SetColor:{
            get:methods.setColor,
        },
        DecreaseColorTemperature:{
            get:methods.setColorTemperature,
            sign:-1,
        },
        IncreaseColorTemperature:{
            get:methods.setColorTemperature,
            sign:1,
        },
        SetColorTemperature:{
            get:methods.setColorTemperature,
        },
        Index:2,
        LightIndex:1,
        HueIndex:3,
        SaturationIndex:4,
        HueHigh:255,
        SaturationHigh:255,
        LightHigh: 255,
        LightLow:0,
        TempIndex:5,
        TempHigh:10000,
        TempLow:1000,
        toAlmond:'sendTwoReuqest',
        colorTemp:{
            2202:{ hue: 30, saturation: 0.83, brightness: 1 },
            2702:{ hue: 30, saturation: 0.67, brightness: 1 },
            4000:{ hue: 32, saturation: 0.37, brightness: 1 },
            5524:{ hue: 30, saturation: 0.13, brightness: 1 },
            7042:{ hue: 250, saturation: 0.05, brightness: 1 },
        }
    },
    48: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        AdjustBrightness: {
            get: methods.adjustBrightness,
        },
        SetBrightness: {
            get: methods.setBrightness,
        },
        SetColor:{
            get:methods.setColor,
        },
        Index:2,
        LightIndex:5,
        HueIndex:3,
        SaturationIndex:4,
        HueHigh:65535,
        SaturationHigh:255,
        LightHigh: 255,
        LightLow:0,
        toAlmond:'sendTwoReuqest'

    },
    1: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        Index:1,
        toAlmond:'sendTwoReuqest'
    },
    2: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: '100',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: '0',
            response:'OFF',
            get: methods.indexValue
        },
        AdjustBrightness: {
            get: methods.adjustBrightness
        },
        SetBrightness: {
            get: methods.setBrightness
        },
        Index:1,
        LightIndex:1,
        LightHigh: 100,
        LightLow:0,
        toAlmond:'sendTwoReuqest'
    },
    4: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        AdjustBrightness: {
            get: methods.adjustBrightness,
        },
        SetBrightness: {
            get: methods.setBrightness,
        },
        Index:2,
        LightIndex:1,
        LightHigh: 255,
        LightLow:0,
        toAlmond:'sendTwoReuqest'
    },
    10: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        Index:1,
        toAlmond:'sendTwoReuqest'
    },
    22: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        Index:1,
        toAlmond:'sendTwoReuqest'
    },
    44: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        Index: 1,
        toAlmond:'sendTwoReuqest'
    },
    45: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        Index: 1,
        toAlmond:'sendTwoReuqest'
    },
    50: {
        ReportState:{
            get:methods.reportPower,
        },
        TurnOn: {
            Value: 'true',
            response:'ON',
            get: methods.indexValue
        },
        TurnOff: {
            Value: 'false',
            response:'OFF',
            get: methods.indexValue
        },
        Index: 1,
        toAlmond:'sendTwoReuqest'
    },
    7: {
        ReportState:{
            get:methods.reportTemp
        },
        SetTargetTemperature: {
            get: methods.setTemperature
        },
        AdjustTargetTemperature: {
            get: methods.adjustTemperature
        },
        SetThermostatMode:{
            get:methods.setMode
        },
        'modeIndex': 2,
        'modes':{
            'OFF': 'Off',
            'HEAT': 'Heat',
            'COOL': 'Cool',
            'AUTO': 'Auto',
        },
        'coolIndex': 5,
        'heatIndex': 4,
        'minTemp': 51,
        'maxTemp': 86,
        toAlmond:'sendTwoReuqest'
    },
    62: {
        ReportState:{
            get:methods.reportTemp
        },
        SetTargetTemperature: {
            get: methods.setTemperature
        },
        AdjustTargetTemperature: {
            get: methods.adjustTemperature
        },
        SetThermostatMode:{
            get:methods.setMode
        },
        'modeIndex': 2,
        'modes':{
            'OFF': 'Off',
            'HEAT': 'Heat',
            'COOL': 'Cool',
            'AUTO': 'Auto',
        },
        'coolIndex': 5,
        'heatIndex': 4,
        'minTemp': 39,
        'maxTemp': 95,
        toAlmond:'sendTwoReuqest'
    },
    57: {
        ReportState:{
            get:methods.reportTemp
        },
        SetTargetTemperature: {
            get: methods.setTemperature
        },
        AdjustTargetTemperature: {
            get: methods.adjustTemperature
        },
        SetThermostatMode:{
            get:methods.setMode
        },
        'isOnline': 11,
        'targetIndex': 3,
        'awayIndex': 8,
        'modeIndex': 2,
        'modes':{
            'OFF': 'off',
            'HEAT': 'heat',
            'COOL': 'cool',
            'AUTO': 'heat-cool',
            'ECO':'eco',
        },
        'coolIndex': 5,
        'heatIndex': 6,
        'canCool': 12,
        'canHeat': 13,
        'minTemp': 50,
        'maxTemp': 90,
        'units': 7,
        nest: true,
        toAlmond:'sendTwoReuqest'
    },
    28:{
        Lock:{
            Value: '1',
            response:'LOCKED',
            get:methods.indexValue
        },
        Unlock:{
            Value: '2',
            response:'UNLOCKED',
            get:methods.indexValue
        },
        ReportState:{
            get:methods.reportLock,
            Lock:'1'
        },
        Index:1,
        isLock:true,
        toAlmond:'sendTwoReuqest'
    },
    27:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:1
        },
    },
    29:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:1
        },
    },
    49:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:4
        },
    },
    11:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:4
        },
    },
    12:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:4
        },
    },
    14:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:4
        },
    },
     24:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:4
        },
    },
    41:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:4
        },
    },
    46:{
        ReportState:{
            get:methods.reportSensorTemperature,
            Index:4
        },
    },
    'Scene':{
        Activate:{
            get:methods.activateScene
        },
        toAlmond:'alexaScene'
    }
}
module.exports=devices;
