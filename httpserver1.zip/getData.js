var bodyParser = require('body-parser');
var oauthServer = require('node-oauth2-server');
var express = require('express');
var fs = require('fs');
var path = require('path');
var https = require('http');
//var http = require('http');
var EM = require('./email/emailDispatcher');
var dashBoard=require('./controllers/dashBoard');
var oauthModel = require('./database/model/oauthCheck');
var sendToAlmond = require('./controllers/sendToAlmond');
var fetchData = require('./controllers/fetchData');
var siteMonitoring = require('./controllers/siteMonitoring.js');
var account = require('./controllers/accounts');
var stripeEvents = require('./scripts/stripeEvents.js');
var alexa = require('./controllers/alexa.js');
var alexaError=require('./alexa/errors.js').types
var dnHis = require('./scripts/downloadHistory');
var Consumer = require('./rabbitmq/consumer');
var sendToQueue= require('./controllers/sendToQueue')
var tracker = require('./tracking')
var config=require('./config.js')
var userSubscriptions= require('./database/model/userSubscription');
var UA= require('./broadcast/updateEndPointNew')
oauthModel.init('../../configs/sample.json');
var zenProcessor= require('./database/model/zenRequests')
var mapping=require('./mapping');
var ivideon=require('./database/model/device').ivideon

var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));
app.oauth = oauthServer({
    model: oauthModel,
    accessTokenLifetime: null,
    grants: ['authorization_code', 'password'],
    debug: true,
    authCodeLifetime: 100,
    continueAfterResponse: true
});

var httpsPrivateKey = fs.readFileSync(path.join(__dirname, './certs/securifi_key.pem')).toString();
var httpsCertificate = fs.readFileSync(path.join(__dirname, './certs/securifi.crt')).toString();
var httpsOptions = {
    key: httpsPrivateKey,
    cert: httpsCertificate,
    requestCert: false,
    rejectUnauthorized: false,
    ca: [
        fs.readFileSync(path.join(__dirname, './certs/gd_bundle-g2-g1.crt'), 'utf8')
    ]
};
if (!(config.HTTP_PORT)) {
    config.HTTP_PORT = 4433;
}
console.log("HTTP_PORT: ", config.HTTP_PORT);
var httpsServer = https.createServer(app);
//var httpsServer = http.createServer(app);
httpsServer.listen(config.HTTP_PORT, function() {
   ; // setTimeout(function() {
    //     tracker.start()
    // }, 3 * 1000)
}).on('uncaughtException', function(e) {
    console.log('uncaughtException', e)
    tracker.error(e.stack)
});
function formBody(req,commandType){
    if(!req)
        return null
    var body=req.body;
    if(req.user)
        body.userid=req.user.id
    body.commandType=commandType.substring(1);
    return body;
}
function processor(callProcessor,request,res,commandType){
    callProcessor.do(formBody(request,commandType),function(statusCode,result){
        return res.status(statusCode).send(JSON.stringify(result));
    })
}
var getRequests = [ "/scenes/getAll", "/clients/getAll","/devices/getAll","/almonds","/devices/getAll/values"
];
var postRequest=["/devices", "/scenes", "/rules", "/clients","/devices/history", "/clients/history","/RecentActivity"
];
app.get(
    getRequests,app.oauth.authorise(),
    function(request, response) {
        processor(fetchData,request,response,request.path);
    }
);
app.post(
    postRequest,app.oauth.authorise(),oauthModel.isValidUserForAlmond,
    function(request, response) {
         processor(fetchData,request,response,request.path);
    }
);
var getRequestsOld = [ "/GetAllScenes", "/GetAllClients","/GetAllDevices","/GetAlmondList"];
var postRequestsOld=["/GetDeviceData", "/GetScenes", "/GetRules", "/GetClients","/GetDeviceHistory", "/GetClientHistory","/RecentActivity"];
app.get(
    getRequestsOld,app.oauth.authorise(),
    function(request, response) {
        processor(fetchData,request,response,mapping[request.path]);
    }
);
app.post(
    postRequestsOld,app.oauth.authorise(),oauthModel.isValidUserForAlmond,
    function(request, response) {
         processor(fetchData,request,response,mapping[request.path]);
    }
);

var sendToAlmondRequests = ["/almond/changeMode", "/scene/activate", "/scene/update", "/EnableGuestNetwork", "/client/update",
    "/device/updateIndex", "/router/summary", "/wirelessSettings/get", "/wirelessSettings/set", "/almond/changeName", 
    "/router/reboot"
];

app.post(
    sendToAlmondRequests,app.oauth.authorise(),oauthModel.isValidUserForAlmond,
    function(request, response) {
        sendToAlmond.do(request,response,request.path);
    }
);
app.post(
    "/almond/link",app.oauth.authorise(),
    function(request, response) {
        sendToAlmond.do(request,response,request.path);
    }
);
var sendToAlmondRequestsOld = ["/ChangeMode", "/ActivateScene", "/UpdateScene", "/EnableGuestNetwork", "/UpdateClient",
    "/UpdateDeviceIndex", "/RouterSummary", "/GetWirelessSettings", "/SetWirelessSettings", "/ChangeAlmondName",
    "/RebootRouter"
];

app.post(
    sendToAlmondRequestsOld,app.oauth.authorise(),oauthModel.isValidUserForAlmond,
    function(request, response) {
        sendToAlmond.do(request,response,mapping[request.path]);
    }
);
app.post(
    "/AffiliationUserRequest",app.oauth.authorise(),
    function(request, response) {
        sendToAlmond.do(request,response,mapping[request.path]);
    }
);


app.post("/alexa/control", app.oauth.authorise(),oauthModel.isValidUserForAlmond, function (req, res) {
    return alexa.do(req, res );
});
app.post("/alexa/accessToken",app.oauth.authorise(),function(req,res){
    return alexa.accessToken(req,res);
})
app.post("/alexa/discovery",app.oauth.authorise(),function(req,res){
    return alexa.discovery(req,res);
})
app.post("/alexa/remove",app.oauth.authorise(),function(req,res){
    alexa.removeDevice(req.body);
    return res.status(200).send(JSON.stringify({"Success":true}));
})
app.get('/', function(req, res) {
    return res.send("hello world");
});

var accountRequests = ["/account/add", "/account/sendActivation", "/account/login",  "/account/logout",
    "/account/reset", "/account/confirmReset", "/account/verify", "/account/delete"
];
app.post(
    accountRequests,
    function(request, response) {
        processor(account,request, response,request.path);
    }
);
var accountRequestsOld=["/SignUp", "/ResendActivationLink", "/Login",  "/Logout",
    "/ResetPassword", "/ConfirmResetPassword", "/VerifyAccount", "/DeleteAccount"
];
app.post(
    accountRequestsOld,
    function(request,response){
        processor(account,request,response,mapping[request.path]);
    })
var StripeEvents = ["/StripeEvents"];
app.post(
    StripeEvents,
    function(request, response) {
        console.log("***** Got An Event From Stripe *****");
    console.log(request.body);
    var data = JSON.stringify(request.body);
    fs.appendFile('./logFile', data + '\n', function (o, err) {});
    console.log(request.body.type);
    stripeEvents.updateDB(request.body.type, request.body);
    response.sendStatus(200);
    }
);

app.post("/SiteMonitoring", function(req, res) {
    return processor(siteMonitoring,req, res,req.path);
});

app.post("/DownloadHistory", function(req, res) {
    console.log("I am here DownloadHistory")
    dnHis.downloadHistory(req.body, res, function(err) {
        if (err)
            console.log(err);
        res.sendStatus(200);
    });
});

// app.post("/RecentActivity", app.oauth.authorise(), function(req, res) {
//     return haCommands.getRecentActivity(req, res, 'RecentActivity');
// });
app.post('/fromDashBoard', function(req, res) {
    dashBoard(req,function(statusCode,result){
        console.log(statusCode,result)
        return res.status(statusCode).send(JSON.stringify(result));
    },res)
})
var sendCommands=["/sendCommand"]
app.post(sendCommands, function(req, res) {
    sendToQueue.do(req,function(statusCode,result){
        console.log(statusCode,result)
        return res.status(statusCode).send(JSON.stringify(result));
    },res)
})
app.post('/zen/add',function(req,res){
    res.commandType='/zen/add';
    res.TimeStamp=Date.now()
    return zenProcessor(req,res)
})
function checkIP(request) {
    var requestIP = request.connection.remoteAddress.split(":");
    if (config.portalIP.indexOf(requestIP[requestIP.length - 1]) > -1)
        return true;
    return false;
}
app.post('/Subscriptions', function (req, res) {
    console.log(" ****** got POST iN subscriptions ...");
   //if (!checkIP(req)  || !req.body )
     //   return res.send('{"Success":false}')
    var request = req.body;
    var cmdType = request.CommandType;
    if (cmdType == "SubscribeMe") {
        userSubscriptions.Subscribe(req.body);
    } else if (cmdType == "DeleteSubscription") {
        userSubscriptions.DeleteSubscription(req.body);
    }
    else if(cmdType=='cancelAtEnd')
        userSubscriptions.doCancelAtEnd(req.body)
    else if(cmdType=='cancelInStripe')
        userSubscriptions.sendCancelToStripe(req.body,req.body.CancelAtEnd);
    else if(cmdType=='reactivateSubs')
        userSubscriptions.reActivateSubs(req.body);
    res.send('{"Success":true}')
});

app.post('/broadcastSubs',function(req,res){
    if(!checkIP(req) || !req.body || ! req.body.AlmondMAC  )
        return res.send('{"Success":false}')
    UA.broadcastToAlmondandMobile(req.body.AlmondMAC,req.body.Services,req.body.Payload,req.body.Command)
})
app.all('/GetAccessCode', oauthModel.getAccessCode, app.oauth.authCodeGrant(function(req, callback) {
    return callback(undefined, true, {
        email: req.body.user,
        userId: req.userId
        //tempPass: req.tempPass
    });
}));

app.post('/GetAccessToken',app.oauth.grant());


app.post("/ivideon/add",app.oauth.authorise(),function(req, res) {
    ivideon(req.body,function(statusCode,result){
        return res.status(statusCode).send(JSON.stringify(result));
    })
});

app.use(function(err, req, res, next) {
    if(err&&err.message=='MAINTENANCE')
        return res.status(200).send( JSON.stringify({
                "error": "MAINTENANCE"
            }));
    if(req && req.body && req.body.event)
        tracker.alexa(req.body.event,502,{reasonCode:alexaError.INVALID_AUTHORIZATION_CREDENTIAL});
    console.log("inside use function")
    if (err ) {
        console.log(err);
        return res.status(502).send( JSON.stringify({
            "error": 'oauth error'
        }));
    }
});
