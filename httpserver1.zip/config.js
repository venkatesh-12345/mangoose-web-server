
'use strict';
var nconf = require('nconf'),
  path = require('path'),
  ROOT = path.resolve(__dirname, './'),
  CONFIG;

nconf.env().argv();

CONFIG = nconf.get('DATABASE') || 'prod';
console.log('CONFIG',CONFIG)
nconf
  .file('local', ROOT + '/configs/'+CONFIG+'.json')
  .file('database', ROOT + '/configs/setting.json')
module.exports=nconf.get();