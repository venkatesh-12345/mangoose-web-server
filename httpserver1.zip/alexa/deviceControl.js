var errors=require('./errors').types;
var helper=require('./util/helper')
var preProcessor = require('../controllers/sendToAlmond.js');
var deviceControl={};
var processor=require('../alexa/responseGenerator');
    
function caluculateTemp(result,deviceValues,delta) {
    if (result.mode == deviceValues.mode.modes.AUTO) {
        var heatTemp = parseInt(deviceValues.heat.value) ;
        var coolTemp = parseInt(deviceValues.cool.value) ;
        result.previouseTargetTemp = (heatTemp - 2 + coolTemp + 1) / 2 ;
        result.targetTemp = result.targetTemp ? result.targetTemp: result.previouseTargetTemp +delta;

        result.commands.push({ Index: deviceValues.heat.index, Value: Math.round(result.targetTemp+2) });
        result.commands.push({ Index: deviceValues.cool.index, Value: Math.round(result.targetTemp-1) });
    }
    else {
        var target = deviceValues.target ? deviceValues.target : (result.mode == deviceValues.mode.modes.HEAT ? deviceValues.heat: deviceValues.cool);
        result.previouseTargetTemp =  parseInt(target.value) ;
        result.targetTemp =  result.targetTemp ? result.targetTemp:  result.previouseTargetTemp + delta ;
        result.commands.push({ Index: target.index, Value: Math.round(result.targetTemp) });
    }

}

function changeTemperature(deviceValues, delta,targetTemp,scale) {
    var result = { mode: deviceValues.mode.value ,commands:[],targetTemp:targetTemp,value:{}};

    if (scale && (result.mode == deviceValues.mode.modes.OFF || result.mode == deviceValues.mode.modes.ECO)){
        result.reasonCode = errors.THERMOSTAT_IS_OFF;
        return result;
    }
    if (deviceValues.isOnline){
        if (deviceValues.isOnline.value == 'false'){
            result.reasonCode = errors.DEVICE_IS_OFFLINE;
            return result;
        }
        if (deviceValues.away.value != 'home'){ 
            result.reasonCode = errors.NEST_IS_IN_AWAY_MODE;
            return result;
        }
    }
    caluculateTemp(result,deviceValues,delta);
    if (result.targetTemp && (result.targetTemp > deviceValues.mode.maxTemp ||result.targetTemp < deviceValues.mode.minTemp)){
        result.reasonCode=errors.TEMPERATURE_VALUE_OUT_OF_RANGE;
        if(scale=="CELSIUS"){
            result.validRange={minimumValue:{scale:scale,value:helper.toCelsius(deviceValues.mode.minTemp)},maximumValue:{scale:scale,value:helper.toCelsius(deviceValues.mode.maxTemp)}}
        }
        else
            result.validRange={minimumValue:{scale:scale,value:deviceValues.mode.minTemp},maximumValue:{scale:scale,value:deviceValues.mode.maxTemp}}
    }
    // Get Mode to send to Alexa
    var keys=Object.keys(deviceValues.mode.modes);
    for(var i in keys){
        if(deviceValues.mode.modes[keys[i]]==result.mode)
            result.value.mode = keys[i];
    }

    return result;
}

deviceControl.adjustTemperature=function(deviceValues, delta) {
    var temp=delta.value;
    if(delta.scale=='CELSIUS')
        temp=temp*9/5;
    var result=changeTemperature(deviceValues,temp,null,delta.scale);
    if(delta.scale=='CELSIUS')
        result.value.targetTemp={value:Math.round(helper.toCelsius(result.targetTemp)),scale:delta.scale};
    else
        result.value.targetTemp={value:result.targetTemp,scale:delta.scale}
    return result;
}

deviceControl.setTemperature=function(deviceValues, targetTemp) {
    var temp =targetTemp.value
    if(targetTemp.scale=='CELSIUS')
        temp=(temp * 9) / 5 + 32;
    var result=changeTemperature(deviceValues,0,temp,targetTemp.scale);
    result.value.targetTemp=targetTemp;
    if(result.previouseTargetTemp==result.targetTemp)
       result.reasonCode = errors.SAME_VALUE_RECEIVED;
    return result   
}

deviceControl.reportTemp=function(deviceValues, delta){
    var result=changeTemperature(deviceValues,0,null,true);
    result.mode=result.value.mode
    if(result.targetTemp)
        result.targetTemp={value:result.targetTemp, scale: "FAHRENHEIT"}
    return result;
}  

deviceControl.activateScene=function(deviceValues){
    return {commandList:[],request:{AlmondMAC:deviceValues.almondMAC,Scenes:{ID:deviceValues.deviceId}}};
}

deviceControl.setMode=function(deviceValues,delta){
    delta=delta.value
    var result=changeTemperature(deviceValues) 
    if (result.reasonCode) {
        return result;
    }
    if(result.mode==deviceValues.mode.modes[delta])
        return {'reasonCode':  errors.SAME_VALUE_RECEIVED,
    value:{targetTemp:{value:result.previouseTargetTemp,scale:"FAHRENHEIT"},mode:delta}};
    return {value:{targetTemp:{value:result.previouseTargetTemp,scale:"FAHRENHEIT"},mode:delta},
    commands:[{Index:deviceValues.mode.index,Value:deviceValues.mode.modes[delta]}]};
}


deviceControl.reportSensorTemperature=function(deviceValues,value,device){
    return {temperature:{"value":parseInt(deviceValues.tempSensor.value),"scale":"FAHRENHEIT"}};
}
deviceControl.reportPower=function(deviceValues, delta,device){
    var response={}
    response.power="ON";
    var temp=deviceValues.onOff ? deviceValues.onOff.value : deviceValues.brightness.value
    if(temp==false||temp=='false'||temp==0)
        response.power="OFF";
    
    if(deviceValues.brightness){
        response.brightness=Math.round(deviceValues.brightness.value*100/deviceValues.brightness.high);
        if(deviceValues.hue){
            response.color={
                "hue": Math.round(parseInt(deviceValues.hue.value)*360/deviceValues.hue.hueHigh),
                "saturation": Math.round(parseInt(deviceValues.saturation.value)/2.55)/100,
                "brightness": response.brightness/100
            }
            if(deviceValues.colorTemp){
                var value = deviceValues.colorTemp.value;
                response.colorTemperatureInKelvin=parseInt(value);
                if(deviceValues.hue.colorTemp[value] && JSON.stringify(deviceValues.hue.colorTemp[value])==JSON.stringify(response.color))
                    delete response.color;
                else
                    delete response.colorTemperatureInKelvin;            
            }
        }
    }
    return response;
}
function indexValueUpdate(deviceValues,targetValue,tag,indexTag){
    var result ={commands:[],value:{}};
    result.value[indexTag]=null;
    if ((deviceValues[tag].value == targetValue))
        result.reasonCode =errors.SAME_VALUE_RECEIVED;
    else
        result.commands.push({Index:deviceValues[tag].index, Value:targetValue});
    return result;
}
deviceControl.indexValue=function(deviceValues, targetValue) {
    if(deviceValues.deviceType==2){
        targetValue=targetValue=='true'?100:0
        return indexValueUpdate(deviceValues,targetValue,'brightness','power')
    }
    return indexValueUpdate(deviceValues,targetValue,'onOff','power')
} 

deviceControl.lock=function(deviceValues,targetValue){
    var result = indexValueUpdate(deviceValues,deviceValues.lock[targetValue],'lock','lockState');
    result.isLock =true;
    return result;
}

deviceControl.adjustBrightness=function(deviceValues, percent) {
    var targetValue= Math.round(parseInt(deviceValues.brightness.value) + (percent * deviceValues.brightness.high/100));
    if (targetValue > deviceValues.brightness.high || targetValue < 0)
        return {reasonCode:errors.VALUE_OUT_OF_RANGE,validRange:{minimumValue:0,maximumValue:100}};
    return controlBrightness(deviceValues ,targetValue);
    
}

deviceControl.setBrightness=function(deviceValues, percent) {
    var targetValue= Math.round(percent * deviceValues.brightness.high/100)
    if(deviceValues.brightness.Value==targetValue)
        return errors.SAME_VALUE_RECEIVED;
    return controlBrightness(deviceValues, targetValue);
}
    

function controlBrightness(deviceValues, targetValue,lightHigh) {
    var response={commands:[],value:{brightness:Math.round(targetValue*100/deviceValues.brightness.high)}}
    if(deviceValues.onOff && deviceValues.onOff.value=='false' && deviceValues.deviceType==48)
        response.commands.push({Index:deviceValues.onOff.index,Value:'true'});
    response.commands.push({Index: deviceValues.brightness.index,Value: targetValue});

    return response;
}

deviceControl.setColor=function(deviceValues,value){

    var targetHue=Math.round(value.hue*deviceValues.hue.hueHigh/360);
    var targetSaturation=Math.round(value.saturation*255);
    var targetBrightness=Math.round(value.brightness*255);
    var response={commands:[],value:{color:value}}
    if(deviceValues.brightness.value!=targetBrightness)
        response.commands.push({Index:deviceValues.brightness.index,Value:targetBrightness});
    if(deviceValues.hue.value!=targetHue)
        response.commands.push({Index:deviceValues.hue.index,Value:targetHue});
    if(deviceValues.saturation.value!=targetSaturation)
        response.commands.push({Index:deviceValues.saturation.index,Value:targetSaturation});

    if(deviceValues.onOff.value=='false' && deviceValues.deviceType==48)
        response.commands.unshift({Index:deviceValues.onOff.index,Value:'true'});
    if(response.commands.length==0)
        response.reasonCode=errors.SAME_VALUE_RECEIVED; 
    return response;
}

deviceControl.setColorTemperature=function(deviceValues, value) {
    var response = {commands:[]};
    var currentValue = parseInt(deviceValues.colorTemp.value);
    if ((currentValue == 10000 && value == 1) || (currentValue == 1000 && value < 0))
        return {reasonCode:errors.VALUE_OUT_OF_RANGE,validRange:{minimumValue:1000,maximumValue:10000} }

    if (value>1)
        response.value = getColor(value);
    else {
        var temp = currentValue + (value * 1000)
        if (temp >= 10000)
            response.value = 10000;
        else if (temp <= 1000)
            response.value = 1000;
        else
            response.value = getColor(temp);
    }
    response.value={colorTemperatureInKelvin:response.value}
    var saturationBrightness = deviceValues.hue.colorTemp[response.value.colorTemperatureInKelvin];
    if(saturationBrightness){
        var commands=deviceControl.setColor(deviceValues,saturationBrightness).commands;
        if(commands)
            response.commands=response.commands.concat(commands);
    }

    if (response.value.colorTemperatureInKelvin != currentValue)
        response.commands.push({ Index: deviceValues.colorTemp.index, Value:response.value.colorTemperatureInKelvin + '' });
    if(response.commands.length==0)
        response.reasonCode=errors.SAME_VALUE_RECEIVED;
    return response;
}


function getColor(value) {
    return parseInt(1000000 / (parseInt(1000000 / value)));
}
deviceControl.reportLock=function(deviceValues,value){
    var device=deviceValues.lock;
    return {lockState:device.value==device.lock?'LOCKED':'UNLOCKED'}
}
deviceControl.constructResponse=function(req,res,data,functionName,values){
    var result = deviceControl[functionName](Object.keys(values).length>1?values:data, data.targetValue);
    if (result.reasonCode||data.event == 'ReportState')
                return processor.getResponse(req.body.event,result,res,'sendResponse');
    if (result.commands) {
        for (var i = 0; i < result.commands.length; i++) {
            var command = result.commands[i];
            command.AlmondMAC = data.almondMAC;
            command.ID = data.deviceId;
            command.CommandType = "UpdateDeviceIndex";
            command.MobileInternalIndex = Math.floor(Math.random() * 1000 + 1);
        }
    }
    var responseFields = {},params={};
    params.request = result.request;
    params.timeoutLimit =  5000 ;
    responseFields.value = result.value;
    responseFields.previousValue=result.previouseTargetTemp;
    responseFields.userid = req.user.id;
    responseFields.response = res;
    responseFields.event=req.body.event
    if (result.isLock) {
        responseFields.deferredResponse=processor.deferredResponse(req.body.event,data.thisTemplate)
        responseFields.isLock = result.isLock;
        responseFields.clientId= req.body.clientId;
        responseFields.region= req.body.region;

        params.timeoutLimit = 5000;
    }
    preProcessor[data.event=='Activate'?'alexaScene':'sendTwoReuqest'](responseFields,params, result.commands);
}
module.exports=deviceControl;
