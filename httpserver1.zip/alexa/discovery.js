var discovery={};
var helper=require('./util/helper')
var CP = require('../database/sql/sqlQuery.js');
var gateway=require('./gateway');
var redisConn = require('../database/redis/redisConnector');
var tracking=require('../tracking');

const discoveryActions={
    'PowerController' :{
        "type": "AlexaInterface",
        "interface": "Alexa.PowerController",
        "version": "3",
        "properties": {
            "supported": [{
                "name": "powerState"
            }],
            "proactivelyReported": true,
            "retrievable": true
        }
    },
    'BrightnessController':{
        "type": "AlexaInterface",
        "interface": "Alexa.BrightnessController",
        "version": "3",
        "properties": {
            "supported": [{
                "name": "brightness"
            }],
            "proactivelyReported": true,
            "retrievable": true
        }
    },
    'ThermostatController':{
        "type": "AlexaInterface",
        "interface": "Alexa.ThermostatController",
        "version": "3",
        "properties": {
            "supported": [
                {
                    "name": "targetSetpoint"
                },
                {
                    "name": "thermostatMode"
                }
            ],
            "proactivelyReported": true,
            "retrievable": true
        }
    },
    'LockController':{
        "type": "AlexaInterface",
        "interface": "Alexa.LockController",
        "version": "3",
        "properties": {
            "supported": [{
                "name": "lockState"
            }],
            "proactivelyReported": true,
            "retrievable": true
        }
    },
    'SceneController':{
        "type": "AlexaInterface",
        "interface": "Alexa.SceneController",
        "version" : "3",
        "supportsDeactivation" : false,
        "proactivelyReported" : false
    },
    'ColorController':{
        "type": "AlexaInterface",
        "interface": "Alexa.ColorController",
        "version": "3",
        "properties": {
            "supported": [{
                "name": "color"
            }],
            "proactivelyReported": true,
            "retrievable": true
        }
    },
    'ColorTemperatureController':{
        "type": "AlexaInterface",
        "interface": "Alexa.ColorTemperatureController",
        "version": "3",
        "properties": {
            "supported": [{
                "name": "colorTemperatureInKelvin"
            }],
            "proactivelyReported": true,
            "retrievable": true
        }
    },
    'TemperatureSensor':{
        "type": "AlexaInterface",
        "interface": "Alexa.TemperatureSensor",
        "version": "3",
        "properties": {
            "supported": [
                {
                    "name": "temperature"
                }
            ],
            "proactivelyReported": false,
            "retrievable": true
        }
    },
    'interface':{
        "type": "AlexaInterface",
        "interface": "Alexa",
        "version": "3"
    }

};

const MAPPER={
    '32': {
        'name': 'Color Dimmable Light',
        'displayCategories':['LIGHT'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController,discoveryActions.BrightnessController,discoveryActions.ColorController,discoveryActions.ColorTemperatureController],
    },
    '48': {
        'name': 'HueLamp',
        'displayCategories':['LIGHT'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController,discoveryActions.BrightnessController,discoveryActions.ColorController],

    },
    '1': {
        'name': 'Binary Switch',
        'displayCategories':['SWITCH'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController],

    },
    '2': {
        'name': 'MultilevelSwitch',
        'displayCategories':['LIGHT'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController,discoveryActions.BrightnessController],
    },
    '4': {
        'name': 'MultilevelSwitchOnOff',
        'displayCategories':['LIGHT'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController,discoveryActions.BrightnessController],
    },
    '10': {
        'name': 'Binary Switch',
        'displayCategories':['SWITCH'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController],
    },
    '22': {
        'name': 'Smart AC Switch',
        'displayCategories':['SWITCH'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController],
    },
    '44': {
        'name': 'Binary Switch',
        'displayCategories':['SWITCH'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController],
    },
    '45': {
        'name': 'Binary Power Switch',
        'displayCategories':['SWITCH'],
        'actions': [discoveryActions.interface,discoveryActions.PowerController],
    },
    '50': {
        'actions': [discoveryActions.interface,discoveryActions.PowerController],
        'displayCategories':['SWITCH'],
    },
    '7': {
        'name': 'Thermostat',
        'displayCategories':['THERMOSTAT'],
        'actions': [discoveryActions.interface,discoveryActions.ThermostatController],
    },
    '62': {
        'name': 'Thermostat',
        'displayCategories':['THERMOSTAT'],
        'actions': [discoveryActions.interface,discoveryActions.ThermostatController],
    },
    '57': {
        'name': 'Nest Thermostat',
        'displayCategories':['THERMOSTAT'],
        'actions': [discoveryActions.interface,discoveryActions.ThermostatController],
    },
    '5':{
        'name':'ZigbeeDoorlock',
        'displayCategories':['SMARTLOCK'],
        'actions':[discoveryActions.interface,discoveryActions.LockController],
    },
    '28':{
        'name':'ZigbeeDoorlock',
        'displayCategories':['SMARTLOCK'],
        'actions':[discoveryActions.interface,discoveryActions.LockController],
    },
    '27':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
        'index':1,
    },
    '29':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'index':1,
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
    },
    '49':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'index':4,
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
    },
    '11':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'index':4,
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
    },
    '12':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'index':4,
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
    },
    '14':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'index':4,
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
    },
    '24':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'index':2,
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
    },
    '41':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'index':4,
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
    },
    '46':{
        'name':'TemperatureSensor',
        'displayCategories':['TEMPERATURE_SENSOR'],
        'index':4,
        'actions':[discoveryActions.interface,discoveryActions.TemperatureSensor],
    },
    'Scene':{
        'name':'Scene',
        'displayCategories':['SCENE_TRIGGER'],
        'actions':[discoveryActions.SceneController]
    }
}

var discoveryResponse = function(endpoints, device) {
    var deviceTemplate = MAPPER[device.DeviceType];
    var endpoint = {
        endpointId: device.AlmondMAC + ':' + device.ID ,
        manufacturerName: device.ManufacturerName?device.ManufacturerName:'Securifi',
        friendlyName: device.Name == undefined ? deviceTemplate.name : device.Name,
        description: deviceTemplate.name + ' via Almond',
        isReachable: true,
        capabilities: deviceTemplate.actions,
        displayCategories:deviceTemplate.displayCategories,
        cookie: {
            'deviceType': device.DeviceType
        }
    };
    endpoints.push(endpoint);
}
discovery.do = function(event,data,res) {
    tracking.alexa(event,200,{success:true});
    var result=helper.GetFormat(event).result;
    constructData(data,function(payload){
        result.event.payload=payload;
        gateway.sendResponse(result,res);
    })
}

var constructData = function(body,callback) {
    var list=body;
    var result = {};
    var genericDevices=[]
    result['endpoints']=[]
    var multi=redisConn.multi();
    for(var i in list){
        if(list.DeviceType==60&&list[i].GenericDeviceType)
            list[i].DeviceType=list[i].GenericDeviceType;
        else if(list[i].DeviceType==60){
            genericDevices.push(i);
            multi.hgetall('MAC:'+list[i].AlmondMAC+':'+list[i].ID);
        }
        if (MAPPER.hasOwnProperty(list[i].DeviceType)) {
            discoveryResponse(result['endpoints'], list[i]);
        }
    }
    if(genericDevices.length==0)
        callback(result);
    else{
        var query='insert into DeviceData (DeviceID,AlmondMAC,DeviceType,GenericDeviceType) values ? on DUPLICATE KEY UPDATE GenericDeviceType = values(GenericDeviceType);'
        var params=[]
        multi.exec(function(err,res){
            if(!res)
                callback(result);
            for(var i in res){
                var deviceResult={Type:60,priority:0};
                for(var index in res[i]){
                    var indexData=parseJSON(res[i][index]);
                    typeCheck(indexData,deviceResult)
                }
                var device=list[genericDevices[i]];
                device.DeviceType=deviceResult.Type
                if (MAPPER.hasOwnProperty(device.DeviceType)) {
                    discoveryResponse(result['endpoints'], device);
                    params.push([device.ID,device.AlmondMAC,device.DeviceType,device.DeviceType])
                }
            }   
            callback(result);
            if(params.length>0)
                CP.queryFunction(query,[params],function(e,o){}) 
        })
        
    }
}

function parseJSON(json){
    try {
        return JSON.parse(json);
    } catch (e) {
        console.log(" JSon error",e)
        return null;
    }
}


var typeCheck = function(indexData,result){
    if(result.found)
        return;
    switch(parseInt(indexData.Type)){
        case 33:  
            result.Type = 32;
            result.found = true;
            break;  
        case 30:  
            if(result.priority!=8){
                result.priority=7;
                result.Type=48;
            }
            break;            
        case 35:  
            if(result.priority<7){
                result.priority=6;
                result.Type=7;
            }
            break;
        case 18:  
            if(result.priority<6){
                result.priority=5;
                result.Type=4;
            }
            break;
        case 23:  
            if(result.priority<5){
                result.priority=4;
                result.Type=28;
            }
            break;
        case 22:  
            if(result.priority<5){
                result.priority=4;
                result.Type=5;
            }
            break;
        case 17:
            if(result.priority<4){
                result.priority=3;
                result.Type=2;
            }
        case 1 :  
            if(result.priority<3){
                result.priority=2;
                result.Type=1;
            }
            break;
        case 25:
            if(result.priority<2){
                result.priority=1;
                result.Type=27;
            }
            break;
    }
}
module.exports=discovery