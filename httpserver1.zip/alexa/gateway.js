var request = require('request');
var buf=require('../configs/sample.json')
var redisConn = require('../database/redis/redisConnector');
var redisStore=require('../database/redis/redisStore');
var genericModel = require('../database/model/genericModel');
var table=require('../util/table');
var url = require('nconf').get('alexaGateway');
var sendToAlmond=require('../almondEndpoint/sendToAlmond')
var gateway={}
var clone=require('./util/clone').clone
var options = {
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'charset':'UTF-8'
    },
    form:{
        grant_type:'authorization_code',
    }
};


gateway.post = function(response,data) {
    getAccessToken(data.userid,data.clientId,function(err,res){
        if(response.event.header.name!='DeleteReport')
            response.event.endpoint.scope.token=res.accessToken
        else
            response.event.payload.scope.token=res.accessToken
        if(err || !res)
          return;
        var options = {
            method: 'POST',
            url: url[res.region],
            headers: {
                'authorization': 'Bearer ' + res.accessToken,
                'content-type': 'application/json'
            },
            body: response,
            json: true
        };
        request(options, function(err, res, resBody) {
            if(res.statusCode==403)
                gateway.alexaDisable(data.userid,true);
            return console.log(err,res.statusCode,resBody,'--------------in alexaGateway-----------------');
        });
    })
}


gateway.getAccessToken=function(tag,code,data,callback){
    var option=clone(options);
    option.form[tag]=code;
    if(tag=='refresh_token')
       option.form.grant_type=tag;
    var clientId=data.clientId
    option.url= buf[clientId].autherization_url;
    option.form.client_id=buf[clientId].clientID;
    option.form.client_secret=buf[clientId].ClientSecret;
    request(option, function(err, response, resBody) {
        if(response && response.statusCode==200){
            try{
               var body=JSON.parse(resBody);
            }catch(error){
                return console.log('error',error)
            }
            data.token=body.access_token;
            var refresh_token=body.refresh_token;
            var accessToken=data.accessToken;
            var params = {userID: data.UserId, tempPass: data.tempPass,alexaToken:body.access_token,refreshToken:refresh_token,startTime:new Date(),region:data.region};
            if(tag!='refresh_token')
                genericModel.insertUpdate(table.USER_TEMP_PASSWORDS, params, function(e,o){});
            redisConn.localQuery('hmset',{key:'alexa_'+data.UserId,params:[data.clientId,JSON.stringify(params)]},function(err,res){
                callback(err,res);
            })
       }
       else 
           callback(true)
   })
}

var getAccessToken=function(userID,clientId,callback){
    if(!userID)
        return;
    redisConn.localQuery('hgetall','alexa_'+userID,function(e,o){
        if(e&&!o)
            return ;
        clientID=o[clientId]?clientId:url.clientIdTest;
        try{
            var params=JSON.parse(o[clientID]);
        }catch(e){return;}
        if(!params.startTime||(new Date()-new Date(params.startTime)>3600000)){
            var data={UserId:params.UserId,tempPass:params.TempPassword,region:params.region,clientId:clientId};
            gateway.getAccessToken('refresh_token',params.refreshToken,data,function(err,res){
                if(!err&&res)
                    return callback(null,{accessToken:data.token,region:data.region})
            })
        }else{
            return callback(null,{accessToken:params.alexaToken,region:params.region});
        }
    })
}
gateway.sendResponse=function(result,response) {
    return response.status(200).send(JSON.stringify(result));
}
gateway.alexaDisable=function(userid,toAlmond){
    genericModel.deleteWithConditions(table.USER_TEMP_PASSWORDS,{equal:{userID:userid},notNull:{refreshToken:true}},function(e,result){
        redisConn.localQuery('del','alexa_'+userid,function(e,o){
            if(!e&&toAlmond){
                redisStore.getAll(userid,function(macs){
                    for(var i in macs){
                        var data={},params={};
                        params.almondMAC=macs[i]
                        data.requestPayload=JSON.stringify({almondMAC:macs[i],CommandType:'alexaUnLinking'});
                        params.requestId=1062
                        params.alexa=true;
                        data.responded=true
                        sendToAlmond.send(data,params);
                    }
                })
            }
        })
    })
}

module.exports=gateway;
