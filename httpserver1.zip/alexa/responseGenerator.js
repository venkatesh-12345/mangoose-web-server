var mapper=require('./mapper.js')
var template = mapper.TEMPLATE;
var helper = require('./util/helper.js');
var errors = require("./errors");
var clone=require('./util/clone').clone
var gateway=require('./gateway');
var DEVICES = mapper.DISCOVERY;
var REPORTSTATE=mapper.RESPONSE
var executor = {};
var tracking=require('../tracking');
var responseFormat = {
    event: {
        header: {
            namespace: "Alexa",
            name: "ChangeReport",
            payloadVersion: "3"
        },
        endpoint: {
            endpointId: '',
            scope: {
                type: "BearerToken",
            }
        },
        payload: {
            change: {
                cause: {
                    type: "APP_INTERACTION"
                }
            }
        }
    }
};
var removeResponse={
    event: {
        header: {
            namespace: "Alexa.Discovery",
            name: "DeleteReport",
            payloadVersion: "3"
        },
        payload: {
            endpoints: [],
            scope: {
                type: "BearerToken",
            }
        }
    }
}

executor.removeHandler = function(result) {
    var response = clone(removeResponse);
    response.event.header.messageId = Math.random().toString(36).substring(2);
    response.event.payload.endpoints.push({endpointId: result.endpoint}) ;
    for(var i in result.userids){
        var res=clone(result);
        res.userid=result.userids[i];
        gateway.post(response,res)
    }
};

executor.changeReportHandler = function(result) {
    var response = clone(responseFormat);
    response.event.header.messageId = Math.random().toString(36).substring(2);
    response.event.endpoint.endpointId =  result.mac + ":" + result.deviceId ;
    var primaryTag=mapper.GENERICINDEXES[result.genericIndex].response;
    if(!result.data.hasOwnProperty(primaryTag))
        return;
    response.event.payload.change.properties = [make(primaryTag,result.data[primaryTag])];
    delete result.data[primaryTag];
    response.context = {properties: []};
    responseHandler.reportState(result.data,response.event,response);
    if(response.context.properties.length==0)
        delete response.context;
    for(var i in result.userids){
        var res=clone(result);
        res.userid=result.userids[i];
        gateway.post(response,res)
    }
};

executor.lockResponseHandler=function(data,almondResponse){
    try{
       var  payload=JSON.parse(almondResponse.payload);
    }catch(error){
        return console.log('Error ',error);
    }
    if((almondResponse.command==1064&&payload.Success=='true')||(almondResponse.command==1200)){
         executor.getResponse(data.event,data,data,'post');
        clearTimeout(data.setTimeout)
    }

}
executor.getResponse = function(event, data,res,gatewayFn) {
    var result=helper.GetFormat(event);
    result.result.event.previousValue=data.previousValue;
    tracking.alexa(event,200,data);
    if (!data.success&&data.reasonCode&&(data.reasonCode.message!='same value received'&&data.reasonCode!=33))
        generateError(result.result, data,event);
    else
        responseHandler[result.thisTemplate.payload?result.thisTemplate.payload:'reportState'](data,event,result.result,result.thisTemplate);
    gateway[gatewayFn](result.result,res);
}

var responseHandler = {};
responseHandler.acceptGrant=function(data,event,result,thisTemplate){
    result.event.header.namespace=event.header.namespace
    return result;
}
responseHandler.sceneResponse=function(data,event,result,thisTemplate){
    var header=result.event.header
    header.namespace=event.header.namespace;
    header.correlationToken=event.header.correlationToken;
    header.name=thisTemplate.responseTag
    result.event.payload={
        "cause" : {
            "type" : "VOICE_INTERACTION"
        },
        "timestamp" : new Date()
    }
    return result;
}
responseHandler.reportState = function(data,event,result,thisTemplate){
    if(thisTemplate && data.value && thisTemplate.response!='StateReport')
        data=data.value
    result.event.header.correlationToken=event.header.correlationToken;
    result.context={}
    var properties=[];
    for(var i in data){
        if(REPORTSTATE.hasOwnProperty(i)){

            if(data[i]==null)
                data[i]=thisTemplate.response
            properties.push(make(i,data[i]));
        }
    }
    result.context.properties=properties;
    return result;
}
var make =function(key,value){
    var response=REPORTSTATE[key];
    response.value=value;
    response.timeOfSample=new Date();
    return response
}


executor.deferredResponse=function(event,thisTemplate){
    var result=thisTemplate.deferredResponse;
    result.event.header.messageId=event.header.messageId;
    result.event.header.correlationToken=event.header.correlationToken
    return result;
}

function generateError(result, data,event) {
    result.event.header.name = 'ErrorResponse';
    result.event.payload.validRange=data.validRange
    if(data.reasonCode.type=='THERMOSTAT_IS_OFF')
       result.event.header.namespace='Alexa.ThermostatController'
    result.event.payload.message = data.message ? data.message : data.reasonCode.message;
    result.event.payload.type=data.reasonCode.type;
    return result;

}


module.exports=executor;
