var mapper={};

const DeferredResponse={
  "event": {
    "header": {
      "namespace": "Alexa",
      "name": "DeferredResponse",
      "messageId": "30d2cd1a-ce4f-4542-aa5e-04bd0a6492d5",
      "correlationToken": "dFMb0z+PgpgdDmluhJ1LddFvSqZ/jCc8ptlAKulUj90jSqg==",
      "payloadVersion": "3"
    },
    "payload": {
      "estimatedDeferralInSeconds": 20
    }
  }
}
mapper.RESPONSE={
    'targetTemp':{
        "namespace":"Alexa.ThermostatController",
        "name":"targetSetpoint",
        "value":{  
           "value":75.0,
           "scale":"FAHRENHEIT"
        },
        "timeOfSample":"2017-02-03T16:20:50.52Z",
        "uncertaintyInMilliseconds": 0
    },
    'mode':{  
        "namespace":"Alexa.ThermostatController",
        "name":"thermostatMode",
        "value":"HEAT",
        "timeOfSample":"2017-02-03T16:20:50.52Z",
        "uncertaintyInMilliseconds": 0
    },
    'brightness':{
        "namespace": "Alexa.BrightnessController",
        "name": "brightness",
        "value": 42,
        "timeOfSample": "2017-02-03T16:20:50.52Z",
        "uncertaintyInMilliseconds": 0
    },
    'power':{
      "namespace": "Alexa.PowerController",
      "name": "powerState",
      "value": "ON",
      "timeOfSample": "2017-02-03T16:20:50.52Z",
      "uncertaintyInMilliseconds": 0
    },
    'temperature':{
        "namespace":"Alexa.TemperatureSensor",
        "name":"temperature",
        "value":{  
           "value":75.0,
           "scale":"FAHRENHEIT"
        },
        "timeOfSample":"2017-02-03T16:20:50.52Z",
        "uncertaintyInMilliseconds": 0
    },
    'color':{
        "namespace": "Alexa.ColorController",
        "name": "color",
        "value": {
            "hue": 350.5,
            "saturation": 0.7138,
            "brightness": 0.6524
        },
        "timeOfSample": "2017-02-03T16:20:50.52Z",
        "uncertaintyInMilliseconds": 0
    },
    'colorTemperatureInKelvin':{
        "namespace":"Alexa.ColorTemperatureController",
        "name":"colorTemperatureInKelvin",
        "value":7500,
        "timeOfSample":"2017-02-03T16:20:50.52Z",
        "uncertaintyInMilliseconds": 0
    },
    'lockState':{
        "namespace": "Alexa.LockController",
        "name": "lockState",
        "value": 'LOCKED',
        "timeOfSample": "2017-02-03T16:20:50.52Z",
        "uncertaintyInMilliseconds": 0
    },
}



mapper.TEMPLATE={
    AcceptGrant:{
        response:'AcceptGrant.Response',
        payload:'acceptGrant'
    },
    Discover:{
        response:'Discover.Response',
        payload:'getDiscoveryResponse'

    },
    ReportState:{
        payload:'reportState',
        response:'StateReport',
        discoveryActions:'httpGet',
        supportedIndexes:[1,17,18,22,23,25,30,31,32,33,35,37,38,56,57,58,59,60,62],
        name:'StateReport'
    },
    Lock: {
        value: 'lock',
        response:'LOCKED',
        supportedIndexes:[22,23],
        get:'lock',
        responseTag:'lockState',
        deferredResponse:DeferredResponse
    },
    Unlock: {
        value: 'unlock',
        response:'UNLOCKED',
        supportedIndexes:[22,23],
        get:'lock',
        responseTag:'lockState',
        deferredResponse:DeferredResponse
    },
    Activate:{
        get:'activateScene',
        payload:'sceneResponse',
        responseTag:'ActivationStarted'
    },
    SetColor:{
        supportedIndexes:[1,18,30,31,32],
        get:'setColor',
        param: 'color',
        responseTag:'color'
    },
    DecreaseColorTemperature:{
        supportedIndexes:[1,18,30,31,32,33],
        get:'setColorTemperature',
        value:-1,
        responseTag:'colorTemperatureInKelvin',
    },
    IncreaseColorTemperature:{
        supportedIndexes:[1,18,30,31,32,33],
        get:'setColorTemperature',
        value:1,
        responseTag:'colorTemperatureInKelvin'
    },
    SetColorTemperature:{
        validators:['isNumber'],
        supportedIndexes:[1,18,30,31,32,33],
        get:'setColorTemperature',
        param: 'colorTemperatureInKelvin',
        responseTag:'colorTemperatureInKelvin'
    },
    TurnOn: {
        value: 'true',
        response:'ON',
        supportedIndexes:[1,17],
        get: 'indexValue',
        responseTag:'powerState'
    },
    TurnOff: {
        value: 'false',
        response:'OFF',
        supportedIndexes:[1,17],
        get: 'indexValue',
        responseTag:'powerState'
    },
    AdjustBrightness: {
        validators:['isNumber','isNonZero'],
        supportedIndexes:[1,17,18],
        get: 'adjustBrightness',
        param: 'brightnessDelta',
        responseTag:'brightness'
    },
    SetBrightness: {
        validators:['isNumber','rangeCheck'],
        get: 'setBrightness',
        supportedIndexes:[1,17,18],
        param: 'brightness',
        responseTag:'brightness'
    },
    SetTargetTemperature: {
        validators:['isNumber'],
        supportedIndexes:[35,37,38,56,57,58,59,60,62],
        get: 'setTemperature',
        param: 'targetSetpoint',
        responseTag:'targetSetpoint',
    },
    SetThermostatMode: {
        validators:[],
        supportedIndexes:[35,37,38,56,57,58,59,60,62],
        get:'setMode',
        param: 'thermostatMode',
        responseTag:'targetSetpoint',
    },
    AdjustTargetTemperature: {
        validators:['isNumber','isNonZero'],
        supportedIndexes:[35,37,38,56,57,58,59,60,62],
        get: 'adjustTemperature',
        param: 'targetSetpointDelta',
        responseTag:'targetSetpoint',
    },
}
mapper.GENERICINDEXES = {
    
    1:{
        tag:'onOff',
        reportState:'reportPower',
        secondaryIndexes:[18,30,31,32,33],
        response:'power'
    },
    17:{
        tag:'brightness',
        reportState:'reportPower',
        high:100,
        secondaryIndexes:[],
        response:'brightness'
    },
    18:{
        tag:'brightness',
        high:255,
        reportState:'reportPower',
        secondaryIndexes:[1,30,31,32,33],
        response:'brightness'
    },
    22:{
        tag:'lock',
        reportState:'reportLock',
        secondaryIndexes:[],
        response:'lockState',
        lock:'255',
        unlock:'0'
    },
    23:{
        tag:'lock',
        reportState:'reportLock',
        secondaryIndexes:[],
        response:'lockState',
        lock:'1',
        unlock:'2'
    },
    25:{
        tag:'tempSensor',
        reportState:'reportSensorTemperature',
    },
    30:{
        tag:'hue',
        hueHigh:65535,
        isPhilipsHue:true,
        secondaryIndexes:[1,18,32],
        response:'color'
    },
    31:{
        tag:'hue',
        hueHigh:255,
        tempHigh:10000,
        tempLow:1000,
        colorTemp:{
            2202:{ hue: 30, saturation: 0.83, brightness: 1 },
            2702:{ hue: 30, saturation: 0.67, brightness: 1 },
            4000:{ hue: 32, saturation: 0.37, brightness: 1 },
            5524:{ hue: 30, saturation: 0.13, brightness: 1 },
            7042:{ hue: 250, saturation: 0.05, brightness: 1 },
        },
        secondaryIndexes:[1,18,32,33],
        response:'color'
    },
    32:{
        tag:'saturation',
        secondaryIndexes:[1,18,30,31,33],
        response:'color'
    },
    33:{
        tag:'colorTemp',
        secondaryIndexes:[1,18,30,31,32],
        response:'colorTemperatureInKelvin'
    },
    35:{
        tag:'mode',
        modes:{
            OFF: 'Off',
            HEAT: 'Heat',
            COOL: 'Cool',
            AUTO: 'Auto',
        },
        minTemp: 51,
        maxTemp: 86,
        reportState:'reportTemp',
        secondaryIndexes:[37,38],
        response:'mode'
    },
    37:{
        tag:'heat',
        secondaryIndexes:[35,38],
        response:'targetTemp'
    },
    38:{
        tag:'cool',
        secondaryIndexes:[35,37],
        response:'targetTemp'
    },
    56:{
        tag:'mode',
        modes:{
            OFF: 'off',
            HEAT: 'heat',
            COOL: 'cool',
            AUTO: 'heat-cool',
            ECO:'eco',
        },
        minTemp: 50,
        maxTemp: 90,
        reportState:'reportTemp',
        secondaryIndexes:[57,58,59],
        response:'mode'
    },
    57:{
        tag:'target',
        secondaryIndexes:[56,58,59],
        response:'targetTemp'
    },
    58:{
        tag:'cool',
        secondaryIndexes:[56,57,59],
        response:'targetTemp'
    },
    59:{
        tag:'heat',
        secondaryIndexes:[56,57,58],
        response:'targetTemp'
    },
    60:{
        tag:'away'
    },
    62:{
        tag:'isOnline',
        reportState:'reportTemp',
    }
  
    
}
module.exports=mapper;
