var constructData = {};
var template=require('../mapper').TEMPLATE;
constructData.toCelsius = function(f){
    return (f - 32) * (5 / 9)
}


constructData.GetFormat=function(event){
    var alexaEvent = event.header.name;
    var result = {
        event: {
            header:{},
            payload:{}
        },
    };
    result.event.header = {
        namespace: event.header.namespace=='Alexa.Discovery'?event.header.namespace:'Alexa',
        messageId: event.header.messageId,
        payloadVersion: 3,
       
    };
    var header=result.event.header;
    if(event.endpoint)
        result.event.endpoint=event.endpoint;
    var thisTemplate = template[alexaEvent];
    header.name = thisTemplate.payload? thisTemplate.response:'Response';
    return {result:result,thisTemplate:thisTemplate};
}
module.exports=constructData;
