var errors = {};
 errors.types = {
    'INVALID_AUTHORIZATION_CREDENTIAL':{ type: 'INVALID_AUTHORIZATION_CREDENTIAL', message: 'Almond Unauthorized' },
    'DEVICEID_NOT_FOUND':{ type: 'INVALID_DIRECTIVE', message: " Device Id not found" },
    'DEVICEVALUES_NOT_PRESENT':{ type: 'INVALID_DIRECTIVE', message: " When deviceValues arent there " },
    'DEVICETYPE_NOT_FOUND':{ type: 'INVALID_DIRECTIVE', message: "when deviceType not found or when that action not supported by that deviceType" },
    'ALMOND_OFFLINE':{ type: 'BRIDGE_UNREACHABLE', message: "Almond Offline" },
    'INTERNAL_ERROR':{ type: 'INTERNAL_ERROR', message: " Internal error in http Server" },
    'TEMPERATURE_VALUE_OUT_OF_RANGE':{ type: 'TEMPERATURE_VALUE_OUT_OF_RANGE', message: " thermostat value out of range" },
    'NEST_IS_IN_AWAY_MODE':{ type: 'NOT_SUPPORTED_IN_CURRENT_MODE', message: " Nest modes if away, some..",currentDeviceMode:"AWAY" },
    'DEVICE_IS_OFFLINE':{ type: 'ENDPOINT_UNREACHABLE', message: ' Device is offline' },
    'THERMOSTAT_IS_OFF':{type: 'THERMOSTAT_IS_OFF', message:'thermostat is off'},
    'DEVICE_ACTION_NOT_PRESENT':{ type: 'INVALID_DIRECTIVE', message: 'template not found'} ,
    "INVALID_VALUE":{ type: "INVALID_VALUE", message: "Payload doesnt have required Property" },
    "ERROR_IN_ALEXA":{type:"INTERNAL_ERROR", message: "Error in Alexa" },
    "VALUE_OUT_OF_RANGE":{type:"VALUE_OUT_OF_RANGE",message:" brighness value out of Range"},
    "SAME_VALUE_RECEIVED":{type:'INVALID_VALUE',message:'same value received'},
    'UNSUPPORTED_THERMOSTAT_MODE':{type:'UNSUPPORTED_THERMOSTAT_MODE',message:'thermostat mode not supported'},
    'ALMOND_USERID_MISMATCH':{type:'INVALID_DIRECTIVE','message':'accessToken not belong to the Almond'},
    'ACCEPT_GRANT_FAILED':{type:'ACCEPT_GRANT_FAILED','message':'Failed to handle the AcceptGrant directive'},
    'SCENE_SAME_VALUE':{type:'INVALID_VALUE',message:'same value received'}
}
 module.exports = errors;

