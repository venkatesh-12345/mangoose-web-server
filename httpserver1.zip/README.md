# HTTP SERVER

Following Diagram shows flow of a request in http server:

![Unable To Load Image](/images/HttpServerFlowDiagram.png?raw=true "Http Server Flow")



USAGE:

for running in production: DATABASE=prod node getData.js

for running in local: node getData.js




Following commands are supported by Http Server: [list](https://prashanthrangaraju.github.io/dist/#!/Request)

[GetAllScenes](https://prashanthrangaraju.github.io/dist/#!/Request/get_GetAllScenes): Get list of scenes of the user.

[GetAllClients](https://prashanthrangaraju.github.io/dist/#!/Request/get_GetAllClients): Get list of clients of the user.

[GetAllDevices](https://prashanthrangaraju.github.io/dist/#!/Request/get_GetAllDevices): Get list of devices of the user.

[GetDeviceData](https://prashanthrangaraju.github.io/dist/#!/Request/post_GetDeviceData): Get the device data of a particular almond belonging to the user

[GetScenes](https://prashanthrangaraju.github.io/dist/#!/Request/post_GetScenes): Get Scenes of a particular almond belonging to the user

GetRules: Get Rules of a particular almond belonging to the user

[GetClients](https://prashanthrangaraju.github.io/dist/#!/Request/post_GetClients): Get Clients of a particular almond belonging to the user

[ChangeMode](https://prashanthrangaraju.github.io/dist/#!/Request/post_ChangeMode): Change mode of a particular almond

[ActivateScene](https://prashanthrangaraju.github.io/dist/#!/Request/post_ActivateScene): Activate a scene

[EnableGuestNetwork](https://prashanthrangaraju.github.io/dist/#!/Request/post_EnableGuestNetwork): Enable Guest network(both 2g and 5g) of an almond

[UpdateClient](https://prashanthrangaraju.github.io/dist/#!/Request/post_UpdateClient): Perform a list of client updates together

[UpdateDeviceIndex](https://prashanthrangaraju.github.io/dist/#!/Request/post_UpdateDeviceIndex): Perform a list of device_index updates together

[GetDeviceHistory](https://prashanthrangaraju.github.io/dist/#!/Request/post_GetDeviceHistory): Get history of a particular device

[GetClientHistory](https://prashanthrangaraju.github.io/dist/#!/Request/post_GetClientHistory): get history of a particular client

[GetAlmondList](https://prashanthrangaraju.github.io/dist/#!/Request/get_GetAlmondList): get list of almonds of a particular user

[SignUp](https://prashanthrangaraju.github.io/dist/#!/Request/post_SignUp): For signing up a new user

[ResendActivationLink](https://prashanthrangaraju.github.io/dist/#!/Request/post_ResendActivationLink): resends activation link

[Login](https://prashanthrangaraju.github.io/dist/#!/Request/post_Login): Logs in with credentials given

[Logout](https://prashanthrangaraju.github.io/dist/#!/Request/post_Logout): Logs out with credentials given

[ResetPassword](https://prashanthrangaraju.github.io/dist/#!/Request/post_ResetPassword): Resets password of a user by sending email to user.

[ConfirmResetPassword](https://prashanthrangaraju.github.io/dist/#!/Request/post_ConfirmResetPassword): Executes when user clicks the link sent for ResetPassword.

[AddAlmondEntry](https://prashanthrangaraju.github.io/dist/#!/Request/post_AddAlmondEntry): Affiliates a user with an almond. (this request has become Obselete)

[VerifyAccount](https://prashanthrangaraju.github.io/dist/#!/Request/post_VerifyAccount): Executes when user clicks the link send during SignUp or ResendActivationLink

[DeleteAccount](https://prashanthrangaraju.github.io/dist/#!/Request/post_DeleteAccount): Deletes a user account.
