
console.log("Hai");

var redisConn = require('../redis/redisConnector');
var util = require('util');
var PREFIX=require('./mapper.js');
var MAC_FORMAT = 'MAC:%s';
var DEVICE_FORMAT = MAC_FORMAT + ':%s';
var DeviceStore = {};
var redisServer = {};

function getDevValues(mac, values, alrows, callback) {
    var DeviceValues = {};
    var ids = Object.keys(values), multi = redisConn.multi();
    for (var i = 0; i < ids.length; i++)
        multi.hgetall(util.format(DEVICE_FORMAT, mac, ids[i]));
    multi.exec(function (error, replies) {
        if (error)
            return callback(error);
        for (var i = 0; i < ids.length; i++) {
            var deviceValuesFromRedis = {};
            if (replies[i])
                Object.keys(replies[i]).forEach(function (index) {
                    try {
                        deviceValuesFromRedis[index] = JSON.parse(replies[i][index]);
                    } catch (error) {
                        callback(error, null);
                    }
                });
            replies[i] = null;
            DeviceValues[ids[i]] = deviceValuesFromRedis;
        }
        callback(null, DeviceValues, alrows.status, alrows.version);
    });
}

redisServer.getDevice = function(payload, errorcallback,callback) {
    if(payload.event=='Activate')
        return callback(null,[])
    var deviceValuesFromRedis = {};
    redisConn.query(PREFIX.GETALL,util.format(DEVICE_FORMAT, payload.almondMAC, payload.deviceId), function(error, replies) {
        if (error || !replies ){
            if(errorcallback)
                errorcallback(error);
            return;
        }
        Object.keys(replies).every(function(index) {
            try {
                deviceValuesFromRedis[index] = JSON.parse(replies[index]);
                return true;
            }
            catch (error) {
                callback(error, null);
                return false;
            }
        });
        callback(null, deviceValuesFromRedis);
    });
};
redisServer.setCode = function(code, values, callback) {
    //0 :mac, 1:server, 2:userid, 3:ICID, 4:longSecret
    redisConn.query('setex', {'key':PREFIX.CODE + code, 'params':[2 * 60, values]}, function(e, o) {
        callback(e, o)
    })
}
redisServer.getCode=function(code,callback){
    redisConn.query(PREFIX.GET, PREFIX.CODE + code, function(e,o){
        if(!e && o){
        var keys = o.split(',')
         return   callback(e,{mac:keys[0], server:keys[1], userID: keys[2], ICID:keys[3], longSecret:keys[4],lastEmail:keys[5],isJson:keys[6]})
        }
        return callback(e,null)
    });
}

redisServer.get = function (payload, callback) {
    var mac = payload.AlmondMAC;
    redisConn.query(PREFIX.GETALL, PREFIX.ALMOND + mac, function (error, alrows) {
        if (error || !alrows)
            return callback(error);
        redisConn.query(PREFIX.GETALL, util.format(MAC_FORMAT, mac), function (error, values) {
            if (error)
                return callback(error);
            if (!values)
                return callback(null, {}, alrows.status, alrows.version);
            getDevValues(mac, values, alrows, callback);
        });
    });
};
redisServer.setQueue = function (server,userid,value, callback) {
    redisConn.query(PREFIX.SETKEYS, {'key':PREFIX.USER+userid,'params':[ PREFIX.QUEUE+server,value]}, function(e,o){
        callback(e,o)
    });
};
function isValid(payload) {
    return payload.Devices && Object.keys(payload.Devices).length > 0;
}

redisServer.UpdateIndex = function (payload, callback) {
    console.log("UPDATE INDEX HERE ");
    if (!isValid(payload))
        return callback("Missing Parameter", null);

    var mac = payload.AlmondMAC;
    var devices = payload.Devices;
    var multi = redisConn.multi();

    multi.hmset(util.format(MAC_FORMAT, mac), devices);

    Object.keys(devices).forEach(function (key) {
        var deviceId = util.format(DEVICE_FORMAT, mac, key), variables = {};
        var valueKeys = devices[key].DeviceValues;
        if (valueKeys && Object.keys(valueKeys).length > 0) {
            Object.keys(valueKeys).forEach(function (valueKey) {
                variables[valueKey] = JSON.stringify(valueKeys[valueKey]);
            });
            multi.hmset(deviceId, variables);
        }
    });
    multi.exec(callback);
};

redisServer.add = redisServer.UpdateIndex;

redisServer.addAll = function (payload, callback) {
    redisServer.removeAll(payload, function (e, o) {
        redisServer.UpdateIndex(payload, callback);
    });
};

redisServer.remove = function (payload, callback) {
    console.log("DeviceStore.REMOVE ", payload.AlmondMAC);
    if (!isValid(payload))
        return callback("Missing Parameter", null);

    var mac = payload.AlmondMAC;
    var deviceId = Object.keys(payload.Devices)[0];
    var multi = redisConn.multi();

    multi.hdel(util.format(MAC_FORMAT, mac), deviceId);
    multi.del(util.format(DEVICE_FORMAT, mac, deviceId));
    multi.exec(callback);
};

redisServer.removeAll = function (payload, callback) {

    var MAC = util.format(MAC_FORMAT, payload.AlmondMAC);

    redisConn.query(PREFIX.GETALL, MAC, function (error, values) {
        if (error || !values) {
            return callback(error);
        }

        var ids = Object.keys(values), multi = redisConn.multi();

        multi.del(MAC);
        for (var i = 0; i < ids.length; i++) {
            multi.del(util.format(DEVICE_FORMAT, payload.AlmondMAC, ids[i]));
        }

        multi.exec(callback);
    });
};

redisServer.clearMacs = function (callback) {
    redisConn.query('keys', util.format(MAC_FORMAT, '*'), function (error, keys) {
        if (error) {
            return callback(error);
        }

        var multi = redisConn.multi();
        keys.forEach(function (key) {
            multi.del(key);
        });

        multi.exec(callback);
    });
};




redisServer.getAlmond = function (AlmondMAC, callback) {
    redisConn.query(PREFIX.GETALL, PREFIX.ALMOND + AlmondMAC, callback);
};


redisServer.setAlmondValues = function (AlmondMAC, keys, callback) {
    //    console.log(" In Set almond value s............................... ",keys);
    redisConn.query(PREFIX.SETKEYS,{key:PREFIX.ALMOND + AlmondMAC,params: keys}, callback);
};
redisServer.setUserValues = function (UserID, keys, callback) {
    //    console.log(" In Set almond value s............................... ",keys);
    redisConn.query(PREFIX.SETKEYS,{key: PREFIX.USER + UserID, params:keys}, callback);
};

redisServer.getUsers = function (Users, callback) {
    var multi = redisConn.multi();
    for (var i in Users) {
        multi.hgetall(PREFIX.USER + Users[i]);
    }
    multi.exec(function (e, replies) {
        console.log('@redisServer:replies:', replies);
        if (!e && replies)
            return callback(null, replies);
    });
};
redisServer.setSecondaryUser=function(AlmondMAC,sUser,callback){
    redisConn.query(PREFIX.SETKEYS,{key:PREFIX.ALMOND+AlmondMAC,params:[PREFIX.PREFIX_SUSER+sUser,1]},function(e,res){
        if(!e)
            redisConn.query(PREFIX.SETKEYS,{key:PREFIX.USER+sUser,params:[PREFIX.PREFIX_SMAC+AlmondMAC,1]},function(e,replies){
            return    callback(e,replies)
            })
    })
}
redisServer.getFirmwareAndVersion = function(entities, callback) {
    var multi = redisConn.multi();
    for (var key in entities)
            multi.hmget(PREFIX.ALMOND + key, 'status', 'name', 'version','mode');
    multi.exec(callback);
}
redisServer.getAll =function (userID,callback){
    redisConn.query('hgetall',PREFIX.USER+userID,function(err,res){
        if(!err&&res){
            var keys = Object.keys(res)
            var MACS=[];
            for (var i in keys){
                var entry =  keys[i].split('_');
                if (keys[i].indexOf(PREFIX.PREFIX_PMAC)==0||keys[i].indexOf(PREFIX.PREFIX_SMAC)==0)
                    MACS.push(entry[1]);
            }
            return callback(MACS);
        }
    }) 
}
module.exports = redisServer;
