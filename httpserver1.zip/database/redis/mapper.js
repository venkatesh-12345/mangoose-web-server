var mapper={};

mapper.ALMOND = 'AL_';
mapper.USER = 'UID_';
mapper.CODE = 'CODE:';
mapper.GETALL = 'hgetall';
mapper.GET  ='get';
mapper.GETKEY = 'hmget';
mapper.REMOVE  ='del';
//mapper.REMOVEALL = 'removeAll';
mapper.SETKEYS  ='hmset';
mapper.INCREMENT = 'hincrby';
//mapper.GETLIST ='getList';
mapper.REMOVEKEY = 'hdel';
mapper.QUEUE = 'Q_';
mapper.SET  = 'set';

mapper.PREFIX_PMAC='PMAC_';
mapper.PREFIX_SMAC='SMAC_';
mapper.PREFIX_SUSER='SUSER_';

mapper.ICID='ICID_'
module.exports = mapper;

