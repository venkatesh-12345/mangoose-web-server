var redis = require('redis');
var handler = require('../model/connectionsCheck.js');
var config = require('../../config.js');
var tracker = require('../../tracking')

var remoteClient, localClient;
var allowed = {
    hgetall: get,
    hmget: set,
    hmset: set,
    get: get,
    scan:set,
    set:set,
    hincrby: set,
    expire:set,
    incr: get,
    setex: set,
    lrange:set,
    hdel:set,
    del:get
}
var redisConn = {};

redisConn.connect = function (port, host, callback) {
    var client = redis.createClient(port, host);

    client.on('connect', function (e, o) {
        callback(client);
    });
    client.on('error', function (err) {
          tracker.error('Main Redis-'+err.stack)
        createTimeout(client, host);
    });
    client.on('reconnect', function (err) {
        createTimeout(client, host);
    });
    client.on('close', function (err) {
        createTimeout(client, host);
    });
};

function createTimeout(client, host) {
    handler.handleEvent(host, client.connected, function () {
        return client.connected;
    });
}

function get(redisClient, query, key, callback) {
    redisClient[query](key, function(e, o) {
        executeCallback(e, o, callback)
    });
}

function set(redisClient, query, key, callback) {
    redisClient[query](key.key, key.params, function(e, o) {
        executeCallback(e, o, callback)
    });
}

redisConn.connect(config.redis.port, config.redis.host, function(client) {
    console.log('Redis master ✔');
    remoteClient = client;
});
redisConn.connect(config.localRedis.port, config.localRedis.host, function(client) {
    console.log('Redis local ✔');
    localClient = client;
});

function executeQuery(redisClient, query, key, callback) {
    if (!redisClient || !redisClient.connected || allowed.hasOwnProperty(query) === -1) {
        return;
    }
    allowed[query](redisClient, query, key, callback);
}

function executeCallback(e, o, callback) {
    if (!e) {
        try {
            callback(e, o);
        }
        catch (err) {
            console.log(err);
            tracker.error('Main Redis-' + err.stack + '---' )
        }
    }
    else
        tracker.error('Main Redis-' + e + '---' )
}


redisConn.query = function(query, params, callback) {
    executeQuery(remoteClient, query, params, callback)
};

redisConn.localQuery = function(query, params, callback) {
    executeQuery(localClient, query, params, callback)
}

redisConn.multi = function() {
    if (remoteClient.connected)
        return remoteClient.multi();
    else
        return null;
};
redisConn.localMulti=function(){
    if (localClient.connected)
        return localClient.multi();
    else
        return null;  
}


module.exports = redisConn;
