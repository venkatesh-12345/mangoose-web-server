var cassdb = {};
var fetchSize = 50;

var pgClient = require('../postgres/pgQueryNew');
var moment = require('moment');


String.prototype.replaceAll = function (search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

cassdb.getLogs = function (mapper, data, command, callback) {
    try {
        var type=command.split('/')[0];
        if (data.AlmondMAC == undefined || (type=='clients' && (data.client_mac == 'null' || data.client_mac == null || data.client_mac == undefined || data.client_mac == 'undefined')) || (type=='devices' && ( data.id == undefined||data.id=='undefined'||data.id==null||data.id=='null'))) {
            return callback(true, JSON.stringify({'error': 'true'}));
        }
        var time = (data.pageState !== undefined&&data.pageState!=null) ? moment.unix(data.pageState).format() : new Date().toISOString().replace(/T/, ' ').replace(/Z/, '')+"+00";
        var QueryReader = "select mac,id AS device_id,name AS device_name,type AS device_type,index_id,index_name,extract(epoch from time) AS pk, extract(epoch from time) AS time,value from recentactivity where mac = $1 AND id = $2 AND time < $3 ORDER BY time DESC LIMIT " + fetchSize;
        var params = [data.AlmondMAC, data.id, time];
        //addition for wifi_client
        if (type=='clients' ) {
            var client_mac_decimal = parseInt(data.client_mac.replaceAll(":", ""), 16);
            QueryReader = "select mac,id AS client_mac, client_id,name AS client_name,type AS client_type,extract(epoch from time) AS pk, extract(epoch from time) AS time,value from recentactivity where mac = $1 AND id = $2 AND time < $3 ORDER BY time DESC LIMIT " + fetchSize;
            params = [data.AlmondMAC, client_mac_decimal, time];
        }
        var logs_response = {};
        pgClient.query(QueryReader, params, function (err, res) {
            if (err) {
                console.log(err,'-----------in notificationFetcher');
                return callback(true, JSON.stringify({'error': 'true'}));
            }
            if (res && res.rows) {
                logs_response.pageState = (res.rows.length < fetchSize) ? null : res.rows[res.rows.length -1].time;
                logs_response.logs = res.rows;
            } else
                logs_response.logs = [];
            logs_response['requestId'] = data.requestId;
            return callback(null, logs_response);
        });
    } catch (error) {
        console.error(error,'--------in catch error');
        callback(true, JSON.stringify({'error': 'true'}));
    }
};

module.exports = cassdb;
