var RS = require("../redis/redisStore");
var tracker = require("../../tracking");
var config = require("../../config");
var hash = "$2b$10$XkVlKZ.S0Q9ZbcMRFYuPjuc056Iafa8VZOjv1HxbOmE.FF9fqEsie";
var genericModel=require('./genericModel');
var table=require('../../util/table');
var bcrypt=require('bcrypt');
var zenUserID= '522247109';//hq@zenthermostat.com
var EmailID='hq@zenthermostat.com'
//var zenUserID = "522285150"; //TestID//v@k.com
//var EmailID = "test@securifi.com";

function responseWriter(res, statusCode, body) {
	console.log("response", res.commandType);
	tracker.logResponse(
		Date.now() - res.TimeStamp,
		statusCode,
		res.commandType
	);
	if (body == undefined) {
		return res.sendStatus(statusCode);
	} else {
		return res.status(statusCode).send(body);
	}
}

var saltAndHash = function (pass, callback)
{
bcrypt.genSalt(10, function(err, salt) {
  bcrypt.hash(pass, salt, function(err, hash) {
    return callback(hash);
  });
});
}
function getName(mac){
	mac= mac.toString()
	return 'Zen-'+mac.substr(mac.length-4)
}
var get_random_string = function(len) {
	var chars = "23456789ABCDEFGHJKLMNPQRSTUVWXTZabcdefghkmnopqrstuvwxyz";
	var len = len ? len : 6;
	var string = "";
	for (var i = 0; i < len; i++) {
		var randomNumber = Math.floor(Math.random() * chars.length);
		string += chars.substring(randomNumber, randomNumber + 1);
	}
	return string;
};
function insertRedis(mac, lg, callback) {
	RS.setAlmondValues(
		mac,["_", lg, "userID", zenUserID, "key", mac, "zen", "true",'name',getName(mac)],function(e, res) {
			if (e) return callback(e);
			RS.setUserValues(zenUserID, ["PMAC_" + mac, "1"], function(e, res) {
				if (e) return callback(e);
				return callback(null, lg);
			});
		}
	);
}

function insertAllAlmondPlus(AlmondMAC,callback){
	genericModel.select(table.ALL_ALMOND_PLUS,{AlmondMAC:AlmondMAC},function(e,rows){
			if(e || !rows || rows.length==0)
				saltAndHash(get_random_string(32),function(hash){
					genericModel.insertUpdate(table.ALL_ALMOND_PLUS,{AlmondMAC:AlmondMAC,AlmondID:hash,FactoryDate:new Date()},callback);
				})
			else
				return callback(null,rows)
		})
}

function insertData(AlmondMAC, callback) {
	if (!AlmondMAC) return callback("no ID");
	insertAllAlmondPlus(AlmondMAC, function(e, Arows) {
		if (e) return callback(e);
		var LongSecret = get_random_string(64);
		genericModel.insertUpdate(table.ALMOND_USERS,{AlmondMAC:AlmondMAC,userID:zenUserID,ownership:'P',LongSecret:LongSecret,AffiliationTS:new Date()},function(e, rows) {
				if (e) return callback(e);
				insertRedis(AlmondMAC, LongSecret, callback);
			}
		);
	});
}
var processor = function(req, res) {
	if (!req || req.get("Authorization") != config.zenAuth)
		return responseWriter(res, 403);
	if (!req.body.AlmondMAC || !req.body.IsZEN) return responseWriter(res, 419);
	RS.getAlmond(req.body.AlmondMAC, function(e, rows) {
		if (e) return responseWriter(res, 419);
		if (!rows) {
			return insertData(req.body.AlmondMAC, function(e, lg) {
				if (e){
					tracker.error('ERROR AT ZEN PROCESSOR--'+e) 
					return responseWriter(res, 419);
				}
				else
				return responseWriter(
					res,
					200,
					JSON.stringify({
						AlmondMAC: req.body.AlmondMAC,
						LongSecret: lg,
						Email: EmailID,
						Firmware:"AL2-R096-ZEN"
					})
				);
			});
		}
		if (!rows.zen || rows.userID != zenUserID)
			return responseWriter(res, 420);
		return responseWriter(
			res,
			200,
			JSON.stringify({
				AlmondMAC: req.body.AlmondMAC,
				LongSecret: rows._,
				Email: EmailID,
				Firmware:"AL2-R096-ZEN"
			})
		);
	});
};
module.exports = processor;
