var CP = require('../sql/sqlQuery.js'),
    table = require('../../util/table');
var mappings = require('../../util/columns')
var tableColumns = mappings.columns;
var queries = mappings.queries;


//SELECT AND DELETE 


var SELECT_QUERY = ' from ?? where AlmondMAC=?';
var SELECT = 'Select ';

var REMOVE_QUERY = 'Delete from ?? where AlmondMAC=? and ??=?';
var REMOVE_ALL_QUERY = 'Delete from ?? where AlmondMAC=?';

var genericModel = {};

function getRowsAndColNames(mac, devices, mapper) {
    var values = [];
    var names;
    Object.keys(devices).forEach(function (key) {
        var row = devices[key];
        row = mapper.secondRoot ? row[mapper.secondRoot] : row;
        if (row) {
            var rowData = getRow(mapper, row, key, mac);
            values.push(rowData[0]);
            names = rowData[1];
        }
    });
    return [values, names];
}



function buildSelectQuery(mapper) {
    var fields = [mapper.keys[0]];

    for (var i = 1; i < mapper.keys.length; i++) {
        fields.push(mapper.keys[i]);
    }
    return SELECT + fields.join() + SELECT_QUERY;
}

genericModel.remove = function (mapper, payload, command, callback) {
    var root = payload[mapper.root];
    if (!root || Object.keys(root).length <= 0)
        return callback("Missing Root tag in JSON", null);
    CP.queryFunction(REMOVE_QUERY, [mapper.table, payload.AlmondMAC, mapper.ID, Object.keys(root)[0]], callback);
};

genericModel.removeAll = function (mapper, payload, command, callback) {
    CP.queryFunction(REMOVE_ALL_QUERY, [mapper.table, payload.AlmondMAC], callback);
};

genericModel.get = function (mapper, payload, command, callback) {
    CP.queryFunction(buildSelectQuery(mapper), [mapper.table, payload.AlmondMAC], callback);
};

genericModel.select = function (tableName, data, callback) {
    var table = tableColumns[tableName];
    var query= 'select * from ' + tableName + ' where ';
    var params = [];
    var selArr = [];
    Object.keys(data).forEach(function(key, index){
        if(table[key]){
            selArr.push(table[key]+" = ? ");
                    params.push(data[key]);
        }

    });
    query += selArr.join(' AND ');
    CP.queryFunction(query, params, callback);
};
genericModel.selectOR = function (tableName, data, callback) {
    var table = tableColumns[tableName];
    var query= 'select * from ' + tableName + ' where ';
    var params = [];
    var selArr = [];
    Object.keys(data).forEach(function(key, index){
        if(table[key]){
            selArr.push(table[key]+" = ? ");
                    params.push(data[key]);
        }

    });
    query += selArr.join(' OR ');
    CP.queryFunction(query, params, callback);
};

genericModel.insertUpdate = function (tableName, data, callback) {
    var table = tableColumns[tableName];
    var columns = [];
    var updateColumns =[];
    var params =[];
    Object.keys(data).forEach(function(key, index){
        if(table[key]){
            columns.push(table[key]);
            if(table.id.indexOf(table[key]) < 0)
                updateColumns.push(table[key] + '=values(' + table[key]+ ')');
            params.push(data[key]);
        }
    });
    var query = 'insert into  ' + tableName +" (" + columns.join() +") Values (?)"
     + " ON DUPLICATE KEY UPDATE " +updateColumns.join();
    CP.queryFunction(query, [params], callback);
};
genericModel.deleteWithConditions=function(tableName,data,callback){
    var table=tableColumns[tableName];
    var query='DELETE FROM ' + tableName + ' where ';
    var params=[];
    var selArr=[];
    if(data.equal)
        Object.keys(data.equal).forEach(function(key, index){
            if(table[key])
                selArr.push(table[key]+" = ? ");
            params.push(data.equal[key]);
        });
    if(data.notEqual)
        Object.keys(data.notEqual).forEach(function(key, index){
            if(table[key])
                selArr.push(table[key]+" != ? ");
            params.push(data.notEqual[key]);
        });
    if(data.null)
        Object.keys(data.null).forEach(function(key, index){
            if(table[key])
                selArr.push(table[key]+" is NULL ");
        });
    if(data.notNull)
        Object.keys(data.notNull).forEach(function(key, index){
            if(table[key])
                selArr.push(table[key]+" is not NULL ");
        });
    query+=selArr.join(' AND ');
    CP.queryFunction(query,params,callback);
}
genericModel.delete = function (tableName, data, callback) {
    var table = tableColumns[tableName];
    var query= 'DELETE FROM ' + tableName + ' where ';
    var params = [];
    var selArr = [];
    Object.keys(data).forEach(function(key, index){
        if(table[key])
            selArr.push(table[key]+" = ? ");
        params.push(data[key]);
    });
    query += selArr.join(' AND ');
    CP.queryFunction(query, params, callback);
};

genericModel.executeQuery = function(queryKey, params, callback) {
    CP.queryFunction(queries[queryKey], params, callback);
}
genericModel.execute = function(query, params, callback) {
    console.log(query,params)
    CP.queryFunction(query, params, callback);
}

module.exports = genericModel;
