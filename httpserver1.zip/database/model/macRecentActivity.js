var pgClient = require('../postgres/pgQueryNew');
var redisConn = require('../redis/redisConnector');
var moment = require('moment');
var util = require("util");
var types = require('pg').types;
var TIMESTAMPTZ_OID = 1184;
var TIMESTAMP_OID = 1114;
var FLOAT8 = 701;
var fs = require('fs');
var parseFn = function(val) {
    return val === null ? null : val;
}
types.setTypeParser(TIMESTAMPTZ_OID, parseFn);
types.setTypeParser(TIMESTAMP_OID, parseFn);
var float2str = function(val) {
    return val === null ? null : val.toString();
}
types.setTypeParser(FLOAT8, float2str);
var recentAct = {};
const MAX_RECORD_SIZE = 50;
console.log('----------- module loaded -----------');
const QUERY = 'SELECT mac,id,extract(epoch from time) AS time,index_id,client_id,index_name,name,owner,type,value FROM recentactivity WHERE mac = $1 ';
const between = "AND time between $%s and $%s ";
const lessThan = "AND time < $%s ";


function getQuery(req) {
    var data = {};
    var idSubQuery = " ";
    var noOfParams = 2;
    data.params = [req.AlmondMAC, req.time];

    if (req.id) {
        idSubQuery = "AND id = ANY($2::int[]) ";
        noOfParams = 3;
        var idArr = req.id.split(',');
        if (req.type === 'client') {
            idSubQuery = "AND id = ANY($2::bigint[]) ";
            var macDecimalArr = [];
            idArr.forEach(function(mac) {
                macDecimalArr.push(parseInt(mac.replace(/:/g, ""), 16));
            });
            idArr = macDecimalArr;
        }
        data.params = [req.AlmondMAC, idArr, req.time];
    }

    var clientSubQuery = req.type === 'client' ? "AND client_id IS NOT NULL " : req.type === 'all' ? "" : "AND client_id IS NULL ";
    var timeSubQuery = req.end ? util.format(between, noOfParams + 1, noOfParams) : util.format(lessThan, noOfParams);

    data.query = QUERY + clientSubQuery + idSubQuery + timeSubQuery + "ORDER BY time DESC LIMIT " + MAX_RECORD_SIZE;
    if (req.end)
        data.params.push(moment.unix(req.end).format())
    return data;
}

function getPageState(rows, req) {
    if (rows.length < MAX_RECORD_SIZE) {
        if (!req.end) return null;
        return req.end;
    }
    return rows[rows.length - 1].time; // make sure to get micro seconds here
}

recentAct.recentActivity = function(req, callback) {
    req.time = (req.pageState) ? moment.unix(req.pageState).format() : new Date().toISOString().replace(/T/, ' ').replace(/Z/, '') + "+00";
    var data = getQuery(req);
   // console.log('data***********',data)
    pgClient.query(data.query, data.params, function(err, res) {
        if (err || !res ) {
            console.log('------- recent activity query failed ------', err);
            return callback(true, { 'error': 'true' });
        }
       //   console.log('rews in recen**',res,err)
        req.pageState = getPageState(res.rows, req);
        if (!req.logs)
            req.logs = [];
        req.logs = req.logs.concat(res.rows);
        delete req.time;
        console.log('----------- page state --- ', req.pageState);
        return callback(null, req);
    });
};

function getLrange(AlmondMAC,request,res,callback){
    if (!redisConn )
        return recentAct.recentActivity(request,res)
    redisConn.localQuery('lrange',{key:AlmondMAC, params:[0, -1]}, function(e, resp) {
        if (e || resp.length==0) {
            fs.appendFile('ExpiredMacs.txt', AlmondMAC+'    '+new Date()+ '\n',function(e,fs){})
            return callback('no records')
        }
        redisConn.localQuery('expire',{key:AlmondMAC,params:5*24*60*60},function(err,ttl){})
        return callback(null,resp)
    })
}
function sortTime(client){
    var logs=client.logs;
    logs.sort(function(k,b){console.log(k,b); return b.time-k.time})
    client.logs=logs;
    client.pageState=client.logs[client.logs.length-1]['time'];
    return client;
}
function typeBuilder(type,data,tmpObjt){
    var builder={device:{0:'id',1:'time',2:'index_id',3:'index_name',4:'name',5:'type',6:'value'},client:{0:'id',1:'time',2:'index_id',3:'client_id',4:'name',5:'type',6:'value'}}
    if(type=='device')
        tmpObjt.client_id=null;
    for(var j=0;j<data.length;j++){
      // console.log( '***',builder[type][j],j)
       if(!builder[type] || !builder[type][j])
        continue;
        tmpObjt[builder[type][j]]=data[j];
    }
    return tmpObjt;
}
function responseBuilder(mac,type,resp){
    var responseObject={mac:mac,type:type};
    var logs=[];       
    for(var i=0;i<resp.length;i++){
        var data=resp[i].split('|||');
        if(data.length<=1)
            data=resp[i].split('|');
        if(data.length<=1)
            continue;
        var tmpObjt={mac:mac};
        if(type=='all'){
            tmpObjt =typeBuilder(data[data.length-1],data,tmpObjt)
        }
        else if(data[data.length-1]!=type){
            continue;
        }
        else
            tmpObjt=typeBuilder(type,data,tmpObjt)
        logs.push(tmpObjt);
    }
    responseObject.pageState=logs[0]?logs[logs.length-1]['time']:"null"
    responseObject.logs=logs;
  //  console.log('responseObject',responseObject)
    return responseObject;
}
function allDataResponse(request, callback,resp) {
   // console.log('res',resp,request.type)
    var responseData= responseBuilder(request.mac, request.type, resp);
    if(request.end)
        responseData.end=request.end
    return callback(null,responseData);
}
function getfromLocalRedis(request, callback) {
    if(request.type=="all"){
        var AlmondMAC = request.AlmondMAC + "_All";

        getLrange(AlmondMAC, request,callback, function(er, resp) {
            if(!er)
                return allDataResponse(request,callback,resp)
            var AlmondMAC = request.AlmondMAC + "_Device";
            return   getLrange(AlmondMAC,request,callback,function(er,resp){
                console.log('INSIDE getLrange',AlmondMAC,er,resp)
                if(er)
                    return  recentAct.recentActivity(request,callback)
                var  device=responseBuilder(request.AlmondMAC, 'device', resp)
                getLrange(request.AlmondMAC + "_Client",request,resp,function(er,clientData){
                    if(er)
                        return  recentAct.recentActivity(request,callback)
                    var client=responseBuilder(request.mac, 'client', clientData)
                    client.logs= client.logs.concat(device.logs);
                    client.type='all'
                    if(device.pageState<client.pageState)
                        client.pageState=device.pageState;
                    if(request.end)
                        client.end= request.end
                    return callback(null, sortTime(client)); 
                })
            })
        })
    }
    else{
    var AlmondMAC = request.AlmondMAC + "_Device";
        if (request.type == "client") AlmondMAC = request.AlmondMAC + "_Client";
        getLrange(AlmondMAC, request,callback, function(er, resp) {
            if(er)
                return  recentAct.recentActivity(request,callback)
            return callback(null, responseBuilder(request.AlmondMAC, request.type, resp))
        });
  }
}
recentAct.execute = function (mapper, request, command, callback) {
    try {
        if(request.mac)
            request.AlmondMAC=request.mac
        if (!request.AlmondMAC || !request.type)
            return callback( JSON.stringify({
                'success': false,
                'reason': "Insufficient Data"
            }));
        if(!request.id && !request.pageState)
          return      getfromLocalRedis(request,callback)
        recentAct.recentActivity(request,callback)
        
    } catch (error) {
        console.error(error);
          return responseWriter(res, 500, JSON.stringify({
                        'success': false,
                        'reason': "Internal Server Error"
                    }));
    }
};
module.exports = recentAct;