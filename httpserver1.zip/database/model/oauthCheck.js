var model = module.exports,
        util = require('util');
var bcrypt = require('bcrypt');
var errorCodesForClients = require('../../ErrorCodes/errorCodesForClients.js');
var redisConn = require('../redis/redisConnector');
var redisStore=require('../redis/redisStore')
var CP = require('../sql/sqlQuery.js');
var alexa = require('nconf').get('alexaGateway');
var genericModel = require('./genericModel');
var table = require('../../util/table');
var handler = require('../../almondEndpoint/responseHandler');
var crypto = require('crypto');
var fs = require('fs');
var M=require('../redis/mapper')
const AUTH_CODE_EXPIRY_TIME = 500; // seconds
//var db = redis.createClient

var keys = {
    token: 'tokens:%s',
    client: 'clients:%s',
    grantTypes: 'grant_types:%s',
    user: 'users:%s',
    authCode: 'accessCode:%s'
};

var buf = undefined;

//THIS FUNCTION WILL ADD THE CLIENTS etc so that you dont have to add them userself in the redis thing
// adds Amazon-echo etc

model.init = function (filePath) {
    buf = require(filePath);
};
function responseWriter(res, statusCode, body) {
    if (body == undefined) {
        return res.sendStatus(statusCode);
    } else {
        return res.status(statusCode).send(body);
    }
}
class maintenanceError extends Error {
  constructor(message) {
    super(message);
    this.name = this.constructor.name;
  }
}
model.getAccessToken = function (bearerToken, callback) {
    // convert to mySQL
    // also update lastusedtime
    var tempPass = bearerToken.split(':')[0];
    var userid = bearerToken.split(':')[1];
    const query = 'SELECT * FROM ?? WHERE UserId=? and TempPassword=?';
    const params = ['UserTempPasswords', userid, tempPass];
    var data = {userID: userid, tempPass: tempPass};
    genericModel.select('UserTempPasswords', data, function (err, rows) {
        if(err&&err=='MAINTENANCE')
            return callback( new maintenanceError(err) );
        if (rows.length === 0)
            return callback();
        data = {userID: userid, tempPass: tempPass, LastUsedTime: new Date()};
        genericModel.insertUpdate('UserTempPasswords', data, function (err, rows2) {
                callback(null, {
                    accessToken: bearerToken,
                    clientId: rows[0].ClientName,
                    expires: null,
                    userId: rows[0].UserId,
                });
        });
    });
};


model.getClient = function (clientId, clientSecret, callback) {
    if (buf[clientId] != undefined) {
        var client = buf[clientId];
        return callback(null, {
            clientId: client.clientId,
            clientSecret: client.clientSecret,
            redirectUri: client.redirectUri
        });
    } else
        return callback();
};

model.grantTypeAllowed = function (clientId, grantType, callback) {
    if (!buf[clientId] ) 
       return callback();
   var client = buf[clientId];
   var grantTypes = client.grantTypes;
   console.log("The granType is", grantType);
   return callback( null, grantTypes.indexOf(grantType) != -1);
};

model.generateToken = function (type, req, callback) {
    if (type == 'authorization_code')
        callback(undefined);
    else if (type == 'accessToken') {
        if (req.body.grant_type == "authorization_code") {
            model.getAuthCode(req.body.code,function(err,userdetails){
                if (err)
                    return callback(err);
                if (!userdetails){
                    console.log('AuthCode is not  present',new Date());
                    throw "token should be present";
                }
                    var userPass = crypto.randomBytes(64).toString('hex');
                    userdetails.accessToken=userPass + ":" + userdetails.user.id,
                    userdetails.userId=userdetails.user.id;
                    model.saveAccessToken(userdetails.accessToken, userdetails.clientId, null, "What!!", function (err) {
                        callback(null, userdetails);
                    });
            })
        } else if (req.body.grant_type == "password")
            callback(undefined);
        else
            callback(undefined);
    } else
        callback(undefined);
};

model.saveAccessToken = function (accessToken, clientId, expires, user, callback) {
    var userID = accessToken.split(":")[1];
    var tempPass = accessToken.split(":")[0];
    console.log("expiry: ", expires);
    var data = {userID: userID, tempPass: tempPass, ClientName: clientId, Expiry: expires, LastUsedTime: new Date(), FirstTimeUsed: new Date()};
    genericModel.insertUpdate('UserTempPasswords', data, function (err, rows2) {
            callback(undefined);
    });
};

model.getAuthCode = function (authCode, callback) {
     redisConn.localQuery('hgetall',util.format(keys.authCode, authCode), function (err, token) {
        if (err){
            console.log('Error in Redis in getAuthCode',err);
            return callback(err);
        }
        if (!token)
            return callback();
        callback(null, {
            accessToken: token.authCode,
            clientId: token.clientId,
            issueDate: Date.now(),
            expires: token.expires ? new Date(token.expires) : null,
            user: {id: token.userId, email: token.email}
        });
    });
};

model.saveAuthCode = function (authCode, clientId, expires, userDict, callback) {
    redisConn.localQuery('hmset',{key:util.format(keys.authCode, authCode), params:[
	'email', userDict.email,
        'authCode', authCode,
        'clientId', clientId,
        'expires', expires ? expires.toISOString() : null,
        'userId', userDict.userId
                //userPass: userDict.tempPass
    ]}, function (err, data) {
        if (err){
            console.log('Error in Redis in saveAuthCode',err);
            return  callback(err);
        }
	redisConn.localQuery('expire',{key:util.format(keys.authCode, authCode),params:AUTH_CODE_EXPIRY_TIME},function(e,o){});
        callback(err, data);
    });
};

var sendToAlmondforAlexa=function(userId){
    redisStore.getAll(userId,function(macs){
        for(var i in macs){
            var data={},params={};
            params.almondMAC=macs[i];
            data.requestPayload=JSON.stringify({almondMAC:macs[i],CommandType:'alexaLinking'});
            params.requestId=1062
            params.alexa=true;
            data.responded=true
            handler.send(data,params);
        }
    });
}

model.getAccessCode = function (req, res, next) {
    console.log("inside get access code function");
    var email = req.body.user;
    console.log('We have request for GetAccessCode');
    var pass = req.body.password;
    genericModel.select(table.USERS, {emailID: email}, function (err, rows) {
        if(err&&err=='MAINTENANCE')
            return responseWriter(res, 200, JSON.stringify({
                "error": "MAINTENANCE mode"
            }));
        if (rows.length == 0) {
            return responseWriter(res, 401, JSON.stringify({
                "error": "invalid credentials"
            }));
        } else {
            bcrypt.compare(pass, rows[0].Password, function (err, response) {
                if (response) {
                    req.userId = rows[0].UserID;
                    if(req.query.client_id==alexa.clientId||req.query.client_id==alexa.clientIdTest)
                        sendToAlmondforAlexa(req.userId)
                    next();
                } else {
                    return responseWriter(res, 401, JSON.stringify({
                        "error": "invalid credentials"
                    }));
                }
            });
        }
    });
};

model.isValidUserForAlmond = function (req, res, next) {
    var mac=[],userId;
    userId=req.user.id;
    var request=req.body;
    if (request && request.Hub && request.Hub.HubMAC) 
        mac=[request.Hub.HubMAC];
    else if (request&&request.Update){
        for (var index in request.Update) {
            if(mac.indexOf(request.Update[index].AlmondMAC) == -1)
                mac.push(request.Update[index].AlmondMAC);
        }
    }else if(request&&request.AlmondMAC)
        mac.push(request.AlmondMAC);
    else if (request&&request.mac)
        mac.push(request.mac);
    else if (request&&request.almondMAC)
        mac.push(request.almondMAC);
    if(mac.length==0){
        return res.status(556).send({'success': false,'reason': "Insufficient Data"});
    }
    var query = 'SELECT AlmondMAC, userID FROM ?? where AlmondMAC in (?) AND userID=? ' +
            'UNION ' +
            'SELECT AlmondMAC, userID FROM ?? where AlmondMAC in (?) AND userID=? ';
    var params = ['AlmondUsers', mac, userId, 'AlmondSecondaryUsers', mac, userId];
    CP.queryFunction(query, params, function (err, rows) {
        if (err || rows.length <= 0) {
            return res.status(556).send({'success': false,'reason': "Access Denied"});
        } else if (rows.length >= mac.length) {
            next()
        }
    });
   
};
