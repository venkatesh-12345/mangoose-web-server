var RC = {};

RC.Success = 0; //usage : ALC
RC["0"] = "Success";

RC.DatabaseError = 1; //usage : ALC
RC["1"] = "Database Error";

RC.ParamError = 2;
RC["2"] = "Parameter Missing";

RC.StripeNotResponding = 3;
RC["3"] = "Stripe Not Responding";

RC.UserDoesNotOwnAlmond = 4; //usage : MC
RC["4"] = "User Does Not Own Almond";

RC.AlmondAlreadySubscribed = 5; //usage : MC
RC["5"] = "Almond Is Already Subscribed";

RC.AlmondWasNotSubscribed = 6; //usage : MC
RC["6"] = "Almond Was Not Subscribed";

RC.NoSuchUserFound = 7; //usage : MC
RC["7"] = "No Such User Found";

RC.NoCardDetails = 8; //usage : MC
RC["8"] = "No Card Details";
RC.StripeError = 400; //usage : MC
RC["400"] = "Invalid Card Details";
RC.IncorrectCoupon = 9;
RC["9"] = "Incorrect Coupon code";
RC.InvalidCoupon = 10;
RC["10"] = "Coupon code not valid";
RC["11"] = "No such plan";
module.exports = RC;