//var stripe = require("stripe")("sk_test_nYKYagm3H3IrE5eg5heSxwu3");
var stripe = require("stripe");
var defaultStripe = "sk_live_IovebM3XRX0DnoBCC2CycLfe";
var updateEndPoints = require("../../broadcast/updateEndPointNew.js");
var RC = require("./stripeReasonCodes.js");
var decrypt = require("./dycrpt").decrypt;
var table = require("../../util/table");
var AQP = require("../../rabbitmq/producer.js");
var EM = require("../../email/emailDispatcher");
var genericModel = require("./genericModel");
var CP = require("../sql/sqlQuery");
var US = {};
var renewalTimes = {};
renewalTimes["Free"] = 1;
renewalTimes["Paid1M"] = 1;
renewalTimes["Paid3M"] = 3;
renewalTimes["Paid6M"] = 6;
renewalTimes["Paid1Y"] = 12;

var generateRenewalEpoch = function(currentEpoch, plan, duration) {
    var Days = duration ? parseInt(duration) * 30 : renewalTimes[plan] * 30;
    if (isNaN(Days)) return null;
    return new Date(currentEpoch + Days * 24 * 60 * 60 * 1000).getTime();
};

var verifycoupon = function(paramData, callback) {
    if (!paramData.hasOwnProperty("Coupon")) return callback();
    genericModel.select(table.COUPONS, { Code: paramData.Coupon }, function(err, rows) {
        if (err || rows.length == 0) return sendToQueue(paramData, "false", err ? RC.DatabaseError : RC.IncorrectCoupon);
        if (rows[0]["UsageLevel"] != "Multiple" && rows[0]["UsageCount"] > 1) return sendToQueue(paramData, "false", RC.InvalidCoupon);
        callback(rows[0]["Duration"]);
    });
};

var addSubscription = function(paramData, callback) {
    verifycoupon(paramData, function(duration) {
        paramData.RenewalEpoch = generateRenewalEpoch(paramData.EpochTime, paramData.PlanID, duration ? duration : paramData.Duration);
        paramData.Payment = paramData.VATCode ? "VATCode" : "Stripe";
        paramData.Plan = paramData.PlanID;
        if (paramData.PlanName) paramData.Plan += "-" + paramData.PlanName;
        paramData.AccountStatus=paramData.CancelledByUs=null;
        paramData.SubscriptionEpoch = paramData.EpochTime;
        if (duration) paramData.couponDuration = parseInt(duration) * 30;
        genericModel.insertUpdate(table.SUBSCRIPTIONS, paramData, callback);
    });
};
var stripeFunctions = {};
var createNewCustomer = function(emailID, request, stripeKey, callback) {
    var stripeNew = stripe(stripeKey);
    stripeNew.customers.create(
        {
            source: request.StripeToken,
            description: emailID,
	    email:emailID
        },
        function(err, customer) {
            if (err) return callback(err.statusCode, null);
            request.CustomerID = customer.id;
            stripeFunctions.createSubscription(request, stripeKey, callback);
        }
    );
};

stripeFunctions.createSubscription = function(request, stripeKey, callback) {
    var stripeNew = stripe(stripeKey);
    stripeNew.subscriptions.create(
        {
            customer: request.CustomerID,
            plan: request.PlanID
        },
        function(err, subscription) {
            if (err) return callback(err.statusCode, null);
            request.SubscriptionID = subscription.id;
            callback(null, request);
        }
    );
};

function getUserDetails(params, callback, fnCallback) {
    genericModel.select(table.USERS, params, function(err, rows) {
        if (err || !rows || rows.length == 0) return fnCallback(params, err ? RC.DatabaseError : RC.NoSuchUserFound);
        return callback(rows);
    });
}
stripeFunctions.createFirstSubscription = function(request, stripeKey, callback) {
    getUserDetails(
        { userID: request.UserID },
        function(rows) {
            createNewCustomer(rows[0].EmailID, request, stripeKey, callback);
        },
        finalCallback
    );
};

stripeFunctions.upgradeSubscription = function(request, stripeKey, callback) {
    var stripeNew = stripe(stripeKey);
    stripeNew.subscriptions.retrieve(request.SubscriptionID, function(e, subs) {
        if (!subs || e) return callback(e ? e.statusCode : RC.StripeNotResponding, null);
        var item_id = subs.items.data[0].id;
        stripeNew.subscriptions.update(
            request.SubscriptionID,
            {
                items: [
                    {
                        id: item_id,
                        plan: request.PlanID
                    }
                ],
                prorate: request.shiftAfter ? false : true,
                cancel_at_period_end:false
            },
            function(err, subscription) {
                if (err || !subscription) return callback("11", null);
                callback(null, request);
            }
        );
    });
};

function sendMail(req, add) {
    getUserDetails({ userID: req.UserID }, function(rows) {
        req.EmailID = rows[0].EmailID;
        EM.notifyMail(req, add, function() {});
    });
}
function getEmailandSendMail(request, add) {
    if (!request || !request.CMSCode) return;
    if (!request.CMSEmail)
        ///Only when VATCODE
        return getStripeKey(request.CMSCode, function(error, stripeKey, CMSEmail) {
            request.CMSEmail = CMSEmail;
            sendMail(request, add);
        });
    sendMail(request, add);
}

var checkIfStripeShouldBeCalled = function(request, name, callback) {
    if (!name) return callback(null);
    getStripeKey(request.CMSCode, function(error, stripeKey, CMSEmail) {
        if (error) return callback(error);
        if (CMSEmail) request.CMSEmail = CMSEmail;
        stripeFunctions[name](request, stripeKey, callback);
    });
};

US.getUpgradeData = function(request) {
    if (!request.PlanID || !request.AlmondMAC || !request.UserID) return sendToQueue(request, "false", RC.ParamError);
    getSubsData(
        request,
        false,
        function(req) {
            getUpgradeCostFromStripe(req.CustomerID, req.SubscriptionID, request, function(error, cost) {
                if (error) return sendToQueue(request, "false", "1");
                return sendToQueue(request, "true", { CommandType: request.CommandType, Amount: cost, PlanID: request.PlanID });
            });
        },
        finalCallback
    );
};

function getStripeKey(cmsCode, callback) {
    if (!cmsCode) return callback(null, defaultStripe);
    genericModel.select(table.CMS, { CMSCode: cmsCode }, function(err, o) {
        if (err) return callback(RC.DatabaseError);
        return callback(null, decrypt(o[0].StripeKey), o[0].Email);
    });
}

var getUpgradeCostFromStripe = function(CustomerID, SubscriptionID, request, callback) {
    getStripeKey(request.CMSCode, function(error, stripeKey, CMSEmail) {
        if (error) return callback(error);
        var proration_date = Math.floor(Date.now() / 1000);
        var stripeNew = stripe(stripeKey);
        if (CMSEmail) request.CMSEmail = CMSEmail;
        stripeNew.subscriptions.retrieve(SubscriptionID, function(err, subscription) {
            if (err || !subscription) return callback("true");
            var item_id = subscription.items.data[0].id;
            var items = [
                {
                    id: item_id,
                    plan: request.PlanID
                }
            ];
            stripeNew.invoices.retrieveUpcoming(
                CustomerID,
                SubscriptionID,
                {
                    subscription_items: items, // Switch to new plan
                    subscription_proration_date: proration_date
                },
                function(err, invoice) {
                    if (err) return callback(5, null);
                    var cost = 0;
                    for (var i = 0; i < invoice.lines.data.length; i++) {
                        var invoice_item = invoice.lines.data[i];
                        if (new Date(invoice_item.period.start * 1000).setHours(0, 0, 0, 0) == new Date(proration_date * 1000).setHours(0, 0, 0, 0)) cost += invoice_item.amount;
                    }
                    if (cost != 0) cost = cost / 100;
                    return callback(null, cost);
                }
            );
        });
    });
};

function deleteSubscriptionFromStripe(request, callback) {
    getStripeKey(request.CMSCode, function(error, stripeKey, CMSEmail) {
        if (error) return callback({ statusCode: 1 });
        var stripeNew = stripe(stripeKey);
        if (CMSEmail) request.CMSEmail = CMSEmail;
        if (request.CancelAtEnd) {
            callCancelAtEnd(request, stripeNew,true, callback);
            if (request.CancelledByUs) changeSubscriptionStatus([request.AlmondMAC], request.UserID, null, "CancelledByUs",'true');
        }
       else if (!request.hasManyEntries)
            stripeNew.customers.del(request.CustomerID, function(err) {
                callback(err, { CommandType: request.CommandType, AlmondMAC: request.AlmondMAC });
            });
        else
            stripeNew.subscriptions.del(request.SubscriptionID, function(err) {
                callback(err, { CommandType: request.CommandType, AlmondMAC: request.AlmondMAC });
            });
    });
}
function callCancelAtEnd(request, stripeNew, isCancel, callback) {
    stripeNew.subscriptions.update(request.SubscriptionID, { cancel_at_period_end: isCancel ? true : false }, function(err) {
        callback(err, { CommandType: request.CommandType, CancelAtEnd: request.CancelAtEnd, AlmondMAC: request.AlmondMAC });
    });
}

US.sendCancelToStripe = function(request, isCancel) {
    if (!request || !request.SubscriptionID) return;
    getStripeKey(request.CMSCode, (error, stripeKey) => {
        var stripeNew = stripe(stripeKey);
        callCancelAtEnd(request, stripeNew, isCancel, (er, res) => {
            if (er) return console.log("err in sendCancelToStripe", er);
            return console.log("done cancel", request);
        });
    });
};
function changeSubscriptionStatus(macs, users, acctnStatus, type,byUs) {
     var typeMap = {
        AccountStatus: { query: "update Subscriptions set AccountStatus=? where AlmondMAC in (?) and UserID =?", params: [acctnStatus, macs, users] },
        CancelledByUs: { query: "update Subscriptions set CancelledByUs=? where AlmondMAC in (?) and UserID =?", params: [byUs, macs, users] },
        Both: { query: "update Subscriptions set AccountStatus=? , CancelledByUs=? where AlmondMAC in (?) and UserID =?", params: [acctnStatus, byUs, macs, users] }
    };
    var queryParams = typeMap["Both"];
    if (type && typeMap[type]) queryParams = typeMap[type];
    CP.queryFunction(queryParams.query, queryParams.params, function(e, res) {
        console.log("changeSubsStatus", e, res);
    });
}

function checkStatus(subs, onlyStatus, subMacs, request) {
    if (subs.Status != "CancelAtEnd" &&  subs.Status != "Cancelled") {
        subMacs.push(subs.AlmondMAC);
        US.sendCancelToStripe(subs, request.CancelAtEnd);
    } else onlyStatus.push(subs.AlmondMAC);
}
US.reActivateSubs= (request)=>{
    if(!request || ! request.AlmondMAC || !request.CMSCode)
        return;
    CP.queryFunction('select * from ?? where AlmondMAC=? and CMSCode=? and Status="CancelAtEnd" and AccountStatus is null',['Subscriptions',request.AlmondMAC,request.CMSCode],(er,subRows)=>{
        if(er|| !subRows || subRows.length==0)
            return;
        var users=[];
        for(var i in subRows){
            if(subRows[i].CancelledByUs){
                  US.sendCancelToStripe(subRows[i], false);
                  changeSubscriptionStatus([request.AlmondMAC],subRows[i].UserID,null,'CancelledByUs','false')
                  updateEndPoints.broadcastToAlmondandMobile(subRows[i], 1012);
              }
        }
    })
}
US.doCancelAtEnd = (request) => {
    console.log('request om dpcance;AtEnd',request )
    if (!request || !request.Data || request.Data.length == 0) return;
    var almondData = request.Data;
    var keyPair = {};
    var macs = [],
        users;
    for (var i in almondData) {
        if (!almondData[i]) continue;
        keyPair[almondData[i].key] = almondData[i];
        macs.push(almondData[i].key);
        if (!users) users = almondData[i].userID;
    }
    if (Object.keys(keyPair).length == 0) return (2);
    var subMacs = [],
        onlyStatus = [];
    CP.queryFunction("select * from ?? where AlmondMAC in(?) and UserID =?", ["Subscriptions", macs, users], (er, subsData) => {
        if (er || !subsData || subsData.length == 0) return;
        for (var i in subsData)
            checkStatus(subsData[i], onlyStatus, subMacs, request);
        if (subMacs.length > 0) changeSubscriptionStatus(subMacs, users, request.AccountStatus,null,'true');
        if (onlyStatus.length > 0) changeSubscriptionStatus(onlyStatus, users, request.AccountStatus,"AccountStatus");
    });
};

US.UpdateCard = function(request) {
    if (!request.AlmondMAC || !request.UserID || !request.StripeToken) return sendToQueue(request, "false", RC.ParamError);
    getSubsData(
        request,
        false,
        function(response) {
            getStripeKey(request.CMSCode, function(error, stripeKey) {
                if (error) return sendToQueue(request, "false", "1");
                var stripeNew = stripe(stripeKey);
                stripeNew.customers.update(
                    response.CustomerID,
                    {
                        source: request.StripeToken
                    },
                    function(err) {
                        if (err) return sendToQueue(request, "false", err.statusCode, err.message);
                        return sendToQueue(request, "true", { CommandType: request.CommandType, AlmondMAC: request.AlmondMAC });
                    }
                );
            });
        },
        finalCallback
    );
};
US.DeleteSubscription = function(request) {
    console.log(" Delete Subscription**** ");
    if (!request.AlmondMAC || !request.UserID) {
        return sendToQueue(request, "false", RC.ParamError);
    }
    getSubsData(
        request,
        true,
        function() {
            if (request.SubscriptionID) {
                deleteSubscriptionFromStripe(request, function(error, response) {
		    request.Status="Cancelled";
                    if (error) return sendToQueue(request, "false", error.statusCode, error.message);
                    return sendToQueue(request, "true", response);
                });
            } else {
                US.broadCastDelete(request, function() {
                    return sendToQueue(request, "true", request);
                });
            }
        },
        finalCallback
    );
};
US.broadCastDelete = function(request, callback) {
    request.CommandType = "DeleteSubscription";
    request.Status="Cancelled";
    (request.PlanID = request.Plan ? request.Plan : request.PlanID), (request.VATCode = request.VATCode ? request.VATCode : request.Payment=='VATCode');
    console.log(" Broadcast Delete ****** ",JSON.stringify(request));
    updateEndPoints.broadcastToAlmondandMobile(request, 1012);
    getEmailandSendMail(request);
    request.MonitoringStatus = request.SubscriptionID = request.CustomerID = null;
    genericModel.insertUpdate(table["SUBSCRIPTIONS"], request, callback);
};

function sendToQueue(request, success, data, reason) {
    var res;
    if (success == "false") res = JSON.stringify({ CommandType: request.CommandType, Success: success, ReasonCode: data, Reason: reason ? reason : RC[data] });
    else {
        data.Success = success;
        res = JSON.stringify(data);
    }
    console.log(" SendToQueue ",res);
    AQP.sendToQueue(request.queue, JSON.stringify({ command: 1011, unicastID: request.unicastID, payload: res }));
}

function isFreeSub(planID) {
    var plans = ["Free", "FreeExpired", "Cancelled"];
    if (plans.indexOf(planID) > -1) return true;
    return false;
}
function isStatusActive(status) {
    if (!status || status == "Active") return true;
    return false;
}

function getSubsData(request, isDelete, resolve, reject) {
    genericModel.select(table.SUBSCRIPTIONS, { AlmondMAC: request.AlmondMAC, UserID: request.UserID }, function(err, rows) {
        if (err || !rows || rows.length == 0) return reject(request, "6");
        for (var i in rows) {
            if (rows[i].CustomerID || isDelete) {
                request.SubscriptionID = rows[i].SubscriptionID;
                request.CustomerID = rows[i].CustomerID;
                request.RenewalEpoch = rows[i].RenewalEpoch;
                if(rows[i].CMSCode)
                    request.CMSCode=rows[i].CMSCode;
                return resolve(request);
            }
        }
        return reject(request, "6");
    });
}
// Paid  ( saved card false +  Upgrade 'false '(Paid)) || Free || Upgrade
function addAndUpgrade(request, resolve, fnCallback) {
    genericModel.select(table.SUBSCRIPTIONS, { AlmondMAC: request.AlmondMAC }, function(err, rows) {
        //paid or free  - no error
        if (!rows || rows.length==0) {
            if (request.Upgrade) return fnCallback(request);
            return resolve(request);
        }
        if (request.PlanID == "Free") return fnCallback(request);
        for (var i in rows) {
            if (!request.Upgrade && !isFreeSub(rows[i].Plan) && isStatusActive(rows[i].Status) && request.UserID == rows[i].UserID) 
                return fnCallback(request);
            // Plan -> Upgrade true - success
            if (request.Upgrade && rows[i].UserID == request.UserID && rows[i].CustomerID) {
                request.SubscriptionID = rows[i].SubscriptionID;
                request.CustomerID = rows[i].CustomerID;
                request.RenewalEpoch = rows[i].RenewalEpoch;
                return resolve(request);
            }
        }
        return request.Upgrade ? fnCallback(request, "6") : resolve();
    });
}

// Upgrade 'false '(Paid) + Saved Card
function subscribeSaved(request, callback, fnCallback) {
    genericModel.selectOR(table.SUBSCRIPTIONS, { UserID: request.UserID, AlmondMAC: request.AlmondMAC }, function(err, rows) {
        // error paid
        for (var i in rows) {
            //need to add userid also in below check
            if (request.AlmondMAC == rows[i].AlmondMAC && !isFreeSub(rows[i].Plan) && isStatusActive(rows[i].Status)) return fnCallback(request, "8");
            if (rows[i].CustomerID && rows[i].UserID == request.UserID) {
                if (request.CMSCode) {
                    if (rows[i].CMSCode == request.CMSCode) {
                        request.CustomerID = rows[i].CustomerID;
                        return callback();
                    }
                } else if (!rows[i].CMSCode) {
                    request.CustomerID = rows[i].CustomerID;
                    return callback();
                }
            }
        }
        //customer id not there -error
        return fnCallback(request, "8");
    });
}
function hasParams(request) {
    if (!request || !request.PlanID || !request.AlmondMAC || !request.UserID) return false;
    if (request.PlanID != "Free" && !request.Upgrade && !request.savedCard && !request.StripeToken && !request.VATCode) return false;
    return true;
}

function getFunction(request, callback, fnCallback) {
    if (request.VATCode) return callback();
    if (request.savedCard && !request.Upgrade)
        //this for app support as IOS sends saved for upgrade
        return subscribeSaved(request, callback, fnCallback);
    return addAndUpgrade(request, callback, fnCallback);
}
var finalCallback = (req, error) => {
    return sendToQueue(req, "false", error ? error : RC.AlmondAlreadySubscribed);
};
US.Subscribe = function(request) {
    if (!hasParams(request)) return finalCallback(request, RC.ParamError);
    getFunction(
        request,
        function() {
            request.EpochTime = Date.now();
            var stripeFunctionName;
            if (request.PlanID == "Free" || request.VATCode) request.CustomerID = request.SubscriptionID = null;
            else if (!request.CustomerID) stripeFunctionName = "createFirstSubscription";
            else stripeFunctionName = request.Upgrade && request.SubscriptionID ? "upgradeSubscription" : "createSubscription";
            checkIfStripeShouldBeCalled(request, stripeFunctionName, function(error) {
                if (error) return finalCallback(request, error);
                request.Status = "Active";
                if (request.Services.indexOf("CMS") > -1) request.MonitoringStatus = "Pending";
                else request.MonitoringStatus = null;
                addSubscription(request, function() {
                    getEmailandSendMail(request, true);
                    updateEndPoints.broadcastToAlmondandMobile(request, 1012, "add");
                    sendToQueue(request, "true", request);
                });
            });
        },
        finalCallback
    );
};
module.exports = US;
