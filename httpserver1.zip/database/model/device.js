var genericModel = require('./genericModel');
var redisStore = require('../redis/redisStore');
var device = {};
var redisConn = require('../redis/redisConnector');

device.execute = function (mapper, payload, command, callback) {
    var genericModelExecutor = genericModel.get;
    var redisExecutor = redisStore.get;
    redisExecutor(payload, function (e, deviceValues, status, version) {
        genericModelExecutor(mapper, payload, command, function (error, rows) {
            return callback(error, rows, deviceValues, status, version);
        });
    });
};
device.executeQuery = function(mapper, payload, command, callback) {
    var params=[payload.userid,payload.userid];
    genericModel.executeQuery(command.split('/')[0], params, function(err, rows) {
        if (err)
            return callback(code.DATABASE_ERROR, null);
        if (rows.length == 0)
            return callback(null, rows);
        var almonds=getAlmonds(rows);
        if(command.indexOf('values')>0){
            var deviceValues={};
            var keys=Object.keys(almonds);
            var multi=redisConn.localMulti()
            for(var i in keys)
                multi.hmget("DV_" +keys[i], "device");
            multi.exec(function(err,res){
                if(err) callback(err,null);
                for(var i in res)
                    deviceValues[keys[i]]=res[i];
                return callback(err,rows,deviceValues);
            })
        }
        else
            redisStore.getFirmwareAndVersion(almonds, function(err, replies) {
                return callback(null, rows,replies);
            })
    })
};


function getAlmonds(rows) {
    var macs = {};
    for (var i in rows) {
        macs[rows[i].AlmondMAC] = 1;
    }
    return macs;
}

device.ivideon=function(body,callback){
    return redisStore.setUserValues(body.userId,['ivideon',body.refresh_token],function(err1,res1){
        if(!err1)
            callback(200,{success:true})
        else
            callback(401,{success:false})
    })
}

module.exports = device;
