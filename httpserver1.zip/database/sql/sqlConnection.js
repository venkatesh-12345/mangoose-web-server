var mysql = require('mysql');
var config = require('../../config').sql;

console.log('================ SQL config ============');
console.log(config);
console.log('========================================');

/*
CP.data.HOST= 'clouddevvpc.cefeqi1wqggz.us-east-1.rds.amazonaws.com';
CP.data.USER='securifi_dev';
CP.data.PASSWORD= 'clouddevdbnew';
CP.data.DATABASE= 'AlmondplusDB';
*/
/*
Actual:
host     : 'dbmastervpc.cefeqi1wqggz.us-east-1.rds.amazonaws.com' ,
user     :    'httpDBUser',//config.USER,
password : 'j>$`T~8k"Ammaadv'
*/

var pool = mysql.createPool({
    connectionLimit : 15,
    host     : config.host ,
    user     :  config.user,
    password: config.password,
    database : config.db,
    multipleStatements: true  
});

module.exports = pool;


