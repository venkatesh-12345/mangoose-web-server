var client = require('../sql/sqlConnection');
var tracker= require('../../tracking')
var CP = {};
var MAXREC = 5;
var config=require('../../config')
var fs=require('fs')
var mode=config.mode
setInterval(function(){
    fs.readFile("./configs/" + (process.env.DATABASE?process.env.DATABASE:"prod") + ".json",function(err,res){
        console.log(err,res)
        if(!err&&res){
            try{
                var res=JSON.parse(res.toString())
                var newMode=res.mode
                if(mode!=newMode){
                    console.log('Mode changed to ',newMode)
                    mode=newMode
                }
            }catch(err){
                console.log(err)
            }
        }
    })
},5*60*1000);

CP.queryFunction_Retry = function (recCount, query, params, callback) {
    if (recCount > MAXREC) {
        console.log('### Connection Pool Retry - Max limit reached ###');
        return callback('Connection Pool Retry - Max limit reached', null); // err
    }

    client.getConnection(function (err, conn) {
        if (err) {
            CP.queryFunction_Retry(++recCount, query, params, function (err, result) {
                callback(err, result);
            });
        } else {
            conn.query(query, params, function (err, result) {
                conn.release();
                if (err) {
                    if (err.fatal) {
                        CP.queryFunction_Retry(++recCount, query, params, function (err, result) {
                            callback(err, result);
                        });
                    } else {
                        //callback(err, null); err
                    }
                } else
                    callback(null, result);
            });
        }
    });
};

CP.queryFunction = function (query, params, callback) {
     if(mode=='MAINTENANCE')
        return callback("MAINTENANCE")
    var recCount = 0;
    client.getConnection(function (err, conn) {
        if (err) {
            CP.queryFunction_Retry(++recCount, query, params, function (err, result) {
                callback(err, result);
            });
        } else{
            conn.query(query, params, function (err, result) {
                conn.release();
                if (err) {
                    if (err.fatal) {
                        tracker.error(err+'---'+query+'---params--'+params)
                        CP.queryFunction_Retry(++recCount, query, params, function (err, result) {
                            callback(err, result);
                        });
                    } else {
                        tracker.error(err+'---'+query+'---params--'+params)
                        //callback(err, null);
                    }
                } else
                    callback(null, result);
            });
        }
    });
};

module.exports = CP;
