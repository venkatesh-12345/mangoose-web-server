var cassandra = require('cassandra-driver');
var cassConfig = require('../../config').cassandra;
console.log('____________________STARTING CLIENT WITH________________________');
console.log(cassConfig);
console.log('_____________________END CONFIG_______________________');

var consistencyVal = cassandra.types.consistencies.one;
var authProvider1 = new cassandra.auth.PlainTextAuthProvider(cassConfig['user'], cassConfig['password']);
const remoteNodes = 2;
const localDc = 'us-east';
var loggerPoint = new cassandra.Client({
    queryOptions: {
        consistency: consistencyVal
    },
    pooling: {
        coreConnectionsPerHost: {
            '0': 2,
            '1': 2
        }
    },
    authProvider: authProvider1,
    keyspace: cassConfig.keySpace,
    contactPoints: cassConfig['host'],
    policies: {
        loadBalancing: new cassandra.policies.loadBalancing.DCAwareRoundRobinPolicy(localDc, remoteNodes)
    }
});

module.exports = loggerPoint;