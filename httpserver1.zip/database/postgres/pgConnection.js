var pg = require("pg");
var pgConfig = require('../../config').postgres;

var conString = "pg://" + pgConfig.user + ":" + pgConfig.password + "@" + pgConfig.host + ":" + pgConfig.port + "/" + pgConfig.db;

var client = new pg.Client(conString);
client.connect();
console.log('postgres connected to : ', conString);
module.exports = client;
