/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//require("console-stamp")(console, {pattern: "dd/mm/yyyy HH:MM:ss.l"});
var fs = require('fs');
var pg = require("pg");
var pgConfig = require('../../config').postgres;
var tracker= require('../../tracking')

var conString = "pg://" + pgConfig.user + ":" + pgConfig.password + "@" + pgConfig.host + ":" + pgConfig.port + "/" + pgConfig.database;
console.log('postgres connection URL : ', conString);
var st = Date.now();
var pool = new pg.Pool({ connectionString: conString ,max:3});
console.log('--------- time to get new pool -------- : ', Date.now() - st);

var conn = {};

conn.query = function (query, params, callback) {
    var startTime = Date.now();
    pool.connect(function (err, client, done) {
        if (err) {
            console.log('=== connection error ====');
            fs.appendFile("pgPoolErr.log", new Date() + ' error fetching connection from pool --> ' + err + "\n", function(e, o) {});
               tracker.error(err)
            return callback(err, null);
        }
        //console.log('-------POOL: time to get connection -------- : ', Date.now()- startTime);
        //var sTime = Date.now();
        //console.log(query);
        client.query(query, params, function (err, result) {
            //console.log('-------POOL: time for query -------- : ', Date.now() - sTime);
            done();//call `done()` to release the client back to the pool
            if (err) {
                     tracker.error(err)
               // console.log('=== query error ====',query,params);
                fs.appendFile("pgPoolErr.log", new Date() + ' error in query --> ' + err + "\n", function(e, o) {});
                return callback(err, result);
            }
            //console.log(result.rows);
            callback(err, result)
            
        });
    });
    //console.log('----- 1 -----');
};


module.exports = conn;
