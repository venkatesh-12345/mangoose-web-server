var fs = require('fs');
var config =require('./config.js'); 
var data = {};
var request= require('request')
var publicIp = require('public-ip');
var gitData= fs.readFileSync('./.git/FETCH_HEAD').toString().split('branch');
data.DIR 			= __dirname;
data.GIT 			= gitData[1];
data.commit			=gitData[0].trim()		
data.Server			='HTTP_SERVER';
var LOG={};
var RESP_DATA='';
var dir = '/root/cloud_log/';
var filePath=__dirname+'/alexaStats.csv';
var EM=require('./email/emailDispatcher')

try{
publicIp.v4().then(function(IP){
	data.IP= IP;
})
}catch(e){}

function emitEvent(data,event){
	var options= {
		method:'POST',
		uri:config.STATUS_SERVER.URL+'/'+event,
		body:data,
		rejectUnauthorized: false,
		json:true
	}
	request(options,function(e,res){
	})
}
LOG.logResponse=function(time,sucess,command){
	//console.log('time and command',time,command)
	if(!time)
		time=1;
	RESP_DATA+=Date.now()+'	'+sucess+'	'+time+'	'+command+'\n';
	//console.log('RESP_DATA',RESP_DATA)
}

LOG.start=function(){
	var startData={}
	startData.TimeStamp=Date.now();
	startData.EventType='Restart'
	startData.IP= data.IP,
	startData.Server=data.Server;
	startData.Log=JSON.stringify(data)
	emitEvent(startData,'EventEmitter');
}
LOG.error=function(error){
	//console.log('err',error)
	var errorObj= {}
	errorObj.TimeStamp=Date.now();
	errorObj.IP=data.IP;
	errorObj.Server=data.Server;
	errorObj.EventType='Exception'
	errorObj.Log=JSON.stringify(JSON.stringify(error))
	emitEvent(errorObj,'EventEmitter');
}
LOG.alexa=function(event,statusCode,reason){
    fs.appendFile(filePath,new Date()+' , '+event.header.payloadVersion+' , '+event.header.name+' , '+statusCode+' , '+(reason.reasonCode?reason.reasonCode.type:"success")+'\n',function(e,o){console.log(e,o)});
    var sizeOfFile;
    if(fs.existsSync(filePath))
        sizeOfFile=fs.statSync(filePath).size;
    if(sizeOfFile>1000000){
	    EM.sendFile( filePath,'Alexa statics', function(e, o) {
	        fs.writeFile(filePath,'Time  , Version , Action , statsuCode , reason\n',function(e,o){})
	    });
    }
}
setInterval(function(){
	if(RESP_DATA.length>2000)
		fs.appendFile(dir+data.Server+'_ResponseTime.txt',RESP_DATA,function(e,res){
		RESP_DATA='';
		})
	
},60*60*1000)


module.exports=LOG;
