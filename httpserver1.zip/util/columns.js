/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var mappings = {};
var table=require('../util/table')
mappings.columns = {
    "Users": {
        id:["UserID"],
        userID: "UserID",
        emailID: "EmailID",
        password: "Password",
        newpass:"Password",
        token: "ValidationToken",
        Date: "Date",
        EmailValidated: "EmailValidated",
        UserAgent: "UserAgent",
        LastUpdateTime: "LastUpdateTime"
    },
    "AllAlmondPlus":{
        id:["AlmondMAC"],
        AlmondMAC:"AlmondMAC",
        AlmondID:"AlmondID",
        ProductType:"ProductType",
        FactoryDate:"FactoryDate",
        FactoryAdmin:"FactoryAdmin",
        FactoryUploadTS:"FactoryUploadTS",
        LastAffiliatedEmail:"LastAffiliatedEmail",
        LastFirmwareVersion:"LastFirmwareVersion",
        AffiliationDeleteTS:"AffiliationDeleteTS",
        AlmondName:"AlmondName",
        LongSecret:"LongSecret",
        FirmwareVersion:"FirmwareVersion",
        CloudID:"CloudID"
    },
    "SCSIDB.CMS":{
        id:['CMSCode'],
        CMSCode:"CMSCode"
    },
    "SCSIDB.CMSAffiliations":{
        id:['CMSCode',"AlmondMAC"],
        CMSCode:"CMSCode",
        AlmondMAC:"AlmondMAC",
        CustomerID:"CustomerID"  
    },
    UserTempPasswords: {
        id:["UserId", "TempPassword"],
        userID: "UserId",
        tempPass: "TempPassword",
        LastUsedTime: "LastUsedTime",
        refreshToken:"refreshToken",
        ClientName: "ClientName",
        FirstTimeUsed: "FirstTimeUsed",
        Expiry: "Expiry",
        region:"region"
    },
    "AlmondUsers": {
        id:["AlmondMAC"],
        AlmondMAC: "AlmondMAC",
        userID: "userID",
        ownership: "ownership",
        AlmondName: "AlmondName",
        LongSecret: "LongSecret",
        AffiliationTS: "AffiliationTS"

    },
    AlmondSecondaryUsers: {
        id: ["AlmondMAC"],
        AlmondMAC: "AlmondMAC",
        userID: "userID"
    },
    Coupons: {
        id:["Code"],
        Code: "Code",
        Distributer: "Distributer",
        Expiry: "Expiry",
        Duration: "Duration",
        UsageLevel: "UsageLevel",
        UsageCount: "UsageCount"
    },
    Subscriptions: {
        id:["AlmondMAC", "UserID"],
        UserID: "UserID",
        CustomerID: "CustomerID",
        SubscriptionID: "SubscriptionID",
        AlmondMAC: "AlmondMAC",
        Plan: "Plan",
        SubscriptionEpoch: "SubscriptionEpoch",
        RenewalEpoch: "RenewalEpoch",
        LastUpdateTime: "LastUpdateTime",
        Coupon: "Coupon",
        Status: "Status",
        MonitoringStatus:'MonitoringStatus',
        Services: "Services",
        Payment:'Payment',
        CMSCode:'CMSCode',
        AccountStatus:'AccountStatus',
        CancelledByUs:'CancelledByUs'
    },
    InvitedEmails: {
        EmailID: "EmailID"
    },
    DeviceData:{
       table:table.DEVICE_DATA,
        keys:["DeviceID","DeviceType","DeviceName","AssociationTimeStamp","FriendlyDeviceType","Location"],
        required:["ID","Type","Name","AssociationTimeStamp","FriendlyDeviceType","Location"]
	},
	SCENE:{
        table:table.SCENE,
	    keys:["SceneID","SceneName","IsActive","LastActivated","SceneEntryList"],	
        required:["ID","Name","Active","LastActiveEpoch","SceneEntryList"]
	},
	RULE:{
        table:table.RULE,
	    keys:["ID","Name","Valid","Triggers","Actions"],
        required:["ID","Name","Valid","Triggers","Results"]

	},
	WIFICLIENTS:{
        table:table.WIFICLIENTS,
	    keys:["ClientID","ClientDetails"],
        required:["ID","Clients"]
	},
        AlmondProperties2:{
            "AlmondMAC":"AlmondMAC"
        },
        FirmwareUpdate:{
            AlmondMAC:'AlmondMAC'
        },
        AlmondFWUpdate:{
            AlmondMAC:'AlmondMAC'
        },
        FirmwareUpdate:{
            id:['AlmondMAC'],
            AlmondMAC:'AlmondMAC',
            Status:'Status',
            Time:'Time'
        }
};

mappings.queries = {
'scenesAndDevices':'select T.AlmondMAC, D.DeviceID AS ID, D.DeviceName AS Name,"Device" as model , D.DeviceType, D.GenericDeviceType, D.ManufacturerName from (select AU.AlmondMAC from AlmondUsers AU where AU.UserID = ? union select ASU.AlmondMAC from AlmondSecondaryUsers ASU where ASU.UserID = ?) T INNER JOIN DeviceData D on T.AlmondMAC = D.AlmondMAC union select TS.AlmondMAC, concat(S.SceneID,":s") AS ID, S.SceneName AS Name, "Scene" as model, "Scene" as DeviceType  , null , null from (select AUS.AlmondMAC from AlmondUsers AUS where AUS.UserID = ? union select ASUS.AlmondMAC from AlmondSecondaryUsers ASUS where ASUS.UserID = ?) TS INNER JOIN Scene S on TS.AlmondMAC = S.AlmondMAC',    
'devices': 'select T.AlmondMAC, D.DeviceID, D.DeviceName, D.DeviceType, D.AssociationTimeStamp, D.ManufacturerName from (select AU.AlmondMAC from AlmondUsers AU where AU.UserID = ? union select ASU.AlmondMAC from AlmondSecondaryUsers ASU where ASU.UserID = ?) T LEFT JOIN DeviceData D on T.AlmondMAC = D.AlmondMAC',
    'scenes': 'select T.AlmondMAC, S.SceneID, S.SceneName, S.SceneEntryList from (select AU.AlmondMAC from AlmondUsers AU where AU.UserID = ? union select ASU.AlmondMAC from AlmondSecondaryUsers ASU where ASU.UserID = ?) T LEFT JOIN Scene S on T.AlmondMAC = S.AlmondMAC',
    'clients': 'select T.AlmondMAC, WC.ClientID, WC.ClientDetails from (select AU.AlmondMAC from AlmondUsers AU where AU.UserID = ? union select ASU.AlmondMAC from AlmondSecondaryUsers ASU where ASU.UserID = ?) T LEFT JOIN WifiClients WC on T.AlmondMAC = WC.AlmondMAC',
    'almonds': 'SELECT AU.AlmondName, AU.AlmondMAC, AU.FirmwareVersion from AlmondUsers AU where AU.userID=? UNION SELECT AU.AlmondName, AU.AlmondMAC, AU.FirmwareVersion from AlmondSecondaryUsers ASU, AlmondUsers AU where AU.AlmondMAC=ASU.AlmondMAC and ASU.userID=?'
}

module.exports = mappings;
