function define(name, value) {
    Object.defineProperty(exports, name, {
        value:      value,
        enumerable: true
    });
}

define("ALMOND_USERS", 'AlmondUsers');
define("ALMOND_SUSER", 'AlmondSecondaryUsers');
define("DEVICE_DATA", 'DeviceData');
define("WIFICLIENTS", 'WifiClients');
define("SCENE", 'Scene');
define("RULE", 'Rule');
define("SUBSCRIPTIONS", 'Subscriptions');
define("COUPONS", 'Coupons');
define("USERS", 'Users');
define("INVITEDEMAILS",'InvitedEmails');
define("CMS",'SCSIDB.CMS');
define("CMSAffiliations","SCSIDB.CMSAffiliations");
define("USER_TEMP_PASSWORDS", 'UserTempPasswords');
define("ALL_ALMOND_PLUS",'AllAlmondPlus')