var CP=require('./middleware/sql')
var xlsx = require('xlsx');
var INSERT_QUERY1='insert into ?? (';
var INSERT_QUERY2=') values ? ';
var INSERT_QUERY3='on duplicate key update '
var mapper=require('./mapper.js');
var columns=require('./util/columns')
var oldEmployeeTable=columns.oldEmployeeData
var config=require('./initConf').get();
var s3prefix=config.S3.prefix
var knox = require('knox').createClient(config.S3);
var fs=require('fs');
var constants=require('./util/constants.js');
var notification=require('./notification.js');
var queries=constants.queries;
constants=constants.constants

var createQuery = function(id, columns) {
    var query = INSERT_QUERY1 + columns.join(',') + INSERT_QUERY2;
    var query2 = []
    if (id) {
        query=query+INSERT_QUERY3
        for (var i in columns) {
            if (columns[i] != id) {
                var col = columns[i];
                query2.push(columns[i] + '= if(values(' + col + ')!="0" ,values(' + col + '),' + col + ') ');
            }
        }
    }
    query+=query2.join(',');
    return query;
}
var parseFn={}

var getColums=function(mapping,data){
    var result={col:[],excel:[]};
    var start=0;
    var prefix=''
    var col=mapping.keyColumn;
    do{
        try{
            var column=prefix+String.fromCharCode(65+start%26);
            if(data[column+col]||data[column+(col+1)]){
                var chinese=data[column+col]?data[column+col].v:data[column+(col+1)].v;
                if(mapping.keys && mapping.keys.hasOwnProperty(chinese) && result.col.indexOf(mapping.keys[chinese])<0){
                    result.col.push(mapping.keys[chinese]);
                    result.excel.push(column);
                }
                if(mapping.idNReq.hasOwnProperty(chinese)){
                    for(var i in mapping.idNReq[chinese])
                        result[mapping.idNReq[chinese][i]]=column;
                }
            }
            start++;
            if(start%26==0){
                prefix=String.fromCharCode(64+start/26)
            }
        }catch(err){
            return
        }

    }while(column!=mapping.endColumn)
    return result;
}

parseFn.parseLeaves=function(mapping,sheet,json){
    var count=mapping.start;
    var data=json.data;
    var result=getColums(mapping,sheet)
    if(json.count==0)
        json.col=[constants.LOGIN_ID];
    while(sheet[result.required1+count] || sheet[result.required2+count]){
        if(!sheet[result.required2+count]||isNaN(sheet[result.required1+count].v)){
            count++;
            continue;
        }
        var id=sheet[result.id+count].v;
        if(!data[id])
            data[id]={};
        var leaves=data[id];
        leaves[constants.LOGIN_ID]=id;
        var type=mapping.leaveTypes?mapping.leaveTypes[sheet[result.leaveColumn+count].v]:mapping.column;
        if(!leaves[type])
            leaves[type]=0;
        leaves[type]+=result.hrsColumn?sheet[result.hrsColumn+count].v:1;
        count++;
    }
    json.count++;
    json.col=json.col.concat(mapping.col);
    if(json.count==4){
        var query=createQuery(constants.LOGIN_ID,json.col);
        var params=[];
        for(var ids in json.data){
            var keys=json.col;
            var param=[];
            for(var i in keys){
                param.push(data[ids][keys[i]]?data[ids][keys[i]]:0)
            }
            params.push(param);
            
        }
        CP.query(query,[mapping.table,params],function(err,res){console.log(err,res)});
    }
}

parseFn.parseProfile=function(mapping,sheet,json){
    var count=mapping.start;
    var result=getColums(mapping,sheet)
    if(json.count==0)
        json.col=[constants.LOGIN_ID];
    var data=json.data;
    while(sheet[result.required1+count]||sheet[result.required2+count]){
        if(!sheet[result.required1+count]){
            count++;
            continue;
        }
        var param=[]
        var columns=result.excel;
        var id=sheet[result.id+count].v;
        for(var i in columns){
            var value=sheet[columns[i]+count]?sheet[columns[i]+count].v:0;
            param.push(value);
        }
        if(!data[id])
            data[id]=[id];

        if(data[id].length!=json.col.length){
            data[id]=data[id].concat(Array(json.col.length-data[id].length).fill(0));
        }
        data[id]=data[id].concat(param);
        count++;
    }
    json.count++;
    json.col=json.col.concat(result.col);
    if(json.count==3){
        var query=createQuery(constants.LOGIN_ID,json.col);
        var params=Object.keys(json.data).map(function(_) { return json.data[_]; })
        for(var i in params){
            if(params[i].length!=json.col.length)
                params[i]=params[i].concat(Array(json.col.length-params[i].length).fill(0))
        }
        CP.query(query,[mapping.table,params],function(err,res){console.log(err,res)});
    }    
}
function twoDigits(d) {
    d = parseInt(d)
    if (0 <= d && d < 10) return "0" + d.toString();
    return d.toString();
}
parseFn.addReview = function(mapping, sheet, json) {
    var count = mapping.start;
    var result = getColums(mapping, sheet)
    var data = json.data;
    var index=result.col.indexOf('time')
    var dateCol=result.excel[index]
    result.excel.splice(index,1)
    result.col.splice(index,1)
    while (sheet[result.required1 + count] || sheet[result.required2 + count]) {
        if (!sheet[result.required1 + count]||sheet[result.required2+count].v=='Google') {
            count++;
            continue;
        }
        json.col = ['reviewId']
        var columns = result.excel;
        var id ;
        var row=[id]
        for (var i in columns) {
            if (result.col[i] == 'createTime') {
                if (sheet[columns[i] + count].v && sheet[columns[i] + count].v != '-') {
                    var date1 = new Date(sheet[columns[i] + count].v)
                    date1 = date1.getFullYear() + '-' + twoDigits(date1.getMonth() + 1) + '-' + twoDigits(date1.getDate())
                    var date2
                    if(sheet[dateCol + count].v&&sheet[dateCol + count].v!='-'){
                        date2 = new Date(sheet[dateCol + count].v)
                        date2 = twoDigits(date2.getHours()) + ':' + twoDigits(date2.getMinutes()) + ':00'
                    }else
                        date2='00:00:00'
                    var dateformat = date1 + 'T' + date2
                    var value = new Date(new Date(dateformat))
                    id=value
                } else
                    var value = null
            } else
                var value = sheet[columns[i] + count] ? sheet[columns[i] + count].v : 0;
            row.push(value);
        }
        if(id!=null){
            row[0]=id
            data[id]=row
        }
        count++;
    }
    json.col = json.col.concat(result.col);
    var query = createQuery(null, json.col)+queries.REVIEW_UPLOAD;
    var params = Object.keys(json.data).map(function(_) {
        return json.data[_];
    })
    for (var i in params) {
        if (params[i].length != json.col.length)
            params[i] = params[i].concat(Array(json.col.length - params[i].length).fill(0))
    }
    CP.query(query, [mapping.table, params], function(err, res) {
        console.log(err, res)
    });
}
var save={}
var checkAndStoreOldData=function(err,rows,callback){
    if(err || !rows || rows.length>0)
    return callback();
    var columns=Object.keys(oldEmployeeTable).join()
    CP.query('insert into oldEmployeeData ('+columns+') select '+columns+' from employee ',[],function(err,res){
        callback();
    }) 
}
save.reviewData = function(data) {
    var obj = xlsx.readFile(constants.UPLOAD + data.filename,{cellDates:true}); // parses a file
    try {
        var json = {
            addReview: {
                data: {},
                col: []
            }
        };
        for (var sheet in obj.SheetNames) {
            var sheetName = obj.SheetNames[sheet]
            var mapping = mapper['reviewData']
            parseFn[mapping.parse](mapping, obj.Sheets[sheetName], json[mapping.parse]);
        }
        knox.putFile(constants.UPLOAD + data.filename, data.filename, {'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}, function(err, result) {
            if (200 == result.statusCode) {
                console.log(data.filename)
                fs.unlinkSync(constants.UPLOAD + data.filename);
                console.log('xlsx file uploadded to Amazon S3 bucket')
            } else {
                console.log('Failed to upload xlsx file to Amazon S3');
            }
        });
    } catch (err) {
        console.log("===err", err)
    }

}
save.xlsx=function(data){
    console.log(data)
    CP.query(queries.CHECK_DATE,[(new Date()).getUTCMonth()+1],function(err,rows){
        checkAndStoreOldData(err,rows,function(){
            var obj = xlsx.readFile(constants.UPLOAD + data.filename,{cellDates:true}); // parses a file
            try{
                var json={
                    parseProfile:{
                        count:0,
                        data:{},
                        col:[]
                    },
                    parseLeaves:{
                        count:0,
                        data:{},
                        col:[]
                    }
                };
                for(var sheet in obj.SheetNames){
                    if(mapper[sheet]){
                        var mapping=mapper[sheet]
                        parseFn[mapping.parse](mapping,obj.Sheets[sheet],json[mapping.parse]);
                    }
                }
                knox.putFile(constants.UPLOAD + data.filename, data.filename, {'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}, function(err, result) {
                    if (200 == result.statusCode) { 
                        console.log(data.filename)
                        fs.unlinkSync(constants.UPLOAD + data.filename);
                        console.log('xlsx file uploadded to Amazon S3 bucket') 
                    }
                    else { console.log('Failed to upload xlsx file to Amazon S3'); }
                });
            }catch(err){
                console.log(err)
            } 
        })
    })
}
save.uploadVideo=function(data){
    CP.query(queries.VIDEO_INSERT,[data.folder,data.subFolder,data.filename,data.name,data.id,new Date()],function(err,res){})
    data.extension=data.filename.substr(data.filename.lastIndexOf('.')+1)
    knox.putFile(constants.UPLOAD + data.filename, 'video/'+data.folder+'/'+data.filename, {'Content-Type': 'application/'+data.extension}, function(err, result) {
        if (result && 200 == result.statusCode) {
            fs.unlinkSync(constants.UPLOAD + data.filename);
            fs.unlinkSync(constants.PUBLIC + data.filename);
            console.log('bulletin board file uploadded to Amazon S3 bucket') 
        }
        else { console.log('bulletin board Failed to upload file to Amazon S3'); }
    });
}
save.addEvent=function(data){
    knox.putFile(constants.UPLOAD + data.filename, data.path, {'Content-Type': 'application/'+data.extension}, function(err, result) {
        if (result && 200 == result.statusCode) {
            fs.unlinkSync(constants.UPLOAD + data.filename);
            if(data.endTime)
                fs.unlinkSync(constants.PUBLIC + data.filename);
            console.log('bulletin board file uploadded to Amazon S3 bucket') 
        }
        else { console.log('bulletin board Failed to upload file to Amazon S3'); }
    });
}
save.png=function(data){
    var filename=data.filename;
    data.extension=filename.substr(filename.lastIndexOf('.')+1)
    if(data.sendNow){
        CP.query(queries.INSERT_SCHEDULE,[new Date(data.dateTime),null,data.recepients,data.title,data.onlyNotice?null:new Date(data.startTime),data.onlyNotice?null:new Date(data.endTime),'bulletin',null,null,null,data.dateList,data.repetition,data.extension,null,true,null,null,data.onlyNotice],function(err,res){
            if(!err&&res){
                data.mes_no=res.insertId;
                data.path=s3prefix+res.insertId+'.'+data.extension
                save.addEvent(data);
                if(!data.onlyNotice)
                    notification.send([data],function(err,res){
                        console.log(err,res);
                    })
            }
        })
    }else{
        data.recepients
        notification.sendToServer(data,function(err,res){
            if(!err&&res){
                data.mes_no=res.id;
                data.path=s3prefix+res.id+'.'+data.extension
                save.addEvent(data);
            }
        })
    }
    
}

save.clear=function(list,prefix){
    console.log(list[0])
    for(var i in list){
        if(list[i].path)
            list[i]=list[i].path;
        knox.deleteFile('/'+list[i],function(err,res){console.log(err)})
        CP.query(queries.DELETE_WITH_ATTACH,[prefix?prefix:s3prefix,list[i]],function(err,res){})
    }
}
module.exports=save;
