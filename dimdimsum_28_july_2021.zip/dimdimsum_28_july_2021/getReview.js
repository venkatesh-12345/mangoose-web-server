var request = require('request');
var CP=require('./middleware/sql')
var config = require('./initConf');

var constants=require('./util/constants.js');
var queries=constants.queries;
var fs=require('fs')
var constants=constants.constants
var token;
var url1='https://mybusiness.googleapis.com/v4/accounts/'+config.get('AccountId')+'/locations/';
var url2='/reviews?'
var opts = {};
var reviewIds
var getAll
function getRefreshedToken(flag){
    getAll=flag;
    reviewIds=[]
    console.log("Getting new access token....");
    var options = {
        'method': 'POST',
        'url': 'https://www.googleapis.com/oauth2/v4/token',
        'headers': {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        form: {
          'grant_type': 'refresh_token',
          'client_id': constants.CLIENT_ID,
          'client_secret': constants.CLIENT_SECRET,
          'refresh_token': config.get('RefreshToken')
        }
      };
      request(options, function (error, response) {
        if (error) throw new Error(error);
        console.log(response.body);
        var token = JSON.parse(response.body);
        if(token.hasOwnProperty('RefreshToken')){
            config.set('RefreshToken',token.refresh_token);
            config.save();
        }
        getreview(token.access_token);
      });    
}
var mapping={
    '點點心-新光桃園':'10969236476832654055',
    '點點心-巨城新竹':'10472211000461009297',
    '點點心-三井林口':'12693463266733258306',
    '點點心-微風信義':'11725328276125784663',
    '太興-ATT信義':'6933393147513656585',
    '點點心-新光台中':'14121226078337707001',
    '太興-微風北車':'15694932716952860567',
    '點點心-微風北車':'5244484540512033808',
    '點點心-新光台南':'1931973717791833134'
}

var hotel=Object.keys(mapping)
var getreview=function(token){
    var count=0;
    setTimeout(function(){
        console.log(reviewIds)
        // delete_query(reviewIds)
    },10*1000*60)
    serialExecution();
    function serialExecution(){
        if(hotel[count]){
            var key=hotel[count]
            opts.url = url1+mapping[key]+url2+'access_token='+token;
            requesting_model()
            function requesting_model(nextPageToken){
                if(nextPageToken)    
                    opts.url = opts.url+'&pageToken='+nextPageToken
                request.get(opts, function (error, response, body) {
                    if(!error && response){
                        var reviews = JSON.parse(body);
                         console.log(reviews.nextPageToken)
                        insert_query(reviews.reviews,key,function(){
                            var next_token=reviews.nextPageToken
                            console.log("=====",next_token)
                            var time=reviews.reviews[reviews.reviews.length-1]['createTime']
                            time=new Date(time)
                            if(next_token&&(getAll||(new Date()-time<24*60*60*1000))){
                                requesting_model(next_token)
                            }
                            else {
                                count++
                                serialExecution();
                            }
                        })
                    }
                })
            }
        }
    }
}

function insert_query(reviews,hotel,callback){
    var params=[]
    for(var i in reviews){
        reviewIds.push(reviews[i]['reviewId'].toString())
        params.push([reviews[i].reviewer['displayName'],reviews[i]['reviewId'],reviews[i].reviewer['profilePhotoUrl'],reviews[i]['starRating'],new Date(new Date(reviews[i]['createTime'])-0+8*60*60*1000),reviews[i]['comment'],reviews[i].reviewReply?reviews[i].reviewReply['comment']:null,hotel,'Google'])
    }
    var query_insert='insert into greview (name,reviewId,profilepic,rating,createTime,comment,reviewReply,hotel,source) values ? on duplicate key update rating=values(rating),createTime=values(createTime),comment=values(comment),reviewReply=values(reviewReply)';
    
    CP.query(query_insert,[params],function(err,res){
        console.log(err)
      callback()
     })
}


function delete_query(reviewsid){
    console.log(reviewsid.length)
    var delete_query='delete from greview where reviewId NOT IN (?)'
    CP.query(delete_query,[reviewsid],function(err,res){
        console.log(err,res)
        reviewsid=[]
    })
}
setInterval(function(){
    getRefreshedToken(true)
},15*60*1000)
getRefreshedToken(true)

module.exports=getRefreshedToken
