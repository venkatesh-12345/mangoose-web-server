var request = require("request");
var email=require('./emailDispatcher.js').sendFCMEmail
var config = require("./initConf").get();
var CP=require('./middleware/sql')
var s3prefix=config.S3.prefix
var constants=require('./util/constants.js')
var queries=constants.queries;
constants=constants.constants

var notification={}
var sendNotification=function(regIds,data,counts,retry,index){
    if(!index)
        index=0;
    if(!retry)
        retry=0;
    if(retry>5){
        email(JSON.stringify(data, null, 4),function(err,res){})
        console.log('Retry Exausted',data)
        return sendNotification(regIds,data,counts,0,index+1)
    }
    if(data.message&&data.message.length>400){
        data.message=data.message.substring(0,400)
        data.largeMsg=true
    }
    var msg = {
        registration_ids: [regIds[index]],
        notification: {
            badge: counts[regIds[index]],
            sound: constants.SOUND,
            title: data.title?data.title:constants.TITLE,
            body: data.message,
            type:data.type,
            largeMsg:data.largeMsg,
            mes_no:parseInt(data.mes_no)
        },
        data:{
            click_action: constants.CLICK_ACTION,
            badge: counts[regIds[index]],
            title: data.title?data.title:constants.TITLE,
            body: data.message,
            extension:data.extension,
            type:data.type,
            largeMsg:data.largeMsg,
            mes_no:data.mes_no
        },
        priority: 10
    }
    if(data.message){
        msg.data.senderTitle=data.senderTitle;
        msg.data.company=data.company;
        msg.data.name=data.name;
        msg.data.dateTime=new Date(data.dateTime);
        if(data.extension)
            msg.data.path="notification/"+data.mes_no+"."+data.extension
    }else if(data.endTime){
        msg.notification.body=constants.BULLETIN_BODY;
        msg.data.groups=data.recepients.join();
        if(data.jobs)
            msg.data.jobs=data.jobs.join();
        if(data.allIds)
            msg.data.ids=data.allIds.join();
        msg.data.dateTime=new Date(data.dateTime);
        msg.data.startTime=(new Date(data.dateTime)-0)*1000;
        msg.data.endTime=(new Date(data.endTime)-0)*1000;
        msg.data.path=s3prefix+data.mes_no+"."+data.extension
    }

    request.post({
        uri: config.Firebase,
        body: msg,
        json: true,
        headers: {
            Authorization: 'key=' + config.AuthKey
        }
    }, function(err, response, b) {
        console.log(err, b)
        if(b.failure>0)
            return handleUnsentNotification(regIds,err,data,b,retry,counts,index)
        CP.query(queries.UPDATE_COUNT,[counts[regIds[index]],regIds[index]],function(err,res){})
        if(index+1<regIds.length)
            sendNotification(regIds,data,counts,retry,index+1)
    })
}

var handleUnsentNotification=function(regIds,err,data,body,retry,counts,index){
    var disableList = [];
    var retryList = [];
    var response = body.results[0];
    var error=response.error
    if (error == "InvalidRegistration" || error == "NotRegistered" || error == "MissingRegistration") 
        disableList.push(regIds[index])
    else if(error == 'InternalServerError' || error == 'Unavailable')
        retryList.push(regIds[index])
    if(disableList.length>0)
        CP.query(queries.DISABLE_REGIDS,[disableList],function(err,res){});
    if (retryList.length > 0) {
        retry++;
        sendNotification(retryList,data,counts,retry,index)
    }else if(index+1<regIds.length)
        sendNotification(regIds,data,counts,retry,index+1)
};

notification.send=function(res,callback){
    var groups=[];
    for(var i in res){
        var group=res[i].recepients.split(',');
        for(var j in group)
            if(groups.indexOf(group[j])==-1)
                groups.push(group[j])
        res[i].recepients=group;
    }
    var checkGroup=constants.CHECK;
    var groupArray=[],inserts=[];
    for(var department in checkGroup){
        var data=checkGroup[department];
        var recepients=res[0].recepients.join(',');
        if(recepients.indexOf(department)>=0&&recepients.indexOf(data.group)<0&&groupArray.indexOf(data.loginId)<0){
            inserts.push([new Date(),res[0].title,res[0].message,data.loginId,'notification2',true])
            groupArray.push(data.loginId)
        }
    }
    if(groupArray.length>0){
        CP.query(queries.REG_ID_WITH_LOGINID,[groupArray],function(err,res1){
            if(!err&&res1&&res1.length>0){
                var counts={}
                var groupData={dateTime:new Date(),regids:[],title:res[0].title,message:res[0].message};
                for(var i in res1){
                    var regid=res1[i].regId
                    var data=groupData.regids;
                    if(data.indexOf(regid)<0){
                        if(!counts[regid])
                            counts[regid]=res1[i].count
                        counts[regid]++;
                        data.push(regid)
                    }
                }
                sendNotification(groupData.regids,groupData,counts)
            }
        })
        CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
    }
    var columns=[]
    var params=[]
    if(res[0].jobs){
            res[0].jobs=res[0].jobs.split(',');
            columns.push(' joblayer IN(?) ')
            params.push(res[0].jobs)
        }
        if(res[0].allIds){
            res[0].allIds=res[0].allIds.split(',');
            columns.push(' loginId IN(?) ')
            params.push(res[0].allIds)
        }
        if(res[0].recepients){
            columns.push(' layer IN(?) ')
            params.push(res[0].recepients)
        }
    CP.query(queries.GET_REG_ID_NEW+columns.join(' or ')+')',params,function(err,result){
        if(!err && result && result.length>0){
            var counts={}
            var empWithGroups={}
            for (var i in result){
                if(!counts[result[i].regId])
                    counts[result[i].regId]=result[i].count
                counts[result[i].regId]++;
                if(empWithGroups[result[i].layer])
                    empWithGroups[result[i].layer].push(result[i].regId)
                else
                    empWithGroups[result[i].layer]=[result[i].regId];
                if(empWithGroups[result[i].joblayer])
                    empWithGroups[result[i].joblayer].push(result[i].regId)
                else
                    empWithGroups[result[i].joblayer]=[result[i].regId];
                if(empWithGroups[result[i].loginId])
                    empWithGroups[result[i].loginId].push(result[i].regId)
                else
                    empWithGroups[result[i].loginId]=[result[i].regId];
            }
            for(var i in res){
                var regIds=[];
                for(var j in res[i].recepients)
                    if(empWithGroups[res[i].recepients[j]])
                        regIds=regIds.concat(empWithGroups[res[i].recepients[j]].filter((item) => regIds.indexOf(item) < 0))
                for(var j in res[i].jobs)
                    if(empWithGroups[res[i].jobs[j]])
                        regIds=regIds.concat(empWithGroups[res[i].jobs[j]].filter((item) => regIds.indexOf(item) < 0))
                for(var j in res[i].allIds)
                    if(empWithGroups[res[i].allIds[j]])
                        regIds=regIds.concat(empWithGroups[res[i].allIds[j]].filter((item) => regIds.indexOf(item) < 0))
                sendNotification(regIds,res[i],counts);

            }
            callback('SUCCESS',{success:true})
        }
        else if(!err)
            callback('SUCCESS',{success:true})
        else
            callback('NOT_FOUND',{success:false})
    })
}
notification.sendToServer=function(data,callback){
    request.post({
        uri: config.NotifUrl+config.NotifPort,
        body: data,
        json: true,
        headers: {
            'Content-Type':'application/json',
        }
    }, function(err, response, b) {
        callback(err,b)
    })
}
module.exports=notification;




