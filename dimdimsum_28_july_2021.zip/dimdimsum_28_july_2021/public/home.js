console.log(senderTitle)
var socket = io.connect();
var extensions={
    bulletin:['pdf','jpeg','jpg','png','gif'],
    notification:['pdf','jpeg','jpg','png','gif'],
    reviewData:['xlsx'],
    uploadVideo:['mp4','pdf']
}
var folderType=['點點心','太興','資運中心']
var subFolderType=['設備操作','ERP操作','餐點標準']
var accessName=['行事曆',' 餐點排行榜(單店)','營業收入(單店)','餐點排行榜(全部)','營業收入(全部)','成績單(全部)','推播通知發送權限訪']

var accessList,accessId,removeIndex,departmentAccess,isDepartmentAccess,allDepartments,allJobs,allIds;
var groups={'點點心股份有限公司':['人資部','行銷部','財務部','採購部','工程部','營運服務','營運廚務','資運倉儲組','資運生產組','董事總經理室','點點心微風信義店服務組','點點心微風信義店廚務組','點點心微風北車店(服務)','點點心微風北車店(廚務)','點點心微風北車店服務組','點點心微風北車店廚務組','點點心新光台中店(服務)','點點心新光台中店(廚務)','點點心新光台中店服務組','點點心新光台中店廚務組','點點心巨城新竹店服務組','點點心巨城新竹店廚務組','太興燒味微風北車店(廚務)','太興燒味微風北車店服務組','太興燒味微風北車店廚務組','太興燒味ATT信義店(服務)','太興燒味ATT信義店服務組','太興燒味ATT信義店廚務組']}
var notificationDisable=['營運服務','營運廚務']
setTimeout(function(){
    if(loginId!='151001'&&loginId!='160505')
        $('#onlyNotice').css('display','none')
},3000)
if(loginId=='15100111')
    groups={'testGroup':['testSubGroup']};
request('/getAccess', {employeeID: loginId}, function(resultData) {
    if(resultData){
        resultData=JSON.parse(resultData)
        if(resultData.fullAccess)
            var accessList=resultData.fullAccess.split(',')
    }
    console.log(accessList,resultData.fullAccess)
        if (loginId == '151001' || (accessList?accessList[28]=='1':false))
            $('#reviewButton').css('display', 'block')
})

var recepients=[],employeeList,recepientsJob=[],recepientsId=[];
function updateVideoList(){
    request('/video',{webui:true},function(resultData){
        if(resultData){
            resultData=JSON.parse(resultData);
            var list=resultData.result
            var string=''
            var count=0;
            $('#videoList').empty();
            string+='<div style="display:block"><div style="display:block; background-color: darkslateblue;color: white;"><div style="display:inline-block; padding-left:1%;">已上傳影片</div></div><div style="background-color: #DFEEFF;display:block"><div style="display:inline-block; width:15%;padding-left:1%;">上傳時間</div><div style="display:inline-block;width:15%;padding-left:1%;">上傳者工號</div><div style="display:inline-block;width:15%;padding-left:1%;">上傳者姓名</div><div style="display:inline-block;padding-left:1%;">影片名稱</div></div>';
            for(var i in list){
                var fileName=list[i].file
                count++
                string+='<div div style="display:block;'+ (count%2==0?' background-color: #DFEEFF;':'')+'"><div style="display:inline-block;width:15%;padding-left:1%;">'+(new Date(list[i].time)).toLocaleDateString()+'</div><div style="display:inline-block;width:15%;padding-left:1%;">'+list[i].id+'</div><div style="display:inline-block;width:15%;padding-left:1%;">'+list[i].uploader+'</div><div style="display:inline-block;padding-left:1%;">'+fileName.substr(0,fileName.lastIndexOf('.'))+'</div></div>'
            }
            string+='</div>';
            if(count>0)
                $('#videoList').append($(string).html())
        }
    })
}
updateVideoList();
for(var i in groups){
    for(var j in groups[i])
        recepients.push(i+'|'+groups[i][j])
}
function updateGroups(){
    var count=0;
    recepients=[]
    for(var i in groups){
        for(var j in groups[i]){
            if(loginId=='151001')
                $('#searchDepartment').append($('<option>', {value:groups[i][j], text:groups[i][j]}))
            recepients.push(i+'|'+groups[i][j])
        }
    }
    for(var i in groups){
        $('#groups').empty()
        var newItem=$('<div style="padding-top:20px;">'+i+'</div>')
        $("#groups").append(newItem.html());

        for (var j in groups[i]) {
            var newItem = $('<td><div id="'+groups[i][j]+'"" style="padding-top:10px;height:50px;"><div style="display: inline-block;padding-top: 10px;padding-left: 10px;padding-right:40px; width:40px;"><input id="selectgroup'+(count+parseInt(j))+'" type="checkbox" name="vehicle" value="Bike"></div><div style="display: inline-block;position:absolute;padding-top:10px;">'+groups[i][j]+'</div></div></td>');
            $("#groups").append(newItem.html());
        }
        count+=groups[i].length
    }
}
var dayOfWeek=['日','一','二','三','四','五','六']
var group,extension,jobgroup=[],idgroup=[];
var filename,date,title,screen,list,pop_up,dashBoard,endDate,bulletinList,notifiList,sendNow,fileId;
socket.emit('factory');
var groupCount=0;
socket.on('departments',function(departments){
    if(loginId!='15100111')
        groups['點點心股份有限公司']=departments;
    updateGroups();
})
var extensionMap={
    reviewData:'只能支援 .xlsx 格式',
    uploadVideo:'只能支援 .mp4,.pdf 格式',
}

function eventChange(){
    jQuery('#charCount').text($('#title').val().length+'/30');
}
function titleChange(){
    jQuery('#charNotiCount').text($('#AnnounceTitle').val().length+'/30');
}
function scheduled(){
    var filter;
    jQuery('#bulletinList').empty();
    if(screen=='已發佈公告訊息'){
        filter=true;
        jQuery('#scheduledHeading').text('已發佈公告');
    }else
        jQuery('#scheduledHeading').text('已排程公告');
    var json={};
    var dates=[];
    bulletinList=[];
    var count=0;
    if(list){
        while((!filter&&count<list.length) || (list[count] && list[count].startTime<new Date())){
            bulletinList.push(list[count]);
            var repeatDate
            if(list[count].startTime||list[count].endTime){
                list[count].startDate=new Date(list[count].startTime);
                list[count].endDate=new Date(list[count].endTime);
                list[count].startDate=list[count].startDate.toLocaleDateString().replace(/-/g, "/")+' '+list[count].startDate.toLocaleTimeString()
                list[count].endDate=list[count].endDate.toLocaleDateString().replace(/-/g, "/")+' '+list[count].endDate.toLocaleTimeString()
            }
            if(list[count].repetition){
                repeatDate=getRepeatString(list[count]);
            }
            $('#bulletinList').append($('<td><div  class="heading"><div style="display: inline-block;padding-top: 20px;padding-left: 10px;padding-right:30px; width:30px ; "><input id ="delete'+count+'" type="checkbox" name="bulletin" value="test"></div><div id="scheduledTitle" style="display: inline-block; padding-top:20px;padding-left: 60px; width:60% ; ">'+list[count].title+'</div><div id="scheduledDate" style="display: inline-block; padding-top:10px;padding-bottom:10px; padding-left: 20px;width:20% ;">'+(list[count].startDate&&list[count].endDate?('開始 '+list[count].startDate+'<br>結束 '+list[count].endDate):'')+'</div>'+(repeatDate?('<div  style="display: inline-block; padding-top:10px;padding-bottom:10px; padding-left: 20px;width:17% ;">'+repeatDate+'</div>'):'')+'</div></td>').html());
            repeatDate=null;
            count++;
        }
    }
    jQuery('#dashBoard').hide()
    jQuery('#bulletin-board').show();
    jQuery('#scheduled').show();
}
socket.on('list',function(result){
    list=result;
    scheduled();            

})
var updateEmpData=function(departments,jobs,ids){
    var count=0
    allDepartments=departments
    allJobs=jobs
    allIds=ids
    recepients=[]
    recepientsJob=[]
    recepientsId=[]
    $('#groups').empty()
    var newItem=$('<div style="padding-top:20px;">部門選擇</div>')
        $("#groups").append(newItem.html());
    for (var i in allDepartments) {
        recepients.push('點點心股份有限公司|'+allDepartments[i])
        var newItem = $('<td><div id="'+allDepartments[i]+'"" style="padding-top:10px;height:50px;"><div style="display: inline-block;padding-top: 10px;padding-left: 10px;padding-right:40px; width:40px;"><input id="selectgroup'+(count+parseInt(i))+'" type="checkbox" name="vehicle" value="Bike"></div><div style="display: inline-block;position:absolute;padding-top:10px;">'+allDepartments[i]+'</div></div></td>');
        $("#groups").append(newItem.html());
    }
    count=0
    var newItem=$('<div style="padding-top:20px;">職務選擇(Job)</div>')
        $("#empjobs").append(newItem.html());
    for (var i in allJobs) {
        recepientsJob.push(allJobs[i])
        var newItem = $('<td><div id="'+allJobs[i]+'"" style="padding-top:10px;height:50px;"><div style="display: inline-block;padding-top: 10px;padding-left: 10px;padding-right:40px; width:40px;"><input id="selectjob'+(count+parseInt(i))+'" type="checkbox" name="vehicle" value="Bike"></div><div style="display: inline-block;position:absolute;padding-top:10px;">'+allJobs[i]+'</div></div></td>');
        $("#empjobs").append(newItem.html());
    }
    count=0
    var newItem=$('<div style="padding-top:20px;">輸入工號(ID)</div>')
        $("#empids").append(newItem.html());
    for (var i in allIds) {
        recepientsId.push(allIds[i])
        var newItem = $('<td><div id="'+allIds[i]+'"" style="padding-top:10px;height:50px;"><div style="display: inline-block;padding-top: 10px;padding-left: 10px;padding-right:40px; width:40px;"><input id="selectid'+(count+parseInt(i))+'" type="checkbox" name="vehicle" value="Bike"></div><div style="display: inline-block;position:absolute;padding-top:10px;">'+allIds[i]+'</div></div></td>');
        $("#empids").append(newItem.html());
    }
}
function done2(type){
    if(type=='empjobs'){
        jobgroup=[]
        var currentgroup=jobgroup
        var recepientsType=recepientsJob
    }
    if(type=='empids'){
        idgroup=[]
        var currentgroup=idgroup
        var recepientsType=recepientsId
    }
    var current_div='#'+type
    var count=0
    var obj=$(current_div)[0];
    for(var i in obj.childNodes){
        if(obj.childNodes[i]&&obj.childNodes[i].childNodes&&obj.childNodes[i].childNodes[0]){
            if(obj.childNodes[i].childNodes[0].childNodes[0].checked){
                currentgroup.push(recepientsType[count])
            }
            count++;
        }
    }
    var string ='<tr><td style="width:160px;"></td><td>'+currentgroup.join(' , ')+'</td></tr>'
    if(type=='empjobs'){
        $('#notifijobs').text('');
        $('#notifijobs').append(string);
        $("#jobemp").modal("hide");
        $('#jobgroup-title').show();
        $('#jobgroupTitle').show();
    }
    else if(type=='empids'){
        $('#notifiids').text('');
        $('#notifiids').append(string);
        $("#idemp").modal("hide");
        $('#idgroup-title').show();
        $('#idgroupTitle').show();
    }
}
function done(type){
    group=[];
    var groupList={}
    var count=0
    var obj=$('#groups')[0];
    for(var i in obj.childNodes){
        if(obj.childNodes[i]&&obj.childNodes[i].childNodes&&obj.childNodes[i].childNodes[0]){
            if(obj.childNodes[i].childNodes[0].childNodes[0].checked){
                group.push(recepients[count])
            }
            count++;
        }
    }
    var string ='<tr><td style="width:160px;"></td><td>'+group.join(' , ')+'</td></tr>'
    
    if(dashBoard=='bulletin'){
        
        jQuery('#fileTitle').text(filename);
        jQuery('#dashBoard').hide();
        jQuery('#bulletinBoard').show();
        $('#title').val('')
        $('#groupList').text('');
        $('#groupList').append(string);
        $('#preview1').empty();
        repeatCheck('bulletin');
        $('#preview1').append("<iframe width='100%' height='200' src='preview/"+filename+"' frameborder='0'></iframe>")
        $("#group").modal("hide");
    }else if(dashBoard=='notification'){
        $('#notifiGroups').text('');
        $('#notifiGroups').append(string);
        $("#group").modal("hide");
        $('#group-title').show();
        $('#groupTitle').show();
    }
}
function checkDate(type){
    var repeat=$('#'+type+'Repeat').val();
    var noti_date=$('#'+type+'Date').val()+ ' '+$('#'+type+'Hour').val()+':'+ $('#'+type+'Min').val();
    var time=new Date();
    if(noti_date.length<14||new Date(noti_date)-time<0){
        if(type=='notify'||noti_date.length<14){
            $('#'+type+'Date').val(time.getFullYear()+ "-" + ("0"+(time.getMonth()+1)).slice(-2) + "-" +("0" + time.getDate()).slice(-2) )
            $('#'+type+'Hour').val(time.getHours())
            $('#'+type+'Min').val(time.getMinutes())
        }
        $('#'+type+'SendNow').text('現在傳送');
    }else 
        $('#'+type+'SendNow').text('已排程');
}
function clearList(){
    var clear=[];
    for(var i =0;i<bulletinList.length;i++){
        if($('#delete'+i)[0].checked)
            clear.push(bulletinList[i].path);
    }
    if(clear.length>0)
        socket.emit('clear',clear);
    setTimeout(function(){
        socket.emit('list');
    },3000)
}
function request(url,data,callback){
    $.ajax({
        type: 'POST',
        url: url,
        headers:{
            'Content-Type':'application/x-www-form-urlencoded',
            'token':token
        },
        data:data,
        datatype:'text',
        success: callback,
        error: function(XMLHttpRequest, textStatus, errorThrown){
            if(url!='/logout')
                logout();
            return ;
        }
    })
}
function clone(index){
    dashBoard='notification';
    hide();
    $('#AnnounceTitle').val(notifiList[index].title)
    $('#message').val('').val(notifiList[index].message);
    jQuery('#logo').hide();
    jQuery('#notification').show();
    $('#notifiyFile').text('');
    jQuery('#scheduleNotifi').show();
    repeatCheck('notify');
    checkDate('notify');
}
function clearNotifi(){
    var clear=[];
    for(var i =0;i<notifiList.length;i++){
        if($('#deleteNotifi'+i)[0].checked)
            clear.push(notifiList[i].mes_no);
    }
    if(clear.length>0){
        request('/notification/delete',{mes_no:clear},function(resultData){
            notifiList=undefined;
            getNotification();
        })
    }
}
function addCustom(type){
    var dates=$('#'+type+'CustomDates').text();
    var lastdate
    if(dates){
        lastdate=dates.split(',')
        if(lastdate.length==5)
            return setGenericPopUp('時間錯誤','只能添加5個日期')
        lastdate=lastdate[lastdate.length-1];
    }
    var newDate=$('#'+type+'Date').val()+ ' '+$('#'+type+'Hour').val()+':'+ $('#'+type+'Min').val();
    if(new Date(newDate)<new Date()||new Date(newDate)<=new Date(lastdate)){
        return setGenericPopUp('時間錯誤','請選擇未來的日期和時間')
    }
    dates=dates+(dates?' , ':'')+$('#'+type+'Date').val()+ ' '+$('#'+type+'Hour').val()+':'+ $('#'+type+'Min').val();
    $('#'+type+'Min').val((parseInt($('#'+type+'Min').val())+61)%60)
    $('#'+type+'CustomDates').text(dates);
    checkDate(type);
}
function repeatCheck(type){
    switch($('#'+type+'Repeat').val()){
        case 'Does_not_Repeat': if(type=='notify'){
                                    $('#'+type+'DateStr').show();
                                    $('#'+type+'DateDiv').show();
                                    $('#'+type+'Hour').show();
                                    $('#'+type+'Min').show();
                                    $('#'+type+'Week').hide();
                                    $('#'+type+'Month').hide();
                                    $('#'+type+'Custom').hide();
                                    $('#'+type+'CustomDates').hide();
                                }else{
                                    $('#'+type+'DateStr').hide();
                                    $('#'+type+'DateDiv').hide();
                                    $('#'+type+'Hour').hide();
                                    $('#'+type+'Month').hide();
                                    $('#'+type+'Min').hide();
                                    $('#'+type+'Week').hide();
                                    $('#'+type+'Custom').hide();
                                    $('#'+type+'CustomDates').hide();
                                }
                                break;
        case 'daily':           $('#'+type+'SendNow').text('已排程');
                                $('#'+type+'DateStr').hide();
                                $('#'+type+'Hour').show();
                                $('#'+type+'Min').show();
                                $('#'+type+'DateDiv').hide();
                                $('#'+type+'Week').hide();
                                $('#'+type+'Month').hide();
                                $('#'+type+'Custom').hide();
                                $('#'+type+'CustomDates').hide();
                                break;
        case 'weekly-':         $('#'+type+'SendNow').text('已排程');
                                $('#'+type+'DateStr').hide();
                                $('#'+type+'DateDiv').hide();
                                $('#'+type+'Hour').show();
                                $('#'+type+'Min').show();
                                $('#'+type+'Week').show();
                                $('#'+type+'Month').hide();
                                $('#'+type+'Custom').hide();
                                $('#'+type+'CustomDates').hide();
                                break;
        case 'monthly-':         $('#'+type+'SendNow').text('已排程');
                                $('#'+type+'DateStr').hide();
                                $('#'+type+'DateDiv').hide();
                                $('#'+type+'Hour').show();
                                $('#'+type+'Min').show();
                                $('#'+type+'Week').hide();
                                $('#'+type+'Month').show();
                                $('#'+type+'Custom').hide();
                                $('#'+type+'CustomDates').hide();
                                break;
        case 'custom':          $('#'+type+'SendNow').text('已排程');
                                $('#'+type+'DateStr').show();
                                $('#'+type+'DateDiv').show();
                                $('#'+type+'Hour').show();
                                $('#'+type+'Min').show();
                                $('#'+type+'Week').hide();
                                $('#'+type+'Month').hide();
                                $('#'+type+'Custom').show();
                                $('#'+type+'CustomDates').show();
                                $('#'+type+'CustomDates').text('');
                                break;
    }
    checkDate(type);
}
function setGenericPopUp(heading,detail,height){
    pop_up='generic';
    $('#heading').text(heading)
    $('#detail').text(detail);
    if(height)
        $('#height').css('height',height)
    $('#generic').modal('show');
}
function getRepeatString(data){
    var date;
    var repetition=data.repetition
    if(repetition=='daily'){
        date='每天 '+new Date(data.dateTime).toLocaleTimeString()
    }else if(repetition=='custom'){
        var dates=data.dateList.split(',');
        var customDates=[];
        for(var j in dates){
            var customDate=new Date(parseInt(dates[j]));
            customDates.push(customDate.toLocaleDateString().replace(/-/g, "/")+' '+customDate.toLocaleTimeString())
        }
        date=customDates.join('  ')
    }else if(repetition.indexOf('weekly-')>=0){
        date='每週 '+dayOfWeek[repetition[repetition.length-1]]+' '+new Date(data.dateTime).toLocaleTimeString()
    }else{
        date='每月一次 '+repetition.split('-')[1]+' '+new Date(data.dateTime).toLocaleTimeString()

    }
    return date;
}
function notificationList(){
    $('#notifyList').empty();
    for(var i in notifiList){
        var date;
        if(notifiList[i].repetition){
            date=getRepeatString(notifiList[i])
        }else{
            date=new Date(notifiList[i].dateTime);
            date=date.toLocaleDateString().replace(/-/g, "/")+' '+date.toLocaleTimeString()
        }
        $('#notifyList').append($('<td><div  class="heading"><div style="display: inline-block;padding-top: 20px;padding-left: 10px;padding-right:30px; width:30px ; "><input id ="deleteNotifi'+i+'" type="checkbox" name="bulletin" value="test"></div><div  style="display: inline-block; padding-top:20px;padding-left: 60px; width:70% ; ">'+(notifiList[i].title+' : '+notifiList[i].message)+'</div><div id="scheduledDate" style="display: inline-block; padding-top:10px;padding-bottom:10px; padding-left: 20px;width:200px;">'+date+'</div><div style="display: inline-block; padding-left:100px;clickable:true;" onclick="clone('+i+')"><img src="clone.png" style="height: 20px; width:20px;"></div></div></td>').html());
    }
}
function getNotification(){
    if(!notifiList)
        request('/notification/list',null,function(resultData){
            try{
                notifiList=JSON.parse(resultData).history;
            }catch(err){
                return ;
            }
            notificationList();
        })
    else
        notificationList();
}
function send(type){
    switch(type){
        case 'notifiGroup':$('#group-title').hide();
                        $('#groupTitle').hide();
                        for(var i in notificationDisable){
                            $('#'+notificationDisable[i]).css('display','none')
                        }
                        pop_up='group'
                        $("#group").modal("show");
                        break;
        case 'notifijob':$('#jobgroup-title').hide();
                        $('#jobgroupTitle').hide();
                        pop_up='jobemp'
                        $("#jobemp").modal("show");
                        break;
        case 'notifiids':$('#idgroup-title').hide();
                        $('#idgroupTitle').hide();
                        pop_up='idemp'
                        $("#idemp").modal("show");
                        break;
        case 'video':   pop_up='confirmVideo'
                        $("#confirmVideo").modal("show"); 
                        break;
        case 'bulletin':var onlyNotice=$('#calendar').prop('checked')
                        if(!onlyNotice){
                            date=$('#eventDate').val()+ ' '+$('#eventHour').val()+':'+ $('#eventMin').val();
                            endDate=$('#endDate').val()+ ' '+$('#endHour').val()+':'+ $('#endMin').val()
                            var repeat=$('#bulletinRepeat').val();
                            var customDates=$('#bulletinCustomDates').text();
                            sendNow=$('#eventSendNow').text()=='現在傳送';
                            if(endDate.length<14||new Date(endDate)-new Date(date)<=0){
                                return setGenericPopUp('排程時間錯誤','结束时间必须大于预定时间，请重新选择！','200px')
                            }
                            else if(repeat=='custom'&&!customDates){
                                return setGenericPopUp('排程時間錯誤','選擇至少一個日期')
                            }
                        }
                        title=$('#title').val()
                        if(title==''){
                            return setGenericPopUp('標題錯誤','标题不能为空')
                        }
                        pop_up='confirm'
                        $("#confirm").modal("show");
                        break;
        case 'notification':
                        var repeat=$('#notifyRepeat').val();
                        var customDates=$('#notifyCustomDates').text();
                        var dateList;
                        if(repeat=='Does_not_Repeat'){
                            date=$('#notifyDate').val()+ ' '+$('#notifyHour').val()+':'+ $('#notifyMin').val();
                            repeat=null;
                        }
                        else if(repeat=='custom'){
                            if(!customDates){
                                setGenericPopUp('錯誤的推播通知設定','選擇至少一個日期')
                                break;
                            }
                            customDates=customDates.split(',')
                            dateList=[];
                            date=customDates[0];
                            for(var i in customDates){
                                dateList.push(new Date(customDates[i])-0)
                                if((new Date()-60)>new Date(date))
                                    date=customDates[i];
                            }
                            dateList=dateList.join(',');
                        }else{
                            date='4019-01-01 '+$('#notifyHour').val()+':'+ $('#notifyMin').val()
                            if(repeat=='weekly-')
                                repeat+=$('#notifyWeek').val();
                            if(repeat=='monthly-')
                                repeat+=(parseInt($('#notifyMonth').val())+1);
                        }

                        var notifyTitle=$('#AnnounceTitle').val();
                        var message=$('#message').val();
                        var selectedDeparment=[]
                        var selectedJobs=[]
                        var selectedIds=[]
                        console.log(allDepartments,group)
                        for(var i in group){
                            var singlegroup=group[i].split('|')
                            if(allDepartments.indexOf(singlegroup[1])>=0)
                                selectedDeparment.push(group[i])
                        }
                        console.log(jobgroup,idgroup)
                        for(var i in jobgroup){
                            if(allJobs.indexOf(jobgroup[i])>=0)
                                selectedJobs.push(jobgroup[i])
                        }
                        for(var i in idgroup){
                            if(allIds.indexOf(idgroup[i])>=0)
                                selectedIds.push(idgroup[i])
                        }
                        console.log("+++++++++++",selectedDeparment,selectedJobs,selectedIds)
                        var validDeparments=selectedDeparment
                        var validJobs=[]
                        var validIds=[]
                        /*for(var i in employeeList){
                            if(validDeparments.indexOf(employeeList[i].DEPARTMENT_CNAME) < 0)
                                if((selectedJobs.indexOf(employeeList[i].JOB_CNAME) >= 0)&& (validJobs.indexOf(employeeList[i].JOB_CNAME) < 0))
                                    validJobs.push(employeeList[i].JOB_CNAME)
                        }
                        for(var i in employeeList){
                                if((validDeparments.indexOf(employeeList[i].DEPARTMENT_CNAME) < 0)&& (validJobs.indexOf(employeeList[i].JOB_CNAME) < 0))
                                    validIds.push(i)
                        }*/
                        var groups=selectedDeparment.join(',');
                        var jobsResult=selectedJobs.join(',');
                        var idResult=selectedIds.join(',');
                        sendNow=$('#notifySendNow').text()=='現在傳送';
                        if(notifyTitle==''){
                            setGenericPopUp('標題錯誤','標題不能為空白')
                            break;
                        }else if(groups==''){
                            setGenericPopUp('组错误','最少必須選擇一個群組')
                            break
                        }else if(message==''){
                            setGenericPopUp('消息错误','推播的訊息不能為空白')
                            break;
                        }
                        var body={
                            recepients:groups,
                            jobs:jobsResult,
                            allIds:idResult,
                            title:notifyTitle,
                            message:message,
                            sender:loginId,
                            senderTitle:senderTitle,
                            name:name,
                            company:company,
                            dateList:dateList,
                            filename:filename
                        }
                        if(filename){
                            var fileSplit=filename.split('.')
                            body.extension=fileSplit[fileSplit.length-1]
                        }
                        if(repeat)
                            body.repetition=repeat;
                        if(sendNow&&!repeat){
                            body.sendNow=true;
                            body.dateTime=new Date();
                        }
                        else 
                            body.dateTime=new Date(date);
                        request('/notification/save',body,function(resultData){
                            $('#AnnounceTitle').val('')
                            $('#message').val('')
                            $('#notifiGroups').text('')
                            $('#notifiids').text('');
                            $('#notifijobs').text('');
                            $('#notifyDate').val('')
                            $('#scheduleNotifi').hide();
                            $('#notifiyFile').text('');
                            $('#notifiList').show(); 
                            notifiList=undefined;
                            getNotification();
                            $('#notifiyFile').text('');

                        })
                        break;
        case 'delete'   :pop_up='confirmDelete';
                        $("#delete").modal("show");
                        break;
        case 'yesDelete':if(dashBoard=='bulletin')
                            clearList();
                        else if(dashBoard=='notification')
                            clearNotifi();
                        $('#delete').modal("hide");
                        break;
        case 'noDelete' :$('#delete').modal("hide");
                        break;
        case 'no':      $("#confirm").modal("hide");
                        break;
        case 'noVideo':    $("#confirmVideo").modal("hide");
                        break;
        case 'noEmployee':    $("#updateEmployee").modal("hide");
                        break;
        case 'noDepartment':    $("#updateDepartments").modal("hide");
                        break;
        case 'noConfirmEmployee':$("#confirmEmployee").modal("hide");
                        break;
        case 'noConfirmDepartment':$("#confirmDepartment").modal("hide");
                        break;
        case 'yesVideo':$("#confirmVideo").modal("hide");
                        socket.emit('sent',{tag:'uploadVideo',type:'uploadVideo',name:name,id:loginId,folder:filename.split('-')[0],subFolder:filename.split('-')[1],filename:filename});
                        filename=null;
                        setTimeout(function(){
                            $('#showVideo').hide();
                            hide()
                            jQuery('#logo').hide();
                            socket.emit('reset',{file:filename})
                            filename=null;
                            updateVideoList()
                            $('#browse').val('');
                            jQuery('#videoUploader').show();
                            jQuery('#uploadVideoButton').show();
                        },2000)
                        break;
        case 'yes':     var onlyNotice=$('#calendar').prop('checked')
                        $("#confirm").modal("hide");
                        if(onlyNotice){
                            socket.emit('sent',{sendNow:true,type:'bulletin',tag:'png',dateTime:new Date(),title:title,filename:filename,recepients:group.join(),onlyNotice:onlyNotice});
                            return setTimeout(function(){
                                $('#bulletinBoard').hide();
                                jQuery('#logo').hide();
                                screen='已排程公告'
                                jQuery('#bulletinList').empty();
                                jQuery('#mainTitle').text('公 告');
                                socket.emit('list');
                            },2000)
                        }
                        var repeat=$('#bulletinRepeat').val();
                        var customDates=$('#bulletinCustomDates').text();
                        var notifyDate,dateList;
                        if(repeat=='Does_not_Repeat'){
                            notifyDate=date;
                            repeat=null;
                        }else if(repeat=='custom'){
                            customDates=customDates.split(',')
                            dateList=[];
                            notifyDate=new Date(customDates[0]);
                            for(var i in customDates){
                                dateList.push(new Date(customDates[i])-0)
                                if(new Date()>notifyDate)
                                    notifyDate=new Date(customDates[i]);
                            }
                            dateList=dateList.join(',');
                        }else{
                            notifyDate='4019-01-01 '+$('#bulletinHour').val()+':'+ $('#bulletinMin').val()
                            if(repeat=='weekly-')
                                repeat+=$('#bulletinWeek').val();
                            else if(repeat=='monthly-')
                                repeat+=(parseInt($('#bulletinMonth').val())+1);
                        }
                        socket.emit('sent',{sendNow:sendNow&&!repeat,type:'bulletin',tag:'png','startTime':new Date(date)-0,dateTime:new Date(notifyDate)-0,dateList:dateList,repetition:repeat,endTime:new Date(endDate)-0,title:title,filename:filename,recepients:group.join()});
                        filename=null;
                        setTimeout(function(){
                            $('#bulletinBoard').hide();
                            jQuery('#logo').hide();
                            screen='已排程公告'
                            jQuery('#bulletinList').empty();
                            jQuery('#mainTitle').text('公 告');
                            socket.emit('list');
                        },2000)
                        pop_up='sent';
                        $('#sent').modal('show');
                        break;
        case 'yesEmployee':   $("#updateEmployee").modal("hide");
                        $('#confirmEmployee').modal("show");
                        pop_up='confirmEmployee';
                        break;
        case 'yesConfirmEmployee':
                        $('#confirmEmployee').modal("hide");
                        socket.emit('updateEmployee');
                        break;
        case 'yesDepartment':   $("#updateDepartments").modal("hide");
                        $("#confirmDepartment").modal("show")
                        pop_up='confirmDepartment'
                        break;
        case 'yesConfirmDepartment':
                        $("#confirmDepartment").modal("hide")
                        socket.emit('updateDepartments');
                        break;
        case 'yesAccess':   $("#removeAccess").modal("hide")
                        if(isDepartmentAccess)
                            setDepartmentAccess(removeIndex,accessId,'0')
                        else
                            setAccess(removeIndex,'0')
                        break;
        case 'noAccess': $("#removeAccess").modal("hide")
        case 'generic':$('#generic').modal('hide');
                        $('#height').css('height','160px')
                        break;
        case 'sent':    $('#sent').modal('hide');
                        break;
        case 'sentHr':    $('#senthr').modal('hide');
                        break;
        case 'right':   jQuery('#bulletin').show();
                        jQuery('#right').hide();
                        jQuery('#down').show();
                        break;
        case 'down':    jQuery('#bulletin').hide();
                        jQuery('#right').show();
                        jQuery('#down').hide();
                        break;
        case 'right2':  jQuery('#notifi').toggle();
                        jQuery('#right2').toggle();
                        jQuery('#down2').toggle();
                        break;
        case 'down2':   jQuery('#notifi').toggle();
                        jQuery('#right2').toggle();
                        jQuery('#down2').toggle();
                        break;
        case 'right4':   $("#updateEmployee").modal("show");
                        pop_up='updateEmployee';
                        break;
        case 'right5':   $("#updateDepartments").modal("show");
                        pop_up='updateDepartments';
                        break;
        case 'right8':   dashBoard='uploadVideo'
                            hide()
                            jQuery('#logo').hide();
                            socket.emit('reset',{file:filename})
                            filename=null;
                $('#browse').val('');
                            jQuery('#videoUploader').show();
                            jQuery('#uploadVideoButton').show();
                            break;
        case 'right7':   dashBoard='reviewData'
                            hide()
                            jQuery('#logo').hide();
                            socket.emit('reset',{file:filename})
                            filename=null;
                            jQuery('#reviewSheetUploader').show();
                            break;
        case 'right6':  hide()
                        jQuery('#Access').show();
                        jQuery('#search').show();
                        getEmployeeList()
                        empUpdate()
                        break;
        case 'right3': logout();
                        break;
    }
}
function setAccess(index,enable){
    accessList[index]=enable
    employeeList[accessId].fullAccess=accessList.join(',')
    request('/setAccess',{employeeID:accessId,access:accessList.join(',')},function(resultData){
        createAccessList();
    })
}
function showList(){
    var employee=$('#searchText').val();
    $('#accessError').text('');
    if(!employeeList[employee])
        return $('#accessError').text('找不到此員工編號');
    else 
        showEmployee(employee)
}
function setDepartmentAccess(index,employeeId,enable){
    accessList=employeeList[employeeId].fullAccess;
    if(!accessList)
        accessList='0,0,0,0,0,0,0';
    accessList=accessList.split(',')
    accessList[index]=enable
    employeeList[employeeId].fullAccess=accessList.join(',')
    request('/setAccess',{employeeID:employeeId,access:accessList.join(',')},function(resultData){
        showEmployeeAccess(index);
    })
}
function showDepartmentPopUp(index,employeeId,enable){
    if(enable==1)
        return setDepartmentAccess(index,employeeId,enable)
    accessId=employeeId;
    removeIndex=index
    isDepartmentAccess=true;
    var member=employeeList[employeeId]
    $('#removeEmployeeID').text('員工編號 : '+member.EMPLOYEE_NO);
    $('#removeEmployeeName').text('員工姓名 : '+member.EMPLOYEE_CNAME);
    $('#removeEmployeeJob').text('職務名稱 : '+member.JOB_CNAME);
    $('#removeEmployeeCompany').text('所屬單位 : '+member.DEPARTMENT_CNAME);
    $('#removeAccessTitle').text('您確定要刪除以下用戶的「'+accessName[index]+'」管理權限嗎 ?');
    $('#removeAccess').modal('show')
    pop_up='removeAccess'
}
function showPopUp(index,enable){
    if(enable==1)
        return setAccess(index,enable)
    isDepartmentAccess=false
    removeIndex=index
    var member=employeeList[accessId]
    $('#removeEmployeeID').text('員工編號 : '+member.EMPLOYEE_NO);
    $('#removeEmployeeName').text('員工姓名 : '+member.EMPLOYEE_CNAME);
    $('#removeEmployeeJob').text('職務名稱 : '+member.JOB_CNAME);
    $('#removeEmployeeCompany').text('所屬單位 : '+member.DEPARTMENT_CNAME);
    $('#removeAccessTitle').text('您確定要刪除以下用戶的「'+accessName[index]+'」管理權限嗎 ?');
    $('#removeAccess').modal('show')
    pop_up='removeAccess'
}

function createAccessList(){
    $('#accessList').empty()
    for(var i in accessName){
        $('#accessList').append($('<td><div  class="heading" style="width:100%" ><div  style="display:inline-block; padding-top:20px;padding-left: 60px;  ">'+accessName[i]+(accessList[i]=='0'?'(尚未授權)':'')+'</div><div style="display:inline-block;float:right;padding-right:50px;"><button  onclick="showPopUp('+i+','+(parseInt(accessList[i])+1)%2+')" style=" background-color:#283590;  border-radius: 10px;   color: white;padding: 5px 10px; "><b><div id="notifySendNow">'+(accessList[i]=='0'?'新增':'刪除')+'</div></b></button></div></div></td>').html());
    }
}
function showEmployee(id){

    console.log('came here '+id)
    $('#search').hide();
    $('#employeeAccess').show()
    var member=employeeList[id]
    $('#employeeID').text('員工編號 : '+member.EMPLOYEE_NO);
    $('#employeeName').text('員工姓名 : '+member.EMPLOYEE_CNAME);
    $('#employeeJob').text('職務名稱 : '+member.JOB_CNAME);
    $('#employeeCompany').text('所屬單位 : '+member.DEPARTMENT_CNAME);
    accessId=id;
    accessList=member.fullAccess
    if(accessList){
        accessList=accessList.split(',')
    }else{
        accessList=[0,0,0,0,0,0,0]
    }
    console.log(accessList)
    createAccessList();
}

function showEmployeeAccess(index){
    jQuery('#departmentAccess').hide();
    jQuery('#departmentEmployee').show();
    $('#departmentEmployeeList').empty()
    for(var i in employeeList){
        var member=employeeList[i];
        if(member.DEPARTMENT_CNAME!=departmentAccess)
            continue;
        var fullAccess=member.fullAccess
        if(!fullAccess)
            fullAccess='0,0,0,0,0,0,0'
        fullAccess=fullAccess.split(',')[index]
        $('#departmentEmployeeList').append($('<td><div  class="heading"  style=" width:100%" ><div style="display:inline-block;"><div  style=" padding-top:20px;padding-left: 60px;  ">員工編號 : '+member.EMPLOYEE_NO+'</div><div  style=" padding-top:10px;padding-bottom:10px; padding-left: 60px;">員工姓名: '+member.EMPLOYEE_CNAME+'</div></div><div style="display:inline-block;float:right;padding-right:50px;padding-top:2%;"><button  onclick="showDepartmentPopUp('+index+','+member.EMPLOYEE_NO+','+(parseInt(fullAccess)+1)%2+')" style=" background-color:#283590;  border-radius: 10px;   color: white;padding: 5px 10px; "><b><div id="notifySendNow">'+(fullAccess=='0'?'新增':'刪除')+'</div></b></button></div></div></td>').html());
    }
}
function showAccessList(){
    jQuery('#search').hide();
    jQuery('#departmentAccess').show();
    departmentAccess=$('#searchDepartment').val();
    $('#departmentAccessList').empty()
    for(var i in accessName){
        $('#departmentAccessList').append($('<td><div  class="heading" style="width:100%" ><div  style="display:inline-block; padding-top:20px;padding-left: 60px;  ">'+accessName[i]+'</div><div style="display:inline-block;float:right;padding-right:50px;"><button  onclick="showEmployeeAccess('+i+')" style=" background-color:#283590;  border-radius: 10px;   color: white;padding: 5px 10px; "><b>新增</b></button></div></div></td>').html());
    }
}

function createEmployeeList(){
    $('#employeeList').empty()
    for(var i in employeeList){
        var member=employeeList[i];
        $('#employeeList').append($('<td><div  class="heading" onclick="showEmployee('+member.EMPLOYEE_NO+')" style="width:100%" ><div  style=" padding-top:20px;padding-left: 60px;  ">員工編號 : '+member.EMPLOYEE_NO+'</div><div  style=" padding-top:10px;padding-bottom:10px; padding-left: 60px;">員工姓名: '+member.EMPLOYEE_CNAME+'</div></div></td>').html());
    }
}
function getEmployeeList(){
    if(!employeeList)
        request('/list',{webui:true},function(resultData){
            try{
                var employeeArray=JSON.parse(resultData).list
                employeeList={};
                for(var i in employeeArray){
                    employeeList[employeeArray[i].EMPLOYEE_NO]=employeeArray[i]
                }
                createEmployeeList();
            }catch(err){

            }
        })
    else 
        createEmployeeList
}
empUpdate();
function empUpdate(){
    var department_list = []
    var jobs_list = []
    var emp_ids=[]
    request('/list',{webui:true},function(resultData){
        try{
            var employeeArray=JSON.parse(resultData).list
            employeeList={};
            for(var i in employeeArray){
                if (department_list.indexOf(employeeArray[i].DEPARTMENT_CNAME) < 0)
                    department_list.push(employeeArray[i].DEPARTMENT_CNAME)
                if (jobs_list.indexOf(employeeArray[i].JOB_CNAME) < 0)
                    jobs_list.push(employeeArray[i].JOB_CNAME)
                if (emp_ids.indexOf(employeeArray[i].EMPLOYEE_NO) < 0)
                    emp_ids.push(employeeArray[i].EMPLOYEE_NO)
                employeeList[employeeArray[i].EMPLOYEE_NO]=employeeArray[i]
            }
            updateEmpData(department_list,jobs_list,emp_ids)
        }catch(err){

        }
    })
}
function hide(){
    jQuery('#dashBoard').hide()
    jQuery('#scheduled').hide()
    jQuery('#bulletinBoard').hide()
    jQuery('#bulletin-board').hide()
    jQuery("#notification").hide();
    jQuery("#reviewSheetUploader").hide();
    jQuery("#videoUploader").hide();
    jQuery('#notifiList').hide();
    jQuery('#scheduleNotifi').hide();
    jQuery('#uploadVideoButton').hide();
    jQuery('#showVideo').hide();
    $('#notifiyFile').text('');
    jQuery('#Access').hide();
    jQuery('#employeeAccess').hide()
    jQuery('#departmentAccess').hide();
    jQuery('#departmentEmployee').hide()
    filename=null;
}
function logout(){
    request('/logoutUI',{regid:'localWebui'+loginId,loginId:loginId},function(resultData){
        window.location.href = '/';
    })
}
function onSubmit(event,jq_xhr,fileSelect){
    event.preventDefault();
    var files = fileSelect.files;
    var formData = new FormData();
    var file = files[0]; 
    if(!file)
        return 
    filename=file.name
    if(!filename)
        return 
    var size=file.size
    var extension=filename.substr(filename.lastIndexOf('.')+1)
    if(dashBoard=='uploadVideo'&&(filename.indexOf('-')<0||filename.split('-').length<3))
        return setGenericPopUp('上傳檔案過大','影片名稱錯誤, 上傳失敗')
    var type=filename.split('-')[0]
    var type2=filename.split('-')[1]
    if(dashBoard=='uploadVideo'&&filename.length>=50){
        setGenericPopUp('上傳檔案名稱過長。','檔案名稱長度不能超過50個字元，上傳失敗。')
        return ;
    }
    if(dashBoard=='uploadVideo'&&(folderType.indexOf(type)<0||subFolderType.indexOf(type2)<0)){
        setGenericPopUp('上傳檔案過大','影片名稱錯誤, 上傳失敗')
        return ;
    }
    if (extensions[dashBoard].indexOf(extension)<0)  {
        var detail=extensionMap[dashBoard]?extensionMap[dashBoard]:'只能支援以下格式 pdf ; jpeg  ; png ; gif';
        setGenericPopUp('不支援此檔案格式',detail,'200px')
        return ;
    } else if((dashBoard=='uploadVideo'&&size >300*1024*1024)||(dashBoard!='uploadVideo'&&size >50*1024*1024)){
        setGenericPopUp('上傳檔案過大',dashBoard!='uploadVideo'?'檔案大小只支援 50MB 以內':'檔案大小只支援 300MB 以內')
        return ;
    }
    formData.append('browse', file, file.name);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/videoUpload', true);
    jq_xhr[dashBoard]=xhr
    xhr.upload.onprogress = function (event) {
        if(!filename&&fileId!=null&&fileId!=undefined)
            return;
        fileId='aaa'
        if($('#filename').text()!=filename)
            $('#filename').text(filename);
        pop_up='progress';
        $("#progress").modal({
            backdrop: 'static',
            keyboard: true, 
            show: true
        });
        $("#myBar").css('width',Math.round((event.loaded / event.total) * 100)+"%");
        $('#fileSize').text((event.loaded/(1024*1024)).toFixed(2)+'MB')
    };
    // Set up a handler for when the task for the request is complete.
    xhr.onload = function () {
        if (xhr.status === 200) {
            $("#progress").modal("hide");
            if(dashBoard=='uploadVideo'){
                jQuery('#uploadVideoButton').hide()
                jQuery('#showVideo').show()
                $('#browse').val('')
                $('#videoPreview').empty();
                var extension=filename.substr(filename.lastIndexOf('.')+1)
                if(extension=='mp4')
                    $('#videoPreview').append('<video width="100%" height="100%" controls><source src="preview/'+filename+'" type="video/mp4" /></video>"')
                else
                    $('#videoPreview').append("<iframe width='100%' height='200' src='preview/"+filename+"' frameborder='0'></iframe>")

            }
            else if(dashBoard=='reviewData'){
                $('#browseReview').val('')
                socket.emit('sent',{tag:'reviewData',filename:filename});
                setGenericPopUp('成功','回顾上传成功。')
            }else if(dashBoard=='bulletin'){
                $('#browseBulletin').val('')
                $('#selectAllGroup').prop('checked',false)
                $('#groupTitle').text(filename)
                pop_up='group';
                for(var i in notificationDisable){
                    $('#'+notificationDisable[i]).css('display','block')
                }
                $("#group").modal({
                        backdrop: 'static',
                        keyboard: true, 
                        show: true
                });
            }else{
                $('#browseNotifi').val('')
                $('#notifiyFile').text(filename);
            }
        } else {
            $("#progress").modal("hide");
            filename=null
        }
    };
    xhr.send(formData);
}
function setUploadButton(button,file,submit){
    console.log(button,file,submit)
    $("#"+button).click(function () {
        $('#'+file).val('')
        $("#"+file).trigger('click');
    });
    $('#'+file).val('') 
    $('#'+file).change(function () {
       $("#"+submit).trigger('click');
    });
}
jQuery(document).ready(function() {
    hide();
    jQuery('#bulletin').hide();
    jQuery('#down').hide();
    jQuery('#push').hide();
    jQuery('#down2').hide();
    jQuery('#notifi').hide();
    setUploadButton('uploadButton','browse','submitForm')
    var jqXhr={}
    var form = document.getElementById('uploadForm');
    var fileSelect = document.getElementById('browse');
    form.onsubmit = function(event) {
        onSubmit(event,jqXhr,fileSelect)
    }
    setUploadButton('uploadReviewButton','browseReview','submitReviewForm')
    var reviewForm = document.getElementById('uploadReviewForm');
    var reviewFileSelect = document.getElementById('browseReview');
    reviewForm.onsubmit = function(event) {
        onSubmit(event,jqXhr,reviewFileSelect)
    }
    setUploadButton('uploadBulletinButton','browseBulletin','submitBulletinForm')
    var bulletinForm = document.getElementById('uploadBulletinForm');
    var bulletinFileSelect = document.getElementById('browseBulletin');
    bulletinForm.onsubmit = function(event) {
        onSubmit(event,jqXhr,bulletinFileSelect)
    }
    setUploadButton('uploadNotifiButton','browseNotifi','submitNotifiForm')
    var notifiForm = document.getElementById('uploadNotifiForm');
    var notifiFileSelect = document.getElementById('browseNotifi');
    notifiForm.onsubmit = function(event) {
        onSubmit(event,jqXhr,notifiFileSelect)
    }
    $('.link').click(function(){
        switch($(this).text()){
            case '建立公告訊息':jQuery('#bulletin').toggle();
                            jQuery('#right').toggle();
                            jQuery('#down').toggle();
                            break;
            case '新增公告訊息': dashBoard='bulletin';
                            $('#noCalendar').show()
                            $('#calendar').prop('checked',false)
                            jQuery('#mainTitle').text('新增公告');
                            hide();
                            jQuery('#logo').hide();
                            socket.emit('reset',{file:filename})
                            filename=null;
                            checkDate('event')
                            jQuery('#bulletin-board').show();
                            jQuery('#dashBoard').show();
                            break;
            case '推播通知':     jQuery('#notifi').toggle();
                            jQuery('#right2').toggle();
                            jQuery('#down2').toggle();
                            break;
            case '建立推播': dashBoard='notification';
                            hide();
                            jQuery('#logo').hide();
                            socket.emit('reset',{file:filename})
                            filename=null;
                            jQuery('#notification').show();
                            jQuery('#scheduleNotifi').show();
                            $('#notifiyFile').text('');
                            checkDate('notify');
                            repeatCheck('notify');
                            break;
            case '通知清單': dashBoard='notification';
                            hide();
                            jQuery('#logo').hide();
                            socket.emit('reset',{file:filename})
                            filename=null;
                            jQuery('#notification').show();
                            jQuery('#notifiList').show();
                            getNotification();
                            break;
            case '人資系統更新': $("#updateEmployee").modal("show");
                            pop_up='updateEmployee'
                            break;
            case '人資組織架構更新':$("#updateDepartments").modal("show");
                            pop_up='updateDepartments'
                            break;
            case '口碑評價表上傳':dashBoard='reviewData'
                            hide()
                            jQuery('#logo').hide();
                            socket.emit('reset',{file:filename})
                            filename=null;
                            jQuery('#reviewSheetUploader').show();
                            break;
            case '學習專區影片上傳':dashBoard='uploadVideo'
                            hide()
                            jQuery('#logo').hide();
                            socket.emit('reset',{file:filename})
                            filename=null;
                            $('#browse').val('');
                            jQuery('#videoUploader').show();
                            jQuery('#uploadVideoButton').show();
                            break;
            case '權限設定':  hide()
                            jQuery('#logo').hide();
                            jQuery('#Access').show();
                            jQuery('#search').show();
                            getEmployeeList()
                            empUpdate()
                            break;
            case '登出':      logout();
                            break;
            default:   dashBoard='bulletin';
                            $('#calendar').prop('checked',false)
                            $('#noCalendar').show()
                            jQuery('#mainTitle').text('公 告');
                            jQuery('#logo').hide();
                            hide();
                            screen=$(this).text()
                            empUpdate();
                            jQuery('#bulletinList').empty();
                            if(list)
                                scheduled();
                            else
                                socket.emit('list');
                            break;
        }
        socket.emit('dashBoard',dashBoard)
    });
    $('.close').click(function(){
        $('#'+pop_up).modal('hide');
        if(pop_up=='group'||pop_up=='progress'){
            socket.emit('reset',{file:filename});
            filename=null;
            if(pop_up=='progress'){
                jqXhr[dashBoard].abort();
                setTimeout(function(){
                    fileId=null
                },2000)
            }
        }

    })
    $('#notifyList').click(function(){
        var listCount=0;
        for(var i=0;i<notifiList.length;i++)
            if($('#deleteNotifi'+i)[0].checked)
                listCount++;
        if(listCount==notifiList.length)
            $('#selectAllNotifi').prop('checked',true)
        else if(listCount<notifiList.length)
            $('#selectAllNotifi').prop('checked',false)
    })
    $('#selectAllNotifi').click(function(){
        for(var i =0;i<notifiList.length;i++)
            $('#deleteNotifi'+i).prop('checked',this.checked)
    })
    $('#bulletinList').click(function(){
        var listCount=0;
        for(var i=0;i<bulletinList.length;i++)
            if($('#delete'+i)[0].checked)
                listCount++;
        if(listCount==bulletinList.length)
            $('#selectAllList').prop('checked',true)
        else if(listCount<bulletinList.length)
            $('#selectAllList').prop('checked',false)
    })
    $('#selectAllList').click(function(){
        for(var i =0;i<bulletinList.length;i++)
            $('#delete'+i).prop('checked',this.checked)
    })
    $('#calendar').click(function(){
        if(this.checked)
            $('#noCalendar').hide()
        else
            $('#noCalendar').show()
    })
    $('#selectAllGroup').click(function(){
        var value=this.checked;
        var count= allDepartments.length
        for(var i =0;i<count;i++)
            $('#selectgroup'+i).prop('checked',this.checked)
        if(this.checked)
            $('#done').show();
        else
            $('#done').hide()
    })
    $('#selectAlljobs').click(function(){
        var value=this.checked;
        var count= allJobs.length
        for(var i =0;i<count;i++)
            $('#selectjob'+i).prop('checked',this.checked)
        if(this.checked)
            $('#done2').show();
        else
            $('#done2').hide()
    })
    $('#selectAllid').click(function(){
        var value=this.checked;
        var count=allIds.length;
        for(var i =0;i<count;i++)
            $('#selectid'+i).prop('checked',this.checked)
        if(this.checked)
            $('#done3').show();
        else
            $('#done3').hide()
    })
    $('#groups').click(function(){
        var groupCount=0;
        var count= allDepartments.length
        for(var i in this.childNodes)
            if(this.childNodes[i]&&this.childNodes[i].childNodes&&this.childNodes[i].childNodes[0]&&this.childNodes[i].childNodes[0].childNodes[0].checked)
                groupCount++;
        if(groupCount==count)
            $('#selectAllGroup').prop('checked',true)
        else if(groupCount<count)
            $('#selectAllGroup').prop('checked',false)
        if(groupCount==0)
            $('#done').hide();
        else
            $('#done').show();
    })
    $('#empjobs').click(function(){
        var groupCount=0;
        var count= allJobs.length
        for(var i in this.childNodes)
            if(this.childNodes[i]&&this.childNodes[i].childNodes&&this.childNodes[i].childNodes[0]&&this.childNodes[i].childNodes[0].childNodes[0].checked)
                groupCount++;
        if(groupCount==count)
            $('#selectAlljobs').prop('checked',true)
        else if(groupCount<count)
            $('#selectAlljobs').prop('checked',false)
        if(groupCount==0)
            $('#done2').hide();
        else
            $('#done2').show();
    })
    $('#empids').click(function(){
        var groupCount=0;
        var count=allIds.length;
        for(var i in this.childNodes)
            if(this.childNodes[i]&&this.childNodes[i].childNodes&&this.childNodes[i].childNodes[0]&&this.childNodes[i].childNodes[0].childNodes[0].checked)
                groupCount++;
        if(groupCount==count)
            $('#selectAllid').prop('checked',true)
        else if(groupCount<count)
            $('#selectAllid').prop('checked',false)
        if(groupCount==0)
            $('#done3').hide();
        else
            $('#done3').show();
    })
    var color =['pink','brown','orange','blue','green','violet','black','red']

    updateGroups();
    // var newItem = $('<td><div style="padding-top:10px;height:50px;"><div style="display: inline-block;padding-top: 10px;padding-left: 10px;padding-right:40px; width:40px;"><input id="selectgroup'+i+'" type="checkbox" name="vehicle" value="Bike"></div><div style="display: inline-block;height:50px;width:50px; position:absolute; padding-left:10px;""><div class="circle" style="background-color:blue ;padding-right:8%;padding-left:8%;letter-spacing:1px;"><div style="padding-top:25%;font-size:10px;letter-spacing:1px;"><b>test<br>Group</b></div></div></div><div style="display: inline-block;position:absolute;padding-left:70px;padding-top:10px;">testGroup</div></div></td>');
    // $("#groups").append(newItem.html());
    $('#done').hide();
    for(var i =0;i<24;i++){
        $('#eventHour').append('<option value="'+i+'">'+i+'</option>>')
        $('#endHour').append('<option value="'+i+'">'+i+'</option>>')
        $('#notifyHour').append('<option value="'+i+'">'+i+'</option>>')
        $('#bulletinHour').append('<option value="'+i+'">'+i+'</option>>')
    }
    for(var i =0;i<60;i++){
        $('#eventMin').append('<option value="'+i+'">'+i+'</option>>')
        $('#endMin').append('<option value="'+i+'">'+i+'</option>>')
        $('#notifyMin').append('<option value="'+i+'">'+i+'</option>>')
        $('#bulletinMin').append('<option value="'+i+'">'+i+'</option>>')

    }
    for(var i =0;i<7;i++){
        $('#bulletinWeek').append('<option value="'+i+'">'+dayOfWeek[i]+'</option>>')
        $('#notifyWeek').append('<option value="'+i+'">'+dayOfWeek[i]+'</option>>')
    }
    for(var i=0;i<28;i++){
        $('#notifyMonth').append('<option value="'+i+'">'+(i+1)+'</option>>')
    }
    for(var i=0;i<28;i++){
        $('#bulletinMonth').append('<option value="'+i+'">'+(i+1)+'</option>>')
    }
    $('upload_input').css("display","none")
})
