var config=require('./initConf.js').get().EMAIL
var ES = {
	host: 'email-smtp.us-east-1.amazonaws.com',
	user: config.USER,
	password: config.PASSWORD,
	sender: 'Securifi.com <support@securifi.com>',
	adminEmail: 'support@securifi.com',
	monitor: 'cloud@securifi.com',
	LB: 'https://connect.securifi.com',
	FORUM: 'https://forum.securifi.com',
	company: 'Securifi, Inc.',
	product: 'Almond',
	esignature: 'Securifi Team'
}
var EM = {};
EM.product = ES.product;

EM.server = require("emailjs/email").server.connect({
    host: ES.host,
    user: ES.user,
    password: ES.password,
    ssl: true
});

EM.sendEmail = function(password,email, callback) {
    EM.server.send(
        {
            from: ES.sender,
            to: email,
            subject: "WEIDOE Account PASSWORD_RESET" ,
            text: "something went wrong... :(",
            attachment: EM.composeEmail(password)
        },
        callback
    );
};

EM.sendFCMEmail = function(data, callback) {
    EM.server.send(
        {
            from: ES.sender,
            to: 'cloud@securifi.com',
            subject: "FCM Retry limit Exhausted" ,
            text: "something went wrong... :(",
            attachment: [{data:data,name:'notification.json',alternative: true}]
        },
        callback
    );

};
EM.sendAcccessEmail = function(data, callback) {
    EM.server.send(
        {
            from: ES.sender,
            to: 'rashid.hussain@securifi.com,sridevi@securifi.com,jim.yuan@securifi.com,abhinai.vatsal@securifi.com,wayne_liu@weidoe.com',
            subject: "Weideo Access Added " ,
            text: "something went wrong... :(",
            attachment: [{data:"<html><body>"+data+"</body></html>",alternative: true}]
        },
        callback
    );

};

EM.composeEmail = function(password) {
    var html = "<html><body>";
    html += "<p>Hi there,</p>";
    html+="<p>We received a password reset request from you.</p>"
    html+="<p>Please use the following password to login.</p>"
    html+="<p><h3>"+password+"</h3></p>";
    html+="<p>Thank You</p>"
    html+="<p>WEIDOE GROUP</p>";
    html += "</body></html>";

    return [{ data: html, alternative: true }];
};

module.exports = EM;
