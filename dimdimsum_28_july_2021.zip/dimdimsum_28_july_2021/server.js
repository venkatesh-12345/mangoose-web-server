var socketio = require('socket.io'),
    express = require('express'),
    bodyParser = require('body-parser');
var path = require('path');
var fileUpload = require('express-fileupload');
var controller=require('./controller');
var eSession = require('express-session');
var config=require('./initConf').get()
var department=require('./util/departments.json').departments;
var fs = require('fs');
var saveUploaded=require('./saveUploaded')
var constants=require('./util/constants.js').constants;

console.log(" current dir", __dirname);
var app = express()
    .use(fileUpload({
        useTempFiles : true,
        tempFileDir : path.join(__dirname,'tmp'),
    }))
    .use(express.static(__dirname + "/public"))
    .use(bodyParser.urlencoded({ extended: true }))
    .use(eSession({
        secret: 'dImdIm$Um',
        resave: true,
        saveUninitialized: true
    }));
var server = require('http').Server(app);

server.listen(config.Port);
app.engine('html', require('ejs').renderFile);
var findRemoveSync = require('find-remove');
var result = findRemoveSync('./uploads', {age: {seconds: 3600}, extensions: ['.pdf','.jpeg','.jpg','.png','.gif','.xlsx','.mp4'], limit: 100})
var result = findRemoveSync('./tmp', {age: {seconds: 3600},prefix: 'tmp', limit: 100})
var result = findRemoveSync('./public/preview', {age: {seconds: 3600}, extensions: ['.pdf','.jpeg','.jpg','.png','.gif','.xlsx','.mp4'], limit: 100})

console.log(result);
setInterval(function(){
    var result = findRemoveSync('./uploads', {age: {seconds: 3600}, extensions: ['.pdf','.jpeg','.jpg','.png','.gif','.xlsx'], limit: 100})
    var result = findRemoveSync('./public/preview', {age: {seconds: 3600}, extensions: ['.pdf','.jpeg','.jpg','.png','.gif','.xlsx'], limit: 100})
    var result = findRemoveSync('./tmp', {age: {seconds: 3600},prefix: 'tmp', limit: 100})

    console.log(result);    
}, 60*60*1000)
var io = socketio.listen(server);
var session = {};
var controllerReqs=['/updateRegID','/notification/save','/notification/history','/groups','/login','/profile','/signUP','/forgotPswd','/notification/changeAccess','/notification/list','/employeeBasicInfo','/lastMonthData','/bulletin/list','/storeUpdateInfo','/notiTestResult','/revenue/day','/revenue/month','/revenue/foodqty','/revenue/target','/revenue/targetAll','/list','/getAccess','/setAccess','/setGroupAccess','/inventory','/setMultipleAccess','/purchaseStock','/sellout','/setCount','/employee','/fdCost','/salary','/salaryAll','/rating','/ratingAll','/overallRating','/ratingPercent','/allmonthRating','/targetHotel','/graph','/bonus','/reviewGraph','/hotelRating','/timeRating','/timeReview','/nonReplyReview','/employeeNew','/video','/logout','/bomin']
app.post(controllerReqs,controller.authCheck, function(req,res){
	controller.do(req,res);
})
app.post('/logoutUI', function(req,res){
    if(session[req.sessionID])
        delete session[req.sessionID] ;
    controller.do(req,res);

})
app.post('/videoUpload',function(req,res){
    let targetFile = req.files.browse;
    fs.createReadStream(targetFile.tempFilePath).pipe(fs.createWriteStream(constants.UPLOAD+targetFile.name))
    fs.createReadStream(targetFile.tempFilePath).pipe(fs.createWriteStream(constants.PUBLIC+targetFile.name));
    res.send('File uploaded!');
})
app.get('/', function(req, res) {
    if (!session[req.sessionID]) {
        res.render(__dirname+'/public/login.html')
    } else {
        res.redirect('/home');
    }
});
app.post('/',function(req,res){
     var data=req.body;
     if (data &&data.token) {
        var loginId=data.employeeID
        for(var i in session){
            if(session[i].employeeID==loginId){
                delete session[i]
            }
        }
        session[req.sessionID] = {}
        session[req.sessionID] = data;
        res.status(200).send('ok');
    } else {
        res.status(400).send('error');
    }
})
app.get('/home',function(req,res){
    if (!session[req.sessionID]) return res.redirect('/');
    res.render(__dirname+'/public/home.html',session[req.sessionID])
})
app.post('/bulletin/clear',controller.authCheck,function(req,res){
    if(req.body && req.body.path)
        saveUploaded.clear([req.body.path])
    res.status(200).send(JSON.stringify({success:true}));
})
app.post('/notification/delete',controller.authCheck,function(req,res){
    if(req.body && req.body.extension){
        saveUploaded.clear(['notification/'+req.body.mes_no+'.'+req.body.extension],'notification/')
        res.status(200).send(JSON.stringify({success:true}));
    }
    else
        return controller.do(req,res);
})
app.get('*', function(req, res) {
    return res.redirect('/');
    res.end();
})
var fileMapping={
    'uploadVideo':{
        types:['mp4'],
        model:'uploadVideo'
    },
    'bulletin':{
        types:['pdf','jpeg','jpg','png','gif'],
        model:'bulletinBoard'
    },
    'hrReport':{
        types:['xlsx'],
        model:'details'
    },
    'reviewData':{
        types:['xlsx'],
        model: 'details'
    },
    'notification':{
        types:['pdf','jpeg','jpg','png','gif'],
        model:'bulletinBoard'
    }
}
io.sockets.on("connection", function(sock) {
    var userData;
    var dashBoard;
    sock.on('dashBoard',function(data){
        dashBoard=data;
    })
    console.log('connection',new Date())
    sock.on('list',function(){
        controller.list(null,function(err,data){
            sock.emit('list',data);
        })
    })
    setTimeout(function(){
        sock.emit('departments',department)
    },4000)
    sock.on('clear',function(list){
        saveUploaded.clear(list)
    })
    sock.on('sent',function(data){
        saveUploaded[data.tag](data);
    })
    sock.on('updateEmployee',function(){
        controller.updateEmployee(function(loginIds){
            for(var i in session){
                if(loginIds.indexOf(session[i].employeeID)>=0)
                    delete session[i]
            }
        })
    })
    sock.on('updateDepartments',function(){
        controller.updateDepartments(function(departments){
            department=departments;
            sock.emit('departments',departments)
        })    
    })
    sock.on('reset',function(data){
        if(data.file){
            try{
                fs.unlinkSync(constants.UPLOAD + data.file);
                fs.unlinkSync('./public/preview' + data.file);  
            }catch(err){}
        }
    })
    sock.on('error',function(){
        console.log('---------socket error')
    })
});

process.on('uncaughtException', function(err) {
    console.log('uncaughtException Error', err);
    fs.appendFile('errorLogs', err.toString(), function(err, data) {});

});
