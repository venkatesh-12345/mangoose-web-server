-- MySQL dump 10.13  Distrib 5.6.31-ndb-7.4.12, for linux-glibc2.5 (x86_64)
--
-- Host: 10.10.10.101    Database: AlmondplusDB
-- ------------------------------------------------------
-- Server version	5.6.31-ndb-7.4.12-cluster-gpl

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `loginId` varchar(20) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `emailId` varchar(45) DEFAULT NULL,
  `passWord` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `onBoard` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `layer1` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `layer2` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `seniority` int(11) DEFAULT NULL,
  `totalHrs` float DEFAULT '0',
  `overtimeHrs` float DEFAULT '0',
  `usedSwapHrs` float DEFAULT '0',
  `annualLeaveHrs` float DEFAULT '0',
  `marriageLeaveHrs` float DEFAULT '0',
  `maternityLeaveHrs` float DEFAULT '0',
  `menustralLeaveHrs` float DEFAULT '0',
  `sickLeaveHrs` float DEFAULT '0',
  `specialLeaveHrs` float DEFAULT '0',
  `unusedSwapHrs` float DEFAULT '0',
  `unusedAnnualLeaveHrs` float DEFAULT '0',
  `personalLeaveHrs` float DEFAULT '0',
  `abnormalHrs` float DEFAULT '0',
  `salary` int(11) DEFAULT '0',
  `grossSalary` int(11) DEFAULT '0',
  `leaves` int(11) DEFAULT '0',
  `totalDeductions` int(11) DEFAULT '0',
  `net` int(11) DEFAULT '0',
  `bankName` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `accountNo` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `access` varchar(5) DEFAULT NULL,
  `lastUpdated` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`loginId`),
  KEY `loginIdPassowrdIndex` (`loginId`,`passWord`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-30 15:40:54
