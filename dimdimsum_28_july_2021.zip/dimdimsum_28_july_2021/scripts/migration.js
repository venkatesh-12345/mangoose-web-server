//  insert into notifications (title,dateTime,endTime,recepients,extension,type) select title,FROM_UNIXTIME(startTime/1000) as dateTime,FROM_UNIXTIME(endTime/1000) as endTime,groups as recepients,extension,"bulletin" as type from bulletinBoard;
var config=require('../initConf');
var knox = require('knox').createClient(config.S3);
var CP=require('../middleware/sql')

CP.query('select *,concat("/bulletin/",title,"_",startTime,"_",endTime,"_",groups,"_",extension) as path from bulletinBoard',[],function(err,res){
	console.log(res);
	CP.query('select * from notifications where type="bulletin"',[],function(err,res1){
		var count=0;
		console.log(res.length,res1.length)
		var resObj={},res1Obj={};
		for(var i in res){
			resObj[res[i].title+res[i].startTime+res[i].endTime+res[i].groups+res[i].extension]=res[i];
		}
		for(var i in res1){
			res1Obj[res1[i].title+(new Date(res1[i].dateTime)-0)+(new Date(res1[i].endTime)-0)+res1[i].recepients+res1[i].extension]=res1[i];

		}
		for(var i in resObj){
			if(res1Obj[i]){
				count++;
				console.log(resObj[i].path,res1Obj[i].mes_no+'.'+res1Obj[i].extension,count);
				knox.copyFile(resObj[i].path, '/bulletin/'+res1Obj[i].mes_no+'.'+res1Obj[i].extension, function(err, res){
					console.log(err,res)
				});
			}
		}
	})
} )

//update notifications set sent=true where dateTime<NOW();