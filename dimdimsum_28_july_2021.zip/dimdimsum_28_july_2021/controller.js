var CP=require('./middleware/sql')
var MS=require('./middleware/mssql.js')
var notification=require('./notification');
var columns=require('./util/columns')
var email=require('./emailDispatcher')
var config = require("./initConf").get();
var s3prefix=config.S3.prefix
var constants=require('./util/constants.js');
var save=require('./saveUploaded.js');
var fs=require('fs');
var queries=constants.queries;
var department=require('./util/departments.json').departments
var errors=constants.errors;
constants=constants.constants;
var foodType=constants.DAY_FOOD_TYPE
var groupToRes=constants.GROUP_TO_RESTAURANT
var newGroupToRes=constants.NEW_GROUP_TO_RESTAURANT;
var daysOfMonth=constants.MONTH_TO_DAYS
var revRename=constants.GROUP_TO_RES_NEW_REV
var createQuery=function(table,condition){
    var change=[];
    var col=columns[table];
    for(var key in col)
        change.push(key+' as '+col[key]);
    return 'select '+change.join(',')+' from '+table+' where EMPLOYEE_NO=@LOGINID';
}
var storeRegistration=function(data,response,res){
    var token=Math.random().toString(36).split('.')[1];
    if(token){
        CP.query(queries.DELETE_OLD_REGIDS,[data.regid],function(err,res1){
            CP.query(queries.INSERT_TOKEN,[data.username,token,data.regid,res[0].COMPANY_CNAME?res[0].COMPANY_CNAME+'|'+res[0].DEPARTMENT_CNAME:'testGroup|testSubGroup',res[0].COMPANY_CNAME?res[0].JOB_CNAME:'testJob'],function(err,res){
                sendResponse(response,codes.SUCCESS,{token:token})
            })
        })
    }
    else
        sendResponse(response,codes.AUTH_ERROR,{success:false});
}

var login = function(data, response) {
    var params=[{ name: 'USER', value: data.username},{ name: 'PASS', value: data.password}]
    MS.query(queries.MS_LOGIN,params,true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0)
            storeRegistration(data,response,res.recordset);
        else{
            CP.query(queries.LOGIN, [data.username,data.password],function(err,res){
                if(!err&&res&&res.length>0){
                    storeRegistration(data,response,res);
                }
                else 
                    sendResponse(response,codes.AUTH_ERROR,{success:false})
            })
        }
    })
}
var groups=function(data,response){
    var group={'點點心股份有限公司':['董事總經理室','人資部','行銷部','財務部','採購部','工程部','營運服務','營運廚務','資運倉儲組','資運生產組','點點心微風信義店服務組','點點心微風信義店廚務組','點點心微風北車店服務組','點點心微風北車店廚務組','點點心新光台中店服務組','點點心新光台中店廚務組','點點心巨城新竹店服務組','點點心巨城新竹店廚務組','興記菜館微風南山店服務組','興記菜館微風南山店廚務組','太興燒味微風北車店服務組','太興燒味微風北車店廚務組','太興燒味ATT信義店服務組','太興燒味ATT信義店廚務組' ],'testGroup':['testSubGroup']}
    sendResponse(response,codes.SUCCESS,{success:true,groups:['台灣太興餐飲股份有限公司','興記菜館有限公司','點點心股份有限公司','testGroup']})
}
var saveNotification = function(data, response) {
        data.type=constants.NOTI;
        if(!data.recepients&&!data.jobs&&!data.allIds)
            return sendResponse(res,codes.INVALID_DATA,{success:false})
        if(data.sendNow=='true'&&!data.repetition){
            CP.query(queries.INSERT_SEND_NOW,[new Date(),data.message,data.recepients,data.title,data.senderTitle,data.name,data.company,true,data.repetition,data.dateList,data.extension,data.jobs?data.jobs:'',data.allIds?data.allIds:''],function(err,result){
                if(!err&&result)
                    data.mes_no=result.insertId;
                notification.send([data],function(code,result1){
                    result1.mes_no=data.mes_no;
                    if(data.filename){
                        data.path=constants.NOTI+'/'+data.mes_no+'.'+data.extension;
                        save.addEvent(data)
                    }
                    sendResponse(response,codes[code],result1)
                });     
            })
              
        }else {
            notification.sendToServer(data,function(err,result){
                if(err)
                    sendResponse(response,codes.DATABASE_ERROR,{success:false})
                else {
                    if(data.filename){
                        data.path=constants.NOTI+'/'+result.id+'.'+data.extension;
                        save.addEvent(data)
                    }
                    sendResponse(response,codes.SUCCESS,{success:true,mes_no:result.id})
                }
            })
        }
}
var signup=function(data,response){
    CP.query(queries.SIGN_UP_EMAIL_CHECK,[data.emailID],function(err,res){
        if(err)
            sendResponse(response,codes.DATABASE_ERROR,{success:false});
        else if(res.length>0)
            sendResponse(response,codes.SUCCESS,{success:false,Reason:errors[1],ReasonCode:1});
        else{
            CP.query(queries.NEW_USER,[data.username,data.emailID,data.password,new Date(0)],function(err,res){
                if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false});   
                sendResponse(response,codes.SUCCESS,{success:true});
            })
        }
    })
}
var forgotpassword=function(data,response){
    var password=Math.random().toString(16).substring(2,10);
    CP.query(queries.RESET_PASS,[password,data.emailID],function(err,res){
        if(err)       
            return sendResponse(response,codes.DATABASE_ERROR,{success:false});
        else if(res.affectedRows==0)
            return   sendResponse(response,codes.SUCCESS,{success:false,Reason:errors[2],ReasonCode:2});
        email.sendEmail(password,data.emailID,function(err,res){
            if(err)
                sendResponse(response,codes.DATABASE_ERROR,{success:false});
            sendResponse(response,codes.SUCCESS,{success:true});
        })
    })
}
var setCount=function(data,response){
    CP.query(queries.SET_BADGE,[data.token],function(err,res){
        sendResponse(response,codes.SUCCESS,{success:true})
    })
}
var logout=function(data,response){
    CP.query(queries.LOGOUT,[data.loginId,data.regid],function(err,res){
        sendResponse(response,codes.SUCCESS,{success:true})
    })
}
var profile=function(data,response){
    if(!data.loginId)
        return sendResponse(response,codes.INVALID_DATA,{success:true})
    var params=[{ name: 'LOGINID', value: data.loginId}]
    MS.query(queries.PROFILE,params,true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            res=res.recordset
            CP.query(queries.GET_ACCESS,[res[0].employeeID],function(err,res2){
                if(!err&&res2&&res2.length>0){
                    res[0].access=res2[0].access;
                    res[0].fullAccess=res2[0].fullAccess
                }
                if(data.notifiCount==0)
                    return sendResponse(response,codes.SUCCESS,{success:true,details:res[0],departments:department,expire:data.expire,buildVersion:config.BuildVersion,count:data.notifiCount})
                var date=new Date(new Date()-0+(8*60*60*1000))
                date=new Date(date-(date%(24*60*60*1000)))
                date=new Date(date-8*60*60*1000)
                CP.query(queries.NOTI_HISTORY_LIMIT,['%'+res[0].company+'%',res[0].employeeID,'%'+res[0].title+'%','%'+res[0].employeeID+'%',date],function(err,res3){
                    if(data.notifiCount>res3.length){
                        data.notifiCount=res3.length;
                        CP.query(queries.SET_BADGE_COUNT,[data.notifiCount,data.token],function(err,res4){})
                    }
                    sendResponse(response,codes.SUCCESS,{success:true,details:res[0],departments:department,expire:data.expire,buildVersion:config.BuildVersion,count:data.notifiCount,history:res3})
                })
            })
        }
        else if(!err){
            sendResponse(response,codes.SUCCESS,{success:true,details:{employeeID:data.loginId,department:'testGroup',company:'testSubGroup',name:'testUser',boardDate:'20001010',title:'tester',seniority:1,restrictSalary:true,fullAccess:data.loginId=='15100111'?'0,0,0,0,0,0,1':null},departments:department,expire:data.expire,count:data.notifiCount})
        }
        else
            sendResponse(response,codes.SUCCESS,{success:false,Reason:errors[5],ReasonCode:5})
    })
}

var list=function(data,response){
    var params=[]
    if(data.loginId!='151001'&&!data.webui)
        return sendResponse(response,codes.INVALID_DATA,{success:true})
    MS.query(queries.EMPLOYEE_LIST,params,true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            res=res.recordset
            CP.query(queries.GET_ALL_ACCESS,[],function(err,res1){
                if(!err&&res1&&res1.length>0){
                   var  accessList={}
                   for(var i in res1){
                    accessList[res1[i].loginId]=res1[i].fullAccess
                   }
                   for(var i in res){
                        if(accessList[res[i].EMPLOYEE_NO])
                            res[i].fullAccess=accessList[res[i].EMPLOYEE_NO]
                   }
                }
                
                CP.query(queries.GET_ALL_COUNT,[],function(err,res2){
                    var countData = {}
                    if(!err){
                        for(var i in res2){
                            countData[res2[i].accessNo]={ accessNo:res2[i].accessNo  , idCount: res2[i].idCount , departmentCount: res2[i].departmentCount , jobCount: res2[i].jobCount }
                        }
                        for(var j=0 ; j<21 ; j++){
                            if(!countData[j]) countData[j]= { accessNo: j , idCount: 0 , departmentCount: 0 , jobCount: 0 }
                        }
                    }
                    sendResponse(response,codes.SUCCESS,{success:true,list:res,counts:countData})
                })
            })
        }
        else if(!err){
            sendResponse(response,codes.SUCCESS,{success:true,list:[]})
        }
        else
            sendResponse(response,codes.SUCCESS,{success:false,Reason:errors[5],ReasonCode:5})
    })
}
var notificationChangeAccess=function(data,response){
    CP.query(queries.ACCESS,[data.employeeID,data.access],function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        return sendResponse(response,codes.SUCCESS,{success:true});
    })
}
var notificationList=function(data,response){
    CP.query(queries.NOTI_LIST,[],function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        sendResponse(response,codes.SUCCESS,{success:true,history:res});
    })
}
var notificationHistory=function(data,response){
    CP.query(queries.NOTI_HISTORY,['%'+data.group+'%',data.loginId,'%'+data.job+'%','%'+data.loginId+'%'],function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        sendResponse(response,codes.SUCCESS,{success:true,history:res});
    })
}
var notificationDelete=function(data,response){
    CP.query(queries.DELETE_NOTI,[data.mes_no],function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        sendResponse(response,codes.SUCCESS,{success:true,history:res});
    })
}
var employeeBasicInfo=function(data,response){
    var params=[{ name: 'EMPLOYEEID', value: data.employeeID}]
    MS.query(queries.BASIC_INFO,params,true,function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        if(res&&res.recordset&&res.recordset.length==0)
            return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:4,Reason:errors[4]});
        res=res.recordset
        CP.query(queries.GET_ACCESS,[data.employeeID],function(err,res2){
            res[0].access=(!err&&res2&&res2.length>0)?res2[0].access:'0';
            res[0].success=true
            sendResponse(response,codes.SUCCESS,res[0]);
        })
    })
}

var getAccess=function(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.employeeID],function(err,res){
        if(!err&&res&&res.length>0)
            return sendResponse(response,codes.SUCCESS,res[0]);
        else if(!res||res.length==0)
            return sendResponse(response,codes.SUCCESS,{fullAccess:null});
        else if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            
    })
}
var setAccess=function(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.employeeID],function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        var access;
        if(res&&res.length>0&&res[0].fullAccess)
            access=res[0].fullAccess.split(',');
        else
            access=[0,0,0,0,0,0,0]
        var logs='',emailMessage='',newAccess=data.access.split(','),chinese='';
        for(var i in access){
            var log;
            if(access[i]!=newAccess[i])
                log=new Date(new Date()-1+8*60*60*1000).toJSON().replace(/T/,' ').substr(0,19)+','+data.loginId+(newAccess[i]=='1'?' added ':' deleted ')+data.employeeID+"'s "+constants.ACCESS_TYPE[i]+' access from '+(data.webui?'Webui':'App')+'.'
            else 
                continue;
            if(newAccess[i]=='1'){
                chinese+=new Date(new Date()-1+8*60*60*1000).toJSON().replace(/T/,' ').substr(0,19)+','+data.loginId+(newAccess[i]=='1'?' 新增 ':' 刪除 ')+data.employeeID+"'s "+constants.ACCESS_CHINESE_TYPE[i]+' from '+(data.webui?'Webui':'App')+'.<br>'
                emailMessage+=log+'<br>'
            }
            logs+=log+'\n'
        }
        fs.appendFile('./access.log',logs,function(err,res){})
        if(emailMessage)
            email.sendAcccessEmail(emailMessage+chinese,function(err,res){})
        if(data.loginId!='151001')
            return sendResponse(response,codes.INVALID_DATA,{success:true})
        CP.query(queries.SET_FULL_ACCESS,[data.access,data.employeeID],function(err,res){
            if(!err&&res)
                return sendResponse(response,codes.SUCCESS,{success:true});
            else if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
                
        })
    })
}

var setGroupAccess=function(data,response){
    var params=[{ name: 'GROUP', value: data.group}]
    if(data.loginId!='151001')
        return sendResponse(response,codes.INVALID_DATA,{success:true})
    MS.query(queries.GET_GROUP_EMPLOYEE,params,true,function(err,res){
        if(err||!res||!res.recordset||res.recordset.length==0)
            return sendResponse(response,codes.SUCCESS,{success:false,Reason:errors[8],ReasonCode:8});
        var loginIds=[]
        res=res.recordset;
        var accessList={}
        for(var i in res){
            loginIds.push(res[i].EMPLOYEE_NO)
            accessList[res[i].EMPLOYEE_NO]={access:[0,0,0,0,0,0,0],change:true}
            accessList[res[i].EMPLOYEE_NO].access[data.accessNo]=data.access
        }
        CP.query(queries.GET_MULTIPLE_ACCESS,[loginIds],function(err,res1){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            for(var i in res1){
                if(res1[i].fullAccess){
                    var access=res1[i].fullAccess.split(',')
                    if(access[data.accessNo]==data.access)
                        accessList[res1[i].loginId].change=false
                    access[data.accessNo]=data.access
                    accessList[res1[i].loginId].access=access
                }
            }

            var logs='',emailMessage='',newAccess=data.access.split(',')
            var params=[]
            console.log(accessList)
            for(var i in accessList){
                if(accessList[i].change){
                    var log=new Date(new Date()-1+8*60*60*1000).toJSON().replace(/T/,' ').substr(0,19)+','+data.loginId+(data.access=='1'?' added ':' deleted ')+i+"'s "+constants.ACCESS_TYPE[data.accessNo]+' access from '+(data.webui?'Webui':'App')+'.'
                    if(data.access=='1')
                        emailMessage+=log+'<br>'
                    logs+=log+'\n'
                }
                params.push([accessList[i].access.join(','),i])
            }
            fs.appendFile('./access.log',logs,function(err,res){})
            if(emailMessage)
                email.sendAcccessEmail(emailMessage,function(err,res){})
            if(data.loginId!='151001')
                return sendResponse(response,codes.INVALID_DATA,{success:true})
            CP.query(queries.SET_MULTIPLE_ACCESS,[params],function(err,res){
                if(!err&&res)
                    return sendResponse(response,codes.SUCCESS,{success:true});
                else if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false})
                    
            })
        })
    })
}


var bulletinBoardList=function(data,response){
    contoroller.list(data,function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        if(res.length==0)
            return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:6,Reason:errors[6]});
        else
            return sendResponse(response,codes.SUCCESS,{success:true,list:res});
    })
}
var updateRegID=function(data,response){
    CP.query(queries.UPDATE_REG_ID,[data.newID,data.token],function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        if(res.affectedRows==0)
            return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:7,Reason:errors[7]});
        sendResponse(response,codes.SUCCESS,{success:true});
    })
}

fs.appendFile('./storeUpdateInfo.csv','date , previous_version , current_version , token , REGID_IN_CLOUD , regid , Remember_Me\n',function(err,res){console.log(err,res)})
fs.appendFile('./notiTestResult.csv','date , token , REGID_IN_CLOUD , regid , success, Remember_Me\n',function(err,res){})
var storeUpdateInfo=function(data,response){
    if(data){
        fs.appendFile('./storeUpdateInfo.csv',(new Date()-0)+' , '+data.previous_version+' , '+data.current_version+' , '+data.token+' , '+data.REGID_IN_CLOUD+' , '+data.regid+' , '+data.Remember_Me+'\n',function(err,res){})
    }
    sendResponse(response,codes.SUCCESS,{success:true});
}
var notiTestResult=function(data,response){
    if(data){
        fs.appendFile('./notiTestResult.csv',(new Date()-0)+' , '+data.token+' , '+data.REGID_IN_CLOUD+' , '+data.regid+' , '+data.success+' , '+data.Remember_Me+'\n',function(err,res){})
    }
    sendResponse(response,codes.SUCCESS,{success:true});
}
var checkNull=function(value,digit){
    return (value?value:0)
}
function dayRev(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if((data.company&&access[2]=='0')||(!data.company&&access[4]=='0'))
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var day=data.date;
        var date=new Date(day);
        var params=[{ name: 'DATE0', value: day}]
        var params2=[{ name: 'DATE', value: day.replace(/\//g, "")}]
        var column=['@DATE0']
        var column2=[]
        if(data.company){
            var companies=data.company.split(',');
            for(var i in companies){
                params.push({name:'GROUP'+i,value:constants.NEW_GROUP_TO_RESTAURANT[companies[i]]})
                params2.push({name:'GROUP'+i,value:companies[i]})
                column2.push('@GROUP'+i);
            }
        }
        for(var i=0;i<4;i++){
            date=new Date(date-(7*24*60*60*1000));
            params.push({ name: 'DATE'+(i+1),  value: date.getFullYear()+'/'+(date.getMonth()+1)+'/'+date.getDate()})
            column.push('@DATE'+(i+1))
        }
        MS.query(queries.GET_DAYREV_START+column.join(',')+(data.company?queries.GET_DAYREV_GROUP+column2.join(','):"")+queries.GET_DAYREV_END,params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            var hotels={}
            if(!data.company){
                hotels['當日點點心']={serviceMin:0,kitchenMin:0};
                hotels['當日太興']={serviceMin:0,kitchenMin:0};
                var dimdimsumHotel=constants.HOTEL_DIMDIMSUM
                var taxingHotel=constants.HOTEL_TAXING
            }
            res=res.recordset
            var total={serviceMin:0,kitchenMin:0}
            for(var i in res){
                if(!hotels[revRename[res[i].N03]]&&res[i].N03!='全公司'&&res[i].N03!='')
                    hotels[revRename[res[i].N03]]={serviceMin:0,kitchenMin:0};
                if(res[i].N03=='全公司')
                    continue;
                var hotel=res[i].N03=='全公司'||res[i].N03==''?total:hotels[revRename[res[i].N03]];
                if(res[i].date==day){
                    if(res[i].N04+res[i].N05){
                        hotel[foodType[res[i].N02]]=res[i].N04+res[i].N05;
                        if(!total[foodType[res[i].N02]])
                            total[foodType[res[i].N02]]=0
                        total[foodType[res[i].N02]]+=res[i].N04+res[i].N05;
                    }
                    if(res[i].N02=='Z'){
                        for(var key in columns.DAYREV){
                            if(res[i][key]){
                                hotel[columns.DAYREV[key]]=res[i][key];
                                if(!total[columns.DAYREV[key]])
                                    total[columns.DAYREV[key]]=0
                                total[columns.DAYREV[key]]+=res[i][key];
                            }
                        }
                    }
                }
                else{
                    if(!hotel.previous)
                        hotel.previous={}
                    if(!total.previous)
                        total.previous={}
                    if(res[i].N02=='Z'&&(res[i].N04+res[i].N05)){
                        hotel.previous[res[i].date]=res[i].N04+res[i].N05;
                        if(!total.previous[res[i].date])
                            total.previous[res[i].date]=0
                        total.previous[res[i].date]+=res[i].N04+res[i].N05;
                    }
                }
            }
            MS.query(queries.PERFORMANCE_DAY_START+(data.company?queries.PERFORMANCE_DAY_GROUP+column2.join(',')+')':"")+queries.PERFORMANCE_DAY_END,params2,true,function(err,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    var minutesPassed=(new Date()-new Date(data.date))>86400000? 500:parseInt((new Date()%(24*60*60*1000))/(60*1000))
                    res1=res1.recordset
                    for(var i in res1){
                        if(hotels[revRename[newGroupToRes[res1[i].layer]]]&&(res1[i].SIGNIN||res1[i].SIGNOUT)){
                            var hotel=hotels[revRename[newGroupToRes[res1[i].layer]]]
                            var type=(constants.SERVICE_GROUPS.indexOf(res1[i].layer)>=0?'service':'kitchen')+'Min'
                            if(res1[i].SIGNIN&&res1[i].SIGNOUT)
                                hotel[type]+=parseInt((res1[i].SIGNOUT-res1[i].SIGNIN)/(60*1000));
                            else if(!res1[i].SIGNOUT)
                                hotel[type]+=(new Date()-res1[i].SIGNIN)>86400000?480:parseInt(((new Date()-0+8*60*60*1000)-res1[i].SIGNIN)/(60*1000));  
                            if(res1[i].overTime)
                                hotel[type]+=res1[i].overTime*60
                            if(res1[i].leaves)
                                hotel[type]-=res1[i].leaves*60
                        }
                    }
                }
                var dayavgs = [columns.DAYREV["N12"], columns.DAYREV["N14"], columns.DAYREV["N08"], columns.DAYREV["N09"], columns.DAYREV["N26"], columns.DAYREV["N27"],'service','kitchen']
                for(var i in hotels){
                    var hotel=hotels[i]
                    hotel.service=(checkNull(hotel['Internal Visitors'])+checkNull(hotel['Takeaway/transaction pen']))*60/(hotel.serviceMin?hotel.serviceMin:1);
                    hotel.kitchen=hotel['Total TurnOver']*60/hotel.kitchenMin
                    total.serviceMin+=hotel.serviceMin;
                    total.kitchenMin+=hotel.kitchenMin
                    if(!data.company){
                        for(var j in hotel){
                            if(dimdimsumHotel.indexOf(i) >= 0||taxingHotel.indexOf(i) >= 0){
                                var hotelNew=dimdimsumHotel.indexOf(i) >= 0?hotels['當日點點心']:hotels['當日太興']
                                if(j!='previous'){
                                    if(!hotelNew[j])
                                        hotelNew[j]=0
                                    hotelNew[j] += hotel[j]
                                }else{
                                    if(!hotelNew.hasOwnProperty(j)){
                                        hotelNew[j]={}
                                        for(var k in hotel[j])
                                            hotelNew[j][k]=0
                                    }
                                    for(var k in hotel[j])
                                        hotelNew[j][k]+=hotel[j][k]
                                }
                            }

                        }
                    }
                }
           for (var i in hotels) {
                    if (i == '當日點點心' || i == '當日太興') {
                        var count = i=='當日點點心'  ? 6 : 2
                        for (var j in hotels[i]) {
                            if (dayavgs.indexOf(j) >= 0)
                                hotels[i][j] = hotels[i][j] / count
                        }
                    }
                }
                var result={success:true,hotels:hotels}
                total.service=(checkNull(total['Internal Visitors'])+checkNull(total['Takeaway/transaction pen']))*60/(total.serviceMin?total.serviceMin:1);
                total.kitchen=total['Total TurnOver']*60/total.kitchenMin
                result['全公司']=total
                return sendResponse(response,codes.SUCCESS,result);

            })
        });
    });
}

function monRev(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if((data.company&&access[2]=='0')||(!data.company&&access[4]=='0'))
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var mon=data.month
        var date2,month1,allYearMonth=[]
        var params=[{ name: 'MON0', value: mon}]
        var coloumn2=['@MON0','@MON1','@MON2']
        var leap=0;
        var year=parseInt(mon.substring(0,4))
        var month=parseInt(mon.substring(4));
        if(month==2&&year%4==0&&(year%100!=0||(year%100==0&&year&400==0)))
            leap=1
        var currentDate=new Date(new Date()-0+8*60*60*1000)
        var old=mon.substring(4)!=(currentDate.getUTCMonth()+1) 
        var oldYear=mon.substr(0,4)!=currentDate.getUTCFullYear()
        var currentDays=currentDate.getUTCDate()
        var workingHourDays=new Date(currentDate-150*60*1000).getUTCDate()-1
        var currentmonth = currentDate.getUTCMonth() + 1;
        params.push({ name: 'MON1', value:((month>1?year:year-1)+(month>1&&month<=10?'0':'')+(month>1?month-1:12))});
        params.push({ name: 'MON2',  value:((year-1)+(month<10?'0':'')+month)});
        var params2=[{ name: 'DATE0', value: year+"/01/01"},{ name: 'DATE1',value: year+"/"+(month<10?'0':'')+month+"/"+(old?daysOfMonth[month]+leap:workingHourDays)}]
        var column=[]
        if(!data.company) {
            for (i = 1; i <= month; i++) {
                month1 = i < 10 ? ('0' + i) : i
                date2 = year.toString() + month1
                allYearMonth.push(date2)
                if (date2 != params[0].value) {
                    params.push({ name: 'MON' + (i + 2), value: date2 })
                    coloumn2.push('@MON' + (i + 2))
                }
            }
        }
        if (data.company) {
            var companies = data.company.split(',');
            for (var i in companies) {
                params.push({ name: 'GROUP' + i, value: constants.NEW_GROUP_TO_RESTAURANT[companies[i]] })
                params2.push({ name: 'GROUP' + i, value: companies[i] })
                column.push('@GROUP' + i);
            }
        }
        MS.query(queries.GET_MONREV_START + coloumn2.join(',') + ")" + (data.company ? queries.GET_MONREV_GROUP + column.join(',') + ')' : "") + queries.GET_MONREV_END, params, null, function (err, res) {
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res=res.recordset
            var hotels={}
            var yearHotels={}
            if(!data.company){
                hotels['年度點點心']={serviceMin:0,kitchenMin:0};
                hotels['年度太興']={serviceMin:0,kitchenMin:0};
                var dimdimsumHotel=constants.HOTEL_DIMDIMSUM
                var taxingHotel=constants.HOTEL_TAXING
            }
            for(var i in res){
                if(!hotels[revRename[res[i].M02]])
                        hotels[revRename[res[i].M02]]={serviceMin:0,kitchenMin:0};
                if(!yearHotels[revRename[res[i].M02]])
                        yearHotels[revRename[res[i].M02]]={serviceMin:0,kitchenMin:0};
                if(res[i].M00==mon){
                    if(revRename[res[i].M02]!='全公司'){
                        var hotel=hotels[revRename[res[i].M02]]
                        var total=hotels['全公司']
                        if(res[i].M28=='Z'){
                            for(var key in columns.MONREV){
                                if(res[i][key]!='0'){
                                    if(total){
                                        if(!total[columns.MONREV[key]])
                                            total[columns.MONREV[key]]=0
                                        total[columns.MONREV[key]]=+res[i][key]
                                    }
                                    hotel[columns.MONREV[key]]=res[i][key]
                                }
                            }
                            if(total && !total.Discount){
                                total.Discount=0;
                                total['Employee Spend Amount']=0
                                total['Total TurnOver']=0
                                total.estimated=0
                            }
                            if(parseInt(res[i].M15)+parseInt(res[i].M16)){
                                hotel['Discount']=parseInt(res[i].M15)+parseInt(res[i].M16);
                                if(total)
                                    total['Discount']+=parseInt(res[i].M15)+parseInt(res[i].M16);
                            }
                            if(parseInt(res[i].M18)+parseInt(res[i].M19)){
                                hotel['Employee Spend Amount']=parseInt(res[i].M18)+parseInt(res[i].M19);
                                if(total)
                                    total['Employee Spend Amount']+=parseInt(res[i].M18)+parseInt(res[i].M19);
                            }
                            if(parseInt(res[i].M03)+parseInt(res[i].M04)){
                                hotel['Total TurnOver']=parseInt(res[i].M03)+parseInt(res[i].M04);
                                if(total)
                                    total['Total TurnOver']+=parseInt(res[i].M03)+parseInt(res[i].M04);
                            }
                            hotel['estimated']=old?hotel['Total TurnOver']:Math.round(hotel['Total TurnOver']*(daysOfMonth[month]+leap)/(workingHourDays?workingHourDays:1));
                            if(total)
                                total['estimated']+=old?hotel['Total TurnOver']:Math.round(hotel['Total TurnOver']*(daysOfMonth[month]+leap)/(workingHourDays?workingHourDays:1));
                        }else{
                            if(total&&!total[foodType[res[i].M28]])
                                total[foodType[res[i].M28]]=0
                            hotel[foodType[res[i].M28]]=parseInt(res[i].M03)+parseInt(res[i].M04);
                            if(total)
                                total[foodType[res[i].M28]]+=parseInt(res[i].M03)+parseInt(res[i].M04);
                        }
                    }
                }else if(res[i].M28=='Z'){
                    if(parseInt(res[i].M03)+parseInt(res[i].M04) && ((res[i].M00 == params[1].value)||(res[i].M00 == params[2].value))){
                        hotels[revRename[res[i].M02]][res[i].M00==params[1].value?'lastMonth':'last year same month']=parseInt(res[i].M03)+parseInt(res[i].M04);
                    }
                }
                if (allYearMonth.indexOf(res[i].M00) >= 0) {
                    var yearHotel=yearHotels[revRename[res[i].M02]]
                    for(var key in columns.MONREV){
                        if(!yearHotel[columns.MONREV[key]])
                            yearHotel[columns.MONREV[key]]=0
                        if(res[i][key]!='0')
                            yearHotel[columns.MONREV[key]] += parseFloat(res[i][key])
                    }    
                    if(!yearHotel['Discount'])
                        yearHotel['Discount']=0
                    if(!yearHotel['Employee Spend Amount'])
                        yearHotel['Employee Spend Amount']=0
                     if(parseInt(res[i].M15)+parseInt(res[i].M16))
                        yearHotel['Discount']+=parseInt(res[i].M15)+parseInt(res[i].M16);
                    if(parseInt(res[i].M18)+parseInt(res[i].M19))
                        yearHotel['Employee Spend Amount']+=parseInt(res[i].M18)+parseInt(res[i].M19);
                }
            }
            MS.query(queries.PERFORMANCE_MONTH_START+(data.company?queries.PERFORMANCE_MONTH_GROUP+column.join(',')+')':'')+queries.PERFORMANCE_MONTH_END,params2,true,function(err,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    var minutesPassed=(new Date()-new Date(data.date))>86400000? 500:parseInt((new Date()%(24*60*60*1000))/(60*1000))
                    res1=res1.recordset
                    for(var i in res1){
                        var month_in=new Date(res1[i].SIGNIN).toISOString().substr(0,7).replace(/-/,'')
                        if(hotels[revRename[newGroupToRes[res1[i].layer]]]&&(res1[i].SIGNIN||res1[i].SIGNOUT) && (month_in == mon)){
                            var hotel=hotels[revRename[newGroupToRes[res1[i].layer]]]
                            var type=(constants.SERVICE_GROUPS.indexOf(res1[i].layer)>=0?'service':'kitchen')+'Min'
                            if(res1[i].SIGNIN&&res1[i].SIGNOUT)
                                hotel[type]+=parseInt((res1[i].SIGNOUT-res1[i].SIGNIN)/(60*1000));
                            else if(!res1[i].SIGNOUT)
                                hotel[type]+=(new Date()-res1[i].SIGNIN)>86400000?480:parseInt(((new Date()-0+8*60*60*1000)-res1[i].SIGNIN)/(60*1000));
                            if(res1[i].overTime)
                                hotel[type]+=res1[i].overTime*60
                            if(res1[i].leaves){
                                hotel[type]-=res1[i].leaves*60
                            }
                        }
                        if(yearHotels[revRename[newGroupToRes[res1[i].layer]]]&&(res1[i].SIGNIN||res1[i].SIGNOUT)){
                            var yearHotel=yearHotels[revRename[newGroupToRes[res1[i].layer]]]
                            var yearType=(constants.SERVICE_GROUPS.indexOf(res1[i].layer)>=0?'service':'kitchen')+'Min'
                            if(res1[i].SIGNIN&&res1[i].SIGNOUT)
                                yearHotel[yearType]+=parseInt((res1[i].SIGNOUT-res1[i].SIGNIN)/(60*1000));
                            else if(!res1[i].SIGNOUT)
                                yearHotel[yearType]+=(new Date()-res1[i].SIGNIN)>86400000?480:parseInt(((new Date()-0+8*60*60*1000)-res1[i].SIGNIN)/(60*1000));
                            if(res1[i].overTime)
                                yearHotel[yearType]+=res1[i].overTime*60
                            if(res1[i].leaves){
                                yearHotel[yearType]-=res1[i].leaves*60
                            }

                        }

                    }
                }
                var serviceMin=0,kitchenMin=0;
                var monavgs=[columns.MONREV['M11'],columns.MONREV['M13'],columns.MONREV['M21'],columns.MONREV['M07'],columns.MONREV['M08'],columns.MONREV['M25'],columns.MONREV['M26'],'service','kitchen']
                for(var i in hotels){
                    var hotel=hotels[i]
                    hotel.service=(checkNull(hotel['Internal / Visitors'])+checkNull(hotel['Takeaway/transaction pen']))*60/(hotel.serviceMin?hotel.serviceMin:1);
                    hotel.kitchen=hotel['Total TurnOver']*60/hotel.kitchenMin
                    serviceMin+=hotel.serviceMin;
                    kitchenMin+=hotel.kitchenMin
                }
                for(var i in yearHotels){
                    var yearHotel=yearHotels[i]
                    yearHotel['Total TurnOver']=yearHotel['Internal sales']+yearHotel['Take-away turnover']
                    yearHotel.service=(checkNull(yearHotel['Internal / Visitors'])+checkNull(yearHotel['Takeaway/transaction pen']))*60/yearHotel.serviceMin;
                    yearHotel.kitchen=yearHotel['Total TurnOver']*60/yearHotel.kitchenMin
                    if(!data.company){
                        for (var j in yearHotel) {
                            if (dimdimsumHotel.indexOf(i) >= 0 || taxingHotel.indexOf(i) >= 0) {
                                var hotelNew = dimdimsumHotel.indexOf(i) >= 0 ? hotels['年度點點心'] : hotels['年度太興']
                                if (j != 'previous') {
                                    if (!hotelNew[j])
                                        hotelNew[j] = 0
                                    hotelNew[j] += yearHotel[j]
                                } else {
                                    if (!hotelNew[j]) {
                                        hotelNew[j] = {}
                                        for (var k in yearHotel[j])
                                            hotelNew[j][k] = 0
                                    }
                                    for (var k in yearHotel[j])
                                        hotelNew[j][k] = yearHotel[j][k]
                                }
                            }
                        }
                    }
                }
                for(var i in hotels){
                    if (i == '年度點點心' || i == '年度太興') {
                        var count = i== '年度點點心' ? 6 : 2
                        var count2 = !old&&!oldYear ?(allYearMonth.length-1+(currentDays/daysOfMonth[month])) :allYearMonth.length
                        for (var j in hotels[i]) {
                            if (monavgs.indexOf(j) >= 0)
                                hotels[i][j] = hotels[i][j] /  (count*(j=='service'||j=='kitchen'?1:count2))
                        }
                    }
                }
                var hotel=hotels['全公司'];
                if(hotel){
                    hotel.service=(checkNull(hotel['Internal / Visitors'])+checkNull(hotel['Takeaway/transaction pen']))*60/serviceMin;
                    hotel.kitchen=hotel['Total TurnOver']*60/kitchenMin
                }
                return sendResponse(response,codes.SUCCESS,{success:true,hotels:hotels});
            })
        });
    });
}
function foodQty(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[1]=='0'&&access[3]=='0')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var month=data.month
        var mon=parseInt(month.substring(4));
        var year=parseInt(month.substring(0,4))
        var currentDate=new Date(new Date()-0+8*60*60*1000)
        var leap=0;
        if(mon==2&&year%4==0&&(year%100!=0||(year%100==0&&year&400==0)))
            leap=1
        var old=mon!=(currentDate.getUTCMonth()+1) 
        var params=[{ name: 'MON',  value: month},{name:'GROUP',value:groupToRes[data.group]}]
        console.log(old,mon,year)
        MS.query(queries.GET_FOODQTY,params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res=res.recordset
            var hotelName;
            var meals={}
            for(var i in res){
                if(!hotelName)
                    hotelName=res[i].Q04;
                if(!foodType[res[i].Q03])
                    continue;
                if(!meals[res[i].Q05])
                    meals[res[i].Q05]={};
                var meal=meals[res[i].Q05]
                if(!meal[foodType[res[i].Q03]])
                    meal[foodType[res[i].Q03]]={};
                var type=meal[foodType[res[i].Q03]];
                for(var key in columns.FOODQTY){
                    if(res[i][key])
                        type[columns.FOODQTY[key]]=res[i][key]
                } 
                type['daily avg']=Math.round(type['sales volume']/(old?daysOfMonth[mon]+leap:(new Date()).getUTCDate())) 
            }
            return sendResponse(response,codes.SUCCESS,{success:true,hotelName:hotelName,meals:meals});
        });
    });
}
function target(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[5]=='0')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var month=data.month
        var year=month.substr(0,4);
        month=month.substr(4);
        var month=parseInt(month)
        var currentDate=new Date(new Date()-0+8*60*60*1000)
        var leap=0;
        if(month==2&&year%4==0&&(year%100!=0||(year%100==0&&year&400==0)))
            leap=1
        var day=month!=(currentDate.getUTCMonth()+1)?(daysOfMonth[month]+leap):new Date(new Date()-21.5*60*60*1000).getUTCDate();
        if(groupToRes[data.group])
            var groups=constants.RESTAURANT_TO_GROUP[groupToRes[data.group]].groups;
        else 
            return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
        var params2=[{ name: 'DATE0',  value: year+"/"+(month<10?'0':'')+month+"/01"},{ name: 'DATE1',value: year+"/"+(month<10?'0':'')+month+"/"+(daysOfMonth[month]+leap)}]
        var count=0;
        var column=[]
        for(var i in groups.service){
            params2.push({name:'GROUP'+count,value:groups.service[i]})
            column.push('@GROUP'+count++)
        }
        for(var i in groups.kitchen){
            params2.push({name:'GROUP'+count,value:groups.kitchen[i]})            
            column.push('@GROUP'+count++)
        }
        var params=[{ name: 'MON0',  value: data.month},{name:'DATE',value:data.month+(day<10?'0':'')+day}]
        for(var i=0;i<3;i++){
            month=(month+10)%12+1
            if(month==12)
                year=parseInt(year)-1
            params.push({name:'MON'+(i+1),value:year+(month<10?'0':'')+month})
        }
        params.push({name:'GROUP',value:groupToRes[data.group]})
        MS.query(queries.TARGET_START+queries.TARGET_MIDDLE1+queries.TARGET_END,params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res=res.recordset
            var hotel={kitchenMin:0,serviceMin:0,target:{income:0,unitPrice:400,service:5.5,kitchen:3000,loss:'0.5 %'},actual:{income:0,unitPrice:0,service:0,kitchen:0,loss:0}};
            for(var i in res){
                var type;
                if(res[i].M00==params[0].value){
                    type=hotel.actual
                    type.unitPrice+=parseInt(res[i].M07);
                    type.service+=parseInt(res[i].M05)+parseInt(res[i].M10);
                    type.kitchen+=parseInt(res[i].M03)+parseInt(res[i].M04);
                    if(res[i].H00){
                        type.loss=parseInt(res[i].H07)-(res[i].G10?parseInt(res[i].G10):0)
                    }
                }else
                    type=hotel.target
                type.income+=parseInt(res[i].M03)+parseInt(res[i].M04);            
            }
            MS.query(queries.PERFORMANCE_MONTH_START+(data.company?queries.PERFORMANCE_MONTH_GROUP+column.join(',')+')':"")+queries.PERFORMANCE_MONTH_END,params2,true,function(err,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    var minutesPassed=(new Date()-new Date(data.date))>86400000? 500:parseInt((new Date()%(24*60*60*1000))/(60*1000))
                    res1=res1.recordset
                    for(var i in res1){
                        if((groups.service.indexOf(res1[i].layer)>=0||groups.kitchen.indexOf(res1[i].layer)>=0)&&(res1[i].SIGNIN||res1[i].SIGNOUT)){
                            var type=(constants.SERVICE_GROUPS.indexOf(res1[i].layer)>=0?'service':'kitchen')+'Min'
                            if(res1[i].SIGNIN&&res1[i].SIGNOUT)
                                hotel[type]+=parseInt((res1[i].SIGNOUT-res1[i].SIGNIN)/(60*1000));
                            else if(!res1[i].SIGNOUT)
                                hotel[type]+=(new Date()-res1[i].SIGNIN)>86400000?480:parseInt(((new Date()-0+8*60*60*1000)-res1[i].SIGNIN)/(60*1000));
                            if(res1[i].overTime)
                                hotel[type]+=res1[i].overTime*60
                            if(res1[i].leaves){
                                hotel[type]-=res1[i].leaves*60
                            }
                        }
                    }
                }
                var target=hotel.target
                var actual=hotel.actual
                target.income=target.income*1.03/3
                actual.kitchen=actual.kitchen*60/((hotel.kitchenMin?hotel.kitchenMin:0))
                actual.service=actual.service*60/((hotel.serviceMin?hotel.serviceMin:0))
                actual.loss=(actual.loss*100/(actual.income?actual.income:1)).toFixed(2)+' %'
                return sendResponse(response,codes.SUCCESS,{success:true,hotel:hotel});
            })
        });
    });
}
function targetAll(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[5]=='0')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var month=data.month
        var year=month.substr(0,4);
        month=month.substr(4);
        var month=parseInt(month)
        var currentDate=new Date(new Date()-0+8*60*60*1000)
        var leap=0;
        if(month==2&&year%4==0&&(year%100!=0||(year%100==0&&year&400==0)))
            leap=1
        var day=month!=(currentDate.getUTCMonth()+1)?(daysOfMonth[month]+leap):new Date(new Date()-24*60*60*1000).getUTCDate();
        var column=['@GROUP0','@GROUP1']
        var params2=[{ name: 'DATE0',  value: year+"/"+(month<10?'0':'')+month+"/01"},{ name: 'DATE1',value: year+"/"+(month<10?'0':'')+month+"/"+(daysOfMonth[month]+leap)},{name:'GROUP0',value:constants.TRANSPORT},{name:'GROUP1',value:constants.TRANSPORT2}]    
        var params=[{ name: 'MON0',  value: data.month},{ name: 'MON0',  value: data.month},{name:'DATE',value:data.month+(day<10?'0':'')+day}]
        MS.query(queries.TARGET_START+queries.TARGET_MIDDLE2+queries.TARGET_END,params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res=res.recordset
            var hotels={}
            var total=0;
            for(var i in res){
                if(res[i].M01=='ZZ')
                    total+=res[i].M03&&res[i].M04?(parseInt(res[i].M03)+parseInt(res[i].M04)):0;
                hotels[res[i].M02]=(res[i].M03&&res[i].M04?((parseInt(res[i].H07)-(res[i].G10?parseInt(res[i].G10):0))*100/(parseInt(res[i].M03)+parseInt(res[i].M04))).toFixed(2):'0')+'%';
            }
            MS.query(queries.PERFORMANCE_MONTH_START+queries.PERFORMANCE_MONTH_GROUP+column.join(',')+')'+queries.PERFORMANCE_MONTH_END,params2,true,function(err,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    var minutesPassed=(new Date()-new Date(data.date))>86400000? 500:parseInt((new Date()%(24*60*60*1000))/(60*1000))
                    res1=res1.recordset
                    var workingHour=0;
                    for(var i in res1){
                        if(res1[i].SIGNIN||res1[i].SIGNOUT){
                            if(res1[i].SIGNIN&&res1[i].SIGNOUT)
                                workingHour+=parseInt((res1[i].SIGNOUT-res1[i].SIGNIN)/(60*1000));
                            else if(!res1[i].SIGNOUT)
                                workingHour+=(new Date()-res1[i].SIGNIN)>86400000?480:parseInt(((new Date()-0+8*60*60*1000)-res1[i].SIGNIN)/(60*1000));
                            if(res1[i].overTime)
                                workingHour+=res1[i].overTime*60
                            if(res1[i].leaves){
                                workingHour-=res1[i].leaves*60
                            }
                        }
                    }
                }
                total=total*60/(workingHour?workingHour:1)
                return sendResponse(response,codes.SUCCESS,{success:true,hotels:hotels,kitchen:total});
            })
        });
    });
}
function setMultipleAccess(data, response) {
     if(data.loginId!='151001')
           return sendResponse(response,codes.INVALID_DATA,{success:true})
     console.log(data)
     data.access=JSON.parse(data.access)
     var loginIds = Object.keys(data.access)

     console.log(data)
     var params = []
     var accessList={}
     for(var i in loginIds){
        data.access[loginIds[i]]=data.access[loginIds[i]].split(',')
        accessList[loginIds[i]]={access:[0,0,0,0,0,0,0,0,0,0,0,0],change:true}
        accessList[loginIds[i]].access[data.accessNo]=data.access[loginIds[i]][data.accessNo]
    }
    console.log(loginIds,accessList)
     CP.query(queries.GET_MULTIPLE_ACCESS,[loginIds],function(err1,res1){
        if(err1)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        for(var i in res1){
            if(res1[i].fullAccess){
                var access=res1[i].fullAccess.split(',')
                if(access[data.accessNo]==data.access[res1[i].loginId][data.accessNo])
                    accessList[res1[i].loginId].change=false
                else
                    access[data.accessNo]=data.access[loginIds[i]][data.accessNo]
                accessList[res1[i].loginId].access=access
            }
        }
        var logs='',emailMessage='',chinese=''
        for (var i in accessList) {
            if(accessList[i].change){
                var log=new Date(new Date()-1+8*60*60*1000).toJSON().replace(/T/,' ').substr(0,19)+','+data.loginId+(accessList[i].access[data.accessNo]=='1'?' added ':' deleted ')+i+"'s "+constants.ACCESS_TYPE[data.accessNo]+' access from '+(data.webui?'Webui':'App')+'.'
                chinese+=new Date(new Date()-1+8*60*60*1000).toJSON().replace(/T/,' ').substr(0,19)+','+data.loginId+(accessList[i].access[data.accessNo]=='1'?' 新增 ':' 刪除 ')+i+"'s "+constants.ACCESS_CHINESE_TYPE[data.accessNo]+' from '+(data.webui?'Webui':'App')+'.<br>'
                emailMessage+=log+'<br>'
                logs+=log+'\n'
                params.push([accessList[i].access.join(','),i])
            }
        }
        fs.appendFile('./access.log',logs,function(err,res){})
        if(emailMessage)
               email.sendAcccessEmail(emailMessage+chinese,function(err,res){})
        if(params.length>0)
        CP.query(queries.SET_MULTIPLE_ACCESS, [params], function(err2, res2) {
            if (!err2 && res2) {
                CP.query(queries.SET_COUNT, [[[data.accessNo,data.idCount, data.departmentCount, data.jobCount]]], function(err, res) {
                    if (!err && res)
                        return sendResponse(response, codes.SUCCESS, { success: true });
                    else if (err)
                        return sendResponse(response, codes.DATABASE_ERROR, { success: false })
                })
            } else if (err2)
                return sendResponse(response, codes.DATABASE_ERROR, { success: false })

        })
        else return sendResponse(response, codes.SUCCESS, { success: true });
    })
}
  
function inventory(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})

        var access=res[0].fullAccess.split(',')
        var index=data.type=='A'?7:9
        var type=data.type
        if(access[index]!='1'&&access[index+1]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var column=''
        if(access[11]=='1')
            column=',G10,H07'
        var extra=''
        if(type == 'B' && data.group == '緯豆-資運中心')
            extra='_STKQTY'
        var params=[{name:'DATE',value:data.date},{name:'GROUP',value:groupToRes[data.group]},{name:'Type',value:data.type+'%'}]
        var params2=[{name:'DATE0',value:data.date.substr(0,8)+'01'},{name:'DATE1',value:data.date},{name:'GROUP',value:groupToRes[data.group]},{name:'Type',value:data.type+'%'}]
        MS.query(queries['INVENTORY_START_'+type+extra]+column+queries['INVENTORY_END_'+type+extra],params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            MS.query(queries.INVENTORY_SUM,params2,null,function(err,res1){
                var result={}
                if(!err && res1 && res1.recordset){
                    res1=res1.recordset[0];
                    result={G10P:res1.G10P,G10N:res1.G10N,H07DAY:res1.H07,H07MON:res1.H07MON}
                }
                result.success=true,
                result.list=res.recordset
                return sendResponse(response,codes.SUCCESS,result);
            })
        });
    });
}

function sellout(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[15]!='1'&&access[16]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var params=[{name:'DATE',value:data.date},{name:'GROUP',value:groupToRes[data.group]}]
        MS.query(queries['SELLOUT'],params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            return sendResponse(response,codes.SUCCESS,{success:true,list:res.recordset});
        })
    })
}

function podchk(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[17]!='1'&&access[18]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var params=[{name:'DATE',value:data.date}]
        var column=[]
        var hotels=constants.GROUP_TO_HOTEL_PODCHK[data.group]
        for(var i in hotels){
            params.push({name:'GROUP'+i,value:hotels[i]})
            column.push('@GROUP'+i)
        }
        MS.query(queries['PODCHK']+column.join(',')+');',params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            var result={}
            result.success=true,
            result.list=res.recordset
            return sendResponse(response,codes.SUCCESS,result);
        })
    })
}

function twoDigits(d) {
 if(0 <= d && d < 10) return "0" + d.toString();
 return d.toString();
}


function fdcost(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[19]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var type=constants.FDCOST_TYPE[data.type]
        var column=[]
        var params=[]
        for(var i in type){
            var start,end;
            if(type[i].constructor==Array){
                start =  type[i][0]
                end = type[i][1]
            }else{
                start =  type[i]
                end = type[i]
            }
            while(start <= end){
                var num_series = twoDigits(start)
                if(start!=12){
                    params.push({name:'GROUP'+start,value:'F'+num_series+'%'})
                    column.push('J00 LIKE @GROUP'+start)
                }else{
                    var products=constants.FDCOST_F12[data.type]
                    for(var i in products)
                        column.push("J00 = '"+products[i]+"'")
                }
                start++;
            }
        }
        var groups=constants.FDCOST_FOODQTY
        var date=new Date()
        var month= date.getFullYear()+''+((date.getMonth()<9?'0':'')+(date.getMonth()+1))
        params.push({name:'MON',value:month})
        var meal=null
        var column2=[];
        if(groups[data.type]){
            for(var i in groups[data.type]){
                params.push({name:'MEAL'+i,value:groups[data.type][i]})
                column2.push('@MEAL'+i)
            }
        }
        else{
            params.push({name:'MEAL',value:null})
            column2.push('@MEAL')
        }
        params.push({name:'MEAL',value:meal})
        MS.query(queries['FDCOST_START']+column2.join(',')+queries['FDCOST_END']+column.join(' OR ')+queries.FDCOST_ORDER,params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res= res.recordset
            var sellamount=[]
            var total_profit=0
            if(res.length > 0 && groups[data.type]){
                for(var i in res){
                    if(res[i].Q09 || res[i].Q10){
                        res[i]['sellAmount']=(res[i].Q09?res[i].Q09:0)+(res[i].Q10?res[i].Q10:0)
                        res[i]['profitAmount']=(res[i]['J03']-res[i]['J04'])*res[i]['sellAmount']
                        total_profit += res[i]['profitAmount']
                        sellamount.push(res[i]['sellAmount'])
                        sellamount.sort(function(a, b){return b-a})
                        
                    }
                }
                for(var i in res){             
                    if(res[i]['sellAmount']){   
                        res[i]['profitPercent']=((res[i]['profitAmount']/total_profit)*100)+'%'    
                        res[i]['mealRank']=sellamount.indexOf(res[i]['sellAmount'])+1
                    }
                }
            }
            return sendResponse(response,codes.SUCCESS,{success:true,list:res});
        })
    })
}


function salary(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[21]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
         var month=data.month
        var year=month.substr(0,4);
        month=month.substr(4);
        var date1=year+'/'+month+'/'+'01'
        var lastdate=new Date(date1)
        var lastfirstdate= new Date(lastdate.setMonth(lastdate.getMonth()-1))
        var lastseconddate=new Date(lastdate.setMonth(lastdate.getMonth()-1))
        var lastThirddate=new Date(lastdate.setMonth(lastdate.getMonth()-1))
        var date2 = lastfirstdate.getFullYear()+"/"+twoDigits(lastfirstdate.getMonth()+1)+"/01";
        var date3 = lastseconddate.getFullYear()+"/"+twoDigits(lastseconddate.getMonth()+1)+"/01";
        var date4 = lastThirddate.getFullYear()+"/"+twoDigits(lastThirddate.getMonth()+1)+"/01";
        var params=[{name:'DATE1',value:date1},{name:'DATE2',value:date2},{name:'DATE3',value:date3},{name:'DATE4', value:date4}]
        var column=[]
        var dept=constants.VWZZ_SALARY_MAP[data.type]
        for(var i in dept){
            params.push({name:'GROUP'+i,value:dept[i]})
            column.push('@GROUP'+i)
        }
        MS.query(queries['VWZZ_SALARY_START']+column.join(',')+queries['VWZZ_SALARY_END'],params,true,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res=res.recordset
            var allData={'last':{},'lastFirst':{},'lastSecond':{},'lastThird':{}}
            var total={'now':{
                'SALARY_TAX_AMOUNT':0,
                'SALARY_INC_AMOUNT':0,
                'SALARY_DEC_AMOUNT':0,
                'SALARY_AMOUNT':0,
                'PAY_SALARY_AMOUNT':0,
            },'last':0,'lastThree':0}
            for(var i in res){
                res[i].EMPLOYEE_NO=res[i].EMPLOYEE_NO[0]
                var type
                if(res[i].date == date1)
                    type='last'
                if(res[i].date == date2)
                    type='lastFirst'
                if(res[i].date == date3)
                    type='lastSecond'
                if(res[i].date == date4)
                    type='lastThird'
                allData[type][res[i].EMPLOYEE_NO]=res[i]
                if(type=='last'){
                    for(var j in total.now){
                        total.now[j]+=res[i][j]
                    }
                }else{
                    if(type=='lastFirst')
                        total.last+=res[i].SALARY_AMOUNT
                    total.lastThree+=res[i].SALARY_AMOUNT
                }
            }
        if(total['last'])
                total.now['lastMonthPercent']=(total.last<total.now.SALARY_AMOUNT?'+':'')+(((total.now.SALARY_AMOUNT - total.last)/total.last) * 100 ) + '%'
            if(!total.now['lastMonthPercent']||total.now['lastMonthPercent']=='NaN%')
                total.now['lastMonthPercent']='-'
            total.lastThree=total.lastThree/3
            if(total.lastThree)
                total.now['lastThreeMonthPercent']=(total.lastThree<total.now.SALARY_AMOUNT?'+':'')+(((total.now.SALARY_AMOUNT - total.lastThree)/total.lastThree) * 100 ) + '%'
            else
                total.now['lastThreeMonthPercent']='-'
            var result=[]
            for(var i in allData['last']){
                if(allData['lastFirst'][i]){
                    if(allData['last'][i]['SALARY_AMOUNT'] > allData['lastFirst'][i]['SALARY_AMOUNT'] )
                        allData['last'][i]['lastMonthPercent']='+'+(((allData['last'][i]['SALARY_AMOUNT'] - allData['lastFirst'][i]['SALARY_AMOUNT'])/allData['lastFirst'][i]['SALARY_AMOUNT']) * 100 ) + '%'
                    else
                        allData['last'][i]['lastMonthPercent']=(((allData['last'][i]['SALARY_AMOUNT'] - allData['lastFirst'][i]['SALARY_AMOUNT'])/allData['lastFirst'][i]['SALARY_AMOUNT']) * 100 ) + '%'
                }
                if(!allData['last'][i]['lastMonthPercent'] || allData['last'][i]['lastMonthPercent']=='NaN%')
                    allData['last'][i]['lastMonthPercent']='-'
                var avgData=((allData['lastFirst'][i]?allData['lastFirst'][i]['SALARY_AMOUNT']:0)+(allData['lastSecond'][i]?allData['lastSecond'][i]['SALARY_AMOUNT']:0)+(allData['lastThird'][i]?allData['lastThird'][i]['SALARY_AMOUNT']:0))/3
                if(avgData>0){
                    if(allData['last'][i]['SALARY_AMOUNT'] > avgData )
                        allData['last'][i]['lastThreeMonthPercent']='+'+(((allData['last'][i]['SALARY_AMOUNT'] - avgData)/avgData) * 100 ) + '%'
                    else
                        allData['last'][i]['lastThreeMonthPercent']=(((allData['last'][i]['SALARY_AMOUNT'] - avgData)/avgData) * 100 ) + '%'
                }else
                    allData['last'][i]['lastThreeMonthPercent']='-'
                result.push(allData['last'][i])
            }
            return sendResponse(response,codes.SUCCESS,{success:true,list:result,total:total.now});
        })
    })
}

function salaryAll(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[21]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
         var month=data.month
        var year=month.substr(0,4);
        month=month.substr(4);
        var date1=year+'/'+month+'/'+'01'
        var lastdate=new Date(date1)
        var lastdate_2=new Date(date1)
        var lastfirstdate= new Date(lastdate.setMonth(lastdate.getMonth()-1))
        var lastseconddate=new Date(lastdate.setMonth(lastdate.getMonth()-1))
        var lastThirddate=new Date(lastdate.setMonth(lastdate.getMonth()-1))
        var lastyeardate=new Date(lastdate_2.setYear(lastdate_2.getFullYear()-1))
        var date2 = lastfirstdate.getFullYear()+"/"+twoDigits(lastfirstdate.getMonth()+1)+"/01";
        var date3 = lastseconddate.getFullYear()+"/"+twoDigits(lastseconddate.getMonth()+1)+"/01";
        var date4 = lastThirddate.getFullYear()+"/"+twoDigits(lastThirddate.getMonth()+1)+"/01";
        var date5 = lastyeardate.getFullYear()+"/"+twoDigits(lastyeardate.getMonth()+1)+"/01";
        var params=[{name:'DATE1',value:date1},{name:'DATE2',value:date2},{name:'DATE3',value:date3},{name:'DATE4', value:date4},{name:'DATE5', value:date5}]
        MS.query(queries['VWZZ_SALARY_ALL'],params,true,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res=res.recordset
            var allData={'last':{},'lastFirst':{},'lastSecond':{},'lastThird':{},'lastyear':{}}
            for(var i in res){
                if(res[i].date == date1){
                    if(!allData['last'][res[i].DEPARTMENT_CNAME])
                        allData['last'][res[i].DEPARTMENT_CNAME]=[]
                    allData['last'][res[i].DEPARTMENT_CNAME].push(res[i])
                }
                if(res[i].date == date2){
                    if(!allData['lastFirst'][res[i].DEPARTMENT_CNAME])
                        allData['lastFirst'][res[i].DEPARTMENT_CNAME]=[]
                    allData['lastFirst'][res[i].DEPARTMENT_CNAME].push(res[i])
                }
                if(res[i].date == date3){
                    if(!allData['lastSecond'][res[i].DEPARTMENT_CNAME])
                        allData['lastSecond'][res[i].DEPARTMENT_CNAME]=[]
                    allData['lastSecond'][res[i].DEPARTMENT_CNAME].push(res[i])
                }
                if(res[i].date == date4){
                    if(!allData['lastThird'][res[i].DEPARTMENT_CNAME])
                        allData['lastThird'][res[i].DEPARTMENT_CNAME]=[]
                    allData['lastThird'][res[i].DEPARTMENT_CNAME].push(res[i])
                }
                if(res[i].date == date5){
                    if(!allData['lastyear'][res[i].DEPARTMENT_CNAME])
                        allData['lastyear'][res[i].DEPARTMENT_CNAME]=[]
                    allData['lastyear'][res[i].DEPARTMENT_CNAME].push(res[i])
                }
            }
            console.log(allData)
            var sumData={'last':{},'lastFirst':{},'lastSecond':{},'lastThird':{},'lastyear':{}}
            var result={}
            var total={'hotel':{lastFirst:0,lastFirstCount:0,lastSecond:0,lastSecondCount:0,lastThird:0,lastThirdCount:0,lastyearCount:0},'taxHotel':{lastFirst:0,lastFirstCount:0,lastSecond:0,lastSecondCount:0,lastThird:0,lastThirdCount:0,lastyearCount:0}}
            var dimdimsumDeparts=constants.VWZZ_SALARY_DIMDIMSUM
            var taxingDeparts=constants.VWZZ_SALARY_TAXING
            var result_coloumns=['SALARY_TAX_AMOUNT','SALARY_INC_AMOUNT','SALARY_DEC_AMOUNT','SALARY_AMOUNT','PAY_SALARY_AMOUNT']
            for(var i in allData['last']){
                result[i]={}
                sumData['lastFirst'][i]={}
                sumData['lastSecond'][i]={}
                sumData['lastThird'][i]={}
                sumData['lastyear'][i]={}
                sumData['last'][i]={}
                sumData['lastFirst'][i]['length']=allData['lastFirst'][i]?allData['lastFirst'][i].length:0
                sumData['lastSecond'][i]['length']=allData['lastSecond'][i]?allData['lastSecond'][i].length:0
                sumData['lastThird'][i]['length']=allData['lastThird'][i]?allData['lastThird'][i].length:0
                sumData['lastyear'][i]['length']=allData['lastyear'][i]?allData['lastyear'][i].length:0
                sumData['last'][i]['length']=allData['last'][i].length
                for(var j in allData['lastFirst'][i]){
                        if(!sumData['lastFirst'][i]['PAY_SALARY_AMOUNT'])
                            sumData['lastFirst'][i]['PAY_SALARY_AMOUNT']=0
                        sumData['lastFirst'][i]['PAY_SALARY_AMOUNT'] += allData['lastFirst'][i][j]['PAY_SALARY_AMOUNT']    
                }
                for(var j in allData['lastSecond'][i]){
                        if(!sumData['lastSecond'][i]['PAY_SALARY_AMOUNT'])
                            sumData['lastSecond'][i]['PAY_SALARY_AMOUNT']=0
                        sumData['lastSecond'][i]['PAY_SALARY_AMOUNT'] += allData['lastSecond'][i][j]['PAY_SALARY_AMOUNT']  
                   
                }
                for(var j in allData['lastThird'][i]){
                        if(!sumData['lastThird'][i]['PAY_SALARY_AMOUNT'])
                            sumData['lastThird'][i]['PAY_SALARY_AMOUNT']=0
                        sumData['lastThird'][i]['PAY_SALARY_AMOUNT'] += allData['lastThird'][i][j]['PAY_SALARY_AMOUNT']  
                   
                }
                for(var j in allData['last'][i]){
                    for(var k in allData['last'][i][j]){
                        if(result_coloumns.indexOf(k) >= 0){
                            if(!result[i][k])
                                result[i][k]=0
                            result[i][k] += allData['last'][i][j][k]
                        }    
                    }
                }
                result[i]['departmentTotal']=allData['last'][i].length
                result[i]['avgPayLastMonth']=Math.round(sumData['lastFirst'][i]['PAY_SALARY_AMOUNT']/sumData['lastFirst'][i]['length'])
                result[i]['avgPayDept']=Math.round(result[i]['PAY_SALARY_AMOUNT']/allData['last'][i].length)
                result[i]['avgPayLastThreeMonth']=Math.round(((sumData['lastFirst'][i]['PAY_SALARY_AMOUNT']/sumData['lastFirst'][i]['length'])+(sumData['lastSecond'][i]['PAY_SALARY_AMOUNT']/sumData['lastSecond'][i]['length'])+(sumData['lastThird'][i]['PAY_SALARY_AMOUNT']/sumData['lastThird'][i]['length']))/3)
                if(sumData['lastFirst'][i] && sumData['lastFirst'][i].length>0){
                    if(sumData['last'][i]['length'] > sumData['lastFirst'][i]['length'])
                        result[i]['leaveLastMonthPercent']='+'+(((sumData['last'][i]['length'] - sumData['lastFirst'][i]['length'])/sumData['lastFirst'][i]['length']) * 100) + '%'
                    else
                        result[i]['leaveLastMonthPercent']=(((sumData['last'][i]['length'] - sumData['lastFirst'][i]['length'])/sumData['lastFirst'][i]['length']) * 100) + '%'
                }else
                    result[i]['leaveLastMonthPercent']='-'
                if(sumData['lastyear'][i] && sumData['lastyear'][i].length>0){
                    if(sumData['last'][i]['length'] > sumData['lastyear'][i]['length'])
                        result[i]['leaveLastYearPercent']='+'+(((sumData['last'][i]['length'] - sumData['lastyear'][i]['length'])/sumData['lastyear'][i]['length']) * 100) + '%'
                    else
                        result[i]['leaveLastYearPercent']=(((sumData['last'][i]['length'] - sumData['lastyear'][i]['length'])/sumData['lastyear'][i]['length']) * 100) + '%'
                }
                else
                    result[i]['leaveLastYearPercent']='-'
                if(result[i]['avgPayLastThreeMonth']){
                    if(result[i]['avgPayDept'] > result[i]['avgPayLastThreeMonth'] )
                        result[i]['avgPayLastThreeMonthPercent']='+'+(((result[i]['avgPayDept'] - result[i]['avgPayLastThreeMonth'])/result[i]['avgPayLastThreeMonth']) * 100 ) + '%'
                    else
                        result[i]['avgPayLastThreeMonthPercent']=(((result[i]['avgPayDept'] - result[i]['avgPayLastThreeMonth'])/result[i]['avgPayLastThreeMonth']) * 100 ) + '%'
                }else
                    result[i]['avgPayLastThreeMonthPercent']='-'
                if(result[i]['avgPayLastMonth']){
                    if(result[i]['avgPayDept'] > result[i]['avgPayLastMonth'] )
                        result[i]['avgPayLastMonthPercent']='+'+(((result[i]['avgPayDept'] - result[i]['avgPayLastMonth'])/result[i]['avgPayLastMonth']) * 100 ) + '%'
                    else
                        result[i]['avgPayLastMonthPercent']=(((result[i]['avgPayDept'] - result[i]['avgPayLastMonth'])/result[i]['avgPayLastMonth']) * 100 ) + '%'
                }else
                    result[i]['avgPayLastMonthPercent']='-'
                for(var k in result[i]){
                    if(dimdimsumDeparts.indexOf(i) >= 0 && (result_coloumns.indexOf(k) >= 0 ||  k=='departmentTotal')){
                        if(!total['hotel'][k])
                            total['hotel'][k]=0
                        total['hotel'][k] += result[i][k]
                    }
                    if(taxingDeparts.indexOf(i) >= 0 && (result_coloumns.indexOf(k) >= 0 || k=='departmentTotal')){
                        if(!total['taxHotel'][k])
                            total['taxHotel'][k]=0
                        total['taxHotel'][k] += result[i][k]
                    }
                }
                if(dimdimsumDeparts.indexOf(i)>=0){
                    total['hotel']['lastFirst']+=sumData['lastFirst'][i]['PAY_SALARY_AMOUNT']
                    total['hotel']['lastFirstCount']+=sumData['lastFirst'][i]['length']
                    total['hotel']['lastSecond']+=sumData['lastSecond'][i]['PAY_SALARY_AMOUNT']
                    total['hotel']['lastSecondCount']+=sumData['lastSecond'][i]['length']
                    total['hotel']['lastThird']+=sumData['lastThird'][i]['PAY_SALARY_AMOUNT']
                    total['hotel']['lastThirdCount']+=sumData['lastThird'][i]['length']
                    total['hotel']['lastyearCount']+=sumData['lastyear'][i]['length']
                }
                if(taxingDeparts.indexOf(i)>=0){
                    total['taxHotel']['lastFirst']+=sumData['lastFirst'][i]['PAY_SALARY_AMOUNT']
                    total['taxHotel']['lastFirstCount']+=sumData['lastFirst'][i]['length']
                    total['taxHotel']['lastSecond']+=sumData['lastSecond'][i]['PAY_SALARY_AMOUNT']
                    total['taxHotel']['lastSecondCount']+=sumData['lastSecond'][i]['length']
                    total['taxHotel']['lastThird']+=sumData['lastThird'][i]['PAY_SALARY_AMOUNT']
                    total['taxHotel']['lastThirdCount']+=sumData['lastThird'][i]['length']
                    total['hotel']['lastyearCount']+=sumData['lastyear'][i]['length']

                }
            }
            for(var i in total){
                total[i]['avgPayLastMonth']=Math.round(total[i]['lastFirst']/total[i]['lastFirstCount'])
                total[i]['avgPayDept']=Math.round(total[i]['PAY_SALARY_AMOUNT']/total[i]['departmentTotal'])
                total[i]['avgPayLastThreeMonth']=Math.round(((total[i]['lastFirst']/total[i]['lastFirstCount'])+(total[i]['lastSecond']/total[i]['lastSecondCount'])+(total[i]['lastThird']/total[i]['lastThirdCount']))/3)
                if(total[i]['lastFirst'] && total[i]['lastFirstCount']>0){
                    if(total[i]['departmentTotal']> total[i]['lastFirstCount'])
                        total[i]['leaveLastMonthPercent']='+'+(((total[i]['departmentTotal'] - total[i]['lastFirstCount'])/total[i]['lastFirstCount']) * 100) + '%'
                    else
                        total[i]['leaveLastMonthPercent']=(((total[i]['departmentTotal'] - total[i]['lastFirstCount'])/total[i]['lastFirstCount']) * 100) + '%'
                }else
                    total[i]['leaveLastMonthPercent']='-'
                if(total[i]['lastyearCount']>0){
                    if(total[i]['departmentTotal']> total[i]['lastyearCount'])
                        total[i]['leaveLastYearPercent']='+'+(((total[i]['departmentTotal'] - total[i]['lastyearCount'])/total[i]['lastyearCount']) * 100) + '%'
                    else
                        total[i]['leaveLastYearPercent']=(((total[i]['departmentTotal'] - total[i]['lastyearCount'])/total[i]['lastyearCount']) * 100) + '%'
                }
                else
                    total[i]['leaveLastYearPercent']='-'
                if(total[i]['avgPayLastThreeMonth']){
                    if(total[i]['avgPayDept'] > total[i]['avgPayLastThreeMonth'] )
                        total[i]['avgPayLastThreeMonthPercent']='+'+(((total[i]['avgPayDept'] - total[i]['avgPayLastThreeMonth'])/total[i]['avgPayLastThreeMonth']) * 100 ) + '%'
                    else
                        total[i]['avgPayLastThreeMonthPercent']=(((total[i]['avgPayDept'] - total[i]['avgPayLastThreeMonth'])/result[i]['avgPayLastThreeMonth']) * 100 ) + '%'
                }else
                    total[i]['avgPayLastThreeMonthPercent']='-'
                if(total[i]['avgPayLastMonth']){
                    if(total[i]['avgPayDept'] > total[i]['avgPayLastMonth'] )
                        total[i]['avgPayLastMonthPercent']='+'+(((total[i]['avgPayDept'] - total[i]['avgPayLastMonth'])/total[i]['avgPayLastMonth']) * 100 ) + '%'
                    else
                        total[i]['avgPayLastMonthPercent']=(((total[i]['avgPayDept'] - total[i]['avgPayLastMonth'])/total[i]['avgPayLastMonth']) * 100 ) + '%'
                }else
                    total[i]['avgPayLastMonthPercent']='-'
            }
            return sendResponse(response,codes.SUCCESS,{success:true,list:result,total:total});
        })
    })
}

function vwzz_new(data,response,path){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[20]!='1'&&access[22]!='1'&&access[23]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        if(access[20]=='0'&&access[22]=='1'&&access[23]=='0'&&data.loginId!=151007&&path=='/employee')
            data.type=constants.VWZZ_DEPT_TO_HOTEL[data.notifiCompany.split('|')[1]]
        var date=new Date();
        var params=[{name: 'DATE',  value:(date.getUTCFullYear()-(date.getUTCMonth()<9?1:0))+'-10-01' },{name: 'DATE0',  value:date.toISOString().substr(0,8)+'01' },{name: 'DATE1',  value:date.toISOString().substr(0,10) }]
        var column=[]
        var dept
        if(constants.VWZZ_MAP[data.type])
            dept=constants.VWZZ_MAP[data.type]
        else if(constants.VWZZ_MAP_SINGLE[data.type])
            dept=constants.VWZZ_MAP_SINGLE[data.type]
        else 
            dept=[data.type]
        for(var i in dept){
            column.push("'"+dept[i]+"'")
        }
        MS.query(queries['vwZZ_EMPLOYEE_NEW_START']+column.join(',')+queries['vwZZ_EMPLOYEE_NEW_END'],params,true,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res=res.recordset
            for(var i in res)
                res[i].EMPLOYEE_NO=res[i].EMPLOYEE_NO[0]
            return sendResponse(response,codes.SUCCESS,{success:true,list:res});
        })
    })
}
function gReview(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[24]!='1'&& access[25]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var month=data.month
        var year=month.substr(0,4);
        month=month.substr(4);
        var date=year+'-'+parseInt(month) //FORMAT YYYY-MM
        params=[data.type,data.type,date,data.type,data.type]
        var params2=[]
        var keys=['FIVE','FOUR','THREE','TWO','ONE']
        var groups
        if(groupToRes[data.type]){
            groups=constants.RESTAURANT_TO_GROUP[groupToRes[data.type]].groups;
        }else 
            return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
        var targetMonth=year+'-'+(parseInt(month)<10?'0':'')+parseInt(month);
        if(targetMonth<'2021-01')
            targetMonth='2021-01'
        params2.push([groups.service[0],groups.kitchen[0]])
        params2.push(targetMonth)
        CP.query(queries['GET_TARGET'],params2,function(err1,res1){
            if(err1)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res1)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            var target=res1[0].count+res1[1].count
            var service=res1[0].count;
            var kitchen=res1[1].count
            if(res1[0].department!=groups.service[0])
                service=[kitchen,kitchen=service][0]
            CP.query(queries.GETREVIEW,params,function(err,res){
                if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false})
                else if(!res)
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            
                var count={five:{count:0},four:{count:0},three:{count:0},two:{count:0},one:{count:0}}
                var currentMonthData={one:0,five:0}
                var total=0;
                var commentcount=0
                var nonreplycount=0
                for (var i in res) {
                    commentcount += res[i].commentcount
                    nonreplycount += res[i].nonrlycount
                    total += res[i]['count']
                    switch (res[i]['rating']) {
                        case 'FIVE':
                            count.five.count = res[i]['count']
                            if (res[i]['monthCount'])
                                currentMonthData.five = res[i]['monthCount'] ? res[i]['monthCount'] : 0
                            break;
                        case 'FOUR':
                            count.four.count = res[i]['count']
                            break;
                        case 'THREE':
                            count.three.count = res[i]['count']
                            break;
                        case 'TWO':
                            count.two.count = res[i]['count']
                            break;
                        case 'ONE':
                            count.one.count = res[i]['count']
                            if (res[i]['monthCount'])
                                currentMonthData.one = res[i]['monthCount'] ? res[i]['monthCount'] : 0
                            break;
                    }
                }
                averageRating = Math.round((5 * count['five']['count'] + 4 * count['four']['count'] + 3 * count['three']['count'] + 2 * count['two']['count'] + count['one']['count']) * 10 / total) / 10
                return sendResponse(response,codes.SUCCESS,{success:true,list:count,total:total,averageRating:averageRating,month:currentMonthData,target:target,commentcount:commentcount,nonreplycount:nonreplycount,service:service,kitchen:kitchen});
            })
        })
    })
}

function gReviewAll(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[24]!='1'&& access[25]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var result={}
        var reviews={five:{name:'FIVE',value:5},four:{name:'FOUR',value:4},three:{name:'THREE',value:3},two:{name:'TWO',value:2},one:{name:'ONE',value:1}}
        CP.query(queries.GETREVIEWALL,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            for(var i in res){
                if(!result[res[i].hotel])
                    result[res[i].hotel]={five:0,four:0,three:0,two:0,one:0,total:0,averageRating:0}
                result[res[i].hotel]['total']++
                for(var j in reviews){
                    if(res[i].rating == reviews[j].name)
                        result[res[i].hotel][j]++
                }
            }
            for(var i in result){
                for(var j in reviews){
                    result[i]['averageRating']+= reviews[j].value*result[i][j]
                }
                result[i]['averageRating'] = result[i]['averageRating']>0?Math.round((result[i]['averageRating']/result[i]['total']) * 10)/10:0
            }
            return sendResponse(response,codes.SUCCESS,{success:true,list:result});
        })
    })
}

var ratingPercent=function(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[24]!='1'&& access[25]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var inputMonth=parseInt(data.month)
        var month = data.month
        var year = month.substr(0, 4);
        month = twoDigits(parseInt(month.substr(4)));
        var addCurrent=(month==(new Date(new Date()-0+8*60*60*1000).getUTCMonth()+1))
        var date = year + '-' + month
        var startMonth=new Date()
        if(!addCurrent)
            startMonth.setDate(0)
        startMonth=new Date(startMonth)
        var monthCount=startMonth.getMonth()+1;
        if(addCurrent)
            monthCount=monthCount-1
        var endMonth=(startMonth.getFullYear().toString())+'-'+(twoDigits(startMonth.getMonth()+1).toString())
        var startMonth=(startMonth.getFullYear().toString())+'-01'
        var result = {}
        var data_all = {}
        var deptCount={}
        var hotels={'點點心-新光桃園':{},'點點心-巨城新竹':{},'點點心-三井林口':{},'點點心-微風信義':{},'太興-ATT信義':{},'點點心-新光台中':{},'太興-微風北車':{},'點點心-微風北車':{},'點點心-新光台南':{}}
        CP.query(queries['GET_TARGET_YEAR'],[startMonth],function(err1,res1){
            if(err1)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res1)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            for(var i in res1){
                if(!deptCount[res1[i].month])
                    deptCount[res1[i].month]={}
                deptCount[res1[i].month][res1[i].department]=res1[i].count
            }
            for (var i in hotels) {
                if (groupToRes[i]) {
                    var groups = constants.RESTAURANT_TO_GROUP[groupToRes[i]].groups;
                } 
                else
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                for(var j in deptCount){
                    hotels[i][j]=deptCount[j][groups.service[0]]&&deptCount[j][groups.kitchen[0]]?deptCount[j][groups.service[0]]+deptCount[j][groups.kitchen[0]]:0
                }
            }
            CP.query(queries.MONTHLYTARGETALL,[startMonth,endMonth],function(err,res){
                if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false})
                else if(!res)
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                for(var i in res){
                    if(!result[res[i].hotel])
                        result[res[i].hotel]={month:0,overall:0}
                    if(!data_all[res[i].hotel])
                        data_all[res[i].hotel]={}
                    if(!data_all[res[i].hotel][res[i].month])
                        data_all[res[i].hotel][res[i].month]=0
                    if(res[i].rating=='FIVE')
                        data_all[res[i].hotel][res[i].month]+=res[i].count
                    if(res[i].rating=='ONE')
                        data_all[res[i].hotel][res[i].month]-=res[i].count
                }
                for (var i in data_all) {
                    for (var j in data_all[i]) {
                        if(j=='overall'||j=='count')
                            continue;
                        data_all[i][j] = ((data_all[i][j]) / (hotels[i][j]?hotels[i][j]:1) * 100)
                        if (!data_all[i]['overall'])
                            data_all[i]['overall'] = 0
                        if(!addCurrent||j!=endMonth){
                            data_all[i]['overall'] += data_all[i][j]>=100?1:0
                        }
                    }
                }
                for (var i in data_all) {
                    result[i]['month'] = Math.round(data_all[i][date] ? data_all[i][date] : 0)
                    if(result[i]['month']>=100)
                        result[i]['month']=100
                    result[i]['overall'] = Math.round(data_all[i]['overall'] / (i=='點點心-新光台南'&&year=='2021'?monthCount-1:monthCount) * 100)
                }
                var sumPercent = 0
                var count = 0
                for (var i in result) {
                    count++;
                    sumPercent += result[i]['month']>=100?1:0
                }
                return sendResponse(response,codes.SUCCESS,{success:true,list:result,AveragePercent:(Math.round(sumPercent/count*100))});
            })
        })
    })
}
var overallRating=function(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[24]!='1'&& access[25]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var date=new Date()
        date.setDate(0)
        date=new Date(date)
        var inputMonth=(date.getFullYear().toString())+'-'+(twoDigits(date.getMonth()+1).toString())
        var startMonth=(date.getFullYear().toString())+'-01'
        var monthCount=date.getMonth()+1;
        var year=(date.getFullYear().toString())
        var result = {}
        var data_all = {}
        var deptCount={}
        var hotels={'點點心-新光桃園':{},'點點心-巨城新竹':{},'點點心-三井林口':{},'點點心-微風信義':{},'太興-ATT信義':{},'點點心-新光台中':{},'太興-微風北車':{},'點點心-微風北車':{},'點點心-新光台南':{}}
        CP.query(queries['GET_TARGET_YEAR'],[startMonth],function(err1,res1){
            if(err1)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res1)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});

            for(var i in res1){
                if(!deptCount[res1[i].month])
                    deptCount[res1[i].month]={}
                deptCount[res1[i].month][res1[i].department]=res1[i].count
            }
            for (var i in hotels) {
                if (groupToRes[i]) {
                    var groups = constants.RESTAURANT_TO_GROUP[groupToRes[i]].groups;
                } 
                else
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                for(var j in deptCount){
                    hotels[i][j]=deptCount[j][groups.service[0]]+deptCount[j][groups.kitchen[0]]
                }
            }
            CP.query(queries.MONTHLYTARGETALL,[startMonth,inputMonth],function(err,res){
                if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false})
                else if(!res)
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                for(var i in res){
                    if(!result[res[i].hotel])
                        result[res[i].hotel]=0
                    if(!data_all[res[i].hotel])
                        data_all[res[i].hotel]={'overall':0,'count':0}
                    if(!data_all[res[i].hotel][res[i].month])
                        data_all[res[i].hotel][res[i].month]=0
                    if(res[i].rating=='FIVE')
                        data_all[res[i].hotel][res[i].month]+=res[i].count
                    if(res[i].rating=='ONE')
                        data_all[res[i].hotel][res[i].month]-=res[i].count
                }
                for (var i in data_all) {
                    for (var j in data_all[i]) {
                        if(j=='overall'||j=='count')
                            continue;
                        data_all[i][j] = (data_all[i][j] / hotels[i][j] * 100)
                        data_all[i]['overall'] += data_all[i][j]>=100?1:0
                        data_all[i]['count']++
                    }
                }
                console.log(data_all)
                for (var i in data_all) {
                    result[i] = Math.round(data_all[i]['overall'] / (i=='點點心-新光台南'&&year=='2021'?monthCount-1:monthCount) * 100)
                }
                return sendResponse(response,codes.SUCCESS,{success:true,list:result});
            })
        })
    })
}
function dateRange(startDate, endDate) {
  var start      = startDate.split('-');
  var end        = endDate.split('-');
  var startYear  = parseInt(start[0]);
  var endYear    = parseInt(end[0]);
  var dates      = [];
  for(var i = startYear; i <= endYear; i++) {
    var endMonth = i != endYear ? 11 : parseInt(end[1]) - 1;
    var startMon = i === startYear ? parseInt(start[1])-1 : 0;
    for(var j = startMon; j <= endMonth; j = j > 12 ? j % 12 || 11 : j+1) {
      var month = j+1;
      var displayMonth = month < 10 ? '0'+month : month;
      dates.push([i, displayMonth].join('-'));
    }
  }
  return dates;
}

function allmonthRating(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[24]!='1'&& access[25]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var date=new Date()
        date.setDate(0)
        date=new Date(date)
        var startMonth=date.getFullYear()+'-01';
        if(date.getFullYear()=='2021' && data.type=='點點心-新光台南')
            startMonth=date.getFullYear()+'-02';
        var endMonth=(date.getFullYear()+'-'+ twoDigits((date.getMonth())+1))
        var result = {}
        var params=[startMonth,endMonth]
        var allmonths=dateRange(startMonth,endMonth)
        params.push(data.type)
        var keys=['FIVE','FOUR','THREE','TWO','ONE']
        var groups
        if(groupToRes[data.type]){
            groups=constants.RESTAURANT_TO_GROUP[groupToRes[data.type]].groups;
        }else
            return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
        var params2=[]
        params2.push([groups.service[0],groups.kitchen[0]])
        CP.query(queries['GET_TARGET_DEPARTMENT'],params2,function(err1,res1){
            if(err1)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res1)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            var target={}
            var deptCount={}
            for(var i in res1){
                if(!deptCount[res1[i].month])
                    deptCount[res1[i].month]={}
                deptCount[res1[i].month][res1[i].department]=res1[i].count;
            }
            for(var i in deptCount){
                target[i]=deptCount[i][groups.service[0]]+deptCount[i][groups.kitchen[0]]
            }
            for(var i in allmonths){
                result[allmonths[i]]= {five:0,four:0,three:0,two:0,one:0,targetReached:0,target:target[allmonths[i]]}
            }
            CP.query(queries.MONTHLYTARGET,params,function(err,res){
                if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false})
                else if(!res)
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
console.log(res)
                for (var i in res) {
                    if (allmonths.indexOf(res[i].month) >= 0) {
                        switch (res[i]['rating']) {
                            case 'FIVE':
                                result[res[i].month]['five'] = res[i].count
                                result[res[i].month]['targetReached'] +=  res[i].count
                                break;
                            case 'FOUR':
                                result[res[i].month]['four'] = res[i].count
                                break;
                            case 'THREE':
                                result[res[i].month]['three'] = res[i].count
                                break;
                            case 'TWO':
                                result[res[i].month]['two'] = res[i].count
                                break;
                            case 'ONE':
                                result[res[i].month]['one'] = res[i].count
                                result[res[i].month]['targetReached'] -= res[i].count
                                break;
                        }
                    }
                }
                var count=0;
                var targetReached=0;
                for(var i in result){
                    count++;
                    if(result[i]['targetReached'] >= target[i])
                        targetReached++;
                }
                return sendResponse(response,codes.SUCCESS,{success:true,list:result,monthlyCompliance:(targetReached+'/'+count),achievmentRate:Math.round(targetReached / count * 100)});
            })
        })
    })
}

function targetHotel(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false});
        var access=res[0].fullAccess.split(',')
        if(access[24]!='1'&& access[25]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false});
        var hotel1={'點點心-新光桃園':0,'點點心-巨城新竹':0,'點點心-三井林口':0,'點點心-微風信義':0,'點點心-新光台中':0,'點點心-微風北車':0,'點點心-新光台南':0};
        var hotel2={'太興-ATT信義':0,'太興-微風北車':0};
        var deptCount={}
        var endDate=new Date()
        endDate=new Date(endDate-0+8*60*60*1000)
        var date=new Date(endDate)
        date.setDate(1)
        date=new Date(date-(date%(24*60*60*1000)))
        var startDate=new Date(date);
        CP.query(queries['GET_TARGET_MONTH'],[endDate.toISOString().substr(0,7)],function(err1,res1){
            if(err1)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res1)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            for(var i in res1){
                deptCount[res1[i].department]=res1[i].count;
            }
            for(var i in hotel1){
                if (groupToRes[i]){
                    var groups = constants.RESTAURANT_TO_GROUP[groupToRes[i]].groups;
                } 
                else
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                hotel1[i]=deptCount[groups.service[0]]+deptCount[groups.kitchen[0]];
            }
            for(var i in hotel2){
                if (groupToRes[i]){
                    var groups = constants.RESTAURANT_TO_GROUP[groupToRes[i]].groups;
                } 
                else
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                hotel2[i]=deptCount[groups.service[0]]+deptCount[groups.kitchen[0]];
            }
            CP.query(queries.GETCUSTOMMONTH,[startDate,endDate],function(err,res){
                if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false})
                else if(!res)
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                var result={}
                for(var i in res){
                    var hotel=res[i].hotel
                    if(!result[hotel])
                        result[hotel]=0
                    if(res[i].rating=='FIVE')
                        result[hotel]++;
                    else if(res[i].rating=='ONE')
                        result[hotel]--;
                }
                var count1=0
                var count2=0;
                for(var i in result){
                    if(hotel1[i]&&result[i]>=hotel1[i])
                        count1++;
                    else if(hotel2[i]&&result[i]>=hotel2[i])
                        count2++;
                }
                var list={
                    'dimdimsumNumber':count1,
                    'taixingNumber':count2,
                    'didimsumPercentage':Math.round(count1/Object.keys(hotel1).length*100),
                    'taixingPercentage':Math.round(count2/Object.keys(hotel2).length*100)
                }

                return sendResponse(response,codes.SUCCESS,{success:true,list:list});
            })
        })
    })
}

function graph(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false});
        var access=res[0].fullAccess.split(',')
        if(access[24]!='1'&& access[25]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false});
        var hotel1={'點點心-新光桃園':{},'點點心-巨城新竹':{},'點點心-三井林口':{},'點點心-微風信義':{},'點點心-新光台中':{},'點點心-微風北車':{},'點點心-新光台南':{}};
        var hotel2={'太興-ATT信義':{},'太興-微風北車':{}};
        var reviews={five:{name:'FIVE',value:5},four:{name:'FOUR',value:4},three:{name:'THREE',value:3},two:{name:'TWO',value:2},one:{name:'ONE',value:1}}
        var deptCount={};
        var date=new Date()
        date.setDate(1)
        date=new Date(date)
        date=new Date(date-date%(24*60*60*1000))
        var endMonth=new Date(date)
        date.setMonth(0)
        var startDate=new Date(date)
        date=new Date(endMonth)
        var endMonth=(endMonth.getFullYear()+'-'+ twoDigits((endMonth.getMonth())+1))
        startMonth=date.setMonth(date.getMonth() - ((data.type>30?data.type:30)/30))
        startMonth=new Date(startMonth)
        if(startMonth<startDate)
            startMonth=startDate
        startMonth=(startMonth.getFullYear()+'-'+ twoDigits((startMonth.getMonth())+1))
        var monthCount=Math.floor((new Date(endMonth)-new Date(startMonth)+7*60*60*1000*24)/(24*60*60*1000)/30)
        CP.query(queries.GET_TARGET_YEAR,[startMonth],function(err1,res1){
            if(err1)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res1)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            var deptCount={}
            for(var i in res1){
                if(!deptCount[res1[i].month])
                    deptCount[res1[i].month]={}
                deptCount[res1[i].month][res1[i].department]=res1[i].count;
            }
            for(var i in hotel1){
                if (groupToRes[i]){
                    var groups = constants.RESTAURANT_TO_GROUP[groupToRes[i]].groups;
                } 
                else
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                for(var j in deptCount){
                    hotel1[i][j]=deptCount[j][groups.service[0]]+deptCount[j][groups.kitchen[0]];
                }
            }
            for(var i in hotel2){
                if (groupToRes[i]){
                    var groups = constants.RESTAURANT_TO_GROUP[groupToRes[i]].groups;
                } 
                else
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                for(var j in deptCount){
                    hotel2[i][j]=deptCount[j][groups.service[0]]+deptCount[j][groups.kitchen[0]];
                }
            }

            
            CP.query(queries.GETCUSTOMYEAR,[],function(err,res){
                if(err)
                    return sendResponse(response,codes.DATABASE_ERROR,{success:false})
                else if(!res)
                    return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
                var result={}
                var totalRating={}
                for(var i in res){
                    if(!result[res[i].hotel]){
                        result[res[i].hotel]={}
                        totalRating[res[i].hotel]={rating:0,ratingCount:0}
                    }
                    var hotel=result[res[i].hotel]
                    var total=totalRating[res[i].hotel]
                    total.rating+=constants.RATING_MAP[res[i].rating]*res[i].count
                    total.ratingCount+=res[i].count
                    if(res[i].month>=startMonth&&res[i].month<endMonth){
                        if(!hotel[res[i].month])
                            hotel[res[i].month]={five:0,four:0,three:0,two:0,one:0,targetReached:0,count:0}
                        var month=hotel[res[i].month]
                        month.count+=res[i].count
                        switch(res[i].rating){
                            case 'FIVE':month.five+=res[i].count
                                        month.targetReached+=res[i].count;
                                        break;
                            case 'FOUR':month.four+=res[i].count
                                        break;
                            case 'THREE':month.three+=res[i].count
                                        break;
                            case 'TWO':month.two+=res[i].count
                                        break;
                            case 'ONE':month.one+=res[i].count
                                        month.targetReached-=res[i].count;
                                        break;
                        }
                    }
                }
                var month={'點點心':{},'太興':{}}
                var hotels={}
                for(var i in result){
                    totalRating[i].rating=Math.round(totalRating[i].rating/totalRating[i].ratingCount*10)/10
                    for(var j in result[i]){
                        var hotel
                        var target
                        if(hotel1[i]){
                            hotel='點點心';
                            target=hotel1[i][j]
                        }
                        else {
                            hotel='太興';
                            target=hotel2[i][j]
                        }
                        if(!month[hotel][j])
                            month[hotel][j]={rating:0,ratingCount:0}
                        if(!hotels[i])
                            hotels[i]={target:0,rating:0,targetCount:0,ratingCount:0}
                        console.log(startMonth,j,startMonth<=j)
                        if(startMonth<=j){
                            if(!month[hotel][j].target){
                                month[hotel][j].target=0;
                                month[hotel][j].targetCount=0;
                            }
                            var percentage=result[i][j].targetReached*100/target
                            if(percentage>=100)
                                percentage=100
                            month[hotel][j].target+=percentage;
                            month[hotel][j].targetCount++;
                            hotels[i].targetCount++
                            hotels[i].target+=percentage;    
                        }
                        var ratingSum=0
                        for(var k in reviews)
                            ratingSum+= reviews[k].value*result[i][j][k]
                        month[hotel][j].rating+=ratingSum
                        month[hotel][j].ratingCount+=result[i][j].count
                        hotels[i].rating+=ratingSum
                        hotels[i].ratingCount+=result[i][j].count
                    }
                    hotels[i].percentage=hotels[i].targetCount>0?Math.round(hotels[i].target/(startMonth=='2021-01'&&i=='點點心-新光台南'?monthCount-1:monthCount)):0
                    if(hotels[i].percentage>100)
                        hotels[i].percentage=100;
                    hotels[i].rating=hotels[i].rating>0?Math.round((hotels[i].rating/hotels[i].ratingCount) * 10)/10:0
                }
                for(var i in month){
                    for(var j in month[i]){
                        if(month[i][j].hasOwnProperty('target')){
                            month[i][j].percentage=Math.round(month[i][j].target/(i=='點點心'?(j=='2021-01'?6:7):2))
                            if(month[i][j].percentage>=100)
                                month[i][j].percentage=100;
                        }
                        month[i][j].rating=month[i][j].rating>0?Math.round((month[i][j].rating/month[i][j].ratingCount) * 10)/10:0
                    }
                }
                return sendResponse(response,codes.SUCCESS,{success:true,months:month,hotels:hotels,totalRating:totalRating});
            })
        })
    })
}

var bonus=function(data,response){
    CP.query(queries.BONUS,[data.year,data.loginId],function(err,res){
        if(err)
            return sendResponse(response,codes.DATABASE_ERROR,{success:false})
        else if(!res||res.length==0)
            return sendResponse(response,codes.SUCCESS,{bonus:null});
        sendResponse(response,codes.SUCCESS,{success:true,bonus:res[0]});
    })
}

var hotelRating=function(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[26]!='1'&& access[27]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var month=data.month
        var year=month.substr(0,4);
        month=month.substr(4);
        var date=year+'-'+twoDigits(parseInt(month)) //FORMAT YYYY-MM
        var hotels=data.type=='點點心'?constants.HOTEL_DIMDIMSUM:constants.HOTEL_TAXING
        params=[date,hotels]
        CP.query(queries.GETREVIEWHOTELS,params,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
        
            var result={}
            for (var i in res) {
                if(!result[res[i].hotel])
                    result[res[i].hotel]={happy:0,normal:0,sad:0}
                var hotel=result[res[i].hotel]
                switch (res[i]['rating']) {
                    case 'FIVE':
                        hotel.happy+=res[i].count
                        break;
                    case 'FOUR':
                        hotel.happy+=res[i].count
                        break;
                    case '正面':
                        hotel.happy+=res[i].count
                        break;
                    case 'THREE':
                        hotel.normal+=res[i].count
                        break;
                    case '中立':
                        hotel.normal+=res[i].count
                        break;
                    case 'TWO':
                        hotel.sad+=res[i].count
                        break;
                    case 'ONE':
                        hotel.sad+=res[i].count
                        break;
                    case '負面':
                        hotel.sad+=res[i].count
                        break;
                }
            }
            return sendResponse(response,codes.SUCCESS,{success:true,list:result});
        })
    })
}
var timeRating=function(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[26]!='1'&& access[27]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var startDate=new Date(new Date(data.startDate)-8*60*60*1000)
        var endDate=new Date(new Date(data.endDate)-0+16*60*60*1000)
        params=[startDate,endDate]
        CP.query(queries.GETTIMERATING,params,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
        
            var result={}
            for (var i in res) {
                if(!result[res[i].hotel])
                    result[res[i].hotel]={happy:0,normal:0,sad:0}
                var hotel=result[res[i].hotel]
                switch (res[i]['rating']) {
                    case 'FIVE':
                        hotel.happy+=res[i].count
                        break;
                    case 'FOUR':
                        hotel.happy+=res[i].count
                        break;
                    case '正面':
                        hotel.happy+=res[i].count
                        break;
                    case 'THREE':
                        hotel.normal+=res[i].count
                        break;
                    case '中立':
                        hotel.normal+=res[i].count
                        break;
                    case 'TWO':
                        hotel.sad+=res[i].count
                        break;
                    case 'ONE':
                        hotel.sad+=res[i].count
                        break;
                    case '負面':
                        hotel.sad+=res[i].count
                        break;
                }
            }
            return sendResponse(response,codes.SUCCESS,{success:true,list:result});
        })
    })
}
var timeReview=function(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[26]!='1'&& access[27]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var startDate=new Date(new Date(data.startDate)-8*60*60*1000)
        var endDate=new Date(new Date(data.endDate)-0+16*60*60*1000)
        params=[startDate,endDate,data.type]
        CP.query(queries.GETTIMEREVIEW,params,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            return sendResponse(response,codes.SUCCESS,{success:true,result:res});
        })
    })
}

function reviewGraph(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false});
        var access=res[0].fullAccess.split(',')
        if(access[26]!='1'&& access[27]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false});
        var hotel1=['點點心-新光桃園','點點心-巨城新竹','點點心-三井林口','點點心-微風信義','點點心-新光台中','點點心-微風北車','點點心-新光台南'];
        var hotel2=['太興-ATT信義','太興-微風北車'];
        var endDate=new Date()
        var date=endDate
        var datestoyear={}
        var month=endDate.getMonth()
        var year=endDate.getFullYear()
        var lastyear,startDate,dateMax;
        if(data.type>15){
            var monthCount=data.type/30
            for(var i=12; i>0;i--){
                if(month == 0){
                    month=12
                    year=year-1
                }
                datestoyear[year+'-'+twoDigits(month)]=[new Date(new Date(year,month,1)),new Date(new Date(year,month-1,2))]
                if(i==1)
                    lastyear=new Date(year,month-1,2)
                month=month-1
            }
            console.log(datestoyear)
            endDate=new Date(endDate.setDate(0))
            var startDate=new Date(endDate)
            startDate=new Date(startDate.setDate(1))
            startDate=startDate.setMonth(startDate.getMonth() - (data.type/30)+1)
            startDate=new Date(startDate) 
            var dateMax=startDate<lastyear?lastyear:startDate
        }else{
            var week=new Date();
            week.setDate(week.getDate()+1-week.getDay())
            week=new Date(week);
            if(week.getDate()>=(new Date()).getDate()){
                week.setDate(week.getDate()-7)
                week=new Date(week)
            }
            week=new Date(week-(week%(24*60*60*1000)))
            endDate=new Date(week-0+24*60*60*1000)
            var startDate=new Date(endDate-(24*60*60*1000*(parseInt(data.type))))
            week=new Date(week-(data.type-1)*24*60*60*1000)
            for(var i=0;i<data.type;i++){
                datestoyear[week.toISOString().substr(0,10)]=[new Date(week-0+24*60*60*1000),new Date(week)]
                week=new Date(week-0+24*60*60*1000)
            }
            date=new Date(endDate)
            console.log(datestoyear)
            dateMax=startDate

        }
        console.log(dateMax,date)
        CP.query(queries.GETCUSTOMREVIEW,[dateMax,date],function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            var result={'dimdimsum':{'ratingBase':{'happy':0,'normal':0,'sad':0},'platformBase':{'google':0,'facebook':0,'instoreData':0,'line':0},'lastyear':{}},'total':{'ratingBase':{'happy':0,'normal':0,'sad':0},'platformBase':{'google':0,'facebook':0,'instoreData':0,'line':0},'lastyear':{}},'taxing':{'ratingBase':{'happy':0,'normal':0,'sad':0},'platformBase':{'google':0,'facebook':0,'instoreData':0,'line':0},'lastyear':{}}}
            var graph={'dimdimsum':{},'taxing':{},'total':{}}
            var barGraph={}
            var total={'dimdimsum':0,'taxing':0,'total':0}
            if(data.type<15)
                for(var i in graph){
                    for(var key in datestoyear){
                        graph[i][key]={sad:0,happy:0,normal:0}
                    }
                }
            var total_last={'dimdimsum':{},'taxing':{},'total':{}}
            var total_bar={}
            for(var i in hotel1){
                barGraph[hotel1[i]]={}
                total_bar[hotel1[i]]={}
                for(var key in datestoyear){
                    barGraph[hotel1[i]][key]={sad:0,happy:0,normal:0}
                    total_bar[hotel1[i]][key]=0
                }
            }
            for(var i in hotel2){
                barGraph[hotel2[i]]={}
                total_bar[hotel2[i]]={}
                for(var key in datestoyear){
                    barGraph[hotel2[i]][key]={sad:0,happy:0,normal:0}
                    total_bar[hotel2[i]][key]=0
                }
            }
            for (var i in res) {
                var type
                if (hotel1.indexOf(res[i].hotel) >= 0) {
                    type = 'dimdimsum'
                }
                if (hotel2.indexOf(res[i].hotel) >= 0) {
                    type = 'taxing'
                }
                if(res[i].createTime > startDate && res[i].createTime < endDate){
                    total['total']++
                    total[type]++
                    if (res[i].rating == 'FIVE' || res[i].rating == 'FOUR' || res[i].rating == '正面') {
                        result[type]['ratingBase']['happy']++
                        result['total']['ratingBase']['happy']++
                    }
                    if (res[i].rating == 'THREE' || res[i].rating == '中立') {
                        result[type]['ratingBase']['normal']++
                        result['total']['ratingBase']['normal']++
                    }
                    if (res[i].rating == 'TWO' || res[i].rating == 'ONE' || res[i].rating == '負面') {
                        result[type]['ratingBase']['sad']++
                        result['total']['ratingBase']['sad']++
                    }
                    if(res[i].source == 'Google' || res[i].source == null){
                        result[type]['platformBase']['google']++
                        result['total']['platformBase']['google']++
                    }
                    if(res[i].source == '店內顧客意見表'){
                        result[type]['platformBase']['instoreData']++
                        result['total']['platformBase']['instoreData']++
                    }
                    if(res[i].source == 'FB'){
                        result[type]['platformBase']['facebook']++
                        result['total']['platformBase']['facebook']++
                    }
                    if(res[i].source == 'LINE'){
                        result[type]['platformBase']['line']++
                        result['total']['platformBase']['line']++
                    }

                }
                var key=data.type>14?res[i].month:res[i].date
                if(datestoyear[key]){
                    var j=key
                    if(!barGraph[res[i].hotel][j]){
                        barGraph[res[i].hotel][j]={'happy':0,'normal':0,'sad':0}
                        total_bar[res[i].hotel][j]=0
                    }
                    if(!total_last[type][j])
                        total_last[type][j]=0
                    if(!total_last['total'][j])
                        total_last['total'][j]=0
                    if(!graph['total'][j])
                        graph['total'][j]={'happy':0,'normal':0,'sad':0}
                    if(!graph[type][j])
                        graph[type][j]={'happy':0,'normal':0,'sad':0}
                    if(res[i].createTime >= datestoyear[j][1] && res[i].createTime <= datestoyear[j][0]){
                        total_last[type][j]++
                        total_last['total'][j]++
                        total_bar[res[i].hotel][j]++
                        if (res[i].rating == 'FIVE' || res[i].rating == 'FOUR' || res[i].rating == '正面' ) {
                            barGraph[res[i].hotel][j]['happy']++
                            graph[type][j]['happy']++
                            graph['total'][j]['happy']++
                        }
                        if (res[i].rating == 'THREE' || res[i].rating == '中立') {
                            barGraph[res[i].hotel][j]['normal']++
                            graph['total'][j]['normal']++
                            graph[type][j]['normal']++
                        }
                        if (res[i].rating == 'TWO' || res[i].rating == 'ONE' || res[i].rating == '負面') {
                            barGraph[res[i].hotel][j]['sad']++
                            graph['total'][j]['sad']++
                            graph[type][j]['sad']++
                        }
                    }
                }
            }
            for(var i in result){
                for(j in result[i]){
                    for(var k in result[i][j]){
                        if(total[i]>0)
                            result[i][j][k]=Math.round((result[i][j][k]/total[i])*100)
                    }
                }
            }
            for(var i in graph){
                for(j in graph[i]){
                    console.log(total_last[i][j],graph[i][j])
                    for(var k in graph[i][j]){
                        if(total_last[i][j]>0)
                            graph[i][j][k]=Math.round((graph[i][j][k]/total_last[i][j])*100)
                    }
                }
            }
            for(var i in barGraph){
                for(j in barGraph[i]){
                    for(var k in barGraph[i][j]){
                        if(total_bar[i][j]>0)
                            barGraph[i][j][k]=Math.round((barGraph[i][j][k]/total_bar[i][j])*100)
                    }
                }
            }
            return sendResponse(response,codes.SUCCESS,{success:true,list:{'pie':result,'graph':graph,'bar':barGraph}});
            console.log(result,graph,barGraph)
        })
    })
}

function nonReplyReview(data,response){
     CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[26]!='1'&& access[27]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        params=[data.type]
        CP.query(queries.NONREPLYREVIEW,params,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            return sendResponse(response,codes.SUCCESS,{success:true,result:res});
            console.log(res)
        })
    })
}

function video(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[29]!='1'&& access[30]!='1' && access[32]!='1' && !data.webui)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        CP.query(queries.VIDEO,[],function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            return sendResponse(response,codes.SUCCESS,{success:true,result:res});
        })
    });
}

function bomin(data,response){
    CP.query(queries.GET_FULL_ACCESS,[data.loginId],function(err,res){
        if(err||!res||res.length==0||!res[0].fullAccess)
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var access=res[0].fullAccess.split(',')
        if(access[31]!='1')
            return sendResponse(response,codes.INVALID_DATA,{success:false})
        var date=data.date
        var month=date.substr(3,2)
        var params=[],params2=[]
        date=new Date(date)
        var startMonth=new Date((new Date(date)).setDate(1))
        var day=startMonth.getDay();
        if(day!=1)
            startMonth.setDate(9-day)    
        month=startMonth.getUTCMonth();
        var weekdays={}
        var startMonth=new Date(startMonth)
        params.push({name:'MONTH_START',value:startMonth.toISOString().substr(0,10)})
        date=new Date(startMonth)
        var count=1;
        while(month==date.getUTCMonth()){
            params2.push({name:'DATE'+(count-1),value:(new Date(date)).toISOString().substr(0,10)})
            weekdays[date.toISOString().substr(0,10)]={start:new Date(date),end:new Date(date-0+(4*24*60*60*1000)),index:count}
            count++;
            date.setDate(date.getDate()+7)
        date=new Date(date)
        }
        params.push({name:'MONTH_END',value:(new Date(date)).toISOString().substr(0,10)})
        var endMonth=new Date(startMonth)
        MS.query(queries.BOMIN,params,null,function(err,res){
            if(err)
                return sendResponse(response,codes.DATABASE_ERROR,{success:false})
            else if(!res||!res.recordset)
                return sendResponse(response,codes.SUCCESS,{success:false,ReasonCode:3,Reason:errors[3]});
            res=res.recordset
            var result={}
            for(var i in res){
                if(!result[res[i].Q01])
                    result[res[i].Q01]={T01:res[i].Q01,T02:res[i].Q02,week:{},days:{},Q04:0}
                var product=result[res[i].Q01];
                var dayDate=new Date(res[i].Q00)
                var weekDate=new Date(res[i].Q00);
                weekDate.setDate(weekDate.getDate()+1-weekDate.getDay())
                weekDate=new Date(weekDate)
                var selectedWeek=weekdays[weekDate.toISOString().substr(0,10)]
                if(selectedWeek&&dayDate>=selectedWeek.start&&dayDate<=selectedWeek.end){
                    if(selectedWeek.index==weekdays[data.date].index){
                        product.Q04+=res[i].Q04
                        product.days[dayDate.toISOString().substr(0,10)]=res[i].Q04;
                    }
                    var weekDate=weekDate.toISOString().substr(0,10)
                    if(!product.week[weekDate])
                        product.week[weekDate]={Q04:0,T08:0}
                    product.week[weekDate].Q04+=res[i].Q04
                }
            }
            console.log(result)
            var weekShdlCol=['T02','T03','T04','T05','T06','T07','T08','T09','T10','T11','T12','T13','T14']
            MS.query(queries.WEEKSHDL_START+(count>5?',@DATE4':'')+queries.WEEKSHDL_END,params2,null,function(errr,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    res1=res1.recordset
                    for(var i in res1){
                        if(!result[res1[i].T01])
                            result[res1[i].T01]={T01:res1[i].T01,T02:res1[i].T02}
                        var product=result[res1[i].T01]
                        var weekDate=new Date(res1[i].T00)
                        weekDate=weekDate.toISOString().substr(0,10)
                        if(product.week&&product.week[weekDate])
                            product.week[weekDate].T08=res1[i].T08
                        if(weekdays[weekDate]&&weekdays[weekDate].index==1){
                            for(var j in res1[i]){
                                if(weekShdlCol.indexOf(j)>=0)
                                    product[j]=res1[i][j]   
                            }
                        }
                    }
                }

                for(var i in result){
                    var product=result[i]
                    if(product.T08&&product.Q04)
                        product.percentage=Math.round(product.Q04*1000/product.T08)/10
                    for(var j in product.week){
                        var weekData=product.week[j]
                        if(weekData.T08&&weekData.Q04)
                            weekData.percentage=Math.round(weekData.Q04*1000/weekData.T08)/10
                    }
                }
                return sendResponse(response,codes.SUCCESS,{success:true,result:result,weeks:Object.keys(weekdays).length});
            })
        });
    });
}

var mapping={
    '/video':{
        model:video,
        fields:[],
        authCheck:true,
    },
    '/bomin':{
        model:bomin,
        fields:['date'],
        authCheck:true,
    },
    '/nonReplyReview':{
        model:nonReplyReview,
        fields:['type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/reviewGraph':{
        model:reviewGraph,
        fields:['type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/hotelRating':{
        model:hotelRating,
        fields:['month','type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/timeRating':{
        model:timeRating,
        fields:['startDate','endDate'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/timeReview':{
        model:timeReview,
        fields:['startDate','endDate','type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/bonus':{
        model:bonus,
        fields:['year'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/graph':{
        model:graph,
        fields:['type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/targetHotel':{
        model:targetHotel,
        fields:['type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/allmonthRating':{
    model:allmonthRating,
        fields:['type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/overallRating':{
        model:overallRating,
        fields:[],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/ratingPercent':{
        model:ratingPercent,
        fields:['month'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/rating':{
        model:gReview,
        fields:['month','type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/ratingAll':{
        model:gReviewAll,
        fields:[],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/sellout':{
        model:sellout,
        fields:['group','date'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/purchaseStock':{
        model:podchk,
        fields:['group','date'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/login': {
        model:login,
        fields:['username','password']
    },
    '/fdCost':{
        model:fdcost,
        fields:['type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/employee':{
        model:vwzz_new,
        fields:['type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/employeeNew':{
        model:vwzz_new,
        fields:['type'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/notification/save': {
        model:saveNotification,
        fields:['dateTime','message'],
        authCheck:true,
    },
    '/notification/history' :{
        model:notificationHistory,
        fields:['group'],
        authCheck:true
    },
    '/groups':{
    	model:groups,
    	fields:[],
        authCheck:true,
    },
    '/profile':{
        model:profile,
        fields:[],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/list':{
        model:list,
        fields:[],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/salary':{
        model:salary,
        fields:['type','month'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/salaryAll':{
        model:salaryAll,
        fields:['month'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true
    },
    '/getAccess':{
        model:getAccess,
        fields:[],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/setAccess':{
        model:setAccess,
        fields:['employeeID','access'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/setGroupAccess':{
        model:setGroupAccess,
        fields:['group','access','accessNo'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/setMultipleAccess':{
        model:setMultipleAccess,
        fields:['idCount','access','accessNo','departmentCount','jobCount'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/inventory':{
        model:inventory,
        fields:['group','type','date'],
        table:'vwZZ_EMPLOYEE',
        authCheck:true,
    },
    '/signUP':{
        model:signup,
        fields:['emailID','username','password']
    },
    '/forgotPswd':{
        model:forgotpassword,
        fields:['emailID']
    },
    '/logout':{
        model:logout,
        fields:['regid'],
        authCheck:true,
    },
    '/logoutUI':{
        model:logout,
        fields:['regid'],
        authCheck:true,
    },
    '/setCount':{
        model:setCount,
        fields:[],
        authCheck:true,
    },
    '/notification/changeAccess':{
        model:notificationChangeAccess,
        fields:['employeeID','access'],
        authCheck:true
    },
    '/notification/list':{
        model:notificationList,
        fields:[],
        authCheck:true
    },
    '/notification/delete' :{
        model:notificationDelete,
        fields:['mes_no'],
        authCheck:true
    },
    '/employeeBasicInfo':{
        model:employeeBasicInfo,
        fields:['employeeID'],
        authCheck:true
    },
    '/lastMonthData':{
        model:profile,
        fields:[],
        table:'oldEmployeeData',
        authCheck:true
    },
    '/bulletin/list':{
        authCheck:true,
        model:bulletinBoardList,
        fields:['group'],
    },
    '/bulletin/clear':{
        authCheck:true
    },
    '/updateRegID':{
        model:updateRegID,
        authCheck:true,
        fields:['newID']
    },
    '/storeUpdateInfo':{
        model:storeUpdateInfo,
        fields:[],
        authCheck:true
    },
    '/notiTestResult':{
        model:notiTestResult,
        fields:[],
        authCheck:true
    },
    '/revenue/day':{
        model:dayRev,
        fields:['date'],
        authCheck:true
    },
    '/revenue/month':{
        model:monRev,
        fields:['month'],
        authCheck:true
    },
    '/revenue/foodqty':{
        model:foodQty,
        fields:['month'],
        authCheck:true
    },
    '/revenue/target':{
        model:target,
        fields:['month','group'],
        authCheck:true
    },
    '/revenue/targetAll':{
        model:targetAll,
        fields:['month'],
        authCheck:true
    },
}
const codes = {
    AUTH_ERROR: 401,
    INVALID_DATA: 400,
    SUCCESS: 200,
    NOT_FOUND:404,
    DATABASE_ERROR:503
}
var contoroller={};

contoroller.list=function(data,callback){
    var query=queries.BULLETIN_LIST;
    var params=[s3prefix]

    if(data){
        query+=queries.GROUP_CHECK
        params.push('%'+(data.group&&data.loginId!='151001'?data.group:'')+'%');
        if(data.startEpoch){
            query+=queries.TIME_FILTER;
            params.push(new Date(parseInt(data.startEpoch)),new Date(parseInt(data.endEpoch)));
        }
    } 
    query+=queries.ORDER_BY
    CP.query(query,params,callback)
}

function sendResponse(res, code,result) {
    res.status(code).send(JSON.stringify(result));
}
contoroller.updateEmployee=function(callback){
    MS.query(queries.GET_OLD_EMPLOYEE,[],true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            res=res.recordset
            console.log('--------employees',res)
            var loginIds=[]
            for(var i in res)
                loginIds.push(res[i].loginId)
            CP.query(queries.REMOVE_OLD_EMPLOYEE,[loginIds],function(err,res1){
                console.log('---old deletes',res1)
                if(!err&&res)
                    callback(loginIds);
            })
        }
    })
}
contoroller.updateDepartments=function(callback){
    MS.query(queries.GET_DEPARTMENTS,[],true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            var departments=[]
            res=res.recordset
            for(var i in res)
                departments.push(res[i].DEPARTMENT_CNAME);
            console.log('---------new departments',departments)
            fs.writeFile('./util/departments.json',JSON.stringify({departments:departments}, null, 4),'utf8', function(err,res){
                department=departments
                callback(departments)
            })
        }
    })
}
contoroller.authCheck=function (req,res,next) {
	if(!mapping[req.path].authCheck)
		return next();
	if(!req || !req.headers || !req.headers.token )
		return sendResponse(res,codes.AUTH_ERROR,{success:false})
	CP.query(queries.TOKEN_CHECK,[req.headers.token],function(err,result){
        if(!err&&result&&result.length>0){
            if(req.body){
                req.body.loginId=result[0].loginId
                req.body.expire=result[0].expire
                req.body.notifiCount=result[0].count
                if(!req.body.job)
                    req.body.job=result[0].joblayer
                req.body.notifiCompany=result[0].layer
            }
            req.body.table=mapping[req.path].table;
            req.body.token=req.headers.token;
            next()
        }
        else 
            sendResponse(res,codes.AUTH_ERROR,{success:false})
    })
}
var validate=function(data,fields){
	var valid=true;
	for(var i in fields)
		if(!data.hasOwnProperty(fields[i])){
			valid=false;
			break;
		}
	return valid;
}
contoroller.do=function(req,res){
	var mapper=mapping[req.path]
	var body=req.body
 	if(!validate(body,mapper.fields))
 		return sendResponse(res,codes.INVALID_DATA,{success:false})
 	mapper.model(body,res,req.path)
}
module.exports=contoroller;
