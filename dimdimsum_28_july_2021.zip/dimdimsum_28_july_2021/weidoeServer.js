var fs = require('fs');
var http = require('http');
var config=require('./initConf');
var url = require('url');


http.createServer(function(req, res){
  var request = url.parse(req.url, true);
  var action = request.pathname;

  if (action == '/privacy-policy') {
     var img = fs.readFileSync('./images/privacyPolicy.png');
     res.writeHead(200, {'Content-Type': 'image/png' });
     res.end(img, 'binary');
  } else { 
    var img = fs.readFileSync('./images/main.png');
    res.writeHead(200, {'Content-Type': 'image/png' });
    res.end(img, 'binary');
  }
}).listen(config.WEIDOEPORT);