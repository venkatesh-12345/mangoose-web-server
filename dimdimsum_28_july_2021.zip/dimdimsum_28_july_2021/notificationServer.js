var request = require("request");
var config = require("./initConf").get();
var s3prefix=config.S3.prefix
var CP=require('./middleware/sql')
var email=require('./emailDispatcher.js').sendFCMEmail
var MS=require('./middleware/mssql')
var notification={}
var reviewsfetch=require('./getReview.js')
var http = require('http');
var messages=[],endDate,messageCounts={};
var columns=require('./util/columns');
var delAttach=require('./saveUploaded.js')
var constants=require('./util/constants.js')
var queries=constants.queries;
constants=constants.constants
var daysOfMonth=constants.MONTH_TO_DAYS
var groupToRes=constants.NEW_GROUP_TO_RESTAURANT;


var sendNotification=function(data,counts,retry,index){
    if(!index)
        index=0;
    if(!retry)
        retry=0;
    if(retry>5){
        email(JSON.stringify(data, null, 4),function(err,res){})
        console.log('Retry Exhausted',data)
        return sendNotification(data,counts,0,index+1)
    }
    if(data.message&&data.message.length>400){
        data.message=data.message.substring(0,400)
        data.largeMsg=true
    }
    if(data.regids.length==0)
        return;
    var msg = {
        registration_ids: [data.regids[index]],
        notification: {
            sound: constants.SOUND,
            title: data.title?data.title:constants.TITLE,
            body:data.message&&data.message.indexOf('<tr')<0? data.message:undefined,
            badge: counts[data.regids[index]],
            type:data.type,
            largeMsg:data.largeMsg,
            time:data.dateTime,
            mes_no:parseInt(data.mes_no),
            image:data.image
        },
        data:{
            click_action: constants.CLICK_ACTION,
            title: data.title?data.title:constants.TITLE,
            badge: counts[data.regids[index]],
            body: data.message,
            extension:data.extension,
            time:data.dateTime,
            type:data.type,
            largeMsg:data.largeMsg,
            mes_no:data.mes_no
        },
        priority: 10
    }
    if(data.message){
        msg.data.senderTitle=data.senderTitle;
        msg.data.company=data.company;
        msg.data.name=data.name;
        msg.data.dateTime=data.dateTime;
        if(data.extension)
            msg.data.path="notification/"+data.mes_no+"."+data.extension
    }else  if(data.endTime){
        msg.notification.body=constants.BULLETIN_BODY;
        msg.data.groups=data.recepients.join();
        if(data.jobs)
            msg.data.jobs=data.jobs.join();
        if(data.allIds)
            msg.data.ids=data.allIds.join();
        msg.data.dateTime=data.dateTime;
        msg.data.startTime=(new Date(data.startTime)-0)*1000;
        msg.data.endTime=(new Date(data.endTime)-0)*1000;
        msg.data.path=s3prefix+data.mes_no+"."+data.extension
    }
    if(data.type=='HBD'){
        msg.data.hbdId=data.hbdId
    }

    request.post({
        uri: config.Firebase,
        body: msg,
        json: true,
        headers: {
            Authorization: 'key=' + config.AuthKey
        }
    }, function(err, response, b) {
        console.log(new Date(),msg,err, b)
        if(b.failure>0)
            handleUnsentNotification(err,data,b,retry,counts,index)
        CP.query(queries.UPDATE_COUNT,[counts[data.regids[index]],data.regids[index]],function(err,res){})
        if(index+1<data.regids.length)
            sendNotification(data,counts,retry,index+1)
    })
}
var handleUnsentNotification=function(err,data,body,retry,counts,index){
    var disableList = [];
    var retryList = [];
    var response = body.results[0];
    var error=response.error
    if (error == "InvalidRegistration" || error == "NotRegistered" || error == "MissingRegistration") 
        disableList.push(data.regids[index])
    else if(error == 'InternalServerError' || error == 'Unavailable')
        retryList.push(data.regids[index])
    if(disableList.length>0)
        CP.query(queries.DISABLE_REGIDS,[disableList],function(err,res){});
    if (retryList.length > 0) {
        data.regids = retryList;
        retry++;
        sendNotification(data,counts,retry,index)
    }
};
var getRegIds=function(res,callback){
    var query
    var columns=[],params=[],groups=[],ids=[],jobs=[]
    for(var i in res){
        if(res[i].jobs){
            var job=res[i].jobs.split(',');
            for(var j in job)
                if(jobs.indexOf(job[j])==-1)
                    jobs.push(job[j])
            res[i].jobs=job;
            if(columns.indexOf(' joblayer IN(?) ')==-1)
                columns.push(' joblayer IN(?) ')
        }
        if(res[i].allIds){
            var id=res[i].allIds.split(',');
            for(var j in id)
                if(ids.indexOf(id[j])==-1)
                    ids.push(id[j])
            res[i].allIds=id
            if(columns.indexOf(' loginId IN(?) ')==-1)
                columns.push(' loginId IN(?) ')
        }
        if(res[i].recepients){
            var group=res[i].recepients.split(',');
            for(var j in group)
                if(groups.indexOf(group[j])==-1)
                    groups.push(group[j])
            res[i].recepients=group;
            if(columns.indexOf(' layer IN(?) ')==-1)
                columns.push(' layer IN(?) ') 
        }
    }
    for(var i in columns){
        if(columns[i]==' joblayer IN(?) ')
            params[i]=jobs
        if(columns[i]==' loginId IN(?) ')
            params[i]=ids
        if(columns[i]==' layer IN(?) ')
            params[i]=groups
    }
    query=queries.GET_REG_ID_NEW+columns.join(' or ')+')'
    CP.query(query,params,function(err,result){
        if(!err && result && result.length>0){
            var empWithGroups={}
            var counts={}
            for (var i in result){
                counts[result[i].regId]=result[i].count+1
                if(empWithGroups[result[i].layer])
                    empWithGroups[result[i].layer].push(result[i].regId)
                else
                    empWithGroups[result[i].layer]=[result[i].regId];
                if(empWithGroups[result[i].joblayer])
                    empWithGroups[result[i].joblayer].push(result[i].regId)
                else
                    empWithGroups[result[i].joblayer]=[result[i].regId];
                if(empWithGroups[result[i].loginId])
                    empWithGroups[result[i].loginId].push(result[i].regId)
                else
                    empWithGroups[result[i].loginId]=[result[i].regId];
            }

            for(var i in res){
                var regIds=[];
                if(res[i].recepients)
                    for(var j in res[i].recepients)
                        if(empWithGroups[res[i].recepients[j]])
                            regIds=regIds.concat(empWithGroups[res[i].recepients[j]].filter((item) => regIds.indexOf(item) < 0))
                if(res[i].jobs)
                    for(var j in res[i].jobs)
                        if(empWithGroups[res[i].jobs[j]])
                            regIds=regIds.concat(empWithGroups[res[i].jobs[j]].filter((item) => regIds.indexOf(item) < 0))
                if(res[i].allIds)
                    for(var j in res[i].allIds)
                        if(empWithGroups[res[i].allIds[j]])
                            regIds=regIds.concat(empWithGroups[res[i].allIds[j]].filter((item) => regIds.indexOf(item) < 0))
                res[i].regids=regIds
            }
            callback(res,counts)
        }
        else
            callback(null)
    })
}

var getRegIdsList = function (res, callback) {
    var groups = [];
    for (var i in res) {
        var group = res[i].recepients.split(',')
        var department_name = group[0].split('|')
        var cname = department_name[0]
        console.log(res[i])
        if (groups.indexOf(group[0]) == -1){
            var groupslist = [];
            for (var hbdmap in constants.HBD_MAPPING) {
                var dept = constants.HBD_MAPPING[hbdmap]
                if (dept.indexOf(department_name[1]) >= 0) {
                    console.log(dept)
                    for (var j in dept) 
                        groupslist.push(cname + '|' + dept[j])
                }
            }
            groups=groups.concat(groupslist)
            res[i].recepients=groupslist
        }
    }
    CP.query(queries.GET_REG_ID, [groups], function (err, result) {
        if (!err && result && result.length > 0) {
            var empWithGroups = {}
            var counts = {}
            for (var i in result) {
                counts[result[i].regId] = result[i].count + 1
                if (empWithGroups[result[i].layer])
                    empWithGroups[result[i].layer].push(result[i].regId)
                else
                    empWithGroups[result[i].layer] = [result[i].regId];
            }

            for (var i in res) {
                var regIds = {};
                for (var j in res[i].recepients){
                    if (empWithGroups[res[i].recepients[j]])
                        regIds[res[i].recepients[j]]=empWithGroups[res[i].recepients[j]]
                }
                res[i].regids = regIds
            }
            callback(res, counts)
        }
        else
            callback(null)
    })
}


var insertNotification=function(message){
    var dateTime;
    if(message.repetition==constants.CUSTOM){
        var dateList=message.dateList.split(',');
        var index=dateList.indexOf(new Date(message.dateTime)-0+'');
        if(index<dateList.length-1)
            dateTime=new Date(parseInt(dateList[index+1]))
    }else{
        message.dateTime=(new Date()).toDateString()+' '+(new Date(message.dateTime)).toTimeString();
    }
        var jobs='',ids=''
    if(message.allIds)
        ids=message.allIds.join()
    if(message.jobs)
        jobs=message.jobs.join()
    CP.query(queries.INSERT_SCHEDULE,[new Date(message.dateTime),message.message,message.recepients.join(),message.title,new Date(message.startTime),new Date(message.endTime),message.type,message.senderTitle,message.name,message.company,null,null,message.extension,message.extension?message.mes_no+'.'+message.extension:null,true,jobs,ids,null],function(err,result){})
    if(dateTime){
        CP.query(queries.UPDATE_CUSTOM,[dateTime,message.mes_no],function(err,res){
            if(dateTime<endDate){
                message.dateTime=dateTime
                addMessage(message);
            }
        })
    }
}
var setSent=function(){
    CP.query(queries.SET_SENT_TRUE,[true,new Date()<endDate?new Date():endDate],function(err,res){});
}
var time_out;
var sendMessage=function(messageList){
    if(time_out)
        clearTimeout(time_out);
    var curMesMin=parseInt(messageList[0].dateTime.toUTCString().split(':')[1])
    var curMin=parseInt(new Date().toUTCString().split(':')[1])
    while(curMesMin==curMin){
        var notification=sendNotification(messageList[0],messageCounts)
        var message=messageList.splice(0,1)[0];
        var checkGroup=constants.CHECK;
        var groupArray=[],inserts=[];
        console.log(message,checkGroup)
        for(var department in checkGroup){
            var data=checkGroup[department];
            var recepients=message.recepients?message.recepients.join(','):'';
            if(recepients.indexOf(department)>=0&&recepients.indexOf(data.group)<0&&groupArray.indexOf(data.loginId)<0){
                inserts.push([new Date(),message.title,message.message,data.loginId,'notification2',true])
                groupArray.push(data.loginId)
            }
        }
        if(groupArray.length>0){
            sendReport([{dateTime:new Date(),regids:[],title:message.title,message:message.message}],groupArray)
            CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
        }
        if(message.repetition){
            insertNotification(message);
        }
        if(messageList.length==0){
            setSent();
            return;
        }
        curMesMin=parseInt(messageList[0].dateTime.toUTCString().split(':')[1])
    }
    setSent();
    var timeout=curMesMin>=curMin?curMesMin-curMin:curMesMin-curMin+60;
    time_out=setTimeout(function(){
        time_out=null;
        sendMessage(messageList)   
    },timeout*60*1000+1)
}
var getRegIdWithLoginIds=function(data,callback){
    CP.query(queries.REG_ID_WITH_LOGINID,[data],function(err,res){
        callback(res);
    })
}
var onBoard=function(){
    var date=new Date();
    var month=date.getUTCMonth()+1;
    var day=date.getUTCDate()
    var params=[]
    for(var i=0;i<4;i++){
        params.push({name: 'DATE'+i,  value: (month<10?'0':'')+month+''+day})
        month=(month+2)%12+1;
    }
    MS.query(queries.ON_BOARD,params,true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            var data={};
            res=res.recordset;
            var loginIds=[];
            for(var i in res){
                var loginId=res[i].loginId
                data[loginId]=res[i];
                if(loginIds.indexOf(loginId)<0)
                    loginIds.push(loginId)
            }
            var empDetails={};
            var inserts=[]
            getRegIdWithLoginIds(loginIds,function(regids){
                for(var i in regids){
                    var loginId=regids[i].loginId
                    var empData=data[loginId]
                    var message=empData.name+constants.ON_BOARD_START+empData.months+constants.ON_BOARD_END
                    if(!empDetails[loginId]) {
                        empDetails[loginId]={regids:[],title:constants.ON_BOARD_TITLE,message:message}
                        inserts.push([new Date(),empDetails[loginId].title,empDetails[loginId].message,loginId,'notification2',true])
                    }
                    empDetails[loginId].regids.push(regids[i].regId);
                }
                for(var i in empDetails){
                    sendNotification(empDetails[i])
                }
                if(inserts.length>0)
                    CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
            });
        }
    })
}
var sendReport=function(groupData,toAllArray){
    // var groups=Object.keys(groupToRes); 
    // CP.query(queries.GET_REG_ID,[groups],function(err,result){
    //     if(!err&&result&&result.length>0){

    //         for(var i in result){
    //             groupData[groupToRes[result[i].layer.split('|')[1]]].regids.push(result[i].regId)
    //         }            
    //     }
        getRegIdWithLoginIds(toAllArray,function(regids){
            if(regids&&regids.length>0){
                var counts={}
                for(var i in regids){
                    var regid=regids[i].regId
                    counts[regids[i].regId]=regids[i].count
                    for(var j in groupData){
                        var data=groupData[j].regids;
                        if(data.indexOf(regid)<0){
                            data.push(regid)
                            counts[regid]++;
                        }
                    }
                }
                for(var i in groupData){
                    sendNotification(groupData[i],counts)
                }
            }
        })
    // })
}
var checkUndefined=function(value,digit){
    value=(value?value:'0')
    var newValue=value
    if(!isNaN(newValue)){
        if(newValue>1000){
            newValue=newValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
    }
    if(digit&&digit>value.toString().length)
        newValue=' '.repeat((digit-(value.toString().length)))+newValue+' '.repeat((digit-(value.toString().length)));
    return newValue
}

var revenueReport=function(index){
    var date=new Date();
    var month=date.getUTCMonth()+1;
    var day=date.getUTCDate()
    var year=date.getFullYear();
    var column=['@DATE0']
    var params=[{ name: 'DATE0', value: year+'/'+(month<10?'0':'')+month+'/'+(day<10?'0':'')+day},{ name: 'INDEX', value:(index+3)+''}]
    for(var i=0;i<4;i++){
        date=new Date(date-(7*24*60*60*1000));
        params.push({ name: 'DATE'+(i+1),  value: date.getFullYear()+'/'+(date.getMonth()+1)+'/'+date.getDate()})
        column.push('@DATE'+(i+1))
    }
    var foodType=constants.DAY_FOOD_TYPE
    var date=new Date(new Date()-24*60*60*1000);
    var params2=[{ name: 'DATE', value: year+(month<10?'-0':'-')+month+(day<10?'-0':'-')+day}]
    MS.query(queries.REVENUE_REPORT+column.join(',')+queries.REVENUE_REPORT_END,params,null,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            var data={};
            res=res.recordset;
            var hotels={}
            for(var i in res){
                if(res[i].N03=='全公司'||!foodType[res[i].N02])
                    continue;
                if(!hotels[res[i].N03])
                    hotels[res[i].N03]={
                        errEmployees:[],
                        total:0,
                        visitors:0,
                        unitPrice:0,
                        visitorsAvg:0,
                        unitPriceAvg:0,
                        unitPriceCount:0,
                        growth:0,
                        preMeal:0,
                        preTotal:0,
                        growth:0,
                        totalAvg:0,
                        service:0,
                        serviceMin:0,
                        kitchenMin:0
                    };
                var hotel=hotels[res[i].N03]
                if(!hotel[foodType[res[i].N02]])
                    hotel[foodType[res[i].N02]]={}
                var meal=hotel[foodType[res[i].N02]]
                if(res[i].date==params[0].value){
                    if(res[i].N02=='Z')continue;
                    meal['total']=res[i].N04+res[i].N05;
                    hotel.service+=res[i].N06+res[i].N11
                    if(res[i].N08) hotel.unitPriceCount++;
                    hotel.unitPrice+=res[i].N08;
                    hotel.visitors+=res[i].N06;
                    hotel.total+=meal.total;
                }else{
                    var meal=hotel[foodType[res[i].N02]];
                    if(!meal.sum){
                        meal.sum=0
                        meal.count=0
                    }
                    hotel.visitorsAvg+=res[i].N06;
                    hotel.unitPriceAvg+=res[i].N08;
                    meal.sum+=res[i].N04+res[i].N05
                    meal.count++;
                    if(res[i].N02!='Z')
                        hotel.preMeal+=res[i].N04+res[i].N05;
                    else{
                        hotel.count++;
                        hotel.preTotal+=res[i].N04+res[i].N05;
                        hotel.precentage=hotel.preMeal*100/(hotel.preTotal)
                        hotel.estimated=parseInt(hotel.total*100/hotel.precentage)
                    }
               }
            }
            for(var i in hotels){
                var hotel=hotels[i]
                for(var j in hotel){
                    if(hotel[j].sum>0){
                        var meal=hotel[j]
                        meal.avg=parseInt(meal.sum/meal.count);
                        if(j!='Total TurnOver')
                            hotel.totalAvg+=meal.avg;
                        hotel.growth=parseInt((hotel.total-hotel.totalAvg)*100/hotel.totalAvg) 
                    }
                }
            }
            MS.query(queries.PERFORMANCE_DAY_START+queries.PERFORMANCE_DAY_END,params2,true,function(err,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    res1=res1.recordset;
                    for(var i in res1){
                        if(hotels[groupToRes[res1[i].layer]]&&(res1[i].SIGNIN||res1[i].SIGNOUT)){
                            var hotel=hotels[groupToRes[res1[i].layer]]
                            var type=(constants.SERVICE_GROUPS.indexOf(res1[i].layer)>=0?'service':'kitchen')+'Min'
                            if(res1[i].SIGNIN<0||res1[i].SIGNOUT<0){
                                hotel.errEmployees.push(res1[i].loginId,res1[i].name);
                                hotel[type]+=index==2?360:480;
                            }
                            else if(res1[i].SIGNIN&&res1[i].SIGNOUT)
                                hotel[type]+=parseInt((res1[i].SIGNOUT-res1[i].SIGNIN)/(60*1000));
                            else if(!res1[i].SIGNIN)
                                hotel[type]+=parseInt((res1[i].SIGNOUT-(new Date()).setHours(0,0,0,0))/(60*1000));
                            else if(!res1[i].SIGNOUT)
                                hotel[type]+=parseInt(((new Date()).setHours((index*4+6),0,0,0)-res1[i].SIGNIN)/(60*1000));
                        }
                    }
                }
                var groupData={}
                var insertArray=[151001,151002]
                var inserts=[]
                for(var restaurant in hotels){
                    var data=hotels[restaurant] 
                    var message=constants.MESSAGE_START+constants.RESTAURANT_TO_GROUP[restaurant].name+constants.MESSAGE0
                    for(var j =1;j<=index;j++){
                        var meal=constants.DAY_FOOD_TYPE[constants.TIME_TO_MEAL[j-1]]
                        if(!data[meal])data[meal]={}
                        message+=constants['MESSAGE'+j]+checkUndefined(data[meal]['total'],5)+'】   【'+checkUndefined(data[meal]['avg'],5)+'】\n';
                    }
                    message+=constants.TOTAL+checkUndefined(data.total,5)+'】   【'+checkUndefined(data.totalAvg,5)+'】\n';
                    message+=constants.VISITOR+checkUndefined(data.visitors,3)+'】        【'+checkUndefined(parseInt(data.visitorsAvg/4),3)+'】\n'+constants.UNIT_PRICE+checkUndefined(parseInt(data.unitPrice/(data.unitPriceCount?data.unitPriceCount:1)),3)+'】        【'+checkUndefined(parseInt(data.unitPriceAvg/(index*4)),3)+'】\n'+constants.GROWTH+parseInt(checkUndefined(data.growth))+'%】\n'+constants.SERVICE+checkUndefined(parseInt(data.service*60/data.serviceMin))+' 】\n'+constants.KITCHEN+parseInt(data.total*60/data.kitchenMin)+' 】'+(data.errEmployees.length>0?'\n'+constants.ERROR_PER:'')
                    for(var i=0;i<data.errEmployees.length/2;i++){
                        if(i==20) break;
                        message+='\n'+data.errEmployees[2*i]+'-'+data.errEmployees[2*i+1]
                    }

                    message+='\n'+constants.ESTIMATED+checkUndefined(data.estimated)+' 】\n';
                    groupData[restaurant]={regids:[],title:constants.REVENUE_TITLE[index],message:message}
                    // var groupArray=insertArray.concat([constants.RESTAURANT_TO_GROUP[restaurant].group])
                    for(var i in insertArray){
                        inserts.push([new Date(),groupData[restaurant].title,groupData[restaurant].message,insertArray[i],'HBD',true])                
                    }
                }
                if(inserts.length>0)
                    CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
                sendReport(groupData,index)
            })
                

        }
    })
}
var revenueSummary=function(index){
    var date=new Date();
    var month=date.getUTCMonth()+1;
    var day=date.getUTCDate()
    var year=date.getFullYear();
    var column=['@DATE0']
    var params=[{ name: 'DATE0', value: year+'/'+(month<10?'0':'')+month+'/'+(day<10?'0':'')+day},{ name: 'INDEX', value:(index)+''}]
    for(var i=0;i<4;i++){
        date=new Date(date-(7*24*60*60*1000));
        params.push({ name: 'DATE'+(i+1),  value: date.getFullYear()+'/'+(date.getMonth()+1)+'/'+date.getDate()})
        column.push('@DATE'+(i+1))
    }
    var foodType=constants.DAY_FOOD_TYPE
    var date=new Date(new Date()-24*60*60*1000);
    var params2=[{ name: 'DATE', value: year+(month<10?'0':'')+month+(day<10?'0':'')+day}]
    MS.query(queries.REVENUE_REPORT+column.join(',')+queries.REVENUE_REPORT_END,params,null,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            var data={};
            res=res.recordset;
            var hotels={}
            for(var i in res){
                if(res[i].N03=='全公司'||!foodType[res[i].N02])
                    continue;
                if(!hotels[res[i].N03])
                    hotels[res[i].N03]={
                        total:0,
                        preMeal:0,
                        totalAvg:0,
                        count:0,
                    };
                var hotel=hotels[res[i].N03]
                if(res[i].date==params[0].value){
                    if(res[i].N02=='Z')continue;
                    hotel.total+=res[i].N04+res[i].N05;
                }else{
                    if(res[i].N02!='Z')
                        hotel.preMeal+=res[i].N04+res[i].N05;
                    else{
                        hotel.totalAvg+=res[i].N04+res[i].N05;
                        hotel.count++;
                    }
               }
            }
            var groupData={}
            var insertArray=[151001,151002]
            var inserts=[]
            date=new Date();
            var html=constants.WIDTH_DIV+parseInt(index*3+index/6)%24+(index<7?':30 ':(index==7?':10 ':':00 '))+date.toISOString().substr(0,10)+' '+constants.DAY_OF_WEEK[new Date().getDay()]+constants.NORMAL_TABLE+constants.HOTELS+constants.ADD_COLUMN+constants.ACTUAL_REVENUE+constants.ADD_COLUMN+constants.OLD_REVENUE+constants.ADD_COLUMN+constants.ESTIMATED_REVENUE+constants.ADD_COLUMN+constants.REVENUE_GROWTH;            
            var total=0,totalAvg=0,totalEstimated=0;
            for(var i in constants.SUMMARY_ORDER){
                var restaurant=constants.SUMMARY_ORDER[i];
                if(!hotels[restaurant])
                    continue;
                var data=hotels[restaurant] 
                var estimated=parseInt(data.total*data.totalAvg/(data.preMeal?data.preMeal:1))
                data.totalAvg=parseInt(data.totalAvg/(data.count?data.count:1))
                total+=data.total;
                totalAvg+=data.totalAvg;
                totalEstimated+=estimated
                html+=constants.ADD_ROW+constants.RESTAURANT_TO_GROUP[restaurant].name+constants.ADD_COLUMN+checkUndefined(data.total)+constants.ADD_COLUMN+checkUndefined(estimated)+constants.ADD_COLUMN+checkUndefined(data.totalAvg)+constants.ADD_COLUMN+((estimated-data.totalAvg)*100/(data.totalAvg?data.totalAvg:1)).toFixed(1)+'%'
            }
            html+=constants.ADD_BOLD_ROW+constants.SUMMARY_TOTAL+constants.ADD_COLUMN+checkUndefined(total)+constants.ADD_COLUMN+checkUndefined(totalEstimated)+constants.ADD_COLUMN+checkUndefined(totalAvg)+constants.ADD_COLUMN+((totalEstimated-totalAvg)*100/totalAvg).toFixed(1)+'%'+constants.TABLE_END
            var data={dateTime:new Date(),regids:[],title:constants.SUMMARY_TITLE,message:html}
            var insertArray=['151001','151002']
            var inserts=[]
            CP.query(queries.GET_REG_ID_ACCESS, [29, insertArray], function (err, result2) {
                var counts={}
                for (var i in result2) {
                    if (insertArray.indexOf(result2[i].loginId)<0) {
                        insertArray.push(result2[i].loginId)
                    }
                    if(result2[i].regId){
                        counts[result2[i].regId]=result2[i].count+1;
                       data.regids.push(result2[i].regId)
                    }
                }
                for (var i in insertArray)
                    inserts.push([data.dateTime, data.title, data.message, insertArray[i], 'HBD', true])
                CP.query(queries.INSERT_HBD, [inserts], function (err, res) { })
                sendNotification(data,counts)
            })
        }
    })
}

var performanceReport=function(){
    var date =new Date();
    var month=date.getUTCMonth();
    var params=[{ name: 'DATE0',  value: date.getUTCFullYear()+"/"+(date.getUTCMonth()+1)+"/01"},{ name: 'DATE1',value: date.getUTCFullYear()+"/"+(date.getUTCMonth()+1)+"/"+date.getUTCDate()}]
    var column=[]
    var month=date.getUTCMonth();
    var params2=[{name:'MONTH',value:date.getUTCFullYear()+(month<9?'0':'')+(month+1)},{ name: 'DATE',  value: date.toISOString().substr(0,10)}]
    var dates=[]
    var column2=[]
    for(var i=0;i<4;i++){
        date=new Date(date-(7*24*60*60*1000));
        dates.push(date.toISOString().substr(0,10).replace(/-/g,"/"))
        params2.push({ name: 'DATE'+i,  value: date.toISOString().substr(0,10)})
        column2.push('@DATE'+i)
        params.push({ name: 'DATE'+(i+2),  value: date.toISOString().substr(0,10)})
        column.push('@DATE'+(i+2))

    }

    MS.query(queries.PERFORMANCE_START+column.join(',')+queries.PERFORMANCE_MIDDLE+column.join(',')+queries.PERFORMANCE_END,params,true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            var hotels={}
            res=res.recordset;
            date=new Date();
            var data={
                avgMin:0,
                totalMin:0,
                transport:0,
                transportCount:0,
                production:0,
                productionCount:0
            }
            for(var i in res){
                if(res[i].SIGNIN||res[i].SIGNOUT){
                    var type=res[i].layer==constants.TRANSPORT?'transport':'production'
                    var min=0;
                    if(res[i].SIGNIN<=0||res[i].SIGNOUT<=0){
                        min=480;
                    }
                    else if(res[i].SIGNIN&&res[i].SIGNOUT)
                        min=parseInt((res[i].SIGNOUT-res[i].SIGNIN)/(60*1000));
                    else if(!res[i].SIGNIN)
                        min=(new Date()).setHours(0,0,0,0)<res[i].SIGNOUT?parseInt((res[i].SIGNOUT-(new Date()).setHours(0,0,0,0))/(60*1000)):480;
                    else if(!res[i].SIGNOUT)
                        min=(new Date()-res[i].SIGNIN)>86400000?480:parseInt(((new Date()).setHours((index*4+6),0,0,0)-res[i].SIGNIN)/(60*1000));
                    if(res[i].overTime)
                        min+=res[i].overTime*60
                    if(res[i].leaves)
                        min-=res[i].leaves*60
                    if(date.getUTCDate()==res[i].date.substr(8,2)){
                        data[type+'Count']++;
                        data[type]+=min;
                    }
                    if(dates.indexOf(res[i].date)>=0)
                        data.avgMin+=min;
                    if(res[i].date.split('/')[1]!=date.getUTCMonth())
                        data.totalMin+=min
                }
            }
            MS.query(queries.PERFORMANCE_REVENUE_START+column2.join(',')+queries.PERFORMANCE_REVENUE_MIDDLE+column2.join(',')+queries.PERFORMANCE_REVENUE_END,params2,null,function(err,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    res1=res1.recordset;
                    var html=constants.WIDTH_DIV+date.toISOString().substr(0,10)+' '+constants.DAY_OF_WEEK[new Date().getDay()]+constants.TABLE+'資運中心'+constants.ADD_COLUMN+'倉儲組'+constants.ADD_COLUMN+'生產組'+constants.ADD_ROW;
                    html+=constants.LIGHT_GREEN+constants.HOURS+constants.COLOR_END+constants.ADD_COLUMN+parseInt(data.transport/60)+constants.ADD_COLUMN+parseInt(data.production/60)+constants.ADD_ROW+constants.LIGHT_GREEN+constants.EMPLOYEE_COUNT+constants.COLOR_END+constants.ADD_COLUMN+data.transportCount+constants.ADD_COLUMN+data.productionCount+constants.ADD_TABLE;
                    var estimated=res1[0].total*res1[0].avg/(res1[0].preTotal?res1[0].preTotal:1)
                    var totalMin=(data.transport+data.production)
                    data.current=parseInt(estimated*60/(totalMin?totalMin:1))
                    data.avg=parseInt(res1[0].avg*60/(data.avgMin?data.avgMin:1))
                    data.growth=((data.current-data.avg)*100/(data.avg?data.avg:1)).toFixed(2);
                    html+=constants.LIGHT_GREEN+constants.TARGET+constants.COLOR_END+constants.ADD_COLUMN+'6,500'+constants.ADD_ROW+constants.LIGHT_GREEN+constants.PRODUCTIVITY+constants.COLOR_END+constants.ADD_COLUMN+checkUndefined(data.current)+constants.ADD_ROW+constants.LIGHT_GREEN+constants.AVG_PRODUCTIVITY+constants.COLOR_END+constants.ADD_COLUMN+checkUndefined(data.avg)+constants.ADD_ROW+constants.LIGHT_GREEN+constants.COMPARE+constants.COLOR_END+constants.ADD_COLUMN+data.growth+'%'+constants.ADD_ROW+constants.LIGHT_GREEN+constants.MONTHLY_PRODUCTIVITY+constants.COLOR_END+constants.ADD_COLUMN+checkUndefined(parseInt(res1[0].month*60/data.totalMin))+constants.TABLE_END+constants.DIV_END
                    var groupData={}
                    var hotel='central kitchen'
                    groupData[hotel]={dateTime:new Date(),regids:[],title:constants.PRODUCTIVITY_TITLE,message:html}
                    var insertArray=['151001','151007']
                    var inserts=[]
                    CP.query(queries.GET_REG_ID_ACCESS,[25,insertArray],function(err2,res2){
                        if(!err2){
                            var counts={}
                            for(var i in res2){
                                counts[res2[i].regId]=res2[i].count+1;
                                groupData[hotel].regids.push(res2[i].regId) 
                                if(insertArray.indexOf(res2[i].loginId)<0){
                                    insertArray.push(res2[i].loginId)
                                }
                            }
                            for(var i in insertArray)
                                inserts.push([groupData[hotel].dateTime,groupData[hotel].title,groupData[hotel].message,insertArray[i],'notification2',true])                
                            CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
                            sendNotification(groupData[hotel],counts)   
                        }
                    })
                }
            })

        }
    })
}

var HrNotification2=function(res){
    var groups={}
    var date=new Date()
    var month=date.getUTCMonth()        
    date=date.getUTCFullYear()+'/'+(month<9?'0':'')+(month+1)

    for(var i in res){
        var group=res[i].department
        var data=res[i]
        if(!groups[group])groups[group]={job:{},employee:{},count:0,settleRemainHours:0,settleCount:0}
        group=groups[group];
        
        group.count++;
        if(!group.job[data.job])group.job[data.job]={count:0}
        group.job[data.job].count++;
        group.employee[data.loginId]=data
        if(data.endDate&&data.endDate.substr(0,7)==date&&data.annualLeaveNotUsed){
            group.settleRemainHours+=data.annualLeaveNotUsed
            group.settleCount++;
            group.employee[data.loginId].settleRemainHours=true
        }
    }
    var groupData={}
    var inserts=[]
    for(var group in groups){
        var data=groups[group];
        var kitchen=groupToRes[group]&&constants.SERVICE_GROUPS.indexOf(group)<0
        var html=constants.WIDTH_DIV+(kitchen?constants.GREEN_TABLE:constants.YELLOW_TABLE)+constants.HR2_START+constants.ADD_ROW+constants.VAR_WIDTH+'90'+constants.WIDTH_END+(new Date()).toISOString().substr(0,10)+constants.DIV_END+constants.VAR_WIDTH+'70'+constants.WIDTH_END+constants.BERRY_SPAWN_TABLE+group+constants.ADD_COLUMN+constants.SETTLE_REMAIN_HOURS+constants.ADD_COLUMN+data.settleRemainHours+constants.ADD_BERRY_ROW+constants.PEOPLE+constants.ADD_COLUMN+data.settleCount+constants.TABLE_END+constants.DIV_END+constants.VAR_WIDTH+'87'+constants.WIDTH_END+group+' '+data.count+'人'+constants.DIV_END+constants.VAR_WIDTH+'0'+constants.WIDTH_END+(kitchen?constants.GREEN_TABLE:constants.YELLOW_TABLE);
        for(var i =0;i<6;i++){
            html+=constants.JOB+constants.ADD_COLUMN+constants.PEOPLE            
            html+=i==5?constants.ADD_ROW:constants.ADD_COLUMN
        }        
        var jobs=data.job;
        var count=0
        for(var i in constants.JOB_ORDER){
            count=(count+1)%6
            job=constants.JOB_ORDER[i]
            html+=job+(jobs[job]?(kitchen?constants.ADD_GREEN_COLUMN:constants.ADD_YELLOW_COLUMN)+jobs[job].count:constants.ADD_COLUMN+0);
            html+=count?constants.ADD_COLUMN:constants.ADD_ROW;
        }
        for(var i=count*2;i<11;i++)
            html+=constants.ADD_COLUMN+''
        html+=constants.TABLE_END+constants.DIV_END;
        var html1=(kitchen?constants.GREEN_TABLE:constants.YELLOW_TABLE)+constants.EMPLOYEE_NO+constants.ADD_COLUMN+constants.NAME+constants.ADD_COLUMN+constants.BIRTH_DAY+constants.ADD_COLUMN+constants.GENDER+constants.ADD_COLUMN+constants.HIRE_DATE+constants.ADD_COLUMN+constants.JOB+constants.ADD_COLUMN+constants.CHANGE_REMAIN_HOURS+constants.ADD_COLUMN+constants.SPECIAL_REMAIN_HOURS+constants.ADD_COLUMN+constants.SETTLE_REMAIN_HOURS+constants.ADD_COLUMN+constants.BANK+constants.ADD_COLUMN+constants.ASK_LEAVE_HOUR_PER+constants.ADD_COLUMN+constants.ASK_LEAVE+constants.ADD_COLUMN+constants.EXCEPTION_COUNT;

        var graph={
            labels: [],
            datasets: [{
                label: constants.ASK_LEAVE_HOUR_PER,
                categoryPercentage:0.5,
                barPercentage:1.0,
                barThickness:'flex',
                data: [],
                backgroundColor: [],
            },{
                label: constants.ASK_LEAVE,
                categoryPercentage:0.5,
                barPercentage:1.0,
                barThickness:'flex',
                data: [],
                backgroundColor: [],
            },{
                label: constants.EXCEPTION_COUNT,
                categoryPercentage:0.5,
                barPercentage:1.0,
                barThickness:'flex',
                data: [],
                backgroundColor: [],
            }]
        }
        var employees=data.employee;
        for(var employee in employees){
            var data1=employees[employee]
            html1+=constants.ADD_ROW+employee+constants.ADD_COLUMN+data1.name+constants.ADD_COLUMN+data1.birthday.toISOString().substr(0,10)+constants.ADD_COLUMN+data1.gender+constants.ADD_COLUMN+data1.hireDate.toISOString().substr(0,10)+constants.ADD_COLUMN+data1.job+constants.ADD_COLUMN+(data1.overTimeSwapNotUsed?data1.overTimeSwapNotUsed:0)+constants.ADD_COLUMN+(data1.annualLeaveNotUsed?data1.annualLeaveNotUsed:0)+constants.ADD_COLUMN+(data1.settleRemainHours?data1.annualLeaveNotUsed:'-')+constants.ADD_COLUMN+(data1.bank?'-':constants.BANK_VALUE)+constants.ADD_COLUMN+(data1.overTime?data1.overTime:0)+constants.ADD_COLUMN+(data1.overTimeFilter?data1.overTimeFilter:0)+constants.ADD_COLUMN+(data1.code?data1.code:0)
            graph.labels.push(data1.name);
            graph.datasets[0].data.push(data1.overTime?data1.overTime:0)
            graph.datasets[1].data.push(data1.overTimeFilter?data1.overTimeFilter:0)
            graph.datasets[2].data.push(data1.code?data1.code:0)
            graph.datasets[0].backgroundColor.push(constants.BLUE);
            graph.datasets[1].backgroundColor.push(constants.RED);
            graph.datasets[2].backgroundColor.push(constants.YELLOW);
        }
        html+=constants.CANVAS_START+'1'+constants.CANVAS_MIDDLE+(kitchen?'#CCFFD4':'#FFFF99')+constants.CANVAS_END+constants.GRAPH_SCRIPT+constants.GRAPH_START+'1'+constants.GRAPH_1+JSON.stringify(graph)+constants.GRAPH_2+constants.VAR_WIDTH+0+constants.WIDTH_END+html1+constants.TABLE_END+constants.DIV_END+constants.TABLE_END+constants.DIV_END;
        groupData[group]={dateTime:new Date(),regids:[],title:constants.HR2_TITLE,message:html}
        inserts.push([groupData[group].dateTime,groupData[group].title,groupData[group].message,'點點心股份有限公司|'+group,'notification2',true]) 
    }
    CP.query(queries.INSERT_HBD,[inserts],function(err,res){})      
    CP.query(queries.GET_ALL_REGID,[],function(err,result){
        if(!err&&result&&result.length>0){
            var counts={}
            for(var i in result){
                if(result[i].layer && groupData[result[i].layer.split('|')[1]]){
                    counts[result[i].regId]=result[i].count+1;
                    groupData[result[i].layer.split('|')[1]].regids.push(result[i].regId)
                }
            }
            for(var group in groupData)
                sendNotification(groupData[group],counts)
        }
    })
    

}

var HrNotification=function(){
    var date =new Date();
    var month=date.getUTCMonth();
    var params=[{ name: 'DATE0',  value: date.getUTCFullYear()+"/"+(date.getUTCMonth()+1)+"/01"},{ name: 'DATE1',value: date.getUTCFullYear()+"/"+(date.getUTCMonth()+1)+"/"+date.getUTCDate()}]
    date=new Date(date-24*60*60*1000)
    var month=date.getUTCMonth();
    var year=date.getUTCFullYear();
    var day=date.getUTCDate();
    var leap=0;
    if(month==1&&year%4==0&&(year%100!=0||(year%100==0&&year&400==0)))
        leap=1
    var params2=[{ name: 'DATE0',  value: date.getUTCFullYear()+"/"+(date.getUTCMonth()+1)+"/01"},{ name: 'DATE1',value: date.getUTCFullYear()+"/"+(date.getUTCMonth()+1)+"/"+date.getUTCDate()},{ name: 'COUNT',  value:daysOfMonth[month+1]+leap},{ name: 'MONTH',  value:date.getUTCFullYear()+(month<9?"0":"")+(date.getUTCMonth()+1)}]
    MS.query(queries.HR_DATA,params,true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            var hotels={}
            res=res.recordset;
            setTimeout(function(){
                HrNotification2(res)
            },15*60*1000)
            date=new Date()
            var month=date.getUTCMonth()
            date=date.getUTCFullYear()+'/'+(month<9?'0':'')+(month+1)
            var groups={}
            for(var i in res){
                var group=res[i].department
                var data=res[i]
                if(!groups[group])groups[group]={changeRemainHours:0,specialRemainHours:0,remainHoursEnding:0,exception:0,bank:0,count:0,overTime:0}
                group=groups[group];
                group.count++;
                group.changeRemainHours+=data.overTimeSwapNotUsed?data.overTimeSwapNotUsed:0
                group.specialRemainHours+=data.annualLeaveNotUsed?data.annualLeaveNotUsed:0
                group.remainHoursEnding+=data.endDate&&data.endDate.substr(0,7)==date?1:0
                group.exception+=data.code?data.code:0
                group.bank+=data.bank?0:1
                group.overTime+=data.overTimeFilter?data.overTimeFilter:0;    
                if(groupToRes[data.department]||data.department=='資運倉儲組'||data.department=='資運生產組'){
                    if(!group.partTime){group.partTime=0;group.income=0;group.orders=0;}
                    if(data.job=='高級計時服專'||data.job=='計時服專')
                        group.partTime++;
                }
            }
            MS.query(queries.HR_REVENUE,params2,null,function(err,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    res1=res1.recordset;
                    for(var i in res1){
                        var group;
                        if(constants.RESTAURANT_TO_GROUP[res1[i].N03])
                            group=constants.RESTAURANT_TO_GROUP[res1[i].N03].groups
                        else if(res1[i].N03=='全公司')
                            group={service:['資運生產組'],kitchen:['資運倉儲組']}
                        else 
                            continue;
                        groups[group.kitchen[0]].income+=res1[i].estimatedIncome;
                        groups[group.service[0]].orders+=res1[i].estimated;

                    }
                }
                var html=constants.WIDTH_DIV+constants.BERRY_TABLE+constants.HR_START+constants.ADD_ROW+constants.SMALL_WIDTH
                html+=constants.BERRY_TABLE+constants.DEPARTMENT+constants.ADD_COLUMN+constants.CHANGE_REMAIN_HOURS+constants.ADD_COLUMN+constants.SPECIAL_REMAIN_HOURS+constants.ADD_COLUMN+constants.SETTLE_REMAIN_HOURS+constants.ADD_COLUMN+constants.EMPLOYEE_GROUP_COUNT+constants.ADD_COLUMN+constants.EMPTY_BANK+constants.ADD_COLUMN+constants.EXCEPTION_COUNT+constants.ADD_COLUMN+constants.ASK_LEAVE
                var html1=constants.BERRY_SPAWN_TABLE+constants.DEPARTMENT+constants.ADD_SPAWN_COLUMN+constants.EMPLOYEE_GROUP_COUNT+constants.ADD_SPAWN_COLUMN+constants.PART_TIME+constants.ADD_SPAWN_COLUMN+constants.PART_TIME_PERCENTAGE+constants.ADD_COLUMN+constants.SUGGESTED+constants.ADD_COLUMN+constants.SUGGESTED+constants.ADD_SPAWN_COLUMN+constants.REDUCTION+constants.ADD_BERRY_ROW+constants.SERVICE_HR+constants.ADD_COLUMN+constants.KITCHEN_HR
                var graph1={
                    labels: [],
                    datasets: [{
                        label: constants.CHANGE_REMAIN_HOURS,
                        categoryPercentage:0.5,
                        barPercentage:1.0,
                        barThickness:'flex',
                        data: [],
                        backgroundColor: [],
                    },{
                        label: constants.SPECIAL_REMAIN_HOURS,
                        categoryPercentage:0.5,
                        barPercentage:1.0,
                        barThickness:'flex',
                        data: [],
                        backgroundColor: [],
                    }]
                }
                var graph2={
                    labels: [],
                    datasets: [{
                        label: constants.ASK_LEAVE,
                        categoryPercentage:0.5,
                        barPercentage:1.0,
                        barThickness:'flex',
                        data: [],
                        backgroundColor: [],
                    }]
                }
                for(var i in constants.GROUPS_RANK){
                    var group=constants.GROUPS_RANK[i];
                    var data=groups[group]
                    if(!data)
                        data={ 
                            changeRemainHours: 0,
                            specialRemainHours: 0,
                            remainHoursEnding: 0,
                            exception: 0,
                            bank: 0,
                            income:0,
                            orders:0,
                            count: 0,
                            overTime: 0 
                        }
                    graph1.labels.push(group);
                    graph1.datasets[0].data.push(parseInt(data.changeRemainHours))
                    graph1.datasets[1].data.push(parseInt(data.specialRemainHours))
                    graph1.datasets[0].backgroundColor.push(constants.BLUE);
                    graph1.datasets[1].backgroundColor.push(constants.RED);
                    graph2.labels.push(group);
                    graph2.datasets[0].data.push(data.overTime)
                    graph2.datasets[0].backgroundColor.push(constants.BLUE);
                    html+=constants.ADD_ROW+group+constants.ADD_COLUMN+parseInt(data.changeRemainHours)+constants.ADD_COLUMN+parseInt(data.specialRemainHours)+constants.ADD_COLUMN+data.remainHoursEnding+constants.ADD_COLUMN+data.count+(data.bank?constants.ADD_YELLOW_COLUMN:constants.ADD_COLUMN)+data.bank+(data.exception?constants.ADD_YELLOW_COLUMN:constants.ADD_COLUMN)+data.exception+constants.ADD_COLUMN+data.overTime;
                    if(groupToRes[group]){
                        var performance=constants.SERVICE_GROUPS.indexOf(group)>=0?(data.orders*31/(5.5*day*8*22)):(data.income*31/(3000*30*8*22))
                        html1+=constants.ADD_ROW+group+constants.ADD_COLUMN+data.count+constants.ADD_COLUMN+checkUndefined(data.partTime)+constants.ADD_COLUMN+(data.partTime?parseInt(data.partTime*100/data.count)+'%':'-')+constants.ADD_COLUMN+(data.orders==0?'-':checkUndefined(parseInt(performance)))+constants.ADD_COLUMN+(data.income==0?'-':checkUndefined(parseInt(performance)))+constants.ADD_COLUMN+(data.count-performance).toFixed(1)
                    }else if(group=='資運倉儲組'){
                        var totalMin=data.min+groups['資運生產組'].min
                        var totalCount=data.count+groups['資運生產組'].count
                        var performance=(data.income*31/(6500*30*8*22))
                        html1+=constants.ADD_ROW+group+constants.ADD_COLUMN+data.count+constants.ADD_COLUMN+data.partTime+constants.ADD_COLUMN+(data.partTime?parseInt(data.partTime*100/data.count)+'%':'-')+constants.ADD_COLUMN+'-'+constants.ADD_SPAWN_COLUMN+(checkUndefined(parseInt(performance)))+constants.ADD_SPAWN_COLUMN+(totalCount-performance).toFixed(1)
                    }else if(group=='資運生產組'){
                        html1+=constants.ADD_ROW+group+constants.ADD_COLUMN+data.count+constants.ADD_COLUMN+data.partTime+constants.ADD_COLUMN+(data.partTime?parseInt(data.partTime*100/data.count)+'%':'-')+constants.ADD_COLUMN+'-';
                    }
                }
                var graph=constants.CANVAS_START+'1'+constants.CANVAS_MIDDLE+'#FFFF99'+constants.CANVAS_END+constants.CANVAS_START+'2'+constants.CANVAS_MIDDLE+'#CCFFCC'+constants.CANVAS_END+constants.GRAPH_SCRIPT+constants.GRAPH_START+'1'+constants.GRAPH_1+JSON.stringify(graph1)+constants.NEW_GRAPH+'2'+constants.GRAPH_1+JSON.stringify(graph2)+constants.GRAPH_2;

                html+=constants.TABLE_END+constants.DIV_END+graph+constants.SMALL_WIDTH+html1+constants.TABLE_END+constants.DIV_END+constants.DIV_END;
                var groupData={}
                var hotel='central kitchen'
                groupData[hotel]={dateTime:new Date(),regids:[],title:constants.HR_TITLE,message:html}
                var insertArray=['151001']
                var inserts=[]
                CP.query(queries.GET_REG_ID_ACCESS,[27,[insertArray]],function(err2,res2){
                    if(!err){
                        var counts={}
                        for(var i in res2){
                            counts[res2[i].regId]=res2[i].count
                            groupData[hotel].regids.push(res2[i].regId)
                            if(insertArray.indexOf(res2[i].loginId)<0){
                                insertArray.push(res2[i].loginId)
                            }
                        }
                        for(var i in insertArray)
                        inserts.push([groupData[hotel].dateTime,groupData[hotel].title,groupData[hotel].message,insertArray[i],'notification2',true])                
                        CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
                        sendNotification(groupData[hotel],counts)  
                    }
                })    
            })

        }
    })

}



var sendMenu=function(){
    var date=new Date(new Date()-0+8*60*60*1000);
    var params=[{name: 'DATE1',  value: date.toISOString().replace('T',' ').substring(0,19)}]
    date=new Date(date-2*60*60*1000)
    params.push({name: 'DATE0',  value: date.toISOString().replace('T',' ').substring(0,19)})
    var month=date.getUTCMonth()
    var year=date.getUTCFullYear()
    var leap=0;
    if(month==1&&year%4==0&&(year%100!=0||(year%100==0&&year&400==0)))
        leap=1
    var hour=date.getUTCHours()
    var params2=[{name: 'DATE0',  value: year+(month<9?'0':'')+(month+1)},{name:'TIME0',value:constants.HOUR_TO_MEAL[hour]+''},{name:'TIME1',value:(constants.HOUR_TO_MEAL[hour]%8+1)+''}]
    if(month==0){
        month=12;
        year=year-1
    }
    params2.push({name: 'DATE1',  value: year+(month<10?'0':'')+month})

    MS.query(queries.SEND_MENU,params,true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            res=res.recordset
            var loginIds=[]
            var data={}
            for(var i in res){
                if(!groupToRes[res[i].layer]) continue;
                loginIds.push(res[i].loginId)
                if(!data[res[i].layer])data[res[i].layer]={ids:[],rank0:[],rank1:[],current0:{},current1:{}}
                data[res[i].layer].ids.push(res[i].loginId)
            }
            if(loginIds.length==0)
                return;
            MS.query(queries.GET_FOOD_RANK,params2,null,function(err,res1){
                if(!err&&res1&&res1.recordset&&res1.recordset.length>0){
                    res1=res1.recordset;
                    for(var i in res1){
                        if(!constants.RESTAURANT_TO_GROUP[res1[i].Q04])
                            continue
                        var groups=constants.RESTAURANT_TO_GROUP[res1[i].Q04].groups;
                        groups=groups.service.concat(groups.kitchen);
                        for(var j in groups){
                            var group=groups[j]
                            if(data[group]){
                                var hotel=data[group]
                                var rank=res1[i].Q03==params2[1].value?0:1;
                                if(res1[i].Q00==params2[0].value){
                                    if(hotel['rank'+rank].length<10){
                                        hotel['rank'+rank].push(res1[i].Q05)
                                        hotel['current'+rank][res1[i].Q05]={'value':res1[i].Q07}
                                    }
                                }else{
                                    var meal=hotel['current'+rank][res1[i].Q05]
                                    if(meal){
                                        meal.lastMonth=res1[i].Q07;
                                    }
                                }
                            }
                        }
                    }
                    var groupData={}
                    var inserts=[]
                    date=new Date(new Date()-0+8*60*60*1000);
                    var day=date.getUTCDate()
                    for(var i in data){
                        var hotel=data[i]
                        var html=constants.WIDTH_DIV+date.getUTCHours()+':'+date.getUTCMinutes()+constants.NORMAL_TABLE+constants.FOOD_CHINESE[params2[1].value]+constants.S_NO+constants.ADD_COLUMN+constants.MEAL+constants.ADD_COLUMN+constants.CURRENT+constants.ADD_COLUMN+constants.CURRENT_AVG+constants.ADD_COLUMN+constants.LAST_MONTH_COMPARE;
                        var html1=''
                        for(var j=0;j<10;j++){
                            if(hotel.rank0.length>j){
                                var meal=hotel.current0[hotel.rank0[j]]
                                var estimated=meal.value*(daysOfMonth[date.getUTCMonth()+1]+leap)/date.getUTCDate();
                                var growth=parseInt((estimated-meal.lastMonth)*100/meal.lastMonth)
                                growth=growth<0?constants.RED_DIV+growth+'%'+constants.COLOR_END:growth+'%';
                                html+=constants.ADD_ROW+'<b>'+(j+1)+'</b>'+constants.ADD_COLUMN+hotel.rank0[j]+constants.ADD_COLUMN+checkUndefined(meal.value)+constants.ADD_COLUMN+checkUndefined(parseInt(meal.value/(day==1?day:day-1)))+constants.ADD_COLUMN+growth;
                            }else{
                                html+=constants.ADD_ROW+'<b>'+(j+1)+'</b>'+constants.ADD_COLUMN+'-'+constants.ADD_COLUMN+'-'+constants.ADD_COLUMN+'-'+constants.ADD_COLUMN+'-';

                            }
                            if(hotel.rank1.length>j){
                                var meal=hotel.current1[hotel.rank1[j]]
                                var estimated=meal.value*(daysOfMonth[date.getUTCMonth()+1]+leap)/date.getUTCDate();
                                var growth=parseInt((estimated-meal.lastMonth)*100/meal.lastMonth)
                                growth=growth<0?constants.RED_DIV+growth+'%'+constants.COLOR_END:growth+'%';
                                html1+=constants.ADD_ROW+'<b>'+(j+1)+'</b>'+constants.ADD_COLUMN+hotel.rank1[j]+constants.ADD_COLUMN+checkUndefined(meal.value)+constants.ADD_COLUMN+checkUndefined(parseInt(meal.value/(day==1?day:day-1)))+constants.ADD_COLUMN+growth;
                            }else{
                                html1+=constants.ADD_ROW+'<b>'+(j+1)+'</b>'+constants.ADD_COLUMN+'-'+constants.ADD_COLUMN+'-'+constants.ADD_COLUMN+'-'+constants.ADD_COLUMN+'-';

                            }
                        }
                        html+=constants.ADD_BOLD_ROW+constants.LIGHT_GREEN+constants.FOOD_CHINESE[params2[2].value]+constants.S_NO+constants.COLOR_END+constants.ADD_COLUMN+constants.LIGHT_GREEN+constants.MEAL+constants.COLOR_END+constants.ADD_COLUMN+constants.LIGHT_GREEN+constants.CURRENT+constants.COLOR_END+constants.ADD_COLUMN+constants.LIGHT_GREEN+constants.CURRENT_AVG+constants.COLOR_END+constants.ADD_COLUMN+constants.LIGHT_GREEN+constants.LAST_MONTH_COMPARE+constants.COLOR_END;
                        html+=html1+constants.TABLE_END+constants.SEND_END_START+constants.FOOD_CHINESE[params2[1].value]+'】【'+constants.FOOD_CHINESE[params2[2].value]+constants.SEND_END+constants.DIV_END;
                        groupData[i]={dateTime:new Date(),regids:[],title:constants.MENU_TITLE_START+constants.RESTAURANT_TO_GROUP[groupToRes[i]].name+constants.MENU_TITLE_END,message:html}
                        for(var j in hotel.ids){
                            inserts.push([groupData[i].dateTime,groupData[i].title,groupData[i].message,hotel.ids[j],'notification2',true])                
                        }

                    }
                    if(inserts.length>0)
                        CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
                    getRegIdWithLoginIds(loginIds,function(regids){
                        var counts={}
                        for(var i in regids){  
                            if(groupData[regids[i].layer.split('|')[1]]){
                                counts[regids[i].regId]=regids[i].count+1;
                                groupData[regids[i].layer.split('|')[1]].regids.push(regids[i].regId)
                            }
                        }
                        for(var i in groupData)
                            sendNotification(groupData[i],counts)
                    })

                }
            })
        }
    })
}
var sendExceptions=function(index){
    MS.query(queries.APPROVAL,[],true,function(err,res1){
        if( index<=5 && ( err || !res1 || !res1.recordset || res1.recordset.length<0 ) )
            return setTimeout(function(){
                sendExceptions(index+1)
            },45*1000)
        setTimeout(function(){
            var date=new Date();
            var params=[{name: 'DATE',  value:(date.getUTCFullYear()-(date.getUTCMonth()<9?1:0))+'-10-01' },{name: 'DATE1',  value:date.toISOString().substr(0,10) }]
            MS.query(queries.AUTO_NOTIFI,params,true,function(err,res){
                if(!err&&res&&res.recordset&&res.recordset.length>0){
                    var data={}
                    res=res.recordset;
                    var loginIds=[];
                    for(var i in res){
                        var loginId=res[i].loginId
                        if(!data[loginId]){
                            data[loginId]=res[i]
                            data[loginId].exceptions=[]
                            data[loginId].count=0,
                            data[loginId].applications={A:{1:0,2:0},B:{1:0,2:0},C:{1:0,2:0},D:{1:0,2:0}}
                        }
                        if(res[i].code!=''&&(res[i].code!=null)){
                            data[loginId].count++;
                            data[loginId].exceptions.push(res[i]);
                        }
                        if(loginIds.indexOf(loginId)<0)
                            loginIds.push(loginId)
                    }
                    var empDetails={};
                    var inserts=[]
                    if(res1&&res1.recordset&&res1.recordset.length>0){       
                        res1=res1.recordset
                        for(var i in res1){
                            var loginId1=res1[i].EMPLOYEE_NO;
                            var loginId2=res1[i].approval_no;
                            for(var type in constants.APPROVAL_TYPES){
                                if(res1[i].SUBJECT.indexOf(type)>=0){
                                    var approvalType=constants.APPROVAL_TYPES[type]
                                    if(data[loginId1])
                                        data[loginId1].applications[approvalType][1]++;
                                    if(data[loginId2])
                                        data[loginId2].applications[approvalType][2]++;
                                }
                            }
                        }
                    }
                    getRegIdWithLoginIds(loginIds,function(regids){
                        var counts={}
                        for(var i in regids){
                            var loginId=regids[i].loginId
                            if(!empDetails[loginId]){
                                var cardData=data[loginId]
                                var message=constants.AUTO_SEND_NAME+cardData.name+constants.AUTO_SEND_JOB+cardData.department+constants.REMAIN_HOUR+(cardData.overTimeSwapNotUsed?cardData.overTimeSwapNotUsed:0)+constants.SPECIAL_HOUR+(cardData.annualLeaveNotUsed?cardData.annualLeaveNotUsed:0)+constants.SPECIAL_HOUR_END+constants.AUTO_END_DATE+(cardData.endDate?cardData.endDate.toISOString().substr(0,10):(date.getUTCFullYear()+(date.getUTCMonth()<9?0:1))+'-10-01')+constants.AUTO_SEND_END
                                message+=constants.EXCEPTION_START+cardData.count+constants.EXCEPTION_DETAIL;
                                var exceptions=cardData.exceptions
                                for(var j in exceptions){
                                    message+=constants.EXCEPTION_MESSAGE+exceptions[j].date.toISOString().substr(0,10)+constants.EXCEPTION_CARD_DATE+exceptions[j].cardDate.toISOString().replace('T',' ').substr(0,16)+constants.EXCEPTION_DATA_DATE+exceptions[j].dataDate.toISOString().replace('T',' ').substr(0,16)+constants.EXCEPTION_CODE+exceptions[j].code+constants.EXCEPTION_MESSAGE_END
                                }
                                message+=constants.EXCEPTION_END;
                                var data1=cardData.applications
                                var count=2;
                                for(var type in constants.APPROVAL_TYPES){
                                    var approvalData=data1[constants.APPROVAL_TYPES[type]]
                                    message+=type+('   '.repeat((8-(type.length))))+(count--?' ':'')+(count>-2?'  ':'')+'【'+checkUndefined(approvalData[1],3)+'】【'+checkUndefined(approvalData[2],3)+'】\n';
                                }
                                empDetails[loginId]={regids:[],title:constants.AUTO_SEND_TITLE,message:message}
                                inserts.push([new Date(),empDetails[loginId].title,empDetails[loginId].message,loginId,'notification2',true])                
                            }
                            counts[regids[i].regId]=regids[i].count+1
                            empDetails[loginId].regids.push(regids[i].regId);
                        }
                        for(var i in empDetails){
                            sendNotification(empDetails[i],counts)
                        }
                        if(inserts.length>0)
                            CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
                    });
                }
            })
        },(5-index)*60*1000+45*1000)
    })
}

var sendselloutdata = function(){
    var date=new Date(new Date()-15*60*1000+8*60*60*1000).toISOString();
    var params=[{name:'DATE',value:date.substring(0,10)}]
    CP.query(queries.AUTO_COUNT,[],function(err,res){
        var notifiCount={}
        if(!err&&res&&res.length>0){
            for(var i in res)
                notifiCount[res[i].hotel]=res[i].count;
        }
        MS.query(queries.AUTO_SELLOUT,params,null,function(err,res){
            if(!err&&res&&res.recordset&&res.recordset.length>0){
                res=res.recordset
                var rowCounts={}
                var loginIds=[]
                var groupData={}
                var inserts=[]
                for(var i in res){
                    var hotel=res[i].R03
                    if(!groupData[hotel])
                        groupData[hotel]={res:[],notifiCount:0}
                    groupData[hotel].res.push(res[i])
                    groupData[hotel].notifiCount++;
                }
                var sendSellout=false;
                for(var i in groupData){
                    if(!notifiCount[i]||notifiCount[i]!=groupData[i].notifiCount)
                        sendSellout=true
                    else
                        delete groupData[i]
                }
                if(!sendSellout)
                    return
                for(var hotelName in groupData){
                    var res=groupData[hotelName].res
                    for(var i in res){
                        if(!groupData[hotelName].html){
                            var html=constants.YELLOW_LARGE_TABLE+constants.HOTELS+constants.ADD_BLUE_COLUMN+hotelName+constants.ADD_COLUMN+constants.SELLOUT_LAST+constants.ADD_BLUE_COLUMN+new Date(res[i].R00).toISOString().substring(0,10)
                            html+=constants.ADD_YELLOW_TABLE+constants.MEAL+constants.ADD_COLUMN+constants.SELLOUT_SALES+constants.ADD_COLUMN+constants.SELLOUT_AVG+constants.ADD_COLUMN+constants.SELLOUT_SUM+constants.ADD_COLUMN+constants.SELLOUT_DAYS+constants.ADD_COLUMN+constants.SELLOUT_TIME+constants.ADD_COLUMN+constants.SELLOUT_RELEASE
                            groupData[hotelName]={html:html,dateTime: new Date(),regids:[],title:constants.SELLOUT_TITLE,type:'notification2',count:0,notifiCount:groupData[hotelName].notifiCount,res:groupData[hotelName].res}
                        }
                        hotel=groupData[hotelName]
                        hotel.count++;
                        var data=res[i]
                        hotel.html+=(hotel.count%2==0?constants.ADD_BLUE_ROW:constants.ADD_ROW)+data.R04+constants.ADD_COLUMN+data.R06+constants.ADD_COLUMN+data.R07+constants.ADD_COLUMN+data.R10+constants.ADD_COLUMN+data.R11+constants.ADD_COLUMN+new Date(data.R12).toISOString().replace('T',' ').substring(0,19)+constants.ADD_COLUMN+(data.R13?new Date(data.R13).toISOString().replace('T',' ').substring(0,19):'-')
                    }
                    groupData[hotelName].message=groupData[hotelName].html+constants.TABLE_END+constants.DIV_END
                }
                CP.query(queries.GET_REG_ID_SELLOUT,[31,33],function(err,res){
                    if(!err&&res&&res.length>0){
                        var counts={}
                        for(var i in res){
                            var access=res[i].fullAccess.split(',')
                            var layer=res[i].layer.split('|')[1]
                            counts[res[i].regId]=res[i].count;
                            var loginId=res[i].loginId
                            var added=true
                            if(loginIds.indexOf(loginId)<0){
                                loginIds.push(loginId)
                                added=false
                            }
                            if(access[16]==1){
                                for(var j in groupData){
                                    var hotel=groupData[j]
                                    if(res[i].regId){
                                        counts[res[i].regId]++;
                                        hotel.regids.push(res[i].regId)
                                    }
                                    if(!added)
                                        inserts.push([hotel.dateTime,hotel.title,hotel.message,res[i].loginId,'notification2',true])
                                }
                            }else if(groupToRes[layer]&&groupData[groupToRes[layer]]){
                                var hotel=groupData[groupToRes[layer]]
                                if(res[i].regId){
                                    counts[res[i].regId]++;
                                    hotel.regids.push(res[i].regId)
                                }
                                if(!added)
                                    inserts.push([hotel.dateTime,hotel.title,hotel.message,res[i].loginId,'notification2',true])
                            }
                        }
                        if(inserts.length>0)
                            CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
                        var params=[]
                        for(var i in groupData){
                            params.push([i,groupData[i].notifiCount])
                            sendNotification(groupData[i],counts)
                        }
                        CP.query(queries.UPDATE_AUTO_COUNT,[params],function(err,res){console.log(err,res)})
                    }
                })
            }
        })
    })
}

var reviewNotification=function(dayFirst){
    var date=new Date()
    date=new Date(date-0+8*60*60*1000)
    var startDate=new Date(date)
    if(dayFirst){
       startDate.setHours(startDate.getHours() - 11);
    }
    else {
        startDate.setHours(startDate.getHours() - 1);
    }
    var params=[startDate,date]
    CP.query(queries.REVIEWSHOURLY,params,function(err,res){
        if(err||!res)
            return 
        var inserts=[]
        var groupData={}
        for(var i in res){
            var group = constants.RESTAURANT_TO_GROUP[constants.GROUP_TO_RESTAURANT[res[i].hotel]].groups;
            if(!groupData[res[i].hotel])
                 groupData[res[i].hotel]={dateTime:new Date(),regids:[],title:constants.REVIEW_TITLE,message:{review:[]}}
            groupData[res[i].hotel]['message']['review'].push(res[i]) 
        }  
        CP.query(queries.GET_REG_ID_SELLOUT,[47,49],function(err,result){
            if(!err&&result&&result.length>0){
                var counts={}
                var loginIds=[]
                for(var i in result){
                    var access=result[i].fullAccess.split(',')
                    var layer=result[i].layer.split('|')[1]
                    counts[result[i].regId]=result[i].count;
                    var hotel=constants.GROUP_TO_RES_NEW_REV[constants.NEW_GROUP_TO_RESTAURANT[layer]]
                    var loginId=result[i].loginId
                    var added=true;
                    if(loginIds.indexOf(loginId)<0){
                        loginIds.push(loginId)
                        added=false
                    }
                    if(access[25]=='1'){
                        for(var dept in groupData){
                            counts[result[i].regId]++  
                            groupData[dept].regids.push(result[i].regId)
                            if(!added){
                                var messages=groupData[dept].message.review
                                for(var review in messages)
                                    inserts.push([groupData[dept].dateTime,groupData[dept].title,JSON.stringify(messages[review]),result[i].loginId,'review',true])
                            }
                        }
                    }
                    else if(result[i].layer && groupData[hotel]){                      
                        if(access[24]=='1'){
                            counts[result[i].regId]++  
                            groupData[hotel].regids.push(result[i].regId)
                            if(!added){
                                var messages=groupData[hotel].message.review
                                for(var review in messages)
                                    inserts.push([groupData[hotel].dateTime,groupData[hotel].title,JSON.stringify(messages[review]),result[i].loginId,'review',true])
                            }
                        }
                    }
                }
                if(inserts.length>0)
                    CP.query(queries.INSERT_HBD,[inserts],function(err,res){})
                var ratings={'FIVE':5,'FOUR':4,'THREE':3,'TWO':2,'ONE':1}
                for(var group in groupData){
                    var notifiData=groupData[group]
                    var review=notifiData.message.review
                    for(var i in review){
                        var message=constants.REVIEW_MESSAGE1+review[i].name+'\n'+group+constants.REVIEW_MESSAGE2+ratings[review[i].rating]+constants.REVIEW_MESSAGE3;
                        var reviewData={dateTime:notifiData.dateTime,regids:notifiData.regids,title:constants.REVIEW_TITLE,message:message,image:review[i].profilepic}
                        sendNotification(reviewData,counts)    
                    }
                }
            }
        })
    })
}

var updateTarget=function(month){
    MS.query(queries.GET_TARGET_INIT,[],true,function(err,res){
        if(!err&&res&&res.recordset&&res.recordset.length>0){
            var params2=[]
            var deptCount={}
            res=res.recordset
            for(var i in res){
                deptCount[res[i].department]=res[i].count;
            }
            var groups=constants.RESTAURANT_TO_GROUP
            for(var i in groups){
                if(deptCount[groups[i].groups.service[0]]){
                    params2.push([groups[i].groups.service[0],deptCount[groups[i].groups.service[0]],month])
                }
                if(deptCount[groups[i].groups.kitchen[0]]){
                    params2.push([groups[i].groups.kitchen[0],deptCount[groups[i].groups.kitchen[0]],month])
                }
            }
            console.log(params2)
            CP.query(queries.TARGET_INSERT,[params2],function(err,res){
                console.log(err,res)
            })
        }
    })
}



var sendMessagesEachHour=function(){
    var hbdMin=new Date().getUTCMinutes()+(new Date().getUTCHours()*60)
    var day=new Date().getDay()
    var hbddate=new Date(new Date()-0+8*60*60*1000)
    var updateMin=hbddate.getUTCMinutes()+(hbddate.getUTCHours()*60)
    var date=hbddate.getUTCDate();
    var month=hbddate.toISOString().substr(0,7)
    if(date==1&&updateMin>0&&updateMin<=60){
        updateTarget(month)
    }
    if(date==3&&updateMin>0&&updateMin<=60){
        updateTarget(month)
    }
    if(hbdMin>900&&hbdMin<=960){
        setTimeout(function(){
            CP.query(queries.RESET_COUNT,[],function(err,res){})
        },(960-hbdMin)*60*1000+1)
    }
    if(hbdMin>60&&hbdMin<=900){
        setTimeout(function(){
            reviewsfetch(false)
        },(60-(hbdMin%60) - 1)*60*1000)
        setTimeout(function(){
            var dayFirst=false
            if(hbdMin>60&&hbdMin<=120)
                dayFirst=true
            reviewNotification(dayFirst);
        },(60-(hbdMin%60))*60*1000+1)
    }

    if(hbdMin>120&&hbdMin<=180){
        setTimeout(function(){
            sendselloutdata();
        },(180-hbdMin)*60*1000+1)
    }
    if(hbdMin>300&&hbdMin<=360){
        setTimeout(function(){
            sendselloutdata();
        },(360-hbdMin)*60*1000+1)
    }
    if(hbdMin>540&&hbdMin<=600){
        setTimeout(function(){
            sendselloutdata();
        },(600-hbdMin)*60*1000+1)
    }
    if(hbdMin>780&&hbdMin<=840){
        setTimeout(function(){
            sendselloutdata();
        },(840-hbdMin)*60*1000+1)
    }
    if(hbdMin>900&&hbdMin<=960){
        setTimeout(function(){
            CP.query(queries.DELETE_SELLOUT,[],function(err,res){})
        },(960-hbdMin+5)*60*1000+1)
    }
    if(hbdMin>60&&hbdMin<=120){
        CP.query(queries.DELETE_OLD_REG,[new Date(new Date()-10*24*60*60*1000)],function(err,res){console.log('Delete expired regid',err,res)})
    }
    if(hbdMin>55&&hbdMin<=115){
        setTimeout(function(){
            sendExceptions(1);
        },(115-hbdMin)*60*1000+1)
    }
    if(hbdMin%120>0&&hbdMin%120<=60){
        setTimeout(function(){
            sendMenu();
        },(60-hbdMin)*60*1000+1)
    }
    if(hbdMin>660&&hbdMin<=720&&day!=0&&day!=6){
        setTimeout(function(){
            performanceReport();
        },(720-hbdMin)*60*1000+1)
    }
    // if(hbdMin>210&&hbdMin<=270){
    //     setTimeout(function(){
    //         revenueSummary(4)
    //     },(270-hbdMin)*60*1000+1)
    // }
    if(hbdMin>390&&hbdMin<=450){
        setTimeout(function(){
            revenueSummary(5)
        },(450-hbdMin)*60*1000+1)
    }
    if(hbdMin>630&&hbdMin<=690){
        setTimeout(function(){
            revenueSummary(6)
        },(690-hbdMin)*60*1000+1)
    }
    if(hbdMin>790&&hbdMin<=850){
        setTimeout(function(){
            revenueSummary(7)
        },(850-hbdMin)*60*1000+1)
    }
    if(hbdMin>120&&hbdMin<=180){
        onBoard()
        var hbdMonth=new Date().getUTCMonth()+1;
        var hbdDate=new Date().getUTCDate();
        if(hbdMonth<=9)
            hbdMonth='0'+hbdMonth;
        if(hbdDate<=9)
            hbdDate='0'+hbdDate;
        hbdDate=hbdMonth+''+hbdDate;
        setTimeout(function(){
            var params=[{name: 'DATE',  value: hbdDate}]
            MS.query(queries.MS_GET_HBD,params,true,function(err,res){
                if(!err&&res&&res.recordset&&res.recordset.length>0){
                    var loginIds=[]
                    res=res.recordset;
                    var names={}
                    for(var i in res){
                        loginIds.push(res[i].loginId);
                        names[res[i].loginId]=res[i].name
                    }
                    CP.query(queries.GET_HBD,[[loginIds]],function(err,res){
                        if(!err&&res&&res.length>0){
                            var inserts=[];
                            getRegIdsList(res,function(hbdList,counts){
                                if(hbdList){
                                    var groups={};
                                    var insertIds=[]
                                    for(var i in hbdList){
                                        var name=names[hbdList[i].loginId];
                                        var data={regids:[hbdList[i].regid],hbd:true,type:'HBD',title:constants.HBD_TITLE_START+name+constants.HBD_TITLE_END,message:name+constants.HBD_MESSAGE+'|'+hbdList[i].loginId}
                                        if(insertIds.indexOf(hbdList[i].loginId)<0){
                                            insertIds.push(hbdList[i].loginId)
                                            inserts.push([new Date(), data.title, data.message, hbdList[i].loginId, 'HBD', true])
                                        }
                                        sendNotification(data, counts)
                                        var recepients=hbdList[i].recepients;
                                        for(var j in recepients){
                                            if(hbdList[i].regids[recepients[j]]&&hbdList[i].regids[recepients[j]].length>0){
                                                if (!groups[recepients[j]])
                                                    groups[recepients[j]] = { name: [], hbdId: [], regids: hbdList[i].regids[recepients[j]] };
                                                if (groups[recepients[j]].name.indexOf(name) < 0) {
                                                    groups[recepients[j]].name.push(name);
                                                    groups[recepients[j]].hbdId.push(hbdList[i].loginId);
                                                }
                                            }
                                        }
                                    }
                                    for(var group in groups){
                                        var data={regids:groups[group].regids, hbd: true, title: constants.HBD_GROUP_TITLE, type: 'HBD', message: constants.HBD_GROUP_START + groups[group].name.join()+constants.HBD_GROUP_END+'|'+groups[group].hbdId.join(',')}
                                        inserts.push([new Date(), data.title, data.message, group, 'HBD', true])
                                        sendNotification(data, counts)
                                    }
                                    CP.query(queries.INSERT_HBD, [inserts], function (err, res) { })
                                }
                            })
                        }
                    })
                }
            })
        },(180-hbdMin)*60*1000+1)
    }
    CP.query(queries.SELECT_OLD_ATTACH_TO_DELETE,[new Date(new Date()-2*24*60*60*1000),'bulletin'],function(err,res){
        if(!err&&res&&res.length>0)
            delAttach.clear(res,'notification/');
        CP.query(queries.DELETE_OLD,[new Date(new Date()-2*24*60*60*1000),'bulletin','bulletin'],function(err,res){})

    })
    var startDate=new Date()-1;
    var dayOfWeek=(new Date()).getUTCDay();
    var dayOfMonth=(new Date()).getUTCDate();
    CP.query(queries.SET_SENT_TRUE,[true,new Date(startDate)],function(err,res){});    
    endDate=new Date(startDate+60*60*1000)
    CP.query(queries.SELECT_ONE_HOUR_NOTI,[new Date(startDate),endDate,constants.DAILY,constants.WEEKLY+dayOfWeek,constants.MONTHLY+dayOfMonth,(new Date(startDate)).toLocaleTimeString(),endDate.toLocaleTimeString()],function(err,res){
        if(!err && res && res.length){
            getRegIds(res,function(messageList,counts){
                if(messageList){
                    messages=messageList
                    messageCounts=counts;
                    sendMessage(messages)
                }else 
                    messageCounts={}
            })
        }

    })
}
setInterval(function(){
    sendMessagesEachHour();
},60*60*1000)
setTimeout(function(){
    CP.query(queries.SEND_OLD_NOTI_AFTER_RESTART,[new Date(),false],function(err,res){
        if(!err && res && res.length){
            getRegIds(res,function(messageList,counts){
                for(var i in messageList){
                    sendNotification(messageList[i],counts)
                }
            })
        }
        sendMessagesEachHour();    
    })
},3000)

var addMessage=function(data,dateTime,counts){
    if(counts)
        for(var i in counts)
            messageCounts[i]=counts[i]
    if(messages.length>0&&(data.dateTime<=messages[0].dateTime||dateTime&&dateTime<=messages[0].dateTime)){
        messages.unshift(data)
        sendMessage(messages);
    }
    else{
        var i=0;
        for(;i<messages.length;i++){
            if(messages[i].dateTime-data.dateTime>0)
                break;
        }

        messages.splice(i,0,data)
        if(messages.length==1){
            sendMessage(messages);
        }
    }
}
var sendResponse=function(response,code,result){
    response.writeHead(code, { 'Content-Type': 'application/json' });
    response.write(JSON.stringify(result))
    response.end();
}
http.createServer(function(req,res){
    var body=''
    req.on("data", function(chunk) {
        body += chunk;
    });

    req.on("end", function() {
        try{
            var data=JSON.parse(body)
            data.dateTime=new Date(data.dateTime)
        CP.query(queries.INSERT_SCHEDULE,[data.dateTime,data.message,data.recepients,data.title,new Date(data.startTime),new Date(data.endTime),data.type,data.senderTitle,data.name,data.company,data.dateList,data.repetition,data.extension,null,false,data.jobs,data.allIds,null],function(err,result){
                if(!err&&result){
                    sendResponse(res,200,{success:true,id:result.insertId})
                    data.mes_no=result.insertId
                    var send,dateTime;
                    if(data.repetition&&((constants.MONTHLY+(new Date()).getUTCDate()==data.repetition)||(constants.WEEKLY+(new Date()).getUTCDay()==data.repetition)||(data.repetition==constants.DAILY))){
                        dateTime=new Date((new Date()).toDateString()+' '+(new Date(data.dateTime)).toTimeString());
                        if(dateTime<endDate&&((new Date()-dateTime<60000&&new Date()-dateTime>=0)||new Date()<dateTime))
                            send=true;
                    }
                    if((data.dateTime<endDate&&(!data.repetition||data.repetition==constants.CUSTOM))||send){
                        getRegIds([data],function(result,counts){
                            if(result)
                                addMessage(result[0],dateTime,counts);
                        })
                    }   
                }
            })
        }catch(err){
            console.log(err)
            sendResponse(res,401,{success:false})      
        }
    })
}).listen(config.NotifPort)

process.on('uncaughtException', function(err) {
    console.log('uncaughtException Error', err);

});

module.exports=getRegIds;
