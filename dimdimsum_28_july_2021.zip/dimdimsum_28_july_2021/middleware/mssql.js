var sql = require("mssql");
var config = require("../initConf").get().Connections.MsSql;
var configHr= require("../initConf").get().Connections.HrMsSql;
var sqlConnection = {};
var pool1= new sql.ConnectionPool(configHr)
var pool2= new sql.ConnectionPool(config)
pool1.connect(err => {
    console.log(err,'---Err in Hr Database --')
})
pool2.connect(err => {
    console.log(err,'----Err in Revenue Database--')
})
sqlConnection.query = function(query,params,hr, callback, recCount) {
    recCount=recCount?recCount+1:0;
    if(recCount>5)
        return callback('DATABASE Error',null);
    var pool=hr?pool1:pool2;
    var request=new sql.Request(pool);
    params.forEach(function(p) {
        request.input(p.name, sql.NVarChar, p.value);
    });
    request.query(query, (err, result) => {
        if(err)
            console.log(err,'-----mssql error')
        sql.close();
        return callback(err,result);
    })    
};

module.exports = sqlConnection;
