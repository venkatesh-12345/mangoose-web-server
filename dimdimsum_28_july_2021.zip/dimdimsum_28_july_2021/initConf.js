"use strict";
var nconf = require("nconf"),
    path = require("path"),
    ROOT = path.resolve(__dirname, "./");

var folder =  process.env.ENV || "local";

nconf.file({
    file: "./configs/"+folder+"/settings.json"
});
module.exports = nconf
