- [ ] 1. Remove weidoeServer and images

- [ ] 2. Remove unwanted code in saveUpload.js

- [ ] 3. In notification.js, the message should have only the things that are required by app

- [ ] 4. Remove unwanted code from mapper.js

- [ ] 5. Controller.js

    Remove group after checking with Vikas
    split dayRev and monRev  function
- [ ] 6. Update scripts to latest tables

- [ ] 7. Come up with genericModel


    
    
    
